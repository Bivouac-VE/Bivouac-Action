// @polsia:user-owned — Daily digest cron (0 8 * * * UTC).
//
// For each user with >=1 connected `Repo` and `digestOptIn=true`, summarise
// the previous 24 hours and send:
//   - the email summary (subject + html + text) via the Polsia email proxy
//   - the same JSON summary payload to any enabled DigestWebhook row, with
//     HMAC signing + retry attempts
//
// The tallies per-user, per-repo:
//   - patches auto-merged         (CveTriageLog, mergeDecision='AUTO_MERGE')
//   - CVE responses opened        (any CveTriageLog row arrived in window)
//   - human pages / overrides     (HumanOverride decidedAt in window)
//
// Idempotency: we set `lastDigestSentAt = NOW` ONLY after `sendEmail` succeeds.
// Webhook dispatch runs AFTER the email succeeds (same watermark rules apply —
// a re-run of the same UTC day will re-fire both the email AND the webhooks
// for users whose watermark hasn't advanced).

const { prisma } = require('../src/lib/server/digest-prisma.cjs');
const webhook = require('../src/lib/server/digest-webhook.cjs');

const WINDOW_MS = 24 * 60 * 60 * 1000;

// Promise import protocol so node can load ESM `@/lib/...` aliases… no — we
// can't reach TS modules from a `.js` cron. The cron does its tally logic
// inline (the same shape as `src/lib/business/digest.ts`); the business
// module exists for any future `GET /api/digest/preview` surface.

function todayUtcString(now = new Date()) {
  return now.toISOString().slice(0, 10);
}

function repoSlugFromUrl(prUrl) {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0]}/${parts[1]}`;
    }
    return '';
  } catch {
    return '';
  }
}

// Eligible = has at least one connected repo, opted-in for the daily digest,
// and the cron hasn't already shipped a digest for "today" (the watermark
// could also be cross-day, but the brief is "previous-24h at 08:00 UTC" so
// "today" == "this run").
async function eligibleUsers(now) {
  const users = await prisma.user.findMany({
    select: { id: true, name: true, email: true },
  });

  const connectedRepos = await prisma.repo.findMany({
    select: { userId: true, id: true, ownerHandle: true, name: true },
  });
  const repoIdsByUser = new Map();
  const slugByRepoId = new Map();
  const slugByUser = new Map();
  for (const repo of connectedRepos) {
    if (!repoIdsByUser.has(repo.userId)) repoIdsByUser.set(repo.userId, []);
    repoIdsByUser.get(repo.userId).push(repo.id);
    slugByRepoId.set(repo.id, `${repo.ownerHandle}/${repo.name}`);
    if (!slugByUser.has(repo.userId)) slugByUser.set(repo.userId, new Set());
    slugByUser.get(repo.userId).add(`${repo.ownerHandle}/${repo.name}`);
  }

  const profiles = await prisma.userProfile.findMany({
    select: { userId: true, digestOptIn: true, lastDigestSentAt: true },
  });
  const profileByUser = new Map(profiles.map((p) => [p.userId, p]));

  const eligible = [];
  for (const user of users) {
    const repos = repoIdsByUser.get(user.id);
    if (!repos || repos.length === 0) continue;
    const profile = profileByUser.get(user.id);
    // No profile yet — first-run signup hasn't touched the dashboard. We
    // treat a missing profile as "opted-in by default" (matches the Prisma
    // schema default) so the digest isn't silently skipped on day one.
    const optedIn = profile ? profile.digestOptIn === true : true;
    if (!optedIn) continue;
    const lastSent = profile?.lastDigestSentAt ?? null;
    // Skip if a digest already shipped "today" UTC — a re-run within the
    // same UTC day would otherwise duplicate. Otherwise the watermark only
    // thwarts persistent backfill across days (we still WANT to send on
    // subsequent days, so anything older than `now` is fine).
    if (lastSent && lastSent.toISOString().slice(0, 10) === todayUtcString()) continue;
    if (!user.email) continue;
    eligible.push({ user, slugByUser: slugByUser.get(user.id) });
  }
  return eligible;
}

async function buildUserTallies(userId, windowStart) {
  const [repos, triageRows, overrideRows] = await Promise.all([
    prisma.repo.findMany({
      where: { userId },
      select: { ownerHandle: true, name: true },
    }),
    prisma.cveTriageLog.findMany({
      where: { userId, createdAt: { gte: windowStart } },
      select: { prUrl: true, mergeDecision: true },
    }),
    prisma.humanOverride.findMany({
      where: { userId, decidedAt: { gte: windowStart } },
      select: { repoId: true },
    }),
  ]);

  const connectedSlugs = new Set(repos.map((r) => `${r.ownerHandle}/${r.name}`));

  // slug → { autoMerged, cveOpened, humanOverrides }
  const tallies = new Map();
  for (const slug of connectedSlugs) {
    tallies.set(slug, { repo: slug, autoMerged: 0, cveOpened: 0, humanOverrides: 0 });
  }

  for (const row of triageRows) {
    const slug = repoSlugFromUrl(row.prUrl);
    if (!slug || !connectedSlugs.has(slug)) continue;
    const current = tallies.get(slug);
    if (!current) continue;
    current.cveOpened += 1;
    if (row.mergeDecision === 'AUTO_MERGE') {
      current.autoMerged += 1;
    }
  }

  if (overrideRows.length > 0) {
    const candidateRepoIds = Array.from(new Set(overrideRows.map((r) => r.repoId)));
    if (candidateRepoIds.length > 0) {
      const joined = await prisma.repo.findMany({
        where: { id: { in: candidateRepoIds }, userId },
        select: { id: true, ownerHandle: true, name: true },
      });
      const slugByRepoId = new Map(joined.map((r) => [r.id, `${r.ownerHandle}/${r.name}`]));
      for (const row of overrideRows) {
        const slug = slugByRepoId.get(row.repoId);
        if (!slug) continue;
        const current = tallies.get(slug);
        if (!current) continue;
        current.humanOverrides += 1;
      }
    }
  }

  return Array.from(tallies.values())
    .filter((t) => t.autoMerged > 0 || t.cveOpened > 0 || t.humanOverrides > 0)
    .sort((a, b) => (a.repo < b.repo ? -1 : a.repo > b.repo ? 1 : 0));
}

// Single per-user payload used by BOTH the email render and the webhook
// dispatch — the brief's "same patch/CVE summary payload" rule. JSON-safe,
// schema-versioned, and bounded (per-repo items capped at 200 so a busy day
// doesn't bloat the wire format). Receivers can ignore unknown fields.
function buildPayload({ user, tallies, day, attestDeepLink, issuedAt }) {
  let totalAutoMerged = 0;
  let totalCveOpened = 0;
  let totalHumanOverrides = 0;
  for (const t of tallies) {
    totalAutoMerged += t.autoMerged;
    totalCveOpened += t.cveOpened;
    totalHumanOverrides += t.humanOverrides;
  }

  const perRepo = tallies.map((t) => ({
    repo: t.repo,
    autoMerged: t.autoMerged,
    cveOpened: t.cveOpened,
    humanOverrides: t.humanOverrides,
  }));

  const subjectsOnly = []; // reserved hook for future per-day titles

  return {
    schema: 'bivouac.daily-digest.v1',
    day,
    issuedAt: issuedAt ?? new Date().toISOString(),
    user: { id: user.id, name: user.name, email: user.email },
    totals: {
      autoMerged: totalAutoMerged,
      cveOpened: totalCveOpened,
      humanOverrides: totalHumanOverrides,
      repos: tallies.length,
    },
    perRepo,
    attestDeepLink,
    subjects: subjectsOnly,
  };
}

// Send the digest email for one user. We don't have access to the TS
// `renderEmail`/`digestEmail`/`sendEmail` helpers from a `.js` cron WITHOUT
// compiling them, so the cron renders a minimal but equivalent email
// directly here. The styling mirrors the email module's inline pattern.
//
// The handle-inline approach: the brief's "renderEmail + sendEmail" rule is
// key for any user-facing transactional email. But crons are server-by-
// server internal; emitting through the mechanism keeps style consistent.
// We perform an HTTP POST to the Polsia email proxy here (same URL the
// framework's sendEmail uses), so the daily cron still goes through the
// framework email transport — the wording of the same proxy call as
// sendEmail's contract (POST `${POLSIA_EMAIL_PROXY_URL}/send`).
async function sendDigest({ user, tallies, day, attestDeepLink, proxyUrl, apiKey }) {
  const headerName = user.name && user.name.trim().length > 0 ? user.name : 'there';

  let totalAutoMerged = 0;
  let totalCveOpened = 0;
  let totalHumanOverrides = 0;
  for (const t of tallies) {
    totalAutoMerged += t.autoMerged;
    totalCveOpened += t.cveOpened;
    totalHumanOverrides += t.humanOverrides;
  }

  const textLines = [
    `Daily digest — ${day}`,
    '',
    `Hi ${headerName}, here is what happened in the last 24 hours for your connected repositories.`,
    tallies.length > 0
      ? `Across ${tallies.length} repo(s): ${totalAutoMerged} auto-merged, ${totalCveOpened} CVE response(s) opened, ${totalHumanOverrides} human override(s).`
      : 'No patch activity in the last 24 hours for your connected repositories.',
    '',
    'Per-repo activity:',
  ];
  for (const t of tallies) {
    textLines.push(
      `- ${t.repo}: ${t.autoMerged} auto-merged · ${t.cveOpened} CVE opened · ${t.humanOverrides} human override`,
    );
  }
  textLines.push('', `Open today's attestation: ${attestDeepLink}`, '');

  const subject = `Daily digest — ${day}`;
  const headerLine = `${totalAutoMerged} auto-merged / ${totalCveOpened} CVE opened / ${totalHumanOverrides} human override across ${tallies.length} repo(s).`;

  const html = [
    '<div style="max-width:560px;margin:0 auto;padding:24px;font-family:Arial,Helvetica,sans-serif;">',
    `<h1 style="margin:0 0 16px;color:#111111;font-size:22px;">Daily digest — ${escapeHtml(day)}</h1>`,
    `<p style="margin:0 0 16px;color:#333333;font-size:15px;line-height:1.6;">Hi ${escapeHtml(headerName)}, here is what happened in the last 24 hours for your connected repositories.</p>`,
    `<p style="margin:0 0 16px;color:#333333;font-size:15px;line-height:1.6;">${escapeHtml(headerLine)}</p>`,
  ];
  html.push(renderTallyTable(tallies));
  html.push(
    `<p style="margin:24px 0 0;"><a href="${escapeHtml(attestDeepLink)}" style="display:inline-block;padding:10px 20px;background:#111111;color:#ffffff;text-decoration:none;font-size:15px;">Open today's attestation</a></p>`,
    `<div style="margin-top:24px;padding-top:16px;border-top:1px solid #e5e5e5;color:#999999;font-size:12px;">You received this because you opted in to the daily digest — turn it off in dashboard settings.</div>`,
    '</div>',
  );

  const htmlDoc = html.join('');
  const body = textLines.join('\n');

  const res = await fetch(`${proxyUrl.replace(/\/+$/, '').replace(/\/send$/, '')}/send`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey ?? ''}`,
    },
    body: JSON.stringify({
      to: user.email,
      subject,
      body,
      html: htmlDoc,
    }),
  });
  return res;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderTallyTable(tallies) {
  const rows = tallies
    .map(
      (t) =>
        `<tr>
          <td style="padding:6px 12px 6px 0;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;">${escapeHtml(t.repo)}</td>
          <td style="padding:6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(t.autoMerged)}</td>
          <td style="padding:6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(t.cveOpened)}</td>
          <td style="padding:6px 0 6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(t.humanOverrides)}</td>
        </tr>`,
    )
    .join('');
  return [
    '<h2 style="margin:24px 0 8px;color:#111111;font-size:16px;">Per-repo activity (last 24 hours)</h2>',
    '<table cellpadding="0" cellspacing="0" role="presentation" style="width:100%;border-collapse:collapse;margin-bottom:8px;">',
    '<thead>',
    '<tr>',
    '<th align="left" style="padding:6px 12px 6px 0;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Repo</th>',
    '<th align="right" style="padding:6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Auto-merged</th>',
    '<th align="right" style="padding:6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">CVE opened</th>',
    '<th align="right" style="padding:6px 0 6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Human override</th>',
    '</tr>',
    '</thead>',
    `<tbody>${rows}</tbody>`,
    '</table>',
  ].join('');
}

// Retry budget: 3 attempts in total — 0ms / 2000ms / 8000ms — sequential.
// Each attempt times out at 8s via AbortController so a hung endpoint can't
// stretch the loop past ~30s/widget/webhook. Beyond 3 attempts we write the
// failure and move on (the next day gets a fresh slot in DigestDelivery).
const MAX_ATTEMPTS = 3;
const ATTEMPT_BACKOFF_MS = [0, 2000, 8000];
const ATTEMPT_TIMEOUT_MS = 8_000;

async function postOnce(url, headers, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ATTEMPT_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body,
      signal: controller.signal,
    });
    const detail = res.ok ? null : await res.text().catch(() => '');
    return {
      ok: res.ok,
      statusCode: res.status,
      error: res.ok ? null : detail ? detail.slice(0, 140) : `HTTP ${res.status}`,
    };
  } catch (err) {
    const message =
      err && err.name === 'AbortError'
        ? `Timeout after ${ATTEMPT_TIMEOUT_MS}ms`
        : err && err.message
          ? err.message
          : 'Network error';
    return { ok: false, statusCode: null, error: message.slice(0, 140) };
  } finally {
    clearTimeout(timer);
  }
}

// Dispatch the same JSON summary payload to every enabled DigestWebhook row
// for `user`. Per webhook, up to MAX_ATTEMPTS attempts; the cumulative result
// becomes a `DigestDelivery` row keyed by (webhookId, day). Failure rows stay
// visible in /dashboard/settings/webhooks so the admin can see the retry
// happened and decide to debug the endpoint.
async function dispatchUserWebhooks({ user, payload, day, selfHost }) {
  const webhooks = await webhook.prisma.digestWebhook.findMany({
    where: { userId: user.id, enabled: true },
  });

  if (webhooks.length === 0) return { delivered: 0, failed: 0 };

  let delivered = 0;
  let failed = 0;
  const body = JSON.stringify(payload);

  for (const hook of webhooks) {
    if (!hook.url) continue;

    // SSRF guard at dispatch time — DNS between SAVE and this morning could
    // swing, so we re-validate each fetch.
    const validation = await webhook.validateOutboundUrl(hook.url, { selfHost });
    if (!validation.ok) {
      await webhook.prisma.digestDelivery.upsert({
        where: { webhookId_runDay: { webhookId: hook.id, runDay: day } },
        create: {
          userId: user.id,
          webhookId: hook.id,
          runDay: day,
          status: 'failed',
          attempts: 1,
          lastStatusCode: null,
          lastError: webhook.previewError(`SSRF check: ${validation.reason}`),
          sentAt: null,
        },
        update: {
          status: 'failed',
          attempts: 1,
          lastStatusCode: null,
          lastError: webhook.previewError(`SSRF check: ${validation.reason}`),
          sentAt: null,
        },
      });
      failed += 1;
      continue;
    }

    const headers = {
      'content-type': 'application/json',
      'user-agent': 'bivouac-digest-webhook/1.0',
      'x-bivouac-digest-kind': 'daily',
      'x-bivouac-digest-day': day,
    };
    if (hook.signingSecret) {
      headers['x-bivouac-digest-signature'] = webhook.signPayload(hook.signingSecret, body);
    }

    let attemptResult = { ok: false, statusCode: null, error: 'not_attempted' };
    let attempts = 0;
    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      attempts = i + 1;
      if (ATTEMPT_BACKOFF_MS[i] > 0) {
        await new Promise((r) => setTimeout(r, ATTEMPT_BACKOFF_MS[i]));
      }
      attemptResult = await postOnce(hook.url, headers, body);
      if (attemptResult.ok) break;
    }

    await webhook.prisma.digestDelivery.upsert({
      where: { webhookId_runDay: { webhookId: hook.id, runDay: day } },
      create: {
        userId: user.id,
        webhookId: hook.id,
        runDay: day,
        status: attemptResult.ok ? 'delivered' : 'failed',
        attempts,
        lastStatusCode: attemptResult.statusCode,
        lastError: webhook.previewError(attemptResult.error),
        sentAt: attemptResult.ok ? new Date() : null,
      },
      update: {
        status: attemptResult.ok ? 'delivered' : 'failed',
        attempts,
        lastStatusCode: attemptResult.statusCode,
        lastError: webhook.previewError(attemptResult.error),
        sentAt: attemptResult.ok ? new Date() : null,
      },
    });

    if (attemptResult.ok) delivered += 1;
    else failed += 1;
  }
  return { delivered, failed };
}

async function main() {
  const now = new Date();
  const windowStart = new Date(now.getTime() - WINDOW_MS);

  const proxyUrl = process.env.POLSIA_EMAIL_PROXY_URL ?? '';
  const apiKey = process.env.POLSIA_API_KEY ?? '';
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? process.env.BETTER_AUTH_URL ?? '';
  const day = todayUtcString(now);
  const selfHost = (() => {
    if (!appUrl) return null;
    try {
      return new URL(appUrl).hostname.trim().toLowerCase();
    } catch {
      return null;
    }
  })();

  if (!proxyUrl) {
    process.stderr.write('[daily-digest] missing POLSIA_EMAIL_PROXY_URL — skipping\n');
    process.exit(0);
  }

  const eligible = await eligibleUsers(now);
  if (eligible.length === 0) {
    process.stdout.write('[daily-digest] no eligible users — nothing to do\n');
    return;
  }

  let sent = 0;
  let failed = 0;
  let webhookDelivered = 0;
  let webhookFailed = 0;
  for (const entry of eligible) {
    const { user } = entry;
    const tallies = await buildUserTallies(user.id, windowStart);

    // Quiet days: no activity. Skip the email AND any webhooks rather than
    // ship a no-op payload. The watermark is NOT advanced for quiet days —
    // tomorrow's cron will still pick this user up.
    if (tallies.length === 0) {
      continue;
    }

    const attestDeepLink = appUrl
      ? `${appUrl.replace(/\/+$/, '')}/dashboard/attest?date=${day}`
      : `/dashboard/attest?date=${day}`;

    let emailOk = false;
    try {
      const res = await sendDigest({
        user,
        tallies,
        day,
        attestDeepLink,
        proxyUrl,
        apiKey,
      });
      if (!res.ok) {
        const detail = await res.text().catch(() => '');
        process.stderr.write(
          `[daily-digest] send failed for ${user.email} → ${res.status} ${detail}`.trim() + '\n',
        );
        failed += 1;
        continue;
      }
      // Watermark advances only on successful send. A failed send keeps
      // the watermark untouched so the next run can retry both the email
      // AND the matching webhook deliveries.
      await prisma.userProfile.upsert({
        where: { userId: user.id },
        create: { userId: user.id, digestOptIn: true, lastDigestSentAt: now },
        update: { lastDigestSentAt: now },
      });
      sent += 1;
      emailOk = true;
    } catch (err) {
      process.stderr.write(`[daily-digest] send threw for ${user.email}: ${err?.stack ?? err}\n`);
      failed += 1;
      continue;
    }

    // Webhook dispatch only after the email succeeded — same idempotency
    // rule. A re-run of this UTC day will re-fire the email (if its
    // watermark hasn't advanced) AND/OR the webhook (DigestDelivery is
    // upserted by (webhookId, day)).
    if (emailOk) {
      const payload = buildPayload({
        user,
        tallies,
        day,
        attestDeepLink,
        issuedAt: now.toISOString(),
      });
      try {
        const result = await dispatchUserWebhooks({ user, payload, day, selfHost });
        webhookDelivered += result.delivered;
        webhookFailed += result.failed;
      } catch (err) {
        process.stderr.write(
          `[daily-digest] webhook dispatch threw for ${user.email}: ${err?.stack ?? err}\n`,
        );
      }
    }
  }

  process.stdout.write(
    `[daily-digest] sent=${sent} failed=${failed} eligible=${eligible.length} webhooks_delivered=${webhookDelivered} webhooks_failed=${webhookFailed}\n`,
  );
  // Reach for both Prisma singletons so they disconnect cleanly on the way
  // out (next-build runs the cron in-process during postinstall sometimes).
  await webhook.prisma.$disconnect().catch(() => undefined);
}

main()
  .then(async () => {
    await prisma.$disconnect();
    process.exit(0);
  })
  .catch(async (err) => {
    process.stderr.write(`[daily-digest] failed: ${err?.stack ?? err}\n`);
    await prisma.$disconnect().catch(() => undefined);
    process.exit(1);
  });
