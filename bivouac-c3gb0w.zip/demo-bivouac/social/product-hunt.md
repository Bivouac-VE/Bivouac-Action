# Product Hunt launch

**Tagline:** Tested dependency fixes, prepared for human review.

**Description:**

Bivouac is a 24/7 on-call agent for dependency triage. Connect a GitHub repo, pick a policy pack, Bivouac:

1. Finds an issue — typically a Dependabot PR that's been sitting open.
2. Prepares the fix — analyzed against your test suite and the policy pack.
3. Runs tests — gates the PR on `node --test` / your CI and `npm audit`.
4. Decides — tested fixes go to a human to approve and merge, breaking majors the team should plan for get flagged, destructive ones get rejected.

On the public sample service, Bivouac cleared 3/5 PRs (3 high-severity advisories closed) and explained the 2 breaking-major decisions in plain English. After the fixes, `node --test` runs 12/12 and `npm audit` is clean.

→ https://getbivouac.com/demo

**Topics:** developer tools · devops · security · open-source · SaaS
