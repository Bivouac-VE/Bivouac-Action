# Cold outreach — three-sentence proof

**Subject:** Your Dependabot queue → 3 CVEs closed, 1 flagged, 1 rejected, 12/12 green

Hi {{first_name}},

I pointed Bivouac at a tiny, deliberately outdated Node sample app — 5 Dependabot PRs, 3 of them high-severity advisories — and asked it to make a real decision on every one. It prepared 3 tested security fixes for a human to approve, flagged 1 breaking-major for your team to plan a migration around, and rejected 1 breaking-major that would have broken the app. After the fixes, `node --test` runs 12/12 and `npm audit` is clean. The full before/after is live at https://getbivouac.com/demo — three minutes to read, no sales call. Worth 10 minutes?

— {{sender}}
