# Cold outreach — three-sentence proof

**Subject:** Your Dependabot queue → 4 merged, 1 flagged, 1 rejected, 12/12 green

Hi {{first_name}},

I wired Bivouac against a tiny, deliberately outdated Node sample app — 6 Dependabot PRs, 3 of them open CVEs — and asked it to make a real decision on every one. It auto-merged 4 (3 security, 1 patch), flagged 1 breaking-major for your team to plan a migration around, and rejected 1 breaking-major that would have torn out test assertions. `node --test` ran 12/12 post-remediation. The full before/after is live at https://bivouac.dev/demo — three minutes to read, no sales call. Worth 10 minutes?

— {{sender}}
