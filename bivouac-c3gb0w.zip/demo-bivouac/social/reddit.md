# Reddit — r/programming, r/node, r/devops

**Title:** Show: Bivouac on a tiny Node fixture — 5 Dependabot PRs, 3 tested fixes, 2 breaking majors handled — here's the before/after

**Body:**

We pinned a tiny, on-purpose outdated sample app to vulnerable versions of lodash, minimatch and node-fetch (plus glob 7 and chalk 4), let Dependabot open 5 PRs, and had Bivouac analyze and decide on each one.

What came out the other side: 3 tested security fixes ready for a human to approve and merge (lodash 4.18.1, minimatch 3.1.5, node-fetch 2.7.0), 1 breaking major flagged for a deliberate human migration (glob 9 drops the callback API), 1 rejected outright (chalk 5 is ESM-only and breaks the CommonJS entry point). Before: `npm audit` fails with 3 high-severity advisories. After: `node --test` runs 12/12 and `npm audit` is clean.

You can reproduce it yourself — `npm run audit:gate` fails on the baseline, `npm run remediate && npm run verify` passes. The leading numbers come from one ledger file, not hand-tuned marketing copy.

→ Live board (before/after in one scroll): https://getbivouac.com/demo
→ Source for the demo: https://github.com/Bivouac-VE/Bivouac-Action
