# Reddit — r/programming, r/node, r/devops

**Title:** Show: Bivouac auto-remediated 4/6 Dependabot PRs on a tiny Node fixture — here's the before/after

**Body:**

A typical Node service sits behind 6 Dependabot PRs, 3 of which are open CVEs. We wired Bivouac against a tiny, on-purpose outdated sample-app (lodash, minimatch, node-fetch, glob, chalk at their vulnerable pins) and made it analyze, decide, and merge-or-flag-or-reject each one.

What came out the other side: 4 auto-merged (3 security + 1 patch), 1 flagged for a deliberate human migration, 1 rejected outright. `node --test` runs 12/12 green post-remediation.

The whole demo runs against a public fixture repo, and the leading numbers are pulled from one ledger file — no hand-tuning the marketing copy.

→ Live board (before/after in one scroll): https://bivouac.dev/demo
→ Fixture repo with the thing actually being remediated: https://github.com/bivouac/demo-sample-app
