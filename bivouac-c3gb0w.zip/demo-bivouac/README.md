# Bivouac remediation demo

A self-contained snapshot of "before Bivouac" vs "after Bivouac" against a trivial Node sample app. The numbers on [getbivouac.com/demo](https://getbivouac.com/demo) come from this directory — `ledger.json` is the single source of truth.

## TL;DR

- 5 Dependabot PRs are open against a typical Node service.
- 3 high-severity security advisories (lodash, minimatch, node-fetch) would sit unreviewed for weeks.
- 2 breaking-major bumps (glob 9, chalk 5) are stacked behind the security work, demanding a human every time.
- Bivouac analyzes all 5 → prepares 3 tested security fixes for a human to approve and merge → flags 1 breaking-major for a deliberate, human-driven migration → rejects 1 breaking-major outright.
- Before: `npm audit` fails with 3 high-severity advisories. After: `node --test` passes **12/12** and `npm audit` is clean.

## Live demo

The live `/demo` board renders the same numbers and the same per-PR row as this sidecar — open [getbivouac.com/demo](https://getbivouac.com/demo) to see the before/after split-pane in one scroll.

## Before → After

| Metric | Before Bivouac | After Bivouac |
|---|---|---|
| Open Dependabot PRs | 5 | 0 stale; 1 flagged-for-review open |
| High-severity advisories (`npm audit`) | 3 | 0 |
| Breaking majors merged accidentally | 0 (still painful to triage) | 0 (rejected or flagged, never merged) |
| Tested fixes approved for merge by a human | — | 3 |
| Flagged for human review | — | 1 |
| Rejected outright | — | 1 |
| Verification | Audit gate fails (3 high) | 12/12 tests pass, audit clean |

The three fixes: lodash 4.17.20 → 4.18.1, minimatch 3.0.4 → 3.1.5, node-fetch 2.6.6 → 2.7.0. A human approves and merges every PR; Bivouac never merges on its own.

See `ledger.json` for the canonical, machine-readable version of every number above.

## What's in here

```
demo-bivouac/
├── README.md                          (this file)
├── ledger.json                        (canonical before/after state — /demo reads from this)
├── sample-app/
│   ├── package.json                   (the fixture manifest with vulnerable pins + verify scripts)
│   ├── package-lock.json              (real dep tree, matches package.json)
│   ├── index.js                       (entrypoint exercising the vulnerable APIs)
│   ├── tests/
│   │   ├── before.test.mjs            (pre-remediation test shape)
│   │   └── after.test.mjs             (post-remediation test shape)
│   └── .github/
│       ├── dependabot.yml             (Dependabot config that generates the PRs)
│       └── workflows/
│           ├── ci.yml                 (before: audit must fail → apply fixes → after: tests + audit pass)
│           └── bivouac.yml            (cosmetic mirror of the analyzer decision)
└── social/
    ├── reddit.md
    ├── linkedin.md
    ├── product-hunt.md
    └── cold-outreach.md
```

## How the demo proves itself

```bash
cd demo-bivouac/sample-app
npm ci
npm test               # 12/12 pass — the tests don't catch the vulnerabilities on their own
npm run audit:gate     # FAILS: 3 high-severity advisories on the baseline pins
npm run remediate      # applies lodash 4.18.1, minimatch 3.1.5, node-fetch 2.7.0
npm run verify         # 12/12 tests pass AND npm audit reports 0 vulnerabilities
```

The GitHub Actions workflow `ci.yml` runs exactly this sequence on push: it fails if the baseline audit is unexpectedly clean, and fails if the fixed state has any failing test or high-severity advisory. The sample app stays pinned to the vulnerable versions so the "before" state is always reproducible.

## Share snippets

- **[Reddit →](social/reddit.md)**
- **[LinkedIn →](social/linkedin.md)**
- **[Product Hunt →](social/product-hunt.md)**
- **[Cold outreach →](social/cold-outreach.md)**

All four use the same leading counts (5 open PRs → 3 tested fixes approved, 3 high-severity advisories → 0, 12/12 tests) as `ledger.json` — the numbers never drift between this README, the `/demo` page, and the share copy.
