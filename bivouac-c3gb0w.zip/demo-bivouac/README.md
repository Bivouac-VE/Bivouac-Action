# Bivouac remediation demo

A self-contained snapshot of "before Bivouac" vs "after Bivouac" against a trivial Node sample app. The numbers on [bivouac.dev/demo](https://bivouac.dev/demo) come from this directory — `ledger.json` is the single source of truth.

## TL;DR

- 6 Dependabot PRs are open against a typical Node service.
- 3 security advisories (lodash, minimatch, node-fetch) would sit unreviewed for weeks.
- 2 breaking-major bumps are stacked behind the security work, demanding a human every time.
- Bivouac analyzes all 6 → auto-merges 4 safe patches → flags 1 breaking-major for a deliberate, human-driven migration → rejects 1 breaking-major outright.
- `node --test` runs clean: **12/12 pass** post-remediation.

## Live demo

The live `/demo` board renders the same numbers and the same per-PR row as this sidecar — open [bivouac.dev/demo](https://bivouac.dev/demo) to see the before/after split-pane in one scroll.

## Before → After

| Metric | Before Bivouac | After Bivouac |
|---|---|---|
| Open Dependabot PRs | 6 | 0 stale; 1 flagged-for-review open |
| Security advisories remaining | 3 | 0 |
| Breaking majors merged accidentally | 0 (still painful to triage) | 0 (rejected or flagged, never auto-merged) |
| Auto-merged by analyzer | — | 4 |
| Flagged for human review | — | 1 |
| Rejected outright | — | 1 |
| Tests passing | 4/12 (before.test.mjs only) | 12/12 (after.test.mjs) |

See `ledger.json` for the canonical, machine-readable version of every number above.

## What's in here

```
demo-bivouac/
├── README.md                          (this file)
├── ledger.json                        (canonical before/after state — /demo reads from this)
├── sample-app/
│   ├── package.json                   (the fixture manifest with vulnerable pins)
│   ├── package-lock.json              (real dep tree, matches package.json)
│   ├── index.js                       (entrypoint exercising the vulnerable APIs)
│   ├── tests/
│   │   ├── before.test.mjs            (pre-remediation test shape)
│   │   └── after.test.mjs             (post-remediation test shape)
│   └── .github/
│       ├── dependabot.yml             (Dependabot config that generates the 6 PRs)
│       └── workflows/
│           ├── ci.yml                 (npm ci + node --test)
│           └── bivouac.yml            (cosmetic mirror of the analyzer decision)
└── social/
    ├── reddit.md
    ├── linkedin.md
    ├── product-hunt.md
    └── cold-outreach.md
```

## How the demo proves itself

```bash
cd demo-bivouac/sample-app
npm ci
npm test          # runs node --test, expects 12/12 pass against the post-remediation shape
```

The `before.test.mjs` file documents the dangerous pre-patch shape; the `after.test.mjs` file documents what the analyzer-accepted state still satisfies. The GitHub Actions workflow `ci.yml` runs the same `npm ci` + `npm test` on push — it's the verifiable "tests passing" check the `/demo` board counts.

## Share snippets

- **[Reddit →](social/reddit.md)**
- **[LinkedIn →](social/linkedin.md)**
- **[Product Hunt →](social/product-hunt.md)**
- **[Cold outreach →](social/cold-outreach.md)**

All four pull the leading counts (6 open PRs → 0 stale, 3 CVEs → 0 remaining, 12/12 tests) from this same `ledger.json` — the numbers never drift between this README, the `/demo` page, and the share copy.
