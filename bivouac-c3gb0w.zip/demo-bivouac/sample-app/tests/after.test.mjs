import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
// POST-remediation shape: Bivouac auto-merged the four safe patches, rejected
// the chalk 5 breaking-major, and flagged the glob 9 breaking-major for human
// review. This file mirrors before.test.mjs and asserts what the safe
// versions still satisfy.
import { test } from 'node:test';

const require = createRequire(import.meta.url);

const chalk = require('chalk');
const glob = require('glob');
const _ = require('lodash');
const minimatch = require('minimatch');
const nodeFetch = require('node-fetch');

test('chalk.bold renders strings (kept at 4.1.2 — 5.x rejected)', () => {
  // The breaking-major chalk 5 bump was rejected by Bivouac because three
  // test assertions would have to be deleted; the project stays at 4.1.2.
  assert.equal(typeof chalk.bold('ok'), 'string');
});

test('glob() callback signature is intact (forced 7.x by rejection of 9.x)', () => {
  // Regression guard: the project still uses the callback signature because
  // Bivouac flagged the 9.x PR for a separate, deliberate migration.
  return new Promise((resolve, reject) => {
    glob('tests/*.mjs', { nodir: true }, (err, files) => {
      if (err) return reject(err);
      assert.ok(Array.isArray(files), 'glob returns an array');
      resolve();
    });
  });
});

test('minimatch patch closed the ReDoS vector (PR-002 auto-merged)', () => {
  assert.equal(minimatch('anything.json', '*.json'), true);
  // The mitigated parser is invoked; we don't assert on ReDoS timing, but the
  // patch keeps the public contract identical.
});

test('lodash.template patch (CVE-2021-23337) keeps the same API', () => {
  const tpl = _.template('<%= msg %>');
  assert.equal(tpl({ msg: 'patched' }), 'patched');
});

test('node-fetch patch (CVE-2022-0235) keeps the same default export', () => {
  assert.equal(typeof nodeFetch, 'function');
});

test('Rejection note: chalk 5 would have shifted away from CJS default', () => {
  // Documents Bivouac's reasoning: a destructive breaking-major would have
  // forced the suite to delete three assertions. The team stays on 4.1.2.
  assert.ok(true);
});

test('Flag note: glob 9 needs a Promise-port migration by a human', () => {
  // This test is here so the after-state has a visible placeholder for the
  // human-review work. Bivouac did not auto-merge because the diff removes
  // the API shape the codebase depends on.
  assert.ok(true);
});
