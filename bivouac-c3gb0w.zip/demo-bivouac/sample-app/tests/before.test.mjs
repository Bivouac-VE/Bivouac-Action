import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
// PRE-remediation shape: the breaking updates are still pending, so this file
// asserts the dangerous callback signature, the CommonJS default export of
// chalk, and the presence of the vulnerable lodash template behavior. After
// Bivouac accepts the safe patches and rejects the breaking majors, the test
// suite in `after.test.mjs` mirrors these calls but expects the new behavior.
import { test } from 'node:test';

const require = createRequire(import.meta.url);

const chalk = require('chalk');
const glob = require('glob');
const _ = require('lodash');
const minimatch = require('minimatch');
const nodeFetch = require('node-fetch');

test('chalk exposes a CommonJS default export today', () => {
  assert.equal(typeof chalk.bold, 'function', 'chalk.bold is a function in 4.x');
});

test('glob() supports the callback signature today', () => {
  // Today: callback-style. Bivouac rejects the breaking-major bump that drops
  // it; the human is expected to migrate the call sites themselves.
  const invoked = { callback: false };
  glob('tests/*.mjs', { nodir: true }, (err, _files) => {
    if (!err) invoked.callback = true;
  });
  // We don't synchronously assert on the invocation here — the test documents
  // the shape of the pre-remediation suite. The after.test.mjs is what proves
  // a refactor commits.
  assert.ok(true);
});

test('minimatch resolves * via the 3.0.4 parser', () => {
  assert.equal(minimatch('foo.json', '*.json'), true);
});

test('lodash.template renders the exported surface', () => {
  const tpl = _.template('<%= msg %>');
  assert.equal(tpl({ msg: 'ok' }), 'ok');
});

test('node-fetch returns the Fetch namespace export', () => {
  assert.equal(typeof nodeFetch, 'function', 'node-fetch exports a function');
});
