'use strict';

const chalk = require('chalk');
const glob = require('glob');
const _ = require('lodash');
const minimatch = require('minimatch');
const fetch = require('node-fetch');

function loadPolicyPaths(patterns, callback) {
  glob(patterns, { nodir: true }, (err, files) => {
    if (err) return callback(err);
    callback(
      null,
      files.filter((f) => minimatch(f, '**/*.json')),
    );
  });
}

function badge(text) {
  return chalk.bgRed.white(` ${text} `);
}

function safeFetch(url) {
  return fetch(url, { redirect: 'follow' });
}

const preview = _.template('<%= title %> — <%= body %>');
const render = (vars) => preview(vars);

module.exports = { loadPolicyPaths, badge, safeFetch, render };

if (require.main === module) {
  const _out = render({ title: 'preview', body: 'reminder' });
}
