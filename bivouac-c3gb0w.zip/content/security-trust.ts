// @polsia:user-owned — typed source for /security-trust. Seeded as a
// build-time module and validated server-side by the /api/security-trust
// handler before being handed to the public client island. Sections are the
// pillars a security buyer asks about in the same order; FAQ entries are the
// follow-ups a buyer asks after reading the pillars (certification wording,
// residency, code-handling scope, audit-log scope, token issuance).

export interface SecurityTrustSection {
  /** Stable anchor id for deep links + schema.org correspondence. */
  id: string;
  /** Short uppercase label rendered above the title (`text-eyebrow`). */
  eyebrow: string;
  /** Section heading. */
  title: string;
  /** 1–4 sentence body. Present-tense, evidence-ready wording — never claim
   *  certification. */
  body: string;
}

export interface SecurityTrustFaqItem {
  /** Buyer question. */
  q: string;
  /** 1–4 sentence answer. Same wording rules as `body`. */
  a: string;
}

const sectionsInternal: SecurityTrustSection[] = [
  {
    id: 'data-residency',
    eyebrow: 'Data residency',
    title: 'Where connected-repository data and patch artefacts live.',
    body: 'Connected-repository metadata, advisory signals, policy-pack decisions, patch PRs, test outcomes, and the quarterly signed attestation bundle are stored in databases and object storage in the European Union (currently France-Central). Bivouac itself runs as a managed service on a single primary region in the EU; we do not replicate working data to non-EU regions. The public surfaces that mirror audit data — /activity, /attestation, /triage — serve from the same primary region so a security reviewer in any geography sees the same canonical rows.',
  },
  {
    id: 'encryption-in-transit',
    eyebrow: 'Encryption in transit',
    title: 'TLS 1.3 end-to-end, with explicit upstream and downstream boundaries.',
    body: 'Every client-to-service and service-to-Git-host connection is over TLS 1.3 with modern cipher suites; no plaintext endpoint exists for the agent control plane, the patch webhook, or the reader dashboard. Outbound GitHub traffic uses the GitHub App short-lived installation token (rotated per triage run) over TLS; advisory ingestion over the same. Sensitive service-to-service calls in the control plane ride an internal mesh that terminates TLS at the service boundary, so a packet capture between hops stays opaque.',
  },
  {
    id: 'encryption-at-rest',
    eyebrow: 'Encryption at rest',
    title: 'Storage encrypted at rest, keys rotated, secrets never logged.',
    body: 'Production databases, object storage, and the secret manager are encrypted at rest with provider-managed keys (AES-256, rotated per provider policy). Repository tokens, webhook signing secrets, and platform encryption keys live in the same secret manager, scoped per service account, and never written to application logs or telemetry — log lines are scrubbed for known token shapes before emission. Backups inherit the same at-rest encryption posture from the underlying managed-store offering.',
  },
  {
    id: 'code-handling',
    eyebrow: 'Code handling',
    title: 'Ephemeral clones, scoped tokens, a never-read list.',
    body: 'When a triage run opens a patch PR, the worker clones the repository into an ephemeral container, runs the test suite, and deletes the clone on exit — no persistent branch checkout is kept. Every pull or push rides a short-lived installation token scoped to the single repository being triaged; the token is revoked when the run completes. Source code is read only to the extent the triage loop needs it: dependency manifests, lockfiles, the diff under review, and the test harness config. Production source code is never read for indexing, embedding, model training, telemetry, or any purpose outside the single running triage PR.',
  },
  {
    id: 'audit-log-posture',
    eyebrow: 'Audit-log posture',
    title: 'Every action on a connected repo is recorded, signed, and replayable.',
    body: 'The audit trail is append-only: every signal ingested, every policy-pack decision evaluated, every patch PR opened, every test run that gated a merge, every manual override, and every signed-bundle export is recorded with the actor, the timestamp, the deterministic decision inputs, and a per-row hash chained to the bundle root. The trail is tenant-scoped (no cross-tenant leak) and replayable — the same row set always hashes to the same root, so a security reviewer can replay the trail offline and compare its root to the published attestation.',
  },
  {
    id: 'soc2-posture',
    eyebrow: 'SOC 2 posture',
    title: 'Controls are in place — Bivouac itself is not SOC 2 certified.',
    body: 'Bivouac runs the Trust Services Criteria controls a Type II auditor expects — access control, change management, logging, vendor risk, incident response — and produces the evidence your team hands to an auditor: the signed attestation bundle at /dashboard/attest, the live /activity feed, and the per-quarter SBOM rollup. Bivouac itself is not SOC 2 certified. The wording we use here and in /soc2 is present-tense and evidence-ready on purpose — we will update this page when our own Type II report is in hand, and not before.',
  },
];

const faqInternal: SecurityTrustFaqItem[] = [
  {
    q: 'Is Bivouac SOC 2 certified?',
    a: 'No, not yet. The controls a Type II auditor expects are in place — access control, change management, logging, vendor risk, incident response — and we produce the evidence your team hands to its own auditor. We will update this page when our own Type II report is in hand, and not before.',
  },
  {
    q: 'Where does my repository data live?',
    a: 'Connected-repository metadata, advisory signals, patch PRs, test outcomes, and the quarterly signed bundle are stored in the European Union (currently France-Central). Bivouac runs as a single-region managed service in the EU and does not replicate working data outside it; the public read surfaces serve from the same region.',
  },
  {
    q: 'Does the agent ever read source code outside the active triage PR?',
    a: 'No. Production source code is only read to the extent the triage loop needs it on the single patch PR it has open: dependency manifests, lockfiles, the diff under review, and the test harness config. Source is never read for indexing, embedding, model training, telemetry, or any purpose outside that one running PR — and the ephemeral clone is deleted when the run finishes.',
  },
  {
    q: 'What does the audit log cover?',
    a: 'Every signal ingested, every policy-pack decision evaluated, every patch PR opened, every test run that gated a merge, every manual override, and every signed-bundle export. Each row carries actor, timestamp, decision inputs, and a per-row hash chained to the bundle root, so a reviewer can replay the trail offline and compare its root to the published attestation.',
  },
  {
    q: 'How are scoped GitHub tokens issued and revoked?',
    a: 'Triage runs pull a short-lived installation token from the GitHub App at the start of the run, scoped to the single repository being triaged. The token is revoked when the run completes; we do not keep a long-lived repo credential in storage. Tokens are never written to logs, and log scrubbers redact known token shapes before emission.',
  },
  {
    q: 'Can I export the audit trail as evidence for my own auditor?',
    a: 'Yes. The signed bundle at /dashboard/attest is the artifact your auditor replays — every patch event carries CVE id, signal source, policy-pack decision, test outcome, merge-vs-human-override flag, and SBOM provenance. The hash is deterministic so the same data always hashes to the same root, and the PDF cover reproduces that root for verification.',
  },
];

export const securityTrustSections: SecurityTrustSection[] = sectionsInternal;
export const securityTrustFaq: SecurityTrustFaqItem[] = faqInternal;
