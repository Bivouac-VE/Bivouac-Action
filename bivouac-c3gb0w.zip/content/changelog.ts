// @polsia:user-owned — typed source for /changelog. Entries are seeded as a
// build-time module and validated server-side by the /api/changelog handler
// before being handed to the public client island. Sort newest first by `date`
// (ISO `YYYY-MM-DD`); `monthBucket` is derived up-front so callers don't split
// strings at render time.

export type ChangelogTag = 'Hero' | 'Pricing' | 'Dashboard' | 'Content' | 'Tooling';

export interface ChangelogLink {
  label: string;
  href: string;
}

export interface ChangelogEntry {
  /** ISO `YYYY-MM-DD`; stable, sortable, used to bucket by month. */
  date: string;
  /** `'YYYY-MM'` derived from `date` so the page doesn't split strings at render. */
  monthBucket: string;
  tag: ChangelogTag;
  title: string;
  /** 1–3 sentence blurb — what shipped, why it matters. */
  summary: string;
  /** Optional row of PR / source links rendered under the summary. */
  links?: ChangelogLink[];
}

const entriesInternal: Array<Omit<ChangelogEntry, 'monthBucket'>> = [
  {
    date: '2026-08-15',
    tag: 'Tooling',
    title: 'Breaking-change detector in the SBOM pipeline',
    summary:
      'A new `breaking-change` detector that flags semver-major dependency bumps in the SBOM before auto-merge — and posts a structured PR comment with the upgrade rationale so a triage engineer sees the lockfile impact before the auto-merge timer fires.',
    links: [
      {
        label: 'Detector spec',
        href: 'https://github.com/bivouac-app/bivouac/blob/main/docs/breaking-change-detector.md',
      },
    ],
  },
  {
    date: '2026-08-12',
    tag: 'Tooling',
    title: 'bivouac-action — automated bot-PR risk comment',
    summary:
      'Open-source GitHub Action that classifies every PR raised by a bot (Dependabot, Renovate, etc.) by blast radius and posts a structured risk comment on the PR — so a triage engineer can spot a critical dep bump before the auto-merge timer fires.',
    links: [
      { label: 'bivouac-action on GitHub', href: 'https://github.com/bivouac-app/bivouac-action' },
    ],
  },
  {
    date: '2026-08-08',
    tag: 'Tooling',
    title: 'Slack + PagerDuty alert routing',
    summary:
      'Native Slack and PagerDuty integrations on the dashboard — so a CVE-to-PR close event or a vuln-posture regression pings the on-call channel directly, instead of forcing the on-call to chase a digest email.',
    links: [{ label: 'Integrations doc', href: 'https://docs.bivouac.app/integrations/slack' }],
  },
  {
    date: '2026-08-05',
    tag: 'Dashboard',
    title: '/dashboard/billing — Stripe-backed subscription page',
    summary:
      'The Stripe-backed subscriptions tab on the dashboard — pick a plan, redeem a coupon, and manage the seat count without a support thread. Hosted-checkout driven through the platform Stripe Connect, so no keys ship in this repo.',
  },
  {
    date: '2026-07-28',
    tag: 'Dashboard',
    title: 'Dashboard first-repo panel — guided repo setup',
    summary:
      'A guided panel on the dashboard that walks a new operator through connecting their first repo: pick a scope, grant the GitHub App, and verify the SBOM webhook in one flow — instead of an empty inbox staring at them.',
  },
  {
    date: '2026-07-22',
    tag: 'Dashboard',
    title: 'Dashboard first-run banner — onboarding surface on entry',
    summary:
      'A first-run banner on the dashboard that surfaces the next-best step on every page-load — connect a repo, sign up for the digest, or wire a webhook — so a fresh signup is never dropped on an empty shell.',
  },
  {
    date: '2026-07-09',
    tag: 'Content',
    title: 'Bivouac vs Snyk blog post',
    summary:
      'A side-by-side comparison of Bivouac and Snyk OSS — auto-merge policy, CVE-to-PR latency, and the audit trail each tool leaves behind — written for a security buyer deciding which to standardise on.',
    links: [{ label: 'Read the post', href: 'https://bivouac.app/blog/bivouac-vs-snyk' }],
  },
  {
    date: '2026-06-25',
    tag: 'Pricing',
    title: 'Pricing redesign — clearer tiers + checkout path',
    summary:
      'A redesigned pricing page: clearer tier boundaries, an explicit seat-by-seat breakdown, and a one-click path to the new /dashboard/billing tab for whatever plan a visitor picks — so a redirect never dead-ends a prospect.',
  },
  {
    date: '2026-06-11',
    tag: 'Content',
    title: 'Comparison table on the homepage',
    summary:
      'A side-by-side comparison table on the landing page — Bivouac vs Dependabot, Renovate, Snyk OSS, Copilot Autofix — covering auto-merge behaviour, audit trail, and time-to-PR so a reader can scan the trade-offs without leaving the page.',
  },
  {
    date: '2026-06-04',
    tag: 'Content',
    title: 'Security & Trust page — controls without a sales call',
    summary:
      'A new `/security-trust` page that consolidates our SOC 2 evidence, NIS2 alignment, and data-handling guarantees — so a security buyer can verify our controls without filing a sales call or chasing the right PDF.',
    links: [{ label: 'Security & Trust', href: 'https://bivouac.app/security-trust' }],
  },
  {
    date: '2026-05-30',
    tag: 'Content',
    title: 'FAQ section on the homepage',
    summary:
      'A new FAQ block on the homepage covering SBOM, audit-log, and auto-merge policy — answering the seven most common buyer objections before the second scroll, instead of parking them in a /docs fork.',
  },
  {
    date: '2026-05-23',
    tag: 'Content',
    title: 'Sitemap + per-page SEO hardening',
    summary:
      'Rebuilt `sitemap.ts`, per-page canonical + OG/Twitter cards, and a hardened `robots.txt` — so every landing, comparison, and changelog route ships with the right canonical, OG image and Twitter card without a hand-rolled `<head>` per page.',
  },
  {
    date: '2026-05-12',
    tag: 'Hero',
    title: 'Homepage hero rewrite — sharper positioning',
    summary:
      'A homepage hero rewrite that swaps the generic "autonomous patcher" framing for a sharper "N-hour CVE-to-PR with provable audit log" claim — and aligns the sub-copy, primary CTA, and social-proof row to the same positioning.',
  },
];

function toMonthBucket(iso: string): string {
  // ISO YYYY-MM-DD → YYYY-MM (locale-independent; no timezone drift on the prefix).
  const m = /^(\d{4})-(\d{2})/.exec(iso);
  return m ? `${m[1]}-${m[2]}` : '1970-01';
}

export const changelog: ChangelogEntry[] = entriesInternal
  .map((e) => ({ ...e, monthBucket: toMonthBucket(e.date) }))
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

export interface ChangelogMonthBucket {
  monthBucket: string;
  label: string;
  entries: ChangelogEntry[];
}

const MONTH_LABEL = new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' });

export function groupByMonthDescending(entries: ChangelogEntry[]): ChangelogMonthBucket[] {
  const ordered: ChangelogMonthBucket[] = [];
  for (const entry of entries) {
    const last = ordered[ordered.length - 1];
    if (!last || last.monthBucket !== entry.monthBucket) {
      ordered.push({
        monthBucket: entry.monthBucket,
        label: MONTH_LABEL.format(new Date(`${entry.monthBucket}-01T00:00:00Z`)),
        entries: [entry],
      });
    } else {
      last.entries.push(entry);
    }
  }
  return ordered;
}
