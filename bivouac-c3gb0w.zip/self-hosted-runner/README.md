# Bivouac Self-Hosted Runner

A self-hosted agent runner that polls the Bivouac API for jobs.

## Required environment variables

- `BIVOUAC_API_URL` — base URL of the Bivouac API (e.g. `https://bivouac.example.com`)
- `BIVOUAC_API_TOKEN` — bearer token used to authenticate poll requests

## Build the image

```
docker build -t bivouac-runner .
```

## Run the container

```
docker run --rm \
  -e BIVOUAC_API_URL=http://stub.local \
  -e BIVOUAC_API_TOKEN=dev \
  bivouac-runner
```

The runner polls `${BIVOUAC_API_URL}/api/runner/jobs` every 30 seconds and emits
a `polling…` line on each tick (status code, an empty queue, a job payload, or an
unreachable endpoint).

## Scope

Execution of polled jobs and any result round-trip POST back to the API are
intentionally out of scope for this skeleton — today the runner polls and logs
only.

Against a stubbed URL the loop never crashes: it logs `polling… unreachable`
until the URL responds, then continues emitting `polling…` lines on subsequent
ticks.
