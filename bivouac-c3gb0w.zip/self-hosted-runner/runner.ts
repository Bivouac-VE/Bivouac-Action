// Reads BIVOUAC_API_TOKEN + BIVOUAC_API_URL, polls
// `${BIVOUAC_API_URL}/api/runner/jobs` every 30s, logs each payload.
// Execution is intentionally out of scope (future PR).

const POLL_INTERVAL_MS = 30_000;
const apiUrl = process.env.BIVOUAC_API_URL;
const token = process.env.BIVOUAC_API_TOKEN;

if (!apiUrl || !token) {
  console.error('[runner] BIVOUAC_API_URL and BIVOUAC_API_TOKEN are required');
  process.exit(1);
}

const endpoint = `${apiUrl.replace(/\/+$/, '')}/api/runner/jobs`;

async function tick() {
  try {
    const res = await fetch(endpoint, {
      headers: { authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      console.log(`polling… ${endpoint} → ${res.status}`);
      return;
    }
    const payload = await res.json().catch(() => null);
    const jobs = Array.isArray(payload?.jobs) ? payload.jobs : [];
    if (jobs.length === 0) {
      console.log('polling… no jobs');
      return;
    }
    for (const job of jobs) {
      console.log(`polling… job: ${JSON.stringify(job)}`);
    }
  } catch (err) {
    console.log(`polling… unreachable (${(err as Error).message})`);
  }
}

(async () => {
  console.log(`[runner] polling ${endpoint} every ${POLL_INTERVAL_MS}ms`);
  while (!(globalThis as { exitFlag?: boolean }).exitFlag) {
    await tick();
    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
  }
})();
