// @polsia:user-owned — shared SEO metadata builders for public marketing
// pages and per-post blog pages. Returns Next `Metadata` shaped the way the
// root layout's `title.template` + `metadataBase` want it: page <title> gets
// the template prefix, OG/Twitter titles are written out in full so the
// template cannot stamp a duplicate suffix. Relative URLs (canonical,
// og:url, ogImage) ride on `metadataBase` and become absolute automatically.
//
// Confined to src/lib/** so the biome noRestrictedImports override lifts
// `@/lib/site` (and the `@/lib/business/blog-meta` import below). No page
// ever has to import `@/lib/db` directly; the Post row is read by the
// blog-meta helper it already calls and plugged in here.

import type { Metadata } from 'next';
import type { PostMeta } from '@/lib/business/blog-meta';
import { siteName, siteUrl } from '@/lib/site';

const OG_IMAGE_PATH = '/opengraph-image';
const LOGO_PATH = '/icon.svg';

export interface PageMetadataInput {
  title: string;
  description: string;
  /** App-absolute path (e.g. "/pricing"). metadataBase makes it absolute. */
  path: string;
  /** App-absolute or relative image path. Defaults to /opengraph-image. */
  ogImage?: string;
  /** OG object type; defaults to 'website'. 'article' for posts. */
  type?: 'website' | 'article';
}

export function pageMetadata({
  title,
  description,
  path,
  ogImage = OG_IMAGE_PATH,
  type = 'website',
}: PageMetadataInput): Metadata {
  const fullTitle = `${title} · ${siteName}`;
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      type,
      title: fullTitle,
      description,
      url: path,
      siteName,
      images: [{ url: ogImage, width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [ogImage],
    },
  };
}

export function blogPostMetadata(post: PostMeta, ogImage: string = OG_IMAGE_PATH): Metadata {
  const title = post.title;
  const fullTitle = `${title} · ${siteName}`;
  const description = post.excerpt;
  const path = `/blog/${post.slug}`;
  const publishedISO = (post.publishedAt ?? new Date(0)).toISOString();
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      type: 'article',
      title: fullTitle,
      description,
      url: path,
      siteName,
      images: [{ url: ogImage, width: 1200, height: 630, alt: title }],
      publishedTime: publishedISO,
      modifiedTime: publishedISO,
      authors: [siteName],
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [ogImage],
    },
  };
}

export function blogPostingLd(post: PostMeta, slug: string): Record<string, unknown> {
  const url = `${siteUrl}/blog/${slug}`;
  const dateISO = (post.publishedAt ?? new Date(0)).toISOString();
  return {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: post.title,
    description: post.excerpt,
    datePublished: dateISO,
    dateModified: dateISO,
    url,
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    author: { '@type': 'Organization', name: siteName, url: siteUrl },
    publisher: {
      '@type': 'Organization',
      name: siteName,
      logo: { '@type': 'ImageObject', url: `${siteUrl}${LOGO_PATH}` },
    },
    image: `${siteUrl}${OG_IMAGE_PATH}`,
  };
}
