// @polsia:user-owned — app navigation rendered by SiteNav/SiteFooter and read by
// the sitemap. Edit it as pages are added or removed.
// This list is a convenience, not module registration.

export type NavGroup = 'primary' | 'secondary' | 'footer';

export interface NavItem {
  /** Visible link text. */
  label: string;
  /** App route, e.g. '/' or '/dashboard'. */
  href: string;
  /** Where it renders: top-nav 'primary'/'secondary', or 'footer'. */
  group: NavGroup;
  /** Group `primary` items into a dropdown: items sharing a `menu` value collapse
   *  into one "<menu> ⌄" top-bar slot (e.g. `menu: 'Resources'` on Blog/Docs/
   *  Changelog). Keeps the bar short. Ignored for 'secondary'/'footer'. */
  menu?: string;
  /** When true, render only if a session exists (see site-nav.tsx). */
  requiresAuth?: boolean;
  /** Sort key within a group (ascending); unordered items fall to the end. */
  order?: number;
}

// Keep the bar short: ~3-5 primary slots, group the tail with `menu`, push the
// rest to 'footer' (SiteNav overflows extras into a "More" dropdown).
export const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', group: 'primary', requiresAuth: true, order: 90 },
  { label: 'Billing', href: '/settings/billing', group: 'primary', requiresAuth: true, order: 95 },
  { label: 'Team', href: '/settings/team', group: 'primary', requiresAuth: true, order: 96 },
  { label: 'Attestation', href: '/attestation', group: 'primary', requiresAuth: true, order: 97 },
  { label: 'Capabilities', href: '/#capabilities', group: 'primary', order: 100 },
  { label: 'Pricing', href: '/pricing', group: 'primary', order: 105 },
  { label: 'Compare', href: '/vs', group: 'primary', order: 110 },
  { label: 'NIS2', href: '/nis2', group: 'primary', order: 112 },
  { label: 'CRA', href: '/cra', group: 'primary', order: 113 },
  { label: 'SOC 2', href: '/soc2', group: 'primary', order: 114 },
  { label: 'Triage loop', href: '/#triage-loop', group: 'primary', order: 115 },
  { label: 'CVE log', href: '/triage', group: 'primary', order: 130 },
  { label: 'Demo', href: '/demo', group: 'primary', order: 132 },
  { label: 'Activity', href: '/activity', group: 'primary', order: 128 },
  { label: 'Blog', href: '/blog', group: 'primary', menu: 'Resources', order: 88 },
  { label: 'Changelog', href: '/changelog', group: 'primary', menu: 'Resources', order: 86 },
  { label: 'Status', href: '/status', group: 'primary', order: 85 },
  { label: 'Guardrails', href: '/#guardrails', group: 'footer', order: 120 },
  { label: 'Changelog', href: '/changelog', group: 'footer', order: 180 },
  { label: 'Privacy', href: '/policies/privacy', group: 'footer', order: 200 },
  { label: 'Terms', href: '/policies/terms', group: 'footer', order: 210 },
  { label: 'Security', href: '/policies/security', group: 'footer', order: 220 },
  { label: 'Security & Trust', href: '/security-trust', group: 'footer', order: 225 },
  { label: 'Log in', href: '/login', group: 'secondary', order: 10 },
  { label: 'Sign up', href: '/signup', group: 'secondary', order: 20 },
  { label: 'Contact', href: 'mailto:bivouac-c3gb0w@polsia.app', group: 'secondary', order: 100 },
];
