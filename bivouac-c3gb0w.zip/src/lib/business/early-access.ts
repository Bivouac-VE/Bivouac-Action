// @polsia:user-owned — typed catalog for the early-access / social-proof
// section on /. Pure data, no JSX: each language ships an `id` that the
// section component dispatches on to render the right mark.
//
// EARLY_ACCESS_TEAMS is deliberately empty today — Bivouac is in private
// beta and we don't put logos on the page before design partners sign off.
// Future swap-in is mechanical: append { name, mark? } entries and the
// section's empty-state callout yields to the tile grid with no other
// edits required.

export const HEADER = "Built for teams that can't afford dependency drift.";
export const SUBHEAD = 'Currently onboarding early-access teams.';
export const BODY =
  "Bivouac is in private beta with a small set of design partners. Each team gets a named engineer, a shared roadmap slot, and a private channel into the audit log — names will appear on this page once they've signed off, not before.";

export const ECOSYSTEM_HEADING = 'Ecosystem coverage';
export const ECOSYSTEM_SUB = 'One agent across every runtime your stack touches.';

export const CUSTOMER_HEADING = 'Early-access teams';
export const CUSTOMER_EMPTY_COPY =
  "A small set of design partners is onboarding now. Names will appear here once they've signed off — we don't put logos on the page before they do.";

export type LanguageId =
  | 'github'
  | 'node'
  | 'python'
  | 'java'
  | 'go'
  | 'ruby'
  | 'rust'
  | 'php'
  | 'dotnet';

export type LanguageEntry = {
  id: LanguageId;
  name: string;
  tagline: string;
};

export const LANGUAGES: readonly LanguageEntry[] = [
  {
    id: 'github',
    name: 'GitHub',
    tagline: 'Repos, advisories, PRs, merge guardrails.',
  },
  {
    id: 'node',
    name: 'Node.js',
    tagline: 'npm lockfiles, transitive SemVer, peer ranges.',
  },
  {
    id: 'python',
    name: 'Python',
    tagline: 'pip, pyproject, private indexes.',
  },
  {
    id: 'java',
    name: 'Java',
    tagline: 'Maven, Gradle, OSV-scored advisories.',
  },
  {
    id: 'go',
    name: 'Go',
    tagline: 'go.mod graph, vendor trees, module proxy.',
  },
  {
    id: 'ruby',
    name: 'Ruby',
    tagline: 'Bundler, gemspec, RubyGems advisories.',
  },
  {
    id: 'rust',
    name: 'Rust',
    tagline: 'Cargo workspace graph, crates.io advisories.',
  },
  {
    id: 'php',
    name: 'PHP',
    tagline: 'Composer, lockfile, private Packagist.',
  },
  {
    id: 'dotnet',
    name: '.NET',
    tagline: 'NuGet, csproj, transitive resolve.',
  },
];

// Explicit annotation keeps the array typed at the declared shape instead
// of widening to `never[]` when the literal is empty. Real teams append
// here once they sign off on a public mention.
export const EARLY_ACCESS_TEAMS: { name: string; mark?: string }[] = [];
