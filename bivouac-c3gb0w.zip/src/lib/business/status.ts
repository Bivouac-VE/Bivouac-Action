// @polsia:user-owned — server-only helpers for the public /status page.
// Reads the global CveTriageLog table (no auth, no per-user scoping) so a
// visitor who never signs up can still see whether the daily cron is
// firing. The fixture table is small enough that we pull the most recent
// 2000 rows to cover ~90 daily buckets + the recent-incident list, then
// shape the response to match the shared contract in
// @/lib/contracts/status.

import 'server-only';
import { deriveSeverity } from '@/lib/business/patches';
import {
  type IncidentRow,
  type StatusAction,
  type StatusOverall,
  type StatusSeverity,
  type StatusSnapshot,
  StatusSnapshot as StatusSnapshotSchema,
  type UptimeBars,
  type UptimeDay,
  type UptimeDayStatus,
} from '@/lib/contracts/status';
import { prisma } from '@/lib/db';

// Pull enough rows to fill 90 daily buckets plus the recent-incident list
// at any reasonable fixture density. 2000 ≈ ~22 rows/day for a 90-day
// window, which is well above anything the fixture ever produces.
const MAX_ROWS = 2000;

// Public page caps recent incidents at 25 to keep the visible list short.
const MAX_RECENT_INCIDENTS = 25;

// 90-day window — matches the brief.
const WINDOW_DAYS = 90;

// Cron fires daily at 08:00 UTC; allow ~36h slack for clock skew /
// transient outage. Up to 36h ago → healthy. 36h–60h → delayed. Otherwise →
// down. No rows at all → no-data.
const HEALTHY_MAX_AGE_HOURS = 36;
const DELAYED_MAX_AGE_DAYS = 2;

// Internal subset type — narrow enough that we can shape it once and feed
// it through the contract without surprises.
type RawRow = {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  eventKind: string;
  createdAt: Date;
};

// Inclusive UTC start-of-day for a given Date — the daily-bucket anchor.
// Matches the source's timezone convention (audit-log + metrics use UTC).
function startOfUtcDay(date: Date): Date {
  const d = new Date(date);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

function dayIso(date: Date): string {
  return date.toISOString().slice(0, 10);
}

// Enumerate exactly `count` consecutive UTC days ending at today (UTC).
// Returns oldest → newest, so the UI can render oldest on the left of the
// strip and today at the right without reversing the array.
function enumerateDays(now: Date, count: number): Date[] {
  const days: Date[] = [];
  const today = startOfUtcDay(now);
  for (let offset = count - 1; offset >= 0; offset -= 1) {
    const day = new Date(today);
    day.setUTCDate(today.getUTCDate() - offset);
    days.push(day);
  }
  return days;
}

function deriveBreakingSeverity(): StatusSeverity {
  // Mirror audit-log.ts: BREAKING rows have no CVE id, fall back to medium.
  return 'medium';
}

function deriveAction(mergeDecision: string): StatusAction {
  switch (mergeDecision) {
    case 'AUTO_MERGE':
      return 'auto-merged';
    case 'MANUAL_REVIEW':
      return 'paged';
    case 'BLOCKED':
      return 'declined';
    default:
      return 'paged';
  }
}

// Today's bucket: render as 'stale' (amber), not 'down' (red). The cron
// hasn't necessarily fired yet today, so an empty day is expected before
// ~08:00 UTC. Once the window has actually passed (yesterday), an empty
// day flips to 'down' — see the rule in the brief.
function classifyDay(
  patchesCount: number,
  dayIsoStr: string,
  todayIsoStr: string,
): UptimeDayStatus {
  if (patchesCount > 0) return 'up';
  if (dayIsoStr === todayIsoStr) return 'stale';
  return 'down';
}

function buildHeadline(
  rows: RawRow[],
  now: Date,
): {
  overall: StatusOverall;
  label: string;
  detail: string;
  lastSeenAt: string | null;
  daysSinceLastSeen: number | null;
} {
  if (rows.length === 0) {
    return {
      overall: 'no-data',
      label: 'No telemetry yet',
      detail:
        'The daily cron has not landed a triage row in this environment yet. The first run should appear within the next 24 hours.',
      lastSeenAt: null,
      daysSinceLastSeen: null,
    };
  }
  // Find the most recent row. rows is already ordered desc by createdAt per
  // the loader's findMany, but the slice over `rows` may skip it; re-find so
  // a future filter change doesn't quietly drop the latest row.
  const first = rows[0];
  if (!first) {
    return {
      overall: 'no-data',
      label: 'No telemetry yet',
      detail: 'No triage rows are available right now.',
      lastSeenAt: null,
      daysSinceLastSeen: null,
    };
  }
  const last = rows.reduce<RawRow>(
    (acc, r) => (r.createdAt.getTime() > acc.createdAt.getTime() ? r : acc),
    first,
  );
  const ageMs = now.getTime() - last.createdAt.getTime();
  const ageHours = ageMs / 3_600_000;
  const ageDays = Math.max(0, Math.floor(ageMs / 86_400_000));

  let overall: StatusOverall;
  if (ageHours <= HEALTHY_MAX_AGE_HOURS) overall = 'healthy';
  else if (ageDays <= DELAYED_MAX_AGE_DAYS) overall = 'delayed';
  else overall = 'down';

  const lastIso = last.createdAt.toISOString();
  const lastPretty = `${last.createdAt.toISOString().replace('T', ' ').slice(0, 16)} UTC`;

  let label: string;
  let detail: string;
  if (overall === 'healthy') {
    const hours = Math.max(0, Math.round(ageHours));
    const unit = hours === 1 ? 'hour' : 'hours';
    label = 'Operational';
    detail = `Last triage run landed ${hours} ${unit} ago (${lastPretty}).`;
  } else if (overall === 'delayed') {
    label = 'Delayed';
    detail =
      `Last triage run is older than expected — ${ageDays} day${ageDays === 1 ? '' : 's'} since ` +
      `the last row (${lastPretty}). The agent is likely catching up.`;
  } else {
    const days = Math.max(1, ageDays);
    label = 'Outage';
    detail =
      `No triage rows in the last ${days} day${days === 1 ? '' : 's'} (last seen ${lastPretty}). ` +
      `Operator intervention may be required.`;
  }

  return {
    overall,
    label,
    detail,
    lastSeenAt: lastIso,
    daysSinceLastSeen: ageDays,
  };
}

function buildUptimeBars(rows: RawRow[], now: Date): UptimeBars {
  const days = enumerateDays(now, WINDOW_DAYS);
  const firstDay = days[0];
  const lastDay = days[days.length - 1];
  if (!firstDay || !lastDay) {
    // enumerateDays(count) always returns `count` entries; the guard is
    // only there to satisfy noUncheckedIndexedAccess.
    throw new Error('enumerateDays returned an empty array');
  }
  const todayStr = dayIso(lastDay);
  const fromStr = dayIso(firstDay);
  const counts = new Map<string, number>();
  for (const row of rows) {
    const key = dayIso(startOfUtcDay(row.createdAt));
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  const cells: UptimeDay[] = days.map((d) => {
    const iso = dayIso(d);
    const n = counts.get(iso) ?? 0;
    return {
      day: iso,
      status: classifyDay(n, iso, todayStr),
      patchesCount: n,
    };
  });
  return {
    fromDay: fromStr,
    toDay: todayStr,
    days: cells,
  };
}

function buildRecentIncidents(rows: RawRow[], now: Date): { items: IncidentRow[] } {
  // rows is already ordered desc by createdAt from the loader — we just cap.
  const take = rows.slice(0, MAX_RECENT_INCIDENTS);
  const nowMs = now.getTime();
  const items: IncidentRow[] = take.map((row) => {
    const severity: StatusSeverity = row.cveId
      ? (deriveSeverity(row.cveId) as StatusSeverity)
      : deriveBreakingSeverity();
    const ageMs = nowMs - row.createdAt.getTime();
    const hours = ageMs / 3_600_000;
    return {
      id: row.id,
      createdAt: row.createdAt.toISOString(),
      cveId: row.cveId,
      packageName: row.packageName,
      fromVersion: row.fromVersion,
      toVersion: row.toVersion,
      severity,
      action: deriveAction(row.mergeDecision),
      prUrl: row.prUrl,
      // Negative guards against malformed clock skew (an incident dated in
      // the future would otherwise produce a sneaky negative latency).
      detectionToPrLatencyHours: hours >= 0 ? hours : null,
    };
  });
  return { items };
}

function buildSummary30d(rows: RawRow[], now: Date): StatusSnapshot['summary30d'] {
  const thirtyDaysAgoMs = now.getTime() - 30 * 86_400_000;
  let patches = 0;
  let autoMerged = 0;
  let paged = 0;
  const ages: number[] = [];
  for (const row of rows) {
    if (row.createdAt.getTime() < thirtyDaysAgoMs) continue;
    patches += 1;
    if (row.mergeDecision === 'AUTO_MERGE') autoMerged += 1;
    if (row.mergeDecision === 'MANUAL_REVIEW') paged += 1;
    const age = now.getTime() - row.createdAt.getTime();
    if (age >= 0) ages.push(age / 3_600_000);
  }
  let medianLatencyHours: number | null = null;
  if (ages.length > 0) {
    ages.sort((a, b) => a - b);
    const mid = Math.floor(ages.length / 2);
    if (ages.length % 2 === 0) {
      const lower = ages[mid - 1];
      const upper = ages[mid];
      medianLatencyHours = lower !== undefined && upper !== undefined ? (lower + upper) / 2 : null;
    } else {
      medianLatencyHours = ages[mid] ?? null;
    }
  }
  return { patches, autoMerged, paged, medianLatencyHours };
}

export async function loadStatusSnapshot(now: Date = new Date()): Promise<StatusSnapshot> {
  const rows = (await prisma.cveTriageLog.findMany({
    orderBy: { createdAt: 'desc' },
    take: MAX_ROWS,
    select: {
      id: true,
      cveId: true,
      packageName: true,
      fromVersion: true,
      toVersion: true,
      prUrl: true,
      testOutcome: true,
      mergeDecision: true,
      eventKind: true,
      createdAt: true,
    },
  })) as RawRow[];

  const headline = buildHeadline(rows, now);
  const uptime = buildUptimeBars(rows, now);
  const recentIncidents = buildRecentIncidents(rows, now);
  const summary30d = buildSummary30d(rows, now);

  // Validate the assembled shape against the shared contract so any drift
  // surfaces here, not in the client island.
  return StatusSnapshotSchema.parse({
    generatedAt: now.toISOString(),
    headline,
    uptime,
    recentIncidents,
    summary30d,
  });
}
