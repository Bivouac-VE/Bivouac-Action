// @polsia:user-owned — competitor comparison data for /vs and /vs/[competitor].
//
// Each `rows[i].source.bullet` is a VERBATIM `label` from
// src/components/custom/compare-tabs.tsx — that file is the source of truth.
// If the landing-page research is ever edited there, keep this file byte-equal
// for the cited bullets, or the source citation in each row goes stale.
//
// Caveats below are also verbatim from that file. oneLiner is the per-
// competitor "why we built this" sentence from the comparison brief.

export type CompetitorSlug =
  | 'dependabot'
  | 'renovate'
  | 'snyk-oss'
  | 'copilot-autofix'
  | 'copilot-coding-agent';

export type ComparisonRow = {
  dimension: string;
  bivouc: string;
  competitor: string;
  source: { bullet: string; location: 'landing-page#compare-tabs'; tab: 'flag-bots' | 'fix-bots' };
};

export type CompetitorProfile = {
  slug: CompetitorSlug;
  name: string;
  navLabel: string;
  oneLiner: string;
  tagline: string;
  rows: [ComparisonRow, ComparisonRow, ComparisonRow];
  /** Verbatim caveat copy from src/components/custom/compare-tabs.tsx. */
  caveat: string;
  ctaSubline: string;
  /** Which research tab on the landing page this competitor maps to. */
  researchTab: 'flag-bots' | 'fix-bots';
};

export const competitorOrder: CompetitorSlug[] = [
  'dependabot',
  'renovate',
  'snyk-oss',
  'copilot-autofix',
  'copilot-coding-agent',
];

// Verbatim caveats from src/components/custom/compare-tabs.tsx.
const FLAG_CAVEAT = 'Useful — but the human still owns the decision tree.';
const FIX_CAVEAT = 'Powerful — but wider scope is wider risk in a regulated tree.';

const FLAG_BOTS_ROWS: [ComparisonRow, ComparisonRow, ComparisonRow] = [
  {
    dimension: 'Trigger cadence',
    bivouc:
      'Continuous watch on GitHub repos, lockfiles, and advisory feeds. A new CVE lands as a patch PR within minutes — the queue gates on the test suite, not on someone noticing.',
    competitor:
      'Opens a PR the moment a CVE lands or a minor version drifts. The signal leaves the moment the alert opens — but every signal does, so the queue fills faster than the team can absorb it.',
    source: {
      bullet: 'Strong at surfacing',
      location: 'landing-page#compare-tabs',
      tab: 'flag-bots',
    },
  },
  {
    dimension: 'Decision-making',
    bivouc:
      'Forward fix, downgrade, or pin is solved locally from SemVer, peer usage, and your repo-aware policy pack. Tests run before a human is paged — judgment is reserved for the contested outcomes.',
    competitor:
      'No built-in choice between forward fix, downgrade, or pinning when a SemVer major bump breaks a consumer. That decision is left to whoever reads the PR first.',
    source: {
      bullet: 'No judgment',
      location: 'landing-page#compare-tabs',
      tab: 'flag-bots',
    },
  },
  {
    dimension: 'On-call load & audit',
    bivouc:
      'Every PR carries feed source, decision rationale, test output, and merge outcome — usable as SOC 2 / NIS2 / CRA evidence. The on-call sees only what a contested decision or a red build left behind.',
    competitor:
      'Every alert reaches the on-call rotation. People triage bots that should be triaging themselves, and the audit trail is whatever your existing PR review captures.',
    source: {
      bullet: 'Queue pressure',
      location: 'landing-page#compare-tabs',
      tab: 'flag-bots',
    },
  },
];

const FIX_BOTS_ROWS: [ComparisonRow, ComparisonRow, ComparisonRow] = [
  {
    dimension: 'Trigger cadence',
    bivouc:
      'Continuous watch on GitHub repos, lockfiles, and advisory feeds. A new CVE lands as a patch PR within minutes — unrelated feature work, refactors, and style cleanups never enter the queue.',
    competitor:
      "Built to write features, refactor code, and chase arbitrary issues. Dependency triage is one job among many, so it competes with everything else on the agent's plate.",
    source: {
      bullet: 'General-purpose',
      location: 'landing-page#compare-tabs',
      tab: 'fix-bots',
    },
  },
  {
    dimension: 'Decision-making',
    bivouc:
      'Scope is locked to CVEs, upstream breaking changes, and supply-chain incidents. Edits stay inside the dependency boundary — no reshaped code adjacent to the patch.',
    competitor:
      'A fix-bot reshapes code adjacent to the patch. For a CVE the wrong neighbour edit is a regression, and there is no built-in cap on how far a single run can drift.',
    source: {
      bullet: 'Broad blast radius',
      location: 'landing-page#compare-tabs',
      tab: 'fix-bots',
    },
  },
  {
    dimension: 'On-call load & audit',
    bivouc:
      'Every PR ships feed source, decision rationale, test output, and merge outcome — SOC 2 / NIS2 / CRA evidence-ready. Pages only on contested license, security-sensitive surfaces, or red builds.',
    competitor:
      "Limited attestation for SOC 2 / NIS2 / CRA — every step must be reproducible in an external audit, and trust accelerates as the agent's scope grows.",
    source: {
      bullet: 'Unregulated trust',
      location: 'landing-page#compare-tabs',
      tab: 'fix-bots',
    },
  },
];

export const competitorProfiles: Record<CompetitorSlug, CompetitorProfile> = {
  dependabot: {
    slug: 'dependabot',
    name: 'Dependabot',
    navLabel: 'Bivouac vs Dependabot',
    tagline: 'Less weekly PR sprawl. More downgrade PRs that actually merge.',
    oneLiner:
      "Bivouc opens downgrade PRs vs Dependabot's weekly PR sprawl — same CVE coverage, but the decision between forward fix and pin is solved locally and merges on green tests.",
    rows: FLAG_BOTS_ROWS,
    caveat: FLAG_CAVEAT,
    ctaSubline:
      "Try it on one repo first. The same Dependabot coverage, a smaller queue for the on-call, and downgrade decisions that don't wait on review.",
    researchTab: 'flag-bots',
  },
  renovate: {
    slug: 'renovate',
    name: 'Renovate',
    navLabel: 'Bivouac vs Renovate',
    tagline: 'From manual review queue to green-build auto-merge.',
    oneLiner:
      "Bivouc auto-merges on green tests vs Renovate's manual review — Renovate opens the same PR, but the merge button and the decision between forward fix and downgrade still belong to a human.",
    rows: FLAG_BOTS_ROWS,
    caveat: FLAG_CAVEAT,
    ctaSubline:
      'Start with one repo, keep Renovate in scope, and let Bivouc own the auto-merge policy per surface. No green-build PRs on the on-call queue.',
    researchTab: 'flag-bots',
  },
  'snyk-oss': {
    slug: 'snyk-oss',
    name: 'Snyk OSS',
    navLabel: 'Bivouac vs Snyk OSS',
    tagline: 'Advisory-only stops at the inbox. Bivouc ships a PR.',
    oneLiner:
      "Bivouc ships PRs vs Snyk's advisory-only flow — every finding leaves the inbox as a tested patch PR ready for review or auto-merge, not a dashboard item someone has to triage.",
    rows: FLAG_BOTS_ROWS,
    caveat: FLAG_CAVEAT,
    ctaSubline:
      'Plug Bivouc alongside your Snyk feed. The same advisories land in a tested PR instead of a queue — Snyk keeps the watch, Bivouc owns the patch.',
    researchTab: 'flag-bots',
  },
  'copilot-autofix': {
    slug: 'copilot-autofix',
    name: 'GitHub Copilot Autofix',
    navLabel: 'Bivouac vs Copilot Autofix',
    tagline: 'On-demand triggers vs a 24/7 dependency agent.',
    oneLiner:
      "Bivouc acts 24/7 vs Copilot Autofix's on-demand trigger — Copilot Autofix fixes the CVE you opened it on; Bivouc discovers and patches every dependency signal in your tree without anyone opening a ticket.",
    rows: FIX_BOTS_ROWS,
    caveat: FIX_CAVEAT,
    ctaSubline:
      'Watch one repo for a week. Let Bivouc surface the CVEs and upstream breaks Copilot Autofix never sees — auto-merge on green, page only on the contested outcomes.',
    researchTab: 'fix-bots',
  },
  'copilot-coding-agent': {
    slug: 'copilot-coding-agent',
    name: 'GitHub Copilot Coding Agent',
    navLabel: 'Bivouac vs Copilot Coding Agent',
    tagline: 'A general-purpose coding agent vs a 24/7 dependency specialist.',
    oneLiner:
      'Bivouc vs Copilot Coding Agent — the agent writes features, refactors, and chases arbitrary issues while the dependency queue grows. Bivouc owns the dependency scope end to end so the CVE patch never waits behind a feature task or a refactor PR.',
    rows: FIX_BOTS_ROWS,
    caveat: FIX_CAVEAT,
    ctaSubline:
      'Watch one repo for a sprint. Let Bivouc own the dependency queue while Copilot Coding Agent keeps writing features — same CVE coverage, narrower scope, audit-ready trail.',
    researchTab: 'fix-bots',
  },
};

/** Short headline for /vs hub cards — punchier than `oneLiner`. */
export const competitorHeadlines: Record<CompetitorSlug, string> = {
  dependabot: 'Less weekly PR sprawl. Decided locally, merged on green tests.',
  renovate: 'Auto-merge on green. Renovation decides? The test suite does.',
  'snyk-oss': 'Advisories become tested PRs. Snyk keeps the watch.',
  'copilot-autofix': 'A 24/7 dependency agent — not an on-demand code writer.',
  'copilot-coding-agent': 'A dependency specialist — not a general-purpose code writer.',
};

/**
 * Compact cell form for the /vs hub matrix — one short Bivouac + competitor
 * pair per dimension. Derived from `profile.rows` so the deep page and the
 * hub matrix share one authored source. Each cell is truncated to the first
 * sentence of the row text; flag-bots competitors intentionally read the same
 * here (their research is shared — the deep page distinguishes them).
 */
export type MatrixPair = { bivouac: string; competitor: string };
export type MatrixSummary = {
  triggerCadence: MatrixPair;
  decisionMaking: MatrixPair;
  onCallAudit: MatrixPair;
};

const MATRIX_MAX_LEN = 90;

function firstSentence(text: string): string {
  const cut = text.indexOf('. ');
  const trimmed = (cut >= 0 ? text.slice(0, cut + 1) : text).trim();
  return trimmed.length <= MATRIX_MAX_LEN
    ? trimmed
    : `${trimmed.slice(0, MATRIX_MAX_LEN - 1).trimEnd()}…`;
}

export function matrixSummary(profile: CompetitorProfile): MatrixSummary {
  return {
    triggerCadence: {
      bivouac: firstSentence(profile.rows[0].bivouc),
      competitor: firstSentence(profile.rows[0].competitor),
    },
    decisionMaking: {
      bivouac: firstSentence(profile.rows[1].bivouc),
      competitor: firstSentence(profile.rows[1].competitor),
    },
    onCallAudit: {
      bivouac: firstSentence(profile.rows[2].bivouc),
      competitor: firstSentence(profile.rows[2].competitor),
    },
  };
}
