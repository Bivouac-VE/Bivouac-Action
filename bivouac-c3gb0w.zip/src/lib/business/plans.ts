// @polsia:user-owned — typed plan catalog for Bivouac's public pricing.
// Pure data: no server-only, no Prisma, no fetch. Imported by both the
// /pricing page island (for rendering) and the /api/checkout route handler
// (for server-side pricing). The single source of truth for the live plan set.

import type { PricingPlan } from '@/lib/contracts/pricing';

const FREE: PricingPlan = {
  slug: 'free',
  name: 'Free',
  eyebrow: '1 active repo · no card required',
  monthlyPerRepoUsd: 0,
  includedActiveRepos: 1,
  features: [
    {
      label: 'Continuous dependency watch',
      body: 'GitHub repo + lockfile scan against public advisory feeds every five minutes.',
    },
    {
      label: 'Manual patch PRs',
      body: 'Agent opens a draft PR with the chosen SemVer bump and rationale. You review and merge on your terms — no auto-merge scope on Free.',
    },
    {
      label: 'Standard SLA',
      body: 'Goal times from disclosure to fix-attempted, broken down by severity.',
    },
  ],
  slaAddons: [],
  ctaLabel: 'Start free',
  priceFootnote: 'free forever for your first repo · no card required',
};

const STARTER: PricingPlan = {
  slug: 'starter',
  name: 'Starter',
  eyebrow: 'Up to 5 active repos',
  monthlyPerRepoUsd: 19,
  includedActiveRepos: 5,
  features: [
    {
      label: 'Continuous dependency watch',
      body: 'GitHub repo + lockfile scan against public advisory feeds every five minutes.',
    },
    {
      label: 'Forward-fix patch PRs',
      body: 'Agent opens a draft PR with the chosen SemVer bump, rationale, and pre-pinned references.',
    },
    {
      label: 'Test-suite gate',
      body: 'Project test suite runs on a clean checkout. Red blocks the merge — every widening of the auto-merge scope is opt-in per repo.',
    },
    {
      label: 'Standard SLA',
      body: 'Goal times from disclosure to fix-attempted, broken down by severity. Pages the on-call rotation on contested decisions.',
    },
  ],
  slaAddons: [],
  ctaLabel: 'Subscribe',
  priceFootnote: 'billed monthly per active repository',
};

const TEAM: PricingPlan = {
  slug: 'team',
  name: 'Team',
  eyebrow: 'Up to 25 active repos · private advisory feeds',
  monthlyPerRepoUsd: 39,
  includedActiveRepos: 25,
  features: [
    {
      label: 'Continuous dependency watch',
      body: 'GitHub repo + lockfile scan against public AND private advisory feeds every five minutes.',
    },
    {
      label: 'Autonomous patch-and-merge',
      body: 'Agent opens, tests, and merges the patch PR unattended for surfaces your policy pack classifies as routine.',
      highlight: 'autonomous-patch',
    },
    {
      label: 'Downgrade-as-fix',
      body: 'On a regression or breaking upstream cut, the agent may downgrade or pin instead of forward-fixing — chosen locally, tested, and merged without paging the on-call.',
      highlight: 'downgrade-as-fix',
    },
    {
      label: 'Multi-repo policy packs',
      body: 'Shared guardrails and severity rules across every repo in the org, surfaced in the audit log for evidence.',
    },
    {
      label: 'Compress SLA',
      body: 'Goal times drop on critical severity. Pages only on contested license or security-sensitive surfaces.',
    },
  ],
  slaAddons: [
    {
      badge: '+24h critical SLA',
      tooltip: 'Critical-severity disclosures land in a merged fix within 24 hours end-to-end.',
    },
    {
      badge: '+business-hours paging',
      tooltip:
        'On-call rotations for contested decisions during business hours, with full audit trail.',
    },
  ],
  ctaLabel: 'Subscribe',
  priceFootnote: 'billed monthly per active repository',
};

const ENTERPRISE: PricingPlan = {
  slug: 'enterprise',
  name: 'Enterprise',
  eyebrow: 'Unlimited repos · dedicated routing',
  monthlyPerRepoUsd: 99,
  includedActiveRepos: 'unlimited',
  features: [
    {
      label: 'Continuous dependency watch',
      body: 'Private feeds, supply-chain provenance scoring, and registry-level disclosures before your scanner catches up.',
    },
    {
      label: 'Autonomous patch-and-merge',
      body: 'Widened auto-merge scope with per-repo overrides, captured in the audit log for evidence.',
      highlight: 'autonomous-patch',
    },
    {
      label: 'Downgrade-as-fix',
      body: 'Forward fix, downgrade, or pin — chosen by Bivouac on your policy. Regression-class fixes go straight to merge.',
      highlight: 'downgrade-as-fix',
    },
    {
      label: 'Multi-repo policy packs',
      body: 'Org-wide guardrails, severity rules, and on-call routing rules. Every widening is opt-in and recorded.',
    },
    {
      label: 'SBOM provenance',
      body: 'Exportable attestation logs aligned with SOC 2, NIS2, and EU Cyber Resilience Act evidence requests — to support your SOC 2, NIS2, and EU CRA evidence workflows, not a Bivouac certification.',
    },
  ],
  slaAddons: [
    {
      badge: '+4h critical SLA',
      tooltip: 'Critical-severity disclosures land in a merged fix within 4 hours end-to-end.',
    },
    {
      badge: '24/7 paging',
      tooltip:
        'Round-the-clock on-call routing for contested decisions, license concerns, or red builds.',
    },
    {
      badge: 'Dedicated on-call routing',
      tooltip:
        'Custom paging paths per team, per severity, per surface — engineering reviews and security review queues.',
    },
  ],
  ctaLabel: 'Talk to sales',
  priceFootnote: 'volume pricing · billed monthly per active repository',
};

export const PLANS: readonly PricingPlan[] = [FREE, STARTER, TEAM, ENTERPRISE];

export function findPlan(slug: string): PricingPlan | undefined {
  return PLANS.find((p) => p.slug === slug);
}
