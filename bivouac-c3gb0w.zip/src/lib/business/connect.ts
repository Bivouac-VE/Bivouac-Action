// @polsia:user-owned — server-only helpers for the GitHub App connect flow.
// Sits under src/lib/business/ (per nextjs-prisma rules: IDOR-prone reads +
// multi-row writes go through a business helper, not directly in the route).
//
// `persistInstallation` synchronously fetches the installation's metadata +
// selected repos from GitHub (via the App JWT helpers in src/lib/github-app)
// and writes the rows into the connect tables. It also write-throughs one
// `Repo` row per selected repo so /api/repos — which reads `Repo` — picks
// the new repos up without schema duplication.

import 'server-only';
import { prisma } from '@/lib/db';
import { getInstallation } from '@/lib/github-app/installation-meta';
import { listInstallationRepos } from '@/lib/github-app/repos';

export interface PersistArgs {
  userId: string;
  installationId: bigint;
  appCredentials: { appId: string; privateKeyB64: string };
}

export interface PersistResult {
  installationId: bigint;
  accountLogin: string;
  accountType: string;
  repoCount: number;
}

/**
 * Upsert one GitHubAppInstallation row + N GitHubAppInstallationRepo rows for
 * the given installation, and write-through one Repo row per repo so the
 * dashboard reflects real state.
 *
 * Idempotent: repeated calls with the same installationId produce the
 * same final shape.
 */
export async function persistInstallation({
  userId,
  installationId,
  appCredentials,
}: PersistArgs): Promise<PersistResult> {
  const account = await getInstallation(installationId, appCredentials);
  const repos = await listInstallationRepos(installationId, appCredentials);

  await prisma.gitHubAppInstallation.upsert({
    where: { installationId },
    create: {
      installationId,
      userId,
      accountLogin: account.login,
      accountType: account.type,
      installedAt: new Date(),
      uninstalledAt: null,
    },
    update: {
      // Re-install on the same account re-binds the installation to the
      // current user. Un-installs are tracked separately on the row.
      userId,
      accountLogin: account.login,
      accountType: account.type,
      uninstalledAt: null,
    },
  });

  // Replace the per-repo selection set so the row matches what the user
  // most recently picked. Stale rows for the previous selection get removed.
  const githubRepoIds = repos.map((r) => r.githubRepoId);
  await prisma.$transaction(async (tx) => {
    if (githubRepoIds.length > 0) {
      await tx.gitHubAppInstallationRepo.deleteMany({
        where: {
          installationId,
          githubRepoId: { notIn: githubRepoIds },
        },
      });
    } else {
      await tx.gitHubAppInstallationRepo.deleteMany({
        where: { installationId },
      });
    }
    for (const r of repos) {
      await tx.gitHubAppInstallationRepo.upsert({
        where: { githubNodeId: r.githubNodeId },
        create: {
          installationId,
          userId,
          githubRepoId: r.githubRepoId,
          githubNodeId: r.githubNodeId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
          selectedAt: new Date(),
        },
        update: {
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
        },
      });
      // Write-through to the dashboard's Repo table. Idempotent on
      // githubNodeId (which already carries the @unique). Default
      // status = HEALTHY, lastScannedAt null until the scanner runs.
      await tx.repo.upsert({
        where: { githubNodeId: r.githubNodeId },
        create: {
          userId,
          githubNodeId: r.githubNodeId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
          status: 'HEALTHY',
          lastScannedAt: null,
        },
        update: {
          // Name/owner can change upstream — refresh on every re-install,
          // but leave status / lastScannedAt so we don't reset triage state.
          userId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
        },
      });
    }
  });

  return {
    installationId,
    accountLogin: account.login,
    accountType: account.type,
    repoCount: repos.length,
  };
}
