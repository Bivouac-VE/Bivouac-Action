// @polsia:user-owned — Same-origin `?returnTo` reader for the auth pages.
// Shared between /login and /signup so the open-redirect guard + default
// destination stay in lockstep. Pure function — safe to import from RSC or
// vitest (no server-only deps).

export const AUTH_RETURN_TO_DEFAULT = '/dashboard/repos';

export function readReturnTo(value: unknown): string {
  if (typeof value !== 'string') return AUTH_RETURN_TO_DEFAULT;
  if (!value.startsWith('/') || value.startsWith('//')) return AUTH_RETURN_TO_DEFAULT;
  return value;
}

export function firstReturnTo(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}
