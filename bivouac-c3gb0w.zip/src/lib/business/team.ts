// @polsia:user-owned — server-only team business logic. Prisma reads live here
// (NOT in route handlers — same convention as src/lib/business/billing.ts) so
// the route handlers stay thin and the tier-gate check is co-located with the
// role catalog. Marked server-only at the top so 'use client' files will fail
// the build if they ever try to import it.
//
// The role CATALOG (ROLE_TONE) lives in src/lib/contracts/team.ts so client
// islands can read it without dragging a Prisma import across the server-only
// boundary.

import 'server-only';
import { prisma } from '@/lib/db';

/**
 * Tier-gate check. Team page is gated to Team-tier OR Enterprise-tier (Starter
 * callers see the empty-state CTA → /pricing, never the admin UI).
 */
export type TierGate = 'ok' | 'no-plan' | 'wrong-tier';

const TEAM_ELIGIBLE = new Set(['team', 'enterprise']);

export async function checkTeamTier(userId: string): Promise<TierGate> {
  const plan = await prisma.billingPlan.findUnique({
    where: { userId },
    select: { slug: true, status: true },
  });
  if (!plan) return 'no-plan';
  if (plan.status === 'CANCELLED') return 'no-plan';
  if (!TEAM_ELIGIBLE.has(plan.slug)) return 'wrong-tier';
  return 'ok';
}

/**
 * Per-team admin gate. Reads the caller's Membership row (if any) and returns
 * `true` only when role === 'admin'. This is the TEAM-specific admin check —
 * NOT the platform-admin check in `@/lib/require-admin`. A starter-tier user
 * with no Membership will correctly resolve to `false`.
 *
 * Idempotent / safe to call multiple times within a single request.
 */
export async function isTeamAdmin(userId: string): Promise<boolean> {
  const row = await prisma.membership.findUnique({
    where: { userId },
    select: { role: true },
  });
  return row?.role === 'admin';
}
