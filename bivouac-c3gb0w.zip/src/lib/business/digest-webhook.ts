// @polsia:user-owned — server-only helpers shared by the daily-digest cron
// (jobs/daily-digest.js, via src/lib/server/digest-webhook.cjs) and the
// /api/digest-webhook/* route handlers. Pure logic only — no Prisma, no
// network I/O. Everything here runs inside the `server-only` envelope so a
// stray client import fails the build at the lint gate.

import 'server-only';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const MAX_URL_LENGTH = 165;

const PRIVATE_IPV4_PATTERNS: Array<{ family: 'ipv4'; test: (parts: number[]) => boolean }> = [
  { family: 'ipv4', test: (p) => (p[0] ?? 0) === 127 },
  { family: 'ipv4', test: (p) => (p[0] ?? 0) === 10 },
  {
    family: 'ipv4',
    test: (p) => (p[0] ?? 0) === 172 && (p[1] ?? 0) >= 16 && (p[1] ?? 0) <= 31,
  },
  { family: 'ipv4', test: (p) => (p[0] ?? 0) === 192 && (p[1] ?? 0) === 168 },
  { family: 'ipv4', test: (p) => (p[0] ?? 0) === 169 && (p[1] ?? 0) === 254 },
  { family: 'ipv4', test: (p) => (p[0] ?? 0) === 0 },
  // 100.64.0.0/10 — carrier-grade NAT (RFC 6598)
  {
    family: 'ipv4',
    test: (p) => (p[0] ?? 0) === 100 && (p[1] ?? 0) >= 64 && (p[1] ?? 0) <= 127,
  },
];

const PRIVATE_IPV6_PATTERNS: Array<(hex: string) => boolean> = [
  // Loopback ::1
  (h) => h === '00000000000000000000000000000001' || h === '1',
  // Unique-local fc00::/7
  (h) => h.startsWith('fc') || h.startsWith('fd'),
  // Link-local fe80::/10
  (h) => h.startsWith('fe8') || h.startsWith('fe9') || h.startsWith('fea') || h.startsWith('feb'),
  // IPv4-mapped IPv6 (::ffff:a.b.c.d)
  (h) => h.startsWith('00000000000000000000ffff'),
  // Multicast ff00::/8
  (h) => h.startsWith('ff'),
  // Unspecified ::
  (h) => h === '00000000000000000000000000000000' || h === '0',
];

export type UrlValidation = { ok: true; url: URL; host: string } | { ok: false; reason: string };

export interface ValidateOpts {
  /// Deploy's own hostname — must NOT match (loopback pivot to the host).
  selfHost?: string | null;
  /// When provided, used INSTEAD of DNS to lookup the host. Strict shape:
  /// for a hostname, return a list of resolved addresses; for an IP literal,
  /// return a single address. Throwing skips the SSRF check (we record but
  /// allow — same shape DNS uses).
  resolveHost?: (host: string) => Promise<string[]> | string[];
}

/** Validate an outbound webhook URL.
 *
 *  - HTTPS only (no http://, no javascript:, no data:).
 *  - Max 165 chars (matches contract).
 *  - Host must NOT be a literal IPv4 in a private/loopback/link-local/CGNAT
 *    range, nor an IPv6 in a private/loopback/link-local/multicast range.
 *  - For hostnames, run the host through `resolveHost` (defaults to dns.lookup)
 *    — if ANY resolved address is in the deny list, reject.
 *  - Must NOT equal the deploy's own hostname (case-insensitive).
 */
export async function validateOutboundUrl(
  rawUrl: string,
  opts: ValidateOpts = {},
): Promise<UrlValidation> {
  if (typeof rawUrl !== 'string' || rawUrl.length === 0) {
    return { ok: false, reason: 'URL is required.' };
  }
  if (rawUrl.length > MAX_URL_LENGTH) {
    return { ok: false, reason: `URL must be ${MAX_URL_LENGTH} characters or fewer.` };
  }
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return { ok: false, reason: 'URL could not be parsed.' };
  }
  if (parsed.protocol !== 'https:') {
    return { ok: false, reason: 'URL must use https.' };
  }
  const host = parsed.hostname.trim().toLowerCase();
  if (host.length === 0) {
    return { ok: false, reason: 'URL has no host.' };
  }

  if (opts.selfHost && host === opts.selfHost.trim().toLowerCase()) {
    return { ok: false, reason: 'URL must not point at this app.' };
  }

  // IP literal — validate directly, no DNS.
  const literalFamily = detectLiteralFamily(host);
  if (literalFamily === 'ipv4') {
    const parts = host.split('.').map(Number);
    for (const rule of PRIVATE_IPV4_PATTERNS) {
      if (rule.test(parts)) {
        return { ok: false, reason: 'URL resolves to a private network address.' };
      }
    }
    return { ok: true, url: parsed, host };
  }
  if (literalFamily === 'ipv6') {
    const normalized = normalizeIpv6(host);
    for (const rule of PRIVATE_IPV6_PATTERNS) {
      if (rule(normalized)) {
        return { ok: false, reason: 'URL resolves to a private network address.' };
      }
    }
    return { ok: true, url: parsed, host };
  }

  // Hostname — resolve and check every returned address.
  let resolved: string[];
  try {
    if (opts.resolveHost) {
      const out = await opts.resolveHost(host);
      resolved = Array.isArray(out) ? out : [out];
    } else {
      const dns = await import('node:dns');
      resolved = await new Promise<string[]>((accept, reject) => {
        dns.lookup(host, { all: true, verbatim: true }, (err, addrs) => {
          if (err) reject(err);
          else accept(addrs.map((a) => a.address));
        });
      });
    }
  } catch {
    // DNS failure — don't silently allow; surface as a validation error.
    return { ok: false, reason: 'URL host could not be resolved.' };
  }

  for (const addr of resolved) {
    const fam = detectLiteralFamily(addr);
    if (fam === 'ipv4') {
      const parts = addr.split('.').map(Number);
      for (const rule of PRIVATE_IPV4_PATTERNS) {
        if (rule.test(parts)) {
          return { ok: false, reason: 'URL resolves to a private network address.' };
        }
      }
    } else if (fam === 'ipv6') {
      const normalized = normalizeIpv6(addr);
      for (const rule of PRIVATE_IPV6_PATTERNS) {
        if (rule(normalized)) {
          return { ok: false, reason: 'URL resolves to a private network address.' };
        }
      }
    }
  }

  return { ok: true, url: parsed, host };
}

function detectLiteralFamily(host: string): 'ipv4' | 'ipv6' | 'name' {
  if (/^[\d.]+$/.test(host)) {
    const parts = host.split('.');
    if (
      parts.length === 4 &&
      parts.every((p) => Number.isFinite(Number(p)) && Number(p) >= 0 && Number(p) <= 255)
    ) {
      return 'ipv4';
    }
  }
  // Strip a bracketed IPv6 — Node URL already strips brackets, but a literal
  // pasted before URL parsing may have any case folding.
  const stripped = host.replace(/^\[|\]$/g, '');
  if (stripped.includes(':')) return 'ipv6';
  return 'name';
}

function normalizeIpv6(host: string): string {
  // Expand `::` shorthand into 8 16-bit groups, lowercased.
  const stripped = host.replace(/^\[|\]$/g, '');
  const sides = stripped.split('::');
  const left = sides[0] ? sides[0].split(':') : [];
  const right = sides[1] ? sides[1].split(':') : [];
  const fill = Array.from({ length: 8 - left.length - right.length }, () => '0');
  const groups = [...left, ...fill, ...right];
  return groups.map((g) => g.padStart(4, '0').toLowerCase()).join('');
}

/// Hex(HMAC-SHA256(body, secret)).  Constant-time compare only on equal-length
/// buffers — caller must pad / truncate accordingly.
export function signPayload(secret: string, body: string): string {
  return createHmac('sha256', secret).update(body, 'utf8').digest('hex');
}

/// Wrap signPayload for receivers that want a `sha256=<hex>` style header value
/// without exposing the secret.
export function signPayloadForHeader(secret: string, body: string): string {
  return `sha256=${signPayload(secret, body)}`;
}

/// Generate a fresh 32-byte hex signing secret. Idempotent across calls in
/// different processes — randomness is per-call.
export function generateSigningSecret(): string {
  return randomBytes(32).toString('hex');
}

/// Constant-time compare of two hex digests.
export function safeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
  } catch {
    return false;
  }
}

/// Truncate the URL for display in the deliveries table so the UI doesn't
/// need to crop again. Preserves scheme + host, then a path head.
export function previewUrl(url: string, max: number = 60): string {
  if (!url) return '';
  if (url.length <= max) return url;
  return `${url.slice(0, max - 1)}…`;
}

/// Truncate a free-text error for the deliveries table.
export function previewError(message: string | null | undefined, max: number = 140): string | null {
  if (!message) return null;
  if (message.length <= max) return message;
  return `${message.slice(0, max - 1)}…`;
}

/// Today's UTC date `YYYY-MM-DD`. Stable for the duration of a cron run.
export function todayUtcString(now: Date = new Date()): string {
  return now.toISOString().slice(0, 10);
}

/// Composes a per-(webhook, day) `runDay` value. Cron-driven rows use the
/// literal UTC date; the manual test ping uses `canary-<ISO timestamp>` so
/// each click writes a distinct row in `DigestDelivery`.
export function canaryRunDay(now: Date = new Date()): string {
  return `canary-${now.toISOString()}`;
}
