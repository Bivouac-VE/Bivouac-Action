// @polsia:user-owned — server-only helpers for the /insights dashboard.
// Each `load*` function takes the signed-in user's id and a `rangeDays`
// (7 | 30 | 90); every Prisma read is scoped to the user's connected repos
// via prUrl-contains OR clauses, matching how `listAudit` already reads the
// same table. If the user has zero connected repos, all helpers short-circuit
// to zeros so an empty OR() never scans globally.

import 'server-only';
import { deriveSeverity } from '@/lib/business/patches';
import type {
  InsightsOverview,
  InsightsRangeDays,
  PatchesByWeekPoint,
  SeverityBucket,
} from '@/lib/contracts/insights';
import { PatchesByWeekSeries, SeverityBreakdownSeries } from '@/lib/contracts/insights';
import { prisma } from '@/lib/db';

// Pin: human-override rate counts only the cron-emitted MANUAL_REVIEW decision
// (= "tests did not pass, a human was paged"). BLOCKED is treated separately
// because it represents "tests/agent errored, never tried to merge".
const TERMINAL_DECISIONS = new Set(['AUTO_MERGE', 'MANUAL_REVIEW', 'BLOCKED']);

function rangeWindow(now: Date, rangeDays: InsightsRangeDays): { start: Date; end: Date } {
  const end = new Date(now);
  const start = new Date(now);
  start.setUTCDate(start.getUTCDate() - rangeDays);
  return { start, end };
}

// Build the { AND: [ date, OR: repoSlug prUrl-contains ] } clause shared by
// every load* function. Returns null when the user has zero repos so callers
// can short-circuit to zero-data instead of issuing a global scan.
async function buildScopedWhere(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<{ AND: Array<Record<string, unknown>> } | null> {
  const repos = await prisma.repo.findMany({
    where: { userId },
    select: { ownerHandle: true, name: true },
  });
  const { start, end } = rangeWindow(new Date(), rangeDays);
  if (repos.length === 0) return null;
  const repoClauses = repos.map((r) => ({ prUrl: { contains: `${r.ownerHandle}/${r.name}` } }));
  return {
    AND: [{ createdAt: { gte: start, lte: end } }, { OR: repoClauses }],
  };
}

function fmtPercent(numerator: number, denominator: number): string {
  if (denominator === 0) return '—';
  return `${Math.round((numerator / denominator) * 100)}%`;
}

function fmtDurationDays(days: number): string {
  if (days < 1) {
    const hours = Math.round(days * 24);
    return hours <= 1 ? '<1h' : `${hours}h`;
  }
  if (days < 14) return `${Math.round(days)}d`;
  const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto', style: 'short' });
  if (days < 60) return rtf.format(-Math.round(days), 'day');
  const months = Math.round(days / 30);
  return rtf.format(-months, 'month');
}

export async function loadInsightsOverview(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<InsightsOverview> {
  const where = await buildScopedWhere(userId, rangeDays);
  const connectedRepoCount = await prisma.repo.count({ where: { userId } });

  if (!where) {
    return {
      rangeDays,
      connectedRepoCount,
      numerics: {
        patchesOpened: 0,
        autoMergeCount: 0,
        manualReviewCount: 0,
        blockedCount: 0,
        mttpDays: null,
      },
      tiles: {
        mttp: { label: 'Mean time to patch', value: '—', hint: 'No patches in this window' },
        patchesOpened: { label: 'Patches opened', value: '0', hint: `Last ${rangeDays} days` },
        autoMergeRate: {
          label: 'Auto-merge rate',
          value: '—',
          hint: 'No patches in this window',
        },
        humanOverrideRate: {
          label: 'Human-override rate',
          value: '—',
          hint: 'No patches in this window',
        },
      },
    };
  }

  const rows = await prisma.cveTriageLog.findMany({
    where,
    select: {
      id: true,
      cveId: true,
      createdAt: true,
      mergeDecision: true,
    },
  });

  const total = rows.length;
  let auto = 0;
  let manual = 0;
  let blocked = 0;
  let ageSumMs = 0;
  let ageCount = 0;
  const now = Date.now();
  for (const row of rows) {
    if (row.mergeDecision === 'AUTO_MERGE') auto += 1;
    else if (row.mergeDecision === 'MANUAL_REVIEW') manual += 1;
    else if (row.mergeDecision === 'BLOCKED') blocked += 1;
    if (TERMINAL_DECISIONS.has(row.mergeDecision)) {
      ageSumMs += now - row.createdAt.getTime();
      ageCount += 1;
    }
  }
  const mttpDays = ageCount === 0 ? null : ageSumMs / ageCount / (1000 * 60 * 60 * 24);

  const mttpTile = {
    label: 'Mean time to patch',
    value: mttpDays === null ? '—' : fmtDurationDays(mttpDays),
    hint:
      mttpDays === null
        ? 'No patches in this window'
        : `Over ${total} patch${total === 1 ? '' : 'es'}`,
  };
  const patchesTile = {
    label: 'Patches opened',
    value: total.toString(),
    hint: `Last ${rangeDays} days`,
  };
  const autoTile = {
    label: 'Auto-merge rate',
    value: fmtPercent(auto, total),
    hint: total === 0 ? 'No patches in this window' : `${auto} of ${total} merged without review`,
  };
  const humanTile = {
    label: 'Human-override rate',
    value: fmtPercent(manual, total),
    hint: total === 0 ? 'No patches in this window' : `${manual} of ${total} paged a human`,
  };

  return {
    rangeDays,
    connectedRepoCount,
    numerics: {
      patchesOpened: total,
      autoMergeCount: auto,
      manualReviewCount: manual,
      blockedCount: blocked,
      mttpDays,
    },
    tiles: {
      mttp: mttpTile,
      patchesOpened: patchesTile,
      autoMergeRate: autoTile,
      humanOverrideRate: humanTile,
    },
  };
}

// Bucket counts by ISO week (Monday-anchored). The window is zero-padded with
// empty buckets so the X-axis reads as a continuous timeline even when the
// cron hasn't opened any PRs that week.
function weekStartOf(date: Date): Date {
  const d = new Date(date);
  d.setUTCHours(0, 0, 0, 0);
  const day = d.getUTCDay(); // 0 (Sun) .. 6 (Sat)
  const diff = (day + 6) % 7; // Monday = 0
  d.setUTCDate(d.getUTCDate() - diff);
  return d;
}

function isoDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function enumerateWeeks(start: Date, end: Date): Date[] {
  const weeks: Date[] = [];
  const cursor = weekStartOf(start);
  const last = weekStartOf(end);
  while (cursor.getTime() <= last.getTime()) {
    weeks.push(new Date(cursor));
    cursor.setUTCDate(cursor.getUTCDate() + 7);
  }
  return weeks;
}

export async function loadPatchesByWeek(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<PatchesByWeekSeries> {
  const where = await buildScopedWhere(userId, rangeDays);
  const { start, end } = rangeWindow(new Date(), rangeDays);

  if (!where) {
    const weeks = enumerateWeeks(start, end);
    return {
      rangeDays,
      points: weeks.map((w) => ({ weekStart: isoDate(w), count: 0 })),
    };
  }

  const rows = await prisma.cveTriageLog.findMany({
    where,
    select: { createdAt: true },
  });

  const buckets = new Map<string, number>();
  for (const w of enumerateWeeks(start, end)) {
    buckets.set(isoDate(w), 0);
  }
  for (const row of rows) {
    const key = isoDate(weekStartOf(row.createdAt));
    buckets.set(key, (buckets.get(key) ?? 0) + 1);
  }
  const points: PatchesByWeekPoint[] = Array.from(buckets.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([weekStart, count]) => ({ weekStart, count }));

  return PatchesByWeekSeries.parse({ rangeDays, points });
}

export async function loadSeverityBreakdown(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<typeof SeverityBreakdownSeries._type> {
  const where = await buildScopedWhere(userId, rangeDays);

  if (!where) {
    const points: { severity: SeverityBucket; count: number }[] = [
      { severity: 'low', count: 0 },
      { severity: 'medium', count: 0 },
      { severity: 'high', count: 0 },
      { severity: 'critical', count: 0 },
    ];
    return SeverityBreakdownSeries.parse({ rangeDays, points });
  }

  const rows = await prisma.cveTriageLog.findMany({
    where,
    select: { cveId: true },
  });

  const counts: Record<SeverityBucket, number> = { low: 0, medium: 0, high: 0, critical: 0 };
  for (const row of rows) {
    const sev = deriveSeverity(row.cveId ?? '');
    counts[sev] += 1;
  }
  const points: { severity: SeverityBucket; count: number }[] = [
    { severity: 'low', count: counts.low },
    { severity: 'medium', count: counts.medium },
    { severity: 'high', count: counts.high },
    { severity: 'critical', count: counts.critical },
  ];
  return SeverityBreakdownSeries.parse({ rangeDays, points });
}
