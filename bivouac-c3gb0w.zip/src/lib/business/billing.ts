// @polsia:user-owned — server-only billing helpers for the authenticated
// "change plan" flow on both /dashboard/billing and /settings/billing.
// SINGLE PLACE where prices are decided — prices must NEVER be read from the
// browser; the route handlers call resolvePlanQuote() and pass amountUsd into
// createCheckoutSession.
//
// Pure data + Prisma-safe computation. Pricing rule:
//   totalUsd = plan.monthlyPerRepoUsd * repoCount + sum(addons)
// A paid-tier checkout with zero connected repos is rejected (returns null)
// so the buyer doesn't end up billed $0. The free tier (monthlyPerRepoUsd =
// 0) bypasses the repoCount guard and resolves to a $0 quote for symmetry.

import 'server-only';
import { findPlan } from '@/lib/business/plans';
import type { BillingAddonSlug, BillingPlanSlug } from '@/lib/contracts/billing';
import type { PricingPlan, PricingPlanSlug } from '@/lib/contracts/pricing';

// Server-side pricing for the SLA badges sold on /pricing. Lives here (not in
// src/lib/business/plans.ts) because these are the *subscription add-on*
// prices, not the free-form catalog. Kept as a const so a typo is a type error.
const ADDON_MONTHLY_USD: Record<BillingAddonSlug, number> = {
  '+24h-critical-sla': 199,
  '+business-hours-paging': 149,
};

const ADDON_LABELS: Record<BillingAddonSlug, string> = {
  '+24h-critical-sla': '+24h critical SLA',
  '+business-hours-paging': '+business-hours paging',
};

export interface PlanQuote {
  planSlug: PricingPlanSlug;
  base: PricingPlan;
  addons: Array<{
    slug: BillingAddonSlug;
    label: string;
    monthlyUsd: number;
  }>;
  totalUsd: number;
  repoLimit: number | null;
  paidRepoCount: number;
}

export function resolvePlanQuote(
  planSlug: BillingPlanSlug,
  addonSlugs: readonly BillingAddonSlug[] = [],
  repoCount: number = 0,
): PlanQuote | null {
  const plan = findPlan(planSlug);
  if (!plan) return null;

  // De-dupe addons defensively; preserve the user's order so the line item
  // summary on the Stripe checkout is stable. Sum from the deduped list so a
  // duplicate input slug does not double-count.
  const seen = new Set<BillingAddonSlug>();
  const addons: PlanQuote['addons'] = [];
  for (const slug of addonSlugs) {
    if (seen.has(slug)) continue;
    seen.add(slug);
    addons.push({
      slug,
      label: ADDON_LABELS[slug],
      monthlyUsd: ADDON_MONTHLY_USD[slug],
    });
  }
  const addonTotalUsd = addons.reduce((s, a) => s + a.monthlyUsd, 0);
  const repoLimit = plan.includedActiveRepos === 'unlimited' ? null : plan.includedActiveRepos;

  // Free tier: zero per-repo, no repoCount guard. Resolves to a $0 (+
  // addons) quote so the caller renders the Free plan row without erroring.
  if (plan.monthlyPerRepoUsd === 0) {
    return {
      planSlug,
      base: plan,
      addons,
      totalUsd: addonTotalUsd,
      repoLimit,
      paidRepoCount: repoCount,
    };
  }

  // Paid tier: require a positive integer repo count — a paid plan cannot be
  // billed against zero repos. The route surfaces this as a 400 invalid_plan.
  if (!Number.isInteger(repoCount) || repoCount < 1) return null;

  const totalUsd = plan.monthlyPerRepoUsd * repoCount + addonTotalUsd;
  return { planSlug, base: plan, addons, totalUsd, repoLimit, paidRepoCount: repoCount };
}
