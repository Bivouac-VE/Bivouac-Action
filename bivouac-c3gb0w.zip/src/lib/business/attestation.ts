// @polsia:user-owned — server-only helpers for the /attestation export.
// Pulls the user's connected repos, the CveTriageLog rows in a quarter window
// (scoped via the same prUrl-contains OR-set the audit log uses), and joins
// the matching HumanOverride annotations into each merge-decision row.
// `import 'server-only'` so a stray client import fails at the build/lint gate
// rather than leaking Prisma through the data plane.

import 'server-only';
import { createHash } from 'node:crypto';
import { deriveSeverity } from '@/lib/business/patches';
import type {
  AttestationBundle,
  AttestationMeta,
  AttestationSummary,
  MttpMetric,
  PatchEvent,
  PolicyVersion,
  QuarterId,
  SbomSummary,
  SeverityCounts,
} from '@/lib/contracts/attestation';
import {
  AttestationBundle as AttestationBundleSchema,
  AttestationSummary as AttestationSummarySchema,
  SbomSummary as SbomSummarySchema,
} from '@/lib/contracts/attestation';
import { prisma } from '@/lib/db';

// Mirrors insights.ts: terminal-decision rows contribute to mean-time-to-patch.
const TERMINAL_DECISIONS = new Set(['AUTO_MERGE', 'MANUAL_REVIEW', 'BLOCKED']);

const ANNOTATION_OVERRIDE_DECISIONS = new Set(['MANUAL_REVIEW', 'BLOCKED']);

const MTTP_DERIVATION =
  'Mean of (now - createdAt) for terminal-decision rows (AUTO_MERGE|MANUAL_REVIEW|BLOCKED) in the quarter, expressed in days.';

// Inclusive UTC start…inclusive UTC end for a quarter id.
export function quarterBounds(quarter: QuarterId): { startUtc: Date; endUtc: Date } {
  const match = /^(\d{4})-Q([1-4])$/.exec(quarter);
  if (!match) {
    throw new Error(`Invalid quarter id: ${quarter}`);
  }
  const yearStr = match[1];
  const qNumStr = match[2];
  if (yearStr === undefined || qNumStr === undefined) {
    // The regex above guarantees both groups captured on success.
    throw new Error(`Invalid quarter id: ${quarter}`);
  }
  const year = Number.parseInt(yearStr, 10);
  const qNum = Number.parseInt(qNumStr, 10);
  const startMonth = (qNum - 1) * 3; // 0, 3, 6, 9
  const endMonth = startMonth + 3; // exclusive end-month
  const startUtc = new Date(Date.UTC(year, startMonth, 1, 0, 0, 0, 0));
  const endUtc = new Date(Date.UTC(year, endMonth, 1, 0, 0, 0, 0));
  return { startUtc, endUtc };
}

// Inclusive end. Use a < endUtc in SQL to keep Q1 ending at the last ms of March.
function inclusiveMsBeforeExclusive(bound: Date): Date {
  return new Date(bound.getTime() - 1);
}

// Convert any quarter-bearing UTC day into its `YYYY-QN` bucket.
function quarterIdForDate(date: Date): QuarterId {
  const month = date.getUTCMonth();
  const qNum = Math.floor(month / 3) + 1;
  return `${date.getUTCFullYear()}-Q${qNum}` as QuarterId;
}

// Distinct quarters the user has data for, computed as the union of:
//  1. The quarters containing any of the user's CveTriageLog.createdAt scoped via
//     prUrl-contains OR-clauses.
//  2. The quarters containing any PolicyVersion.effectiveFrom (so a brand-new
//     repo with no patches yet still offers an empty quarter to the auditor).
function uniqueQuarters(rows: QuarterId[]): QuarterId[] {
  return Array.from(new Set(rows)).sort().reverse();
}

export async function listQuartersForUser(userId: string): Promise<QuarterId[]> {
  const repos = await prisma.repo.findMany({
    where: { userId },
    select: { ownerHandle: true, name: true },
  });
  const fromTriage: QuarterId[] = [];
  if (repos.length > 0) {
    const repoClauses = repos.map((r) => ({
      prUrl: { contains: `${r.ownerHandle}/${r.name}` },
    }));
    const rows = await prisma.cveTriageLog.findMany({
      where: { OR: repoClauses },
      select: { createdAt: true },
    });
    for (const r of rows) fromTriage.push(quarterIdForDate(r.createdAt));
  }
  const policies = await prisma.policyVersion.findMany({ select: { effectiveFrom: true } });
  const fromPolicy = policies.map((p) => quarterIdForDate(p.effectiveFrom));

  // Always offer the current calendar quarter so the picker isn't empty for a
  // brand-new account. Auditors expect to see "the current period".
  const now = new Date();
  const current: QuarterId[] = [quarterIdForDate(now)];

  const all = [...fromTriage, ...fromPolicy, ...current];
  const quarters = uniqueQuarters(all);
  return quarters as QuarterId[];
}

export async function findActivePolicyVersion(
  _repoId: string,
  quarterStart: Date,
): Promise<PolicyVersion> {
  // PolicyVersion is global, not per-repo. Pick the version whose
  // [effectiveFrom, effectiveTo|∞) contains quarterStart. Ties broken by the
  // most recent effectiveFrom.
  const row = await prisma.policyVersion.findFirst({
    where: {
      effectiveFrom: { lte: quarterStart },
      OR: [{ effectiveTo: null }, { effectiveTo: { gte: quarterStart } }],
    },
    orderBy: { effectiveFrom: 'desc' },
  });
  if (row) {
    return {
      id: row.id,
      version: row.version,
      title: row.title,
      effectiveFrom: row.effectiveFrom.toISOString(),
      effectiveTo: row.effectiveTo?.toISOString() ?? null,
    };
  }
  // Synthesised "UNKNOWN" so the auditor's bundle still has a policyVersion
  // field. Better than omitting.
  return {
    id: 'synth:UNKNOWN',
    version: 'POL-UNKNOWN',
    title: 'Unversioned policy',
    effectiveFrom: quarterStart.toISOString(),
    effectiveTo: null,
  };
}

function repoSlugFromPrUrl(prUrl: string): string {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) return `${parts[0]}/${parts[1]}`;
    return '';
  } catch {
    return '';
  }
}

// Upstream-patch identifier for the audit bundle. The schema doesn't store
// the upstream fix SHA, so we echo either the PR number from the matching
// GitHub PR URL (last numeric path segment of /pull/<n>) or null when the
// URL doesn't carry one. This is stable for the same row and useful for an
// auditor linking a patch event to its source PR; it is NOT a real SHA and
// should not be treated as one when verifying the bundle hash.
function upstreamRefFromPrUrl(prUrl: string): string | null {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    const pullIdx = parts.indexOf('pull');
    if (pullIdx >= 0 && pullIdx + 1 < parts.length) {
      const candidate = parts[pullIdx + 1];
      if (candidate && /^\d+$/.test(candidate)) return candidate;
    }
    return null;
  } catch {
    return null;
  }
}

// Light ecosystem heuristic used by the SBOM rollup. Keeps the bundle honest
// without requiring a real SBOM parser.
function ecosystemForPackage(packageName: string): string {
  const lower = packageName.trim().toLowerCase();
  if (lower.startsWith('@') || lower.includes('/')) return 'npm';
  if (lower.includes('.tgz') || lower.startsWith('pip')) return 'pypi';
  return 'npm';
}

function rollupSbom(rows: PatchRow[]): SbomSummary {
  const touched = new Set<string>();
  const ecosystems: Record<string, number> = {};
  for (const r of rows) {
    touched.add(`${ecosystemForPackage(r.packageName)}::${r.packageName}`);
  }
  for (const key of touched) {
    const sepAt = key.indexOf('::');
    if (sepAt < 0) continue;
    const eco = key.slice(0, sepAt);
    ecosystems[eco] = (ecosystems[eco] ?? 0) + 1;
  }
  // We don't have a per-repo SBOM at rest, so totalPackages is the same as
  // packagesTouched for this rollup. The slot exists so a real SBOM loader
  // can later fill it without changing the consumer.
  return SbomSummarySchema.parse({
    packagesTouched: touched.size,
    totalPackages: touched.size,
    ecosystems,
  });
}

interface PatchRow {
  id: string;
  createdAt: Date;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
}

export async function listPatchEventsInQuarter(
  userId: string,
  repoId: string,
  start: Date,
  end: Date,
): Promise<PatchRow[]> {
  const repo = await prisma.repo.findFirst({
    where: { id: repoId, userId },
    select: { ownerHandle: true, name: true },
  });
  if (!repo) return [];
  return prisma.cveTriageLog.findMany({
    where: {
      AND: [
        { createdAt: { gte: start, lt: end } },
        { prUrl: { contains: `${repo.ownerHandle}/${repo.name}` } },
      ],
    },
    orderBy: [{ createdAt: 'asc' }, { cveId: 'asc' }],
  });
}

export function computeSeverityCounts(events: PatchRow[]): SeverityCounts {
  const counts: SeverityCounts = { low: 0, medium: 0, high: 0, critical: 0 };
  for (const e of events) {
    const sev = deriveSeverity(e.cveId ?? '');
    counts[sev] += 1;
  }
  return counts;
}

export function computeMttp(events: PatchRow[], asOf: Date): MttpMetric {
  let ageSumMs = 0;
  let ageCount = 0;
  for (const e of events) {
    if (TERMINAL_DECISIONS.has(e.mergeDecision)) {
      ageSumMs += asOf.getTime() - e.createdAt.getTime();
      ageCount += 1;
    }
  }
  const valueDays = ageCount === 0 ? null : ageSumMs / ageCount / (1000 * 60 * 60 * 24);
  return {
    valueDays,
    sampleSize: ageCount,
    asOf: asOf.toISOString(),
    derivation: MTTP_DERIVATION,
  };
}

function toPatchEvent(row: PatchRow): PatchEvent {
  // PatchEvent contract requires a non-null cveId; upstream-breaking rows
  // (BREAKING eventKind) carry no advisory id, so substitute an empty string
  // for the bundle -- the cveId in the CSV column is also em-dash, but the
  // contract here is the attestable surface. MTTP / severity derivations
  // return 'medium' for these, which is correct (BREAKING is its own
  // category, not a CVE).
  const cveId = row.cveId ?? '';
  return {
    id: row.id,
    createdAt: row.createdAt.toISOString(),
    cveId,
    packageName: row.packageName,
    fromVersion: row.fromVersion,
    toVersion: row.toVersion,
    severity: deriveSeverity(cveId),
    testOutcome: row.testOutcome as PatchEvent['testOutcome'],
    mergeDecision: row.mergeDecision as PatchEvent['mergeDecision'],
    repo: repoSlugFromPrUrl(row.prUrl),
    prUrl: row.prUrl,
    isHumanOverride: row.mergeDecision === 'MANUAL_REVIEW' || row.mergeDecision === 'BLOCKED',
    upstreamSha: upstreamRefFromPrUrl(row.prUrl),
  };
}

export function listOverrides(
  events: PatchRow[],
  annotations: Map<string, { actorEmail: string; reason: string; decidedAt: Date }>,
): AttestationBundle['overrides'] {
  return events
    .filter((e) => ANNOTATION_OVERRIDE_DECISIONS.has(e.mergeDecision))
    .map((e) => {
      const note = annotations.get(e.id);
      const cveId = e.cveId ?? '';
      return {
        id: e.id,
        decidedAt: (note?.decidedAt ?? e.createdAt).toISOString(),
        cveId,
        packageName: e.packageName,
        fromVersion: e.fromVersion,
        toVersion: e.toVersion,
        severity: deriveSeverity(cveId),
        repo: repoSlugFromPrUrl(e.prUrl),
        prUrl: e.prUrl,
        mergeDecision: (e.mergeDecision === 'BLOCKED' ? 'BLOCKED' : 'MANUAL_REVIEW') as
          | 'MANUAL_REVIEW'
          | 'BLOCKED',
        actorEmail: note?.actorEmail ?? null,
        reason: note?.reason ?? null,
      };
    });
}

// Recursively stringify with sorted object keys and no whitespace, so two
// structurally identical bundles yield the same hash regardless of iteration
// order in the source.
function canonicalize(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map(canonicalize).join(',')}]`;
  }
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  const body = keys.map((k) => `${JSON.stringify(k)}:${canonicalize(obj[k])}`).join(',');
  return `{${body}}`;
}

// Input shape for the hash — the bundle's "content" minus the auditor-metadata
// `generatedAt` (which shifts request-to-request and must not break the
// signature). `userId` is included so an auditor can verify who asked for
// the bundle, not just the content — a verifier can replay
// `(userId, repoId, quarter, …)` and match the hash.
export interface HashableAttestationContent {
  meta: {
    repoId: string;
    ownerHandle: string;
    name: string;
    quarter: QuarterId;
    userId: string;
    policyVersion: PolicyVersion;
  };
  counts: { patches: SeverityCounts; overrides: number };
  cveIdsRemediated: string[];
  mttp: MttpMetric;
  overrides: AttestationBundle['overrides'];
  patchEvents: AttestationBundle['patchEvents'];
  sbom: SbomSummary;
}

export function canonicalizeForHash(content: HashableAttestationContent): string {
  return canonicalize(content);
}

export function attestationHash(canonical: string): string {
  return createHash('sha256').update(canonical).digest('hex');
}

async function loadOverrideAnnotations(
  userId: string,
  cveTriageIds: string[],
): Promise<Map<string, { actorEmail: string; reason: string; decidedAt: Date }>> {
  if (cveTriageIds.length === 0) return new Map();
  const rows = await prisma.humanOverride.findMany({
    where: { userId, cveTriageId: { in: cveTriageIds } },
  });
  const out = new Map<string, { actorEmail: string; reason: string; decidedAt: Date }>();
  for (const r of rows) {
    out.set(r.cveTriageId, {
      actorEmail: r.actorEmail,
      reason: r.reason,
      decidedAt: r.decidedAt,
    });
  }
  return out;
}

// Single source for both the preview endpoint and the export endpoint. The
// preview just strips patchEvents off the same bundle — so a previewed match
// actually IS the downloaded match.
//
// Determinism: MTTP is measured against the end-of-quarter timestamp (not
// `Date.now()`), and the hash covers a stable subset of fields. `meta.generatedAt`
// shifts request-to-request by design, so it is NOT included in the hash. The
// hash payload looks like the bundle's content fields only — exactly what an
// auditor would re-sign if they were re-running the algorithm themselves.
export async function buildAttestationBundle(
  userId: string,
  repoId: string,
  quarter: QuarterId,
): Promise<AttestationBundle | null> {
  const repo = await prisma.repo.findFirst({
    where: { id: repoId, userId },
    select: { id: true, ownerHandle: true, name: true },
  });
  if (!repo) return null;

  const { startUtc, endUtc } = quarterBounds(quarter);
  const endInclusive = inclusiveMsBeforeExclusive(endUtc);
  const rows = await listPatchEventsInQuarter(userId, repoId, startUtc, endInclusive);
  const annotations = await loadOverrideAnnotations(
    userId,
    rows.map((r) => r.id),
  );

  const policy = await findActivePolicyVersion(repoId, startUtc);

  const meta: AttestationMeta = {
    repoId: repo.id,
    ownerHandle: repo.ownerHandle,
    name: repo.name,
    quarter,
    userId,
    generatedAt: new Date().toISOString(),
    policyVersion: policy,
  };

  const counts = {
    patches: computeSeverityCounts(rows),
    overrides: rows.filter((r) => ANNOTATION_OVERRIDE_DECISIONS.has(r.mergeDecision)).length,
  };

  // Preserve stable ordering before hashing so a rerun matches.
  const sortedRows = [...rows].sort((a, b) => {
    const t = a.createdAt.getTime() - b.createdAt.getTime();
    if (t !== 0) return t;
    return (a.cveId ?? '').localeCompare(b.cveId ?? '');
  });
  const overrides = listOverrides(sortedRows, annotations);
  const patchEvents = sortedRows.map(toPatchEvent);
  const cveIdsRemediated = Array.from(new Set(patchEvents.map((e) => e.cveId))).sort();
  // MTTP measured against the end of the quarter — deterministic.
  const mttp = computeMttp(sortedRows, endInclusive);
  const sbom = rollupSbom(sortedRows);

  const hashableContent = {
    // `generatedAt` is auditor metadata (shifts request-to-request by design)
    // and is omitted from the signed payload. Everything else (repo id, repo
    // slug, name, quarter, user id, policy version, severity counts, MTTP
    // including its asOf anchor, override list, patch event list, SBOM rollup)
    // is content and stays in the signed view.
    meta: {
      repoId: meta.repoId,
      ownerHandle: meta.ownerHandle,
      name: meta.name,
      quarter: meta.quarter,
      userId: meta.userId,
      policyVersion: meta.policyVersion,
    },
    counts,
    cveIdsRemediated,
    mttp,
    overrides,
    patchEvents,
    sbom,
  };
  const hash = attestationHash(canonicalizeForHash(hashableContent));

  return AttestationBundleSchema.parse({
    meta,
    counts,
    cveIdsRemediated,
    mttp,
    overrides,
    patchEvents,
    sbom,
    attestation: { hash },
  });
}

export function buildAttestationSummary(bundle: AttestationBundle): AttestationSummary {
  // Drop both the heavy patch event list AND the signed attestation block —
  // the summary stays a Cheaper payload for the picker; the hash stays on
  // the full bundle only.
  const { patchEvents: _omitEvents, attestation: _omitHash, ...summaryFields } = bundle;
  return AttestationSummarySchema.parse(summaryFields);
}
