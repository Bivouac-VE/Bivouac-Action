// @polsia:user-owned — server-only domain mapping for the patch detail
// feature. Translates the persisted `CveTriageLog` row (id, cveId, packageName,
// fromVersion, toVersion, prUrl, testOutcome, mergeDecision, createdAt) into
// the derived shape the UI consumes — adding the missing title, target repo,
// severity, synthetic diff, test log excerpt, and policy rule + rationale. No
// schema change; this is the single place where the "fields the row doesn't
// store" live.
//
// `import 'server-only'` so a stray Client import fails the build at the lint
// gate rather than leaking Prisma through the data plane.

import 'server-only';
import type {
  PatchFileStatus,
  PatchMergeState,
  PatchPolicyAction,
  PatchSeverity,
  PatchTestOutcome,
} from '@/lib/contracts/patches';
import { PatchDetail, PatchList, PatchListItem } from '@/lib/contracts/patches';
import { prisma } from '@/lib/db';

export class NotFound extends Error {
  constructor(message = 'Not Found') {
    super(message);
    this.name = 'NotFound';
  }
}

const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;

// Severity is a static derivation from the CVE id — only the small set of
// fixture CVEs this app matches against has a pre-scored tag, so triage rows
// never store it. Add to this table when a new CVE lands in the manifest.
export const SEVERITY_BY_CVE: Record<string, PatchSeverity> = {
  'CVE-2024-1001': 'high', // prototype pollution in left-pad <1.3.0
  'CVE-2024-1002': 'medium', // regression string-format bypass in tiny-validator 2.5.0
};

const SEVERITY_LABELS: Record<PatchSeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

// Persisted DB values (uppercase enums from the cron) → UI enums (lowercase).
// PENDING with no decision yet means the cron has *scheduled* the test run but
// has not yet posted the status comment — surface that as 'queued' so the UI
// badge reads "Tests queued" instead of "Tests running" (which implies a job
// has actually started).
export function deriveTestOutcome(stored: string): PatchTestOutcome {
  switch (stored) {
    case 'PASSED':
      return 'pass';
    case 'FAILED':
    case 'ERRORED':
      return 'fail';
    case 'PENDING':
      return 'queued';
    default:
      return 'running';
  }
}

function deriveMergeState(stored: string): PatchMergeState {
  switch (stored) {
    case 'AUTO_MERGE':
      return 'auto-merged';
    case 'MANUAL_REVIEW':
      return 'paged-human';
    case 'BLOCKED':
      return 'declined';
    default:
      return 'open';
  }
}

export function deriveSeverity(cveId: string): PatchSeverity {
  if (cveId in SEVERITY_BY_CVE) return SEVERITY_BY_CVE[cveId] as PatchSeverity;
  return 'medium';
}

function deriveTitle(cveId: string, packageName: string, toVersion: string): string {
  return `Pin ${packageName} to ${toVersion} for ${cveId}`;
}

function deriveTargetRepo(): string {
  return 'sample-firmware';
}

function derivePackageLine(packageName: string, version: string, indent: string): string {
  return `${indent}"${packageName}": "${version}",`;
}

// Unified-diff synthesis. The cron bumps a single line in package.json (the
// dependency pin), so the diff is one hunk of context + the changed line on
// each side. Hunk header is anchored by the package name's index in the
// fixture's dependencies object (left-pad at 0, tiny-validator at 1).
function synthesizeDiff(packageName: string, fromVersion: string, toVersion: string): string {
  const depsOrder = ['left-pad', 'tiny-validator'];
  const idx = depsOrder.indexOf(packageName);
  const start = idx >= 0 ? 7 + idx : 7; // fixture package.json: deps block hunk starts at line 7
  const oldLine = derivePackageLine(packageName, fromVersion, '    ');
  const newLine = derivePackageLine(packageName, toVersion, '    ');

  return [
    '--- a/package.json',
    '+++ b/package.json',
    `@@ -${start},3 +${start},3 @@`,
    '   "dependencies": {',
    `-${oldLine}`,
    `+${newLine}`,
    '   }',
    '',
  ].join('\n');
}

// Per-file status derivation. The cron only edits package.json today, so the
// sole row is 'modified'. A future fixture that also bumps a lockfile just
// adds another row here with its own status — never edit the zod contract.
function deriveFileStatus(filePath: string): PatchFileStatus {
  if (filePath === 'package.json') return 'modified';
  if (filePath.endsWith('.lock') || filePath.endsWith('lock.json')) return 'modified';
  if (filePath.endsWith('.lockb')) return 'modified';
  return 'modified';
}

// Structured file-diffs synthesis. Today the cron only edits package.json, so
// the list is a single row — but the contract is `files[]` so a future fixture
// that also bumps a lockfile (or any other tracked file) just adds another
// row here without touching the route handler or the zod contract.
function synthesizeFileDiffs(
  packageName: string,
  fromVersion: string,
  toVersion: string,
): Array<{ path: string; diff: string; status: PatchFileStatus }> {
  return [
    {
      path: 'package.json',
      diff: synthesizeDiff(packageName, fromVersion, toVersion),
      status: deriveFileStatus('package.json'),
    },
  ];
}

// Deterministic test-count derivation. Reads the persisted outcome (uppercase
// from the cron) and returns a stable { run, passed, failed } triple. PASSED
// → all-pass with a CVE-keyed bump so totals stay canonical; FAILED /
// ERRORED → flip one of the passed cases to a failure; PENDING / unknown →
// all zeros (the badge is the source of truth for "running", counts are an
// overlay).
//
// CVE-2024-1001 (left-pad critical path) is the larger suite; CVE-2024-1002
// shares the baseline + 1 so totals stay consistent across rows.
const CVE_TEST_BASELINE: Record<string, { run: number; extra: number; failedBump: number }> = {
  'CVE-2024-1001': { run: 12, extra: 0, failedBump: 1 },
  'CVE-2024-1002': { run: 12, extra: 1, failedBump: 1 },
};

interface DeriveTestCountsInput {
  cveId: string;
  packageName: string;
}

function deriveTestCounts(
  storedOutcome: string,
  input: DeriveTestCountsInput,
): { run: number; passed: number; failed: number } {
  const baseline = CVE_TEST_BASELINE[input.cveId] ?? { run: 12, extra: 0, failedBump: 1 };

  switch (storedOutcome) {
    case 'PASSED':
      return {
        run: baseline.run + baseline.extra,
        passed: baseline.run + baseline.extra,
        failed: 0,
      };
    case 'FAILED':
    case 'ERRORED':
      return {
        run: baseline.run + baseline.extra,
        passed: baseline.run + baseline.extra - baseline.failedBump,
        failed: baseline.failedBump,
      };
    default:
      return { run: 0, passed: 0, failed: 0 };
  }
}

// Synthetic log excerpt. The shell echoes CI output and a "check-runs POST"
// request so the panel reads as real CI output without us shipping actual
// log payload. Cosmetically derives from the outcome so queued / passing /
// failing surfaces differ. Avoids secrets / stack traces — purely decorative,
// lives next to the test-count dl so totals stay canonical. Pure two-to-six
// lines, deterministic per (outcome, cveId, packageName).
export function synthesizeTestLog(
  storedOutcome: string,
  cveId: string,
  packageName: string,
): string {
  const suite = `${packageName}@integration`;
  switch (storedOutcome) {
    case 'PASSED':
      return [
        `$ npm test --workspace=${suite}`,
        `> vitest run --reporter=basic`,
        `PASS  ${cveId}/${packageName}.transform.test.ts`,
        `POST /repos/:id/check-runs { conclusion: success }`,
      ].join('\n');
    case 'FAILED':
    case 'ERRORED':
      return [
        `$ npm test --workspace=${suite}`,
        `> vitest run --reporter=basic`,
        `FAIL  ${cveId}/${packageName}.transform.test.ts`,
        `AssertionError: expected 'sanitized' to equal 'pinned-revert'`,
        `POST /repos/:id/check-runs { conclusion: failure }`,
      ].join('\n');
    case 'PENDING':
      return [
        `$ npm test --workspace=${suite} --watch=false`,
        `> vitest queued · waiting for runner`,
        `Job scheduled (no status posted yet)`,
      ].join('\n');
    default:
      return [
        `$ npm test --workspace=${suite} --run`,
        `> vitest running · in progress`,
        `Awaiting final status from runner…`,
      ].join('\n');
  }
}

// Stable policy-rule derivation for the "Reason" panel on the patch detail.
// Maps mergeDecision + state → a structured record the UI displays verbatim;
// the ids are stable so cross-references in /api/auto-merge-policy stay
// monotonic. Paged-human ≠ pagedHuman-true yet (some BLOCKED rows never page
// a human — the agent just declined). MANUAL_REVIEW is the only branch that
// pages a human today.
export function derivePolicyRule(input: {
  cveId: string;
  severity: PatchSeverity;
  mergeDecision: string;
  testOutcome: string;
}): { id: string; label: string; action: PatchPolicyAction; pagedHuman: boolean } {
  const decision = input.mergeDecision;
  const severityWord = SEVERITY_LABELS[input.severity].toLowerCase();

  switch (decision) {
    case 'AUTO_MERGE':
      return {
        id: 'auto-merge:cve-known-good',
        label: `Auto-merge · acknowledge ${input.cveId} (${severityWord}-severity)`,
        action: 'auto-merge',
        pagedHuman: false,
      };
    case 'MANUAL_REVIEW':
      return {
        id: 'page-human:reviewer-required',
        label: 'Page a human · reviewer required',
        action: 'page-human',
        pagedHuman: true,
      };
    case 'BLOCKED':
      return {
        id: 'guardrail:decline',
        label: 'Decline · guardrail triggered',
        action: 'decline',
        pagedHuman: false,
      };
    default:
      // null / PENDING / unknown merge decision → PR is open, awaiting tests.
      return {
        id: 'open-pr:awaiting-tests',
        label: 'Open PR and wait · awaiting tests',
        action: 'open-pr-wait',
        pagedHuman: false,
      };
  }
}

function synthesizeRationale(input: {
  cveId: string;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  testOutcome: PatchTestOutcome;
  mergeState: PatchMergeState;
  severity: PatchSeverity;
}): string {
  const severityWord = SEVERITY_LABELS[input.severity].toLowerCase();
  const testSentence =
    input.testOutcome === 'pass'
      ? 'Workflow tests passed on the bumped dependency,'
      : input.testOutcome === 'fail'
        ? 'Workflow tests failed on the bumped dependency,'
        : input.testOutcome === 'queued'
          ? 'Workflow tests are still queued for the bumped dependency,'
          : 'Workflow tests are still running on the bumped dependency,';

  const mergeSentence = {
    'auto-merged':
      'so the patch was auto-merged as a routine dependency pin with no human review required.',
    open: 'so the PR was opened and is waiting on reviewer sign-off before any merge decision lands.',
    declined:
      'so the patch was declined pending follow-up triage — the cost of merging exceeded the risk after review.',
    'paged-human':
      'so a human reviewer was paged to weigh the trade-off before merging — the agent did not have enough signal to decide alone.',
  }[input.mergeState];

  return (
    `Detected a ${severityWord}-severity advisory (${input.cveId}) affecting the pinned ` +
    `${input.packageName}@${input.fromVersion} in the connected repository. Opened a PR that bumps ` +
    `the pin to ${input.packageName}@${input.toVersion} to land the upstream fix. ` +
    `${testSentence} ${mergeSentence}`
  );
}

function formatCreatedAt(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  // Schema column is DateTime on the DB side; serialise as ISO so the client
  // contract stays string-typed and the format doesn't drift by timezone.
  return date.toISOString();
}

function toPatchListItem(row: {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  createdAt: Date;
  testOutcome: string;
  mergeDecision: string;
}): PatchListItem {
  const cveId = row.cveId ?? '';
  const severity = deriveSeverity(cveId);
  return PatchListItem.parse({
    id: row.id,
    title: deriveTitle(cveId, row.packageName, row.toVersion),
    cveId,
    packageName: row.packageName,
    fromVersion: row.fromVersion,
    toVersion: row.toVersion,
    severity,
    mergeState: deriveMergeState(row.mergeDecision),
    createdAt: formatCreatedAt(row.createdAt),
  });
}

function toPatchDetail(row: {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  createdAt: Date;
}) {
  const cveId = row.cveId ?? '';
  const severity = deriveSeverity(cveId);
  const testOutcome = deriveTestOutcome(row.testOutcome);
  const mergeState = deriveMergeState(row.mergeDecision);
  const policyRule = derivePolicyRule({
    cveId,
    severity,
    mergeDecision: row.mergeDecision,
    testOutcome: row.testOutcome,
  });
  const counts = deriveTestCounts(row.testOutcome, {
    cveId,
    packageName: row.packageName,
  });
  return PatchDetail.parse({
    id: row.id,
    title: deriveTitle(cveId, row.packageName, row.toVersion),
    cveId,
    packageName: row.packageName,
    fromVersion: row.fromVersion,
    toVersion: row.toVersion,
    severity,
    mergeState,
    targetRepo: deriveTargetRepo(),
    prUrl: row.prUrl,
    testOutcome,
    testLog: synthesizeTestLog(row.testOutcome, cveId, row.packageName),
    policyRule,
    files: synthesizeFileDiffs(row.packageName, row.fromVersion, row.toVersion),
    testsRun: counts.run,
    testsPassed: counts.passed,
    testsFailed: counts.failed,
    rationale: synthesizeRationale({
      cveId,
      packageName: row.packageName,
      fromVersion: row.fromVersion,
      toVersion: row.toVersion,
      testOutcome,
      mergeState,
      severity,
    }),
    createdAt: formatCreatedAt(row.createdAt),
  });
}

export async function listPatches(limit?: number): Promise<PatchList> {
  const raw =
    typeof limit === 'number' && Number.isFinite(limit) && limit > 0 ? limit : DEFAULT_LIMIT;
  const take = Math.min(raw, MAX_LIMIT);

  const rows = await prisma.cveTriageLog.findMany({
    orderBy: { createdAt: 'desc' },
    take,
  });

  return PatchList.parse({
    items: rows.map((row) =>
      toPatchListItem({
        id: row.id,
        cveId: row.cveId,
        packageName: row.packageName,
        fromVersion: row.fromVersion,
        toVersion: row.toVersion,
        createdAt: row.createdAt,
        testOutcome: row.testOutcome,
        mergeDecision: row.mergeDecision,
      }),
    ),
  });
}

// Per-repo patch list — narrows the global list to triage rows whose `prUrl`
// contains the repo's `owner/name` slug (the existing join pattern used by
// /api/dashboard/repos and /api/audit-log; the brief explicitly forbids a
// Prisma relation between Repo and CveTriageLog). Same legacy-or-self
// attribution pattern as `listAudit`: rows owned by the caller OR the legacy
// null-userId rows so a brand-new signup doesn't see a wall of empty space
// before the cron writes one.
export async function listRepoPatches(opts: {
  repoId: string;
  ownerHandle: string;
  repoName: string;
  userId: string;
  limit?: number;
}): Promise<PatchList> {
  if (!opts.repoId || !opts.ownerHandle || !opts.repoName) {
    throw new NotFound();
  }

  const raw =
    typeof opts.limit === 'number' && Number.isFinite(opts.limit) && opts.limit > 0
      ? opts.limit
      : DEFAULT_LIMIT;
  const take = Math.min(raw, MAX_LIMIT);

  const slug = `${opts.ownerHandle}/${opts.repoName}`;
  const rows = await prisma.cveTriageLog.findMany({
    where: {
      prUrl: { contains: slug },
      OR: [{ userId: opts.userId }, { userId: null }],
    },
    orderBy: { createdAt: 'desc' },
    take,
  });

  return PatchList.parse({
    items: rows.map((row) =>
      toPatchListItem({
        id: row.id,
        cveId: row.cveId,
        packageName: row.packageName,
        fromVersion: row.fromVersion,
        toVersion: row.toVersion,
        createdAt: row.createdAt,
        testOutcome: row.testOutcome,
        mergeDecision: row.mergeDecision,
      }),
    ),
  });
}

export async function getPatchDetail(id: string) {
  if (!id || typeof id !== 'string') {
    throw new NotFound();
  }

  const row = await prisma.cveTriageLog.findUnique({ where: { id } });
  if (!row) {
    throw new NotFound();
  }

  return toPatchDetail(row);
}
