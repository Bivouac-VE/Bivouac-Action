// @polsia:user-owned — server-only helpers for the daily-digest cron.
// Computes per-user, per-repo tallies (auto-merged patches, CVE responses
// opened, human pages or overrides) for the previous 24h window so the
// email template can render a single section heading + one line per repo.
//
// Cron shape:
//
//   jobs/daily-digest.js  ──require─►  src/lib/server/digest-prisma.cjs
//                                           │
//                                           ▼
//                              buildDigestForUsers (this file)
//
// Why a business module: keeps the cron thin, lets a future
// /api/digest/preview island reuse the exact same shape, and lives inside
// the `server-only` envelope so a stray client import fails the build at
// the lint gate.

import 'server-only';
import { prisma } from '@/lib/db';
import type { DigestRepoTally, DigestSection } from '@/lib/email/templates';

// 24h window — the previous-day rolling cutoff. Cron-driven; no caller.
const WINDOW_MS = 24 * 60 * 60 * 1000;

// Re-uses the same slug derivation as `lib/business/audit-log.ts`. CveTriageLog
// stores the full PR URL (e.g. https://github.com/<owner>/<repo>/pull/N) and
// we collapse that to `owner/repo` so it matches the Repo table's joined
// ownerHandle + name for the grouping pass.
function repoSlugFromUrl(prUrl: string): string {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0]}/${parts[1]}`;
    }
    return '';
  } catch {
    return '';
  }
}

export interface DigestData {
  /** UTC date stamp `YYYY-MM-DD` — the day the digest covers (today). */
  day: string;
  /** UTC start of the rolling 24h window — the cron reads nothing below. */
  windowStart: Date;
  sections: DigestSection[];
}

export interface PerUserDigest {
  userId: string;
  user: { name: string; email: string };
  digest: DigestData;
}

/** Build the digest for a single user. Reads ONLY:
 *       prisma.user           (name + email for the greeting/send)
 *       prisma.repo           (the user's connected set, by userId)
 *       prisma.cveTriageLog   (filtered by userId + createdAt window)
 *       prisma.humanOverride  (filtered by userId + decidedAt window)
 *  Side-effect free with respect to the schema: returns the per-user
 *  DigestData; the caller updates `lastDigestSentAt` AFTER sendEmail
 *  succeeds (so a failed send doesn't flap the watermark and cause a
 *  duplicate on the next rerun). */
export async function buildUserDigest(
  userId: string,
  now: Date = new Date(),
): Promise<PerUserDigest | null> {
  const windowStart = new Date(now.getTime() - WINDOW_MS);

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, name: true, email: true },
  });
  if (!user || !user.email) return null;

  const [repos, triageRows, overrideRows] = await Promise.all([
    prisma.repo.findMany({
      where: { userId },
      select: { id: true, ownerHandle: true, name: true },
    }),
    prisma.cveTriageLog.findMany({
      where: { userId, createdAt: { gte: windowStart } },
      select: { prUrl: true, mergeDecision: true },
    }),
    prisma.humanOverride.findMany({
      where: { userId, decidedAt: { gte: windowStart } },
      select: { repoId: true },
    }),
  ]);

  // Connected-repo set — keyed by `ownerHandle/name` slug. The connection
  // is what decides whether a row's tallies land in the digest at all: a
  // CVE row whose slug doesn't match ANY of the user's connected repos is
  // dropped (a leftover slug from a repo the user disconnected shouldn't
  // show up). HumanOverride is filtered by userId at the SQL level so a
  // stale override whose repoId now belongs to another user's repo can
  // never leak.
  const connectedSlugs = new Set(repos.map((r) => `${r.ownerHandle}/${r.name}`));

  // Per-slug tally accumulator. Starts empty — every connected repo is a
  // candidate entry, even when its counts are zero (so the email still says
  // "0 auto-merged, 0 CVE opened, 0 human override" for quiet repos is a
  // deliberate choice: we omit the row entirely below for those).
  const slugTally = new Map<string, DigestRepoTally>();
  for (const slug of connectedSlugs) {
    slugTally.set(slug, { repo: slug, autoMerged: 0, cveOpened: 0, humanOverrides: 0 });
  }

  // Fold CveTriageLog rows: each row contributes one to `cveOpened`; rows
  // whose mergeDecision is AUTO_MERGE also contribute one to `autoMerged`.
  // Rows whose slug isn't in the connected set are dropped silently.
  for (const row of triageRows) {
    const slug = repoSlugFromUrl(row.prUrl);
    if (!slug || !connectedSlugs.has(slug)) continue;
    const current = slugTally.get(slug);
    if (!current) continue;
    current.cveOpened += 1;
    if (row.mergeDecision === 'AUTO_MERGE') {
      current.autoMerged += 1;
    }
  }

  // Fold HumanOverride rows: each contributes one to `humanOverrides`. We
  // join repoId → slug via a single Prisma lookup so we don't N+1. The
  // join is filtered by userId at the SQL level so a stale override whose
  // repoId now belongs to another user's connected repo can't leak.
  if (overrideRows.length > 0) {
    const candidateRepoIds = Array.from(new Set(overrideRows.map((r) => r.repoId)));
    if (candidateRepoIds.length > 0) {
      const joined = await prisma.repo.findMany({
        where: { id: { in: candidateRepoIds }, userId },
        select: { id: true, ownerHandle: true, name: true },
      });
      const slugByRepoId = new Map<string, string>(
        joined.map((r) => [r.id, `${r.ownerHandle}/${r.name}`] as const),
      );
      for (const row of overrideRows) {
        const slug = slugByRepoId.get(row.repoId);
        if (!slug) continue;
        const current = slugTally.get(slug);
        if (!current) continue;
        current.humanOverrides += 1;
      }
    }
  }

  // Drop quiet rows (no signal at all) and keep the active set sorted by
  // slug so the rendered table is deterministic across runs.
  const items = Array.from(slugTally.values())
    .filter((t) => t.autoMerged > 0 || t.cveOpened > 0 || t.humanOverrides > 0)
    .sort((a, b) => (a.repo < b.repo ? -1 : a.repo > b.repo ? 1 : 0));

  return {
    userId,
    user: { name: user.name, email: user.email },
    digest: {
      day: now.toISOString().slice(0, 10),
      windowStart,
      sections: [
        {
          heading: 'Per-repo activity (last 24 hours)',
          items,
        },
      ],
    },
  };
}
