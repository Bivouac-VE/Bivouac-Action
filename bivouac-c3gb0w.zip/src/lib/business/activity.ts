// @polsia:user-owned — server-only domain mapping for the public /activity
// feed. Reads the global `CveTriageLog` table (no auth, no per-user
// scoping — same public-read convention as /api/patches and /api/status)
// and shapes the rows into the `ActivityFeed` contract consumed by both
// the route handler and the client island. No schema change; the
// "fields the row doesn't store" (repoLabel, timeToPatchHours, severity,
// mergeState) all derive from what's already persisted.
//
// `import 'server-only'` so a stray Client import fails the build at the
// lint gate rather than leaking Prisma through the data plane.

import 'server-only';
import { deriveSeverity } from '@/lib/business/patches';
import {
  type ActivityDotState,
  ActivityFeed,
  type ActivityFeedItem,
  type ActivityLive,
  type ActivityMergeState,
  type ActivitySeverity,
} from '@/lib/contracts/activity';
import { prisma } from '@/lib/db';

// Mirrors the loader caps used by the patch list: default 25 keeps the
// page short (the "Live now" strip + a couple-dozen feed rows is the brief),
// hard cap at 100 keeps the response small enough that a cold outreach
// link never balloons on a fresh boot where the cron has already run
// against a busy fleet.
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;

// Repo label is parsed from the prUrl — no schema column. Accepts any
// path of the form github.com/<owner>/<repo>(/pull/<n>) and returns
// `owner/repo`; null on legacy/non-github prUrl so the UI can fall back
// to a generic chip without crashing.
const PR_URL_PATTERN = /github\.com\/([^/]+)\/([^/]+)/;

function deriveRepoLabel(prUrl: string): string | null {
  const match = prUrl.match(PR_URL_PATTERN);
  if (!match) return null;
  const owner = match[1];
  const repo = match[2];
  if (!owner || !repo) return null;
  return `${owner}/${repo}`;
}

// Persisted DB enum → UI enum. Mirrors `deriveMergeState` in
// business/patches.ts (kept inline here so the contract surface stays
// independent — easier to read the live feed's enum derivation next to
// the loader than to follow the imported helper across files).
function deriveMergeState(stored: string | null | undefined): ActivityMergeState {
  switch (stored) {
    case 'AUTO_MERGE':
      return 'auto-merged';
    case 'MANUAL_REVIEW':
      return 'paged-human';
    case 'BLOCKED':
      return 'declined';
    default:
      return 'open';
  }
}

function formatCreatedAt(value: Date): string {
  return value.toISOString();
}

// Live-strip health dot. The "live now" heuristic is row-age based (no
// cron heartbeat is exposed to the app today). Same thresholds as
// /api/status so the two surfaces never disagree:
//   green: last triage row within 36h
//   amber: last triage row 36h–2.5d
//   red:   no triage row in 2.5d+, or no rows at all
//
// Documented here (not derived from a heartbeat) on purpose — this is a
// marketing surface that mirrors the same heuristic /status uses. A
// future heartbeat-aware change should update both call sites together.
const HEALTHY_MAX_AGE_HOURS = 36;
const DELAYED_MAX_AGE_HOURS = 60;

function classifyDotState(ageHours: number | null): ActivityDotState {
  if (ageHours === null) return 'red';
  if (ageHours <= HEALTHY_MAX_AGE_HOURS) return 'green';
  if (ageHours <= DELAYED_MAX_AGE_HOURS) return 'amber';
  return 'red';
}

// Internal raw-row shape — narrows the Prisma return so the shaping
// code below doesn't accidentally read columns the model never exposes.
type RawRow = {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  createdAt: Date;
};

function toFeedItem(row: RawRow, now: Date): ActivityFeedItem {
  const cveId = row.cveId;
  const severity: ActivitySeverity = cveId ? deriveSeverity(cveId) : 'medium';
  const ageMs = Math.max(0, now.getTime() - row.createdAt.getTime());
  const timeToPatchHours = ageMs / 3_600_000;
  return {
    id: row.id,
    cveId,
    packageName: row.packageName,
    fromVersion: row.fromVersion,
    toVersion: row.toVersion,
    severity,
    mergeState: deriveMergeState(row.mergeDecision),
    repoLabel: deriveRepoLabel(row.prUrl),
    createdAt: formatCreatedAt(row.createdAt),
    timeToPatchHours,
  };
}

function buildLive(rows: RawRow[], now: Date): ActivityLive {
  if (rows.length === 0) {
    return { lastTriageAt: null, patchesLast24h: 0, dotState: 'red' };
  }
  const first = rows[0];
  if (!first) {
    return { lastTriageAt: null, patchesLast24h: 0, dotState: 'red' };
  }
  // rows is already ordered desc by createdAt per the loader's findMany;
  // the first row IS the most recent. Reduce-by-max would also work but
  // re-finds the latest row the loader slice may skip.
  const last = rows.reduce<RawRow>(
    (acc, r) => (r.createdAt.getTime() > acc.createdAt.getTime() ? r : acc),
    first,
  );
  const ageHours = (now.getTime() - last.createdAt.getTime()) / 3_600_000;
  const twentyFourHoursAgo = now.getTime() - 24 * 3_600_000;
  let patchesLast24h = 0;
  for (const row of rows) {
    if (row.createdAt.getTime() >= twentyFourHoursAgo) patchesLast24h += 1;
  }
  return {
    lastTriageAt: last.createdAt.toISOString(),
    patchesLast24h,
    // Negative guards against clock skew (a row dated in the future would
    // otherwise produce a sneaky negative age).
    dotState: classifyDotState(ageHours >= 0 ? ageHours : null),
  };
}

export async function loadActivityFeed(
  limit?: number,
  now: Date = new Date(),
): Promise<ActivityFeed> {
  const raw =
    typeof limit === 'number' && Number.isFinite(limit) && limit > 0 ? limit : DEFAULT_LIMIT;
  const take = Math.min(raw, MAX_LIMIT);

  const rows = (await prisma.cveTriageLog.findMany({
    orderBy: { createdAt: 'desc' },
    take,
    select: {
      id: true,
      cveId: true,
      packageName: true,
      fromVersion: true,
      toVersion: true,
      prUrl: true,
      testOutcome: true,
      mergeDecision: true,
      createdAt: true,
    },
  })) as RawRow[];

  const items = rows.map((row) => toFeedItem(row, now));
  const live = buildLive(rows, now);

  return ActivityFeed.parse({ items, live });
}
