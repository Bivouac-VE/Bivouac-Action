// @polsia:user-owned — typed catalog of usage-based SLA add-ons shown as a
// comparison row on /pricing. Parallel to PLANS; rendered by the page island.

export type SlaAddon = {
  slug: 'mttr-24h' | 'paging-4h' | 'compliance-contact';
  label: string;
  body: string;
  pricingNote: string;
};

export const SLA_ADDONS: readonly SlaAddon[] = [
  {
    slug: 'mttr-24h',
    label: '24h mean-time-to-PR',
    body: 'Mean-time-to-PR clock drops to 24 hours for critical-severity disclosures across every active repo.',
    pricingNote: 'Usage-based · pricing TBD',
  },
  {
    slug: 'paging-4h',
    label: '4h on-call paging',
    body: 'Bivouac pages the right rotation within four hours of a contested decision, 24/7.',
    pricingNote: 'Usage-based · pricing TBD',
  },
  {
    slug: 'compliance-contact',
    label: 'Dedicated compliance contact',
    body: 'A named point of contact for SOC 2 / NIS2 / CRA evidence requests, with quarterly review.',
    pricingNote: 'Per-account · pricing TBD',
  },
];
