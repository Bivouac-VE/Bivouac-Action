// @polsia:user-owned — server-only helpers for the /dashboard/metrics board.
// Mirrors the pattern used by lib/business/insights.ts: every Prisma read is
// scoped to the signed-in user's connected repos via prUrl-contains OR
// clauses, and a zero-repo user short-circuits to a zero-data tile shape so
// an empty OR() never scans globally. The legacy `loadMetricsSummary` keeps
// the insights-side 4-KPI + monthly-bucket surface; the new
// `loadComplianceMetrics` lands the brief's 30/60/90 toggle on daily buckets
// plus the per-repo breakdown table.

import 'server-only';
import type { InsightsRangeDays } from '@/lib/contracts/insights';
import {
  ComplianceMetrics,
  type DailyPoint,
  DailySeries,
  type MetricsRangeDays,
  type MetricsSummary,
  type MttpTrendPoint,
  MttpTrendSeries,
  type PatchesPerMonthPoint,
  PatchesPerMonthSeries,
  type RatePoint,
  RepoBreakdownRow,
} from '@/lib/contracts/metrics';
import { prisma } from '@/lib/db';

const TERMINAL_DECISIONS = new Set(['AUTO_MERGE', 'MANUAL_REVIEW', 'BLOCKED']);

function rangeWindow(now: Date, rangeDays: InsightsRangeDays): { start: Date; end: Date } {
  const end = new Date(now);
  const start = new Date(now);
  start.setUTCDate(start.getUTCDate() - rangeDays);
  return { start, end };
}

export function rangeBoundsIso(
  rangeDays: InsightsRangeDays,
  now: Date = new Date(),
): { from: string; to: string } {
  const { start, end } = rangeWindow(now, rangeDays);
  return { from: start.toISOString().slice(0, 10), to: end.toISOString().slice(0, 10) };
}

// Build the { AND: [ date, OR: repoSlug prUrl-contains ] } clause shared by
// every loader. Returns null when the user has zero repos so callers can
// short-circuit to zero-data instead of issuing a global scan.
async function buildScopedWhere(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<{ AND: Array<Record<string, unknown>> } | null> {
  const repos = await prisma.repo.findMany({
    where: { userId },
    select: { ownerHandle: true, name: true },
  });
  if (repos.length === 0) return null;
  const { start, end } = rangeWindow(new Date(), rangeDays);
  const repoClauses = repos.map((r) => ({ prUrl: { contains: `${r.ownerHandle}/${r.name}` } }));
  return {
    AND: [{ createdAt: { gte: start, lte: end } }, { OR: repoClauses }],
  };
}

function fmtPercent(numerator: number, denominator: number): string {
  if (denominator === 0) return '—';
  return `${Math.round((numerator / denominator) * 100)}%`;
}

function fmtDurationDays(days: number): string {
  if (days < 1) {
    const hours = Math.round(days * 24);
    return hours <= 1 ? '<1h' : `${hours}h`;
  }
  if (days < 14) return `${Math.round(days)}d`;
  const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto', style: 'short' });
  if (days < 60) return rtf.format(-Math.round(days), 'day');
  const months = Math.round(days / 30);
  return rtf.format(-months, 'month');
}

// Bucket anchors are the 1st of the month (UTC). Different from /insights,
// which uses ISO weeks — the dashboard phrase "patches per month" maps
// naturally to calendar months.
function monthStartOf(date: Date): Date {
  const d = new Date(date);
  d.setUTCDate(1);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

function monthIso(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function enumerateMonths(start: Date, end: Date): Date[] {
  const months: Date[] = [];
  const cursor = monthStartOf(start);
  const last = monthStartOf(end);
  while (cursor.getTime() <= last.getTime()) {
    months.push(new Date(cursor));
    cursor.setUTCMonth(cursor.getUTCMonth() + 1);
  }
  return months;
}

export async function loadMetricsSummary(
  userId: string,
  rangeDays: InsightsRangeDays,
): Promise<MetricsSummary> {
  const where = await buildScopedWhere(userId, rangeDays);
  const connectedRepoCount = await prisma.repo.count({ where: { userId } });
  const { from, to } = rangeBoundsIso(rangeDays);

  if (!where) {
    return {
      rangeDays,
      connectedRepoCount,
      from,
      to,
      tiles: {
        mttp: {
          label: 'Mean time to patch',
          value: '—',
          hint: 'Connect a repo to see compliance metrics',
        },
        autoMergeRate: {
          label: 'Auto-merge rate',
          value: '—',
          hint: 'Connect a repo to see compliance metrics',
        },
        humanOverrideRate: {
          label: 'Human-override rate',
          value: '—',
          hint: 'Connect a repo to see compliance metrics',
        },
        patchesPerMonth: {
          label: 'Patches per month',
          value: '—',
          hint: 'Connect a repo to see compliance metrics',
        },
      },
      patchesPerMonthSeries: PatchesPerMonthSeries.parse({
        rangeDays,
        points: [],
      }),
      mttpTrendSeries: MttpTrendSeries.parse({
        rangeDays,
        points: [],
      }),
    };
  }

  const rows = await prisma.cveTriageLog.findMany({
    where,
    select: {
      id: true,
      createdAt: true,
      mergeDecision: true,
    },
  });

  const total = rows.length;
  let auto = 0;
  let manual = 0;
  let ageSumMs = 0;
  let ageCount = 0;
  const now = Date.now();
  for (const row of rows) {
    if (row.mergeDecision === 'AUTO_MERGE') auto += 1;
    else if (row.mergeDecision === 'MANUAL_REVIEW') manual += 1;
    if (TERMINAL_DECISIONS.has(row.mergeDecision)) {
      ageSumMs += now - row.createdAt.getTime();
      ageCount += 1;
    }
  }
  const mttpDays = ageCount === 0 ? null : ageSumMs / ageCount / (1000 * 60 * 60 * 24);

  // Series buckets
  const { start, end } = rangeWindow(new Date(), rangeDays);
  const months = enumerateMonths(start, end);
  const countByMonth = new Map<string, number>();
  const mttpSumByMonth = new Map<string, number>();
  const mttpCountByMonth = new Map<string, number>();
  for (const m of months) {
    const key = monthIso(m);
    countByMonth.set(key, 0);
    mttpSumByMonth.set(key, 0);
    mttpCountByMonth.set(key, 0);
  }
  for (const row of rows) {
    const key = monthIso(monthStartOf(row.createdAt));
    countByMonth.set(key, (countByMonth.get(key) ?? 0) + 1);
    if (TERMINAL_DECISIONS.has(row.mergeDecision)) {
      mttpSumByMonth.set(key, (mttpSumByMonth.get(key) ?? 0) + (now - row.createdAt.getTime()));
      mttpCountByMonth.set(key, (mttpCountByMonth.get(key) ?? 0) + 1);
    }
  }

  const patchesPerMonthPoints: PatchesPerMonthPoint[] = months.map((m) => ({
    monthStart: monthIso(m),
    count: countByMonth.get(monthIso(m)) ?? 0,
  }));
  const mttpTrendPoints: MttpTrendPoint[] = months.map((m) => {
    const key = monthIso(m);
    const count = mttpCountByMonth.get(key) ?? 0;
    const days =
      count === 0 ? null : (mttpSumByMonth.get(key) ?? 0) / count / (1000 * 60 * 60 * 24);
    return { monthStart: key, mttpDays: days };
  });

  // Patches-per-month tile value: average monthly count across the buckets
  // we actually have data in (skip zero buckets so a fresh user with one
  // patch last month reads as "1/mo", not "1/12mo").
  let patchesPerMonthValue: string;
  let patchesPerMonthHint: string;
  if (total === 0) {
    patchesPerMonthValue = '0';
    patchesPerMonthHint = 'No patches in this window';
  } else {
    const activeMonths = patchesPerMonthPoints.filter((p) => p.count > 0);
    const avg = activeMonths.length === 0 ? 0 : total / activeMonths.length;
    const rounded = Math.round(avg * 10) / 10;
    patchesPerMonthValue = rounded % 1 === 0 ? String(rounded) : rounded.toFixed(1);
    patchesPerMonthHint = `${total} patch${total === 1 ? '' : 'es'} across ${activeMonths.length} month${activeMonths.length === 1 ? '' : 's'}`;
  }

  const mttpTile = {
    label: 'Mean time to patch',
    value: mttpDays === null ? '—' : fmtDurationDays(mttpDays),
    hint:
      mttpDays === null
        ? 'No patches in this window'
        : `Over ${total} patch${total === 1 ? '' : 'es'}`,
  };
  const autoTile = {
    label: 'Auto-merge rate',
    value: fmtPercent(auto, total),
    hint: total === 0 ? 'No patches in this window' : `${auto} of ${total} merged without review`,
  };
  const humanTile = {
    label: 'Human-override rate',
    value: fmtPercent(manual, total),
    hint: total === 0 ? 'No patches in this window' : `${manual} of ${total} paged a human`,
  };

  return {
    rangeDays,
    connectedRepoCount,
    from,
    to,
    tiles: {
      mttp: mttpTile,
      autoMergeRate: autoTile,
      humanOverrideRate: humanTile,
      patchesPerMonth: {
        label: 'Patches per month',
        value: patchesPerMonthValue,
        hint: patchesPerMonthHint,
      },
    },
    patchesPerMonthSeries: PatchesPerMonthSeries.parse({
      rangeDays,
      points: patchesPerMonthPoints,
    }),
    mttpTrendSeries: MttpTrendSeries.parse({
      rangeDays,
      points: mttpTrendPoints,
    }),
  };
}

// === Compliance dashboard surface (= brief) =================================
//
// Three daily time series (MTTP / auto-merge / override) over a 30/60/90-day
// toggle, plus a per-repo breakdown (the three series + a 12-week sparkline).
// Series definitions (applied verbatim from the brief):
//
//   MTTP (hours)    = avg(now − createdAt) over terminal rows in that bucket.
//                     Bucketed by day of createdAt. NULL when the day had no
//                     terminal rows (gap in the line).
//   Auto-merge rate = count(AUTO_MERGE) / count(TERMINAL)  (0..1; emit finite
//                     even when denominator = 0 → value 0 so no gap).
//   Override rate   = count(MANUAL_REVIEW) / count(TERMINAL) (same).
//
// All terminal rows = AUTO_MERGE | MANUAL_REVIEW | BLOCKED. Preread of the
// existing CveTriageLog rows is scoped per-user via Repo ownership (the
// `prUrl contains owner/name` join used elsewhere — there is no Prisma
// relation between Repo and CveTriageLog by design). All bucketing happens
// in UTC so a row's day-of-createdAt is stable across pages.

const SPARKLINE_WEEKS = 12;

function dayKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function enumerateDays(start: Date, end: Date): string[] {
  // Inclusive [start, end] day list — anchor to UTC midnight and advance one
  // day at a time so the last day in `end` still emits if it has rows.
  const days: string[] = [];
  const cursor = new Date(start);
  cursor.setUTCHours(0, 0, 0, 0);
  const last = new Date(end);
  last.setUTCHours(0, 0, 0, 0);
  while (cursor.getTime() <= last.getTime()) {
    days.push(dayKey(cursor));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return days;
}

function enumerateIsoWeeks(end: Date, count: number): string[] {
  // Last `count` ISO-week Monday anchors covering the full window, oldest
  // first. We align to Mondays (Mon-Sun) — same convention used by the
  // /insights board — so weekly buckets read consistently across surfaces.
  const lastMonday = new Date(end);
  lastMonday.setUTCHours(0, 0, 0, 0);
  const dayOfWeek = lastMonday.getUTCDay(); // 0 = Sun … 6 = Sat
  // Shift back to Monday: Sun(0) → 6 back, Mon(1) → 0, …, Sat(6) → 5 back.
  const offsetToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  lastMonday.setUTCDate(lastMonday.getUTCDate() - offsetToMonday);

  const mondays: string[] = [];
  for (let i = count - 1; i >= 0; i -= 1) {
    const m = new Date(lastMonday);
    m.setUTCDate(m.getUTCDate() - i * 7);
    mondays.push(dayKey(m));
  }
  // Trim any Monday that falls outside the window so the sparkline won't
  // claim data we never read.
  const endKey = dayKey(end);
  return mondays.filter((k) => k <= endKey);
}

function buildComplianceScopedWhere(
  userId: string,
  rangeDays: MetricsRangeDays,
): Promise<{ AND: Array<Record<string, unknown>> } | null> {
  return (async () => {
    const repos = await prisma.repo.findMany({
      where: { userId },
      select: { ownerHandle: true, name: true },
    });
    if (repos.length === 0) return null;
    const { start, end } = rangeWindowFor(new Date(), rangeDays);
    const repoClauses = repos.map((r) => ({
      prUrl: { contains: `${r.ownerHandle}/${r.name}` },
    }));
    return {
      AND: [{ createdAt: { gte: start, lte: end } }, { OR: repoClauses }],
    };
  })();
}

// Mirror of rangeWindow but typed for the new range vocabulary. Kept distinct
// from the insights helper because the legacy surface shapes its 4 KPIs over
// the InsightsRangeDays enum and we want any future drift to be loud.
function rangeWindowFor(now: Date, rangeDays: MetricsRangeDays): { start: Date; end: Date } {
  const end = new Date(now);
  const start = new Date(now);
  start.setUTCDate(start.getUTCDate() - rangeDays);
  return { start, end };
}

// Tiny prUrl → owner/name slug parser. Shared shape with audit-log's
// `repoSlugFromRow` — reimplemented here rather than imported so the
// business/metrics module stays free of a transitive dep on audit-log
// (which would re-create a circular shape through contracts). If this ever
// drifts we can extract to lib/business/repo-slug.ts.
function repoSlugFromPrUrl(prUrl: string): string {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) return `${parts[0]}/${parts[1]}`;
    return '';
  } catch {
    return '';
  }
}

interface ComplianceRow {
  id: string;
  createdAt: Date;
  mergeDecision: string;
  prUrl: string;
  repoSlug: string;
  isTerminal: boolean;
}

function isTerminalDecision(decision: string): boolean {
  return TERMINAL_DECISIONS.has(decision);
}

function isAutoMerge(decision: string): boolean {
  return decision === 'AUTO_MERGE';
}

function isManualReview(decision: string): boolean {
  return decision === 'MANUAL_REVIEW';
}

export async function loadComplianceMetrics(
  userId: string,
  rangeDays: MetricsRangeDays,
): Promise<ComplianceMetrics> {
  const where = await buildComplianceScopedWhere(userId, rangeDays);
  const { from, to } = complianceRangeBoundsIso(rangeDays);
  const connectedRepoCount = await prisma.repo.count({ where: { userId } });

  if (!where) {
    return ComplianceMetrics.parse({
      rangeDays,
      from,
      to,
      connectedRepoCount,
      mttpSeries: { rangeDays, points: [] },
      autoMergeSeries: { rangeDays, points: [] },
      overrideSeries: { rangeDays, points: [] },
      repos: [],
    });
  }

  const rawRows = await prisma.cveTriageLog.findMany({
    where,
    select: {
      id: true,
      createdAt: true,
      mergeDecision: true,
      prUrl: true,
    },
  });
  const rows: ComplianceRow[] = rawRows.map((row) => ({
    id: row.id,
    createdAt: row.createdAt,
    mergeDecision: row.mergeDecision,
    prUrl: row.prUrl,
    repoSlug: repoSlugFromPrUrl(row.prUrl),
    isTerminal: isTerminalDecision(row.mergeDecision),
  }));

  const { start, end } = rangeWindowFor(new Date(), rangeDays);
  const days = enumerateDays(start, end);
  const dayIndex = new Map<string, number>(days.map((d, i) => [d, i]));
  const dailyMttpSumMs = new Map<string, number>();
  const dailyMttpCount = new Map<string, number>();
  const dailyAutoMerge = new Map<string, number>();
  const dailyOverride = new Map<string, number>();
  const dailyTerminal = new Map<string, number>();
  for (const d of days) {
    dailyMttpSumMs.set(d, 0);
    dailyMttpCount.set(d, 0);
    dailyAutoMerge.set(d, 0);
    dailyOverride.set(d, 0);
    dailyTerminal.set(d, 0);
  }
  const nowMs = Date.now();
  for (const row of rows) {
    const key = dayKey(row.createdAt);
    const idx = dayIndex.get(key);
    if (idx === undefined) continue; // row falls outside the window
    if (row.isTerminal) {
      dailyMttpSumMs.set(key, (dailyMttpSumMs.get(key) ?? 0) + (nowMs - row.createdAt.getTime()));
      dailyMttpCount.set(key, (dailyMttpCount.get(key) ?? 0) + 1);
      dailyTerminal.set(key, (dailyTerminal.get(key) ?? 0) + 1);
      if (isAutoMerge(row.mergeDecision)) {
        dailyAutoMerge.set(key, (dailyAutoMerge.get(key) ?? 0) + 1);
      } else if (isManualReview(row.mergeDecision)) {
        dailyOverride.set(key, (dailyOverride.get(key) ?? 0) + 1);
      }
    }
  }

  const mttpPoints: DailyPoint[] = days.map((d) => {
    const count = dailyMttpCount.get(d) ?? 0;
    if (count === 0) return { date: d, value: null };
    return {
      date: d,
      value: (dailyMttpSumMs.get(d) ?? 0) / count / (1000 * 60 * 60),
    };
  });
  const autoMergePoints: RatePoint[] = days.map((d) => {
    const denom = dailyTerminal.get(d) ?? 0;
    return { date: d, value: denom === 0 ? 0 : (dailyAutoMerge.get(d) ?? 0) / denom };
  });
  const overridePoints: RatePoint[] = days.map((d) => {
    const denom = dailyTerminal.get(d) ?? 0;
    return { date: d, value: denom === 0 ? 0 : (dailyOverride.get(d) ?? 0) / denom };
  });

  const repos = await prisma.repo.findMany({
    where: { userId },
    select: { id: true, ownerHandle: true, name: true },
  });
  const weeks = enumerateIsoWeeks(end, SPARKLINE_WEEKS);
  const weekIndex = new Map<string, number>(weeks.map((w, i) => [w, i]));

  const repoRows: RepoBreakdownRow[] = repos.map((repo) => {
    const slug = `${repo.ownerHandle}/${repo.name}`;
    const slice = rows.filter((row) => row.isTerminal && row.repoSlug === slug);
    let ageSumMs = 0;
    let auto = 0;
    let manual = 0;
    for (const row of slice) {
      ageSumMs += nowMs - row.createdAt.getTime();
      if (isAutoMerge(row.mergeDecision)) auto += 1;
      else if (isManualReview(row.mergeDecision)) manual += 1;
    }
    const total = slice.length;
    const mttpHours = total === 0 ? null : ageSumMs / total / (1000 * 60 * 60);
    const autoMergeRate = total === 0 ? 0 : auto / total;
    const overrideRate = total === 0 ? 0 : manual / total;

    const weekMttpSumMs = new Map<string, number>();
    const weekMttpCount = new Map<string, number>();
    for (const w of weeks) {
      weekMttpSumMs.set(w, 0);
      weekMttpCount.set(w, 0);
    }
    for (const row of slice) {
      // Anchor terminal-but-per-repo rows by ISO week of createdAt.
      const dow = row.createdAt.getUTCDay();
      const offsetToMonday = dow === 0 ? 6 : dow - 1;
      const monday = new Date(row.createdAt);
      monday.setUTCHours(0, 0, 0, 0);
      monday.setUTCDate(monday.getUTCDate() - offsetToMonday);
      const key = dayKey(monday);
      const idx = weekIndex.get(key);
      if (idx === undefined) continue;
      weekMttpSumMs.set(key, (weekMttpSumMs.get(key) ?? 0) + (nowMs - row.createdAt.getTime()));
      weekMttpCount.set(key, (weekMttpCount.get(key) ?? 0) + 1);
    }
    const sparkMttpHours = weeks.map((w) => {
      const count = weekMttpCount.get(w) ?? 0;
      if (count === 0) return null;
      return (weekMttpSumMs.get(w) ?? 0) / count / (1000 * 60 * 60);
    });

    return RepoBreakdownRow.parse({
      repoId: repo.id,
      fullName: slug,
      mttpHours,
      autoMergeRate,
      overrideRate,
      patchCount: total,
      sparkMttpHours,
    });
  });

  return ComplianceMetrics.parse({
    rangeDays,
    from,
    to,
    connectedRepoCount,
    mttpSeries: DailySeries.parse({ rangeDays, points: mttpPoints }),
    autoMergeSeries: DailySeries.parse({ rangeDays, points: autoMergePoints }),
    overrideSeries: DailySeries.parse({ rangeDays, points: overridePoints }),
    repos: repoRows,
  });
}

export function complianceRangeBoundsIso(
  rangeDays: MetricsRangeDays,
  now: Date = new Date(),
): { from: string; to: string } {
  const { start, end } = rangeWindowFor(now, rangeDays);
  return { from: start.toISOString().slice(0, 10), to: end.toISOString().slice(0, 10) };
}
