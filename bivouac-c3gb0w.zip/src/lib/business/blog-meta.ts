// @polsia:user-owned — server-side Post reads used by the blog post page's
// `generateMetadata` and `generateStaticParams`. Lives under src/lib/** so the
// biome noRestrictedImports override lifts the `@/lib/db` import restriction;
// the page file wires it through but never imports `@/lib/db` itself.
//
// Same P2021 fallback src/lib/seo-routes.ts uses: on a deploy where the Post
// table hasn't been pushed yet, the build degrades to "no published posts"
// rather than failing. Anything else re-throws so a real bug is not swallowed.

import { prisma } from '@/lib/db';

export type PostMeta = {
  slug: string;
  title: string;
  excerpt: string;
  publishedAt: Date | null;
};

export async function loadPublishedPostMeta(slug: string): Promise<PostMeta | null> {
  try {
    return await prisma.post.findFirst({
      where: { slug, publishedAt: { not: null } },
      select: { slug: true, title: true, excerpt: true, publishedAt: true },
    });
  } catch (error) {
    const code = (error as { code?: string } | null)?.code;
    if (code === 'P2021') return null;
    throw error;
  }
}

export async function listPublishedPostSlugs(): Promise<{ slug: string }[]> {
  try {
    return await prisma.post.findMany({
      where: { publishedAt: { not: null } },
      select: { slug: true },
    });
  } catch (error) {
    const code = (error as { code?: string } | null)?.code;
    if (code === 'P2021') return [];
    throw error;
  }
}
