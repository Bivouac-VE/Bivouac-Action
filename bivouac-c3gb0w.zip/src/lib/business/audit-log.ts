// @polsia:user-owned — server-only helpers for the /dashboard/audit log
// feature. Imports `'server-only'` so a stray client import fails the build
// at the lint gate rather than leaking Prisma through the data plane.
//
// Scope: every read filters rows by `userId = <session.id> OR userId IS NULL`.
// Legacy null rows predate per-user attribution; keeping them visible preserves
// a non-empty experience before the cron writes a real row for a fresh signup
// (plan: option (b)). A future "only my rows" mode is a one-line tightening.

import 'server-only';
import { deriveSeverity } from '@/lib/business/patches';
import {
  type AuditLogAction,
  type AuditLogActor,
  type AuditLogEventKind,
  type AuditLogFilter,
  AuditLogList,
  type AuditLogRow,
  type AuditLogSeverity,
} from '@/lib/contracts/audit-log';
import { prisma } from '@/lib/db';

const DEFAULT_LIMIT = 100;
const MAX_LIMIT = 500;
const NONE_REPO_SLUG = '__none__';
const MAX_REPO_SLUGS = 25;

function clampLimit(rawLimit: number | null): number {
  if (typeof rawLimit !== 'number' || !Number.isFinite(rawLimit) || rawLimit <= 0) {
    return DEFAULT_LIMIT;
  }
  return Math.min(rawLimit, MAX_LIMIT);
}

function trimOrNull(value: string | null): string | null {
  if (value === null) return null;
  const trimmed = value.trim();
  return trimmed.length === 0 ? null : trimmed;
}

const ALLOWED_SEVERITY = new Set(['low', 'medium', 'high', 'critical']);

function parseSeverity(value: string | null): AuditLogSeverity | null {
  if (value === null) return null;
  const v = value.trim().toLowerCase();
  return ALLOWED_SEVERITY.has(v) ? (v as AuditLogSeverity) : null;
}

const ALLOWED_ACTION = new Set(['auto-merged', 'downgraded', 'paged', 'declined', 'exported']);

function parseAction(value: string | null): AuditLogAction | null {
  if (value === null) return null;
  const v = value.trim().toLowerCase();
  return ALLOWED_ACTION.has(v) ? (v as AuditLogAction) : null;
}

const ALLOWED_ACTOR = new Set(['agent', 'human']);

function parseActor(value: string | null): AuditLogActor | null {
  if (value === null) return null;
  const v = value.trim().toLowerCase();
  return ALLOWED_ACTOR.has(v) ? (v as AuditLogActor) : null;
}

// Inclusive end-of-day: an `to=YYYY-MM-DD` value at midnight becomes `T23:59:59.999Z`.
function parseEndOfDay(value: string): Date | null {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    parsed.setUTCHours(23, 59, 59, 999);
  }
  return parsed;
}

// Lightweight numeric-segment compare (locale, numeric). Sufficient for well-
// formed semver / dep versions; for malformed input it falls back to
// lexicographic so the UI badge still renders something stable.
function semverCompare(a: string, b: string): number {
  const left = a.trim();
  const right = b.trim();
  if (left === right) return 0;
  try {
    return left.localeCompare(right, undefined, { numeric: true, sensitivity: 'base' });
  } catch {
    return left < right ? -1 : 1;
  }
}

// Brief's "downgraded" outcome: AUTO_MERGE rows where toVersion < fromVersion
// (e.g. a CVE advisory points at an earlier patched release). 0 is treated as
// "equal/no change", only strictly less counts as a downgrade.
function isDowngrade(fromVersion: string, toVersion: string): boolean {
  return semverCompare(toVersion, fromVersion) < 0;
}

// Persisted mergeDecision (uppercase enum from cron) -> brief's noun form.
// Stays consistent with deriveMergeState in lib/business/patches.ts; when an
// AUTO_MERGE row shipped a strictly older version we surface it as
// `downgraded` (the brief's outcome taxonomy).
function deriveAction(
  mergeDecision: string,
  row: { fromVersion: string; toVersion: string },
): AuditLogAction {
  switch (mergeDecision) {
    case 'AUTO_MERGE':
      return isDowngrade(row.fromVersion, row.toVersion) ? 'downgraded' : 'auto-merged';
    case 'MANUAL_REVIEW':
      return 'paged';
    case 'BLOCKED':
      return 'declined';
    default:
      return 'paged';
  }
}

function deriveActor(stored: string): AuditLogActor {
  return stored === 'human' ? 'human' : 'agent';
}

function deriveEventKind(stored: string): AuditLogEventKind {
  return stored === 'BREAKING' ? 'BREAKING' : 'CVE';
}

// ATTESTATION rows aren't real patch events — they record "this user exported
// this bundle". The AuditLogRow schema requires a few columns the attestation
// table doesn't carry, so we synthesize neutrals; the renderer takes its
// visual reality from `eventKind === 'ATTESTATION'` and bypasses those columns.
function attestationRowFromDownload(row: {
  id: string;
  userId: string;
  repoId: string;
  ownerHandle: string;
  repoName: string;
  quarter: string;
  format: string;
  bundleHash: string;
  createdAt: Date;
}): AuditLogRow {
  return {
    id: row.id,
    createdAt: row.createdAt.toISOString(),
    cveId: null,
    // The renderer shows the package column for triage rows; for ATTESTATION
    // rows it gets overridden to display the badge + quarter + format — so we
    // put the repo name in here to keep the schema's `min(1)` contract met.
    packageName: row.repoName,
    fromVersion: '—',
    toVersion: '—',
    severity: 'low',
    testOutcome: 'PASSED',
    mergeDecision: 'AUTO_MERGE',
    action: 'exported',
    actor: 'human',
    eventKind: 'ATTESTATION',
    repo: `${row.ownerHandle}/${row.repoName}`,
    // Synthetic re-export anchor — the .url() validator accepts it. The
    // /dashboard/attest page reads its picker state from `repoId` + `quarter`
    // search params and re-runs the export with the same input.
    prUrl: `https://attestation.local/${encodeURIComponent(row.bundleHash)}`,
    details: {
      quarter: row.quarter,
      repoId: row.repoId,
      ownerHandle: row.ownerHandle,
      repoName: row.repoName,
      format: row.format,
      bundleHash: row.bundleHash,
    },
  };
}

export function parseAuditFilter(searchParams: URLSearchParams): AuditLogFilter {
  const rawLimit = Number.parseInt(searchParams.get('limit') ?? '', 10);
  // Multi-select: comma-separated slugs, deduped + capped so a malformed query
  // can't blow up the Prisma `OR` clause. Empty string collapses to null.
  const rawRepo = searchParams.get('repo');
  let repo: string[] | null = null;
  if (rawRepo !== null) {
    const parts = rawRepo
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0)
      .slice(0, MAX_REPO_SLUGS);
    const dedup = Array.from(new Set(parts));
    repo = dedup.length > 0 ? dedup : null;
  }
  return {
    repo,
    cveId: trimOrNull(searchParams.get('cveId')),
    from: trimOrNull(searchParams.get('from')),
    to: trimOrNull(searchParams.get('to')),
    severity: parseSeverity(searchParams.get('severity')),
    action: parseAction(searchParams.get('action')),
    actor: parseActor(searchParams.get('actor')),
    limit: clampLimit(Number.isFinite(rawLimit) ? rawLimit : null),
  };
}

// Stable slug extraction. The fixture cron stores full prUrls like
// https://github.com/bivouac/sample-firmware/pull/12 — we surface the
// owner/repo portion so the Repo filter dropdown matches what users see.
export function repoSlugFromRow(prUrl: string): string {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0]}/${parts[1]}`;
    }
    return '';
  } catch {
    return '';
  }
}

// BREAKING rows have no CVE id, so deriveSeverity cannot score them — fall
// back to "medium" until BREAKING rows start carrying their own severity tag.
function deriveBreakingSeverity(): AuditLogSeverity {
  return 'medium';
}

// Inverse of deriveAction: a "paged" filter narrows to rows where
// mergeDecision = 'MANUAL_REVIEW', etc. `downgraded` is filtered in JS
// (semver predicate), so it's intentionally omitted from this map. `exported`
// comes from a different table (AttestationDownload), so it's also omitted.
const ACTION_TO_DECISION: Record<
  Exclude<AuditLogAction, 'downgraded' | 'exported'>,
  'AUTO_MERGE' | 'MANUAL_REVIEW' | 'BLOCKED'
> = {
  'auto-merged': 'AUTO_MERGE',
  paged: 'MANUAL_REVIEW',
  declined: 'BLOCKED',
};

function toAuditRow(row: {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  actor: string;
  eventKind: string;
  createdAt: Date;
}): AuditLogRow {
  const fromVersion = row.fromVersion;
  const toVersion = row.toVersion;
  return {
    id: row.id,
    createdAt: row.createdAt.toISOString(),
    cveId: row.cveId,
    packageName: row.packageName,
    fromVersion,
    toVersion,
    severity: row.cveId
      ? (deriveSeverity(row.cveId) as AuditLogSeverity)
      : deriveBreakingSeverity(),
    testOutcome: row.testOutcome as AuditLogRow['testOutcome'],
    mergeDecision: row.mergeDecision as AuditLogRow['mergeDecision'],
    action: deriveAction(row.mergeDecision, { fromVersion, toVersion }),
    actor: deriveActor(row.actor),
    eventKind: deriveEventKind(row.eventKind),
    repo: repoSlugFromRow(row.prUrl),
    prUrl: row.prUrl,
  };
}

export async function listAudit(filter: AuditLogFilter, userId: string): Promise<AuditLogList> {
  const conditions: Record<string, unknown>[] = [];

  if (filter.cveId) {
    conditions.push({ cveId: { contains: filter.cveId } });
  }
  if (filter.from) {
    const fromDate = new Date(filter.from);
    if (!Number.isNaN(fromDate.getTime())) {
      conditions.push({ createdAt: { gte: fromDate } });
    }
  }
  if (filter.to) {
    const toDate = parseEndOfDay(filter.to);
    if (toDate) {
      conditions.push({ createdAt: { lte: toDate } });
    }
  }
  // Multi-select repo filter: each slug OR'd so the table shows rows from any
  // selected repo. The lone `__none__` slug matches nothing (a sentinel for
  // "show rows with no repo slug yet"). An empty array means "no filter".
  if (filter.repo && filter.repo.length > 0) {
    const slugs = filter.repo;
    if (slugs.length === 1 && slugs[0] === NONE_REPO_SLUG) {
      conditions.push({ prUrl: { contains: '__never_matches_a_real_pr_url__' } });
    } else {
      const orClauses = slugs.map((slug) => ({ prUrl: { contains: slug } }));
      if (slugs.includes(NONE_REPO_SLUG)) {
        orClauses.push({ prUrl: { contains: '__never_matches_a_real_pr_url__' } });
      }
      conditions.push({ OR: orClauses });
    }
  }
  if (filter.action && filter.action !== 'exported') {
    // Map the short-noun action back onto the persisted enum where possible.
    // `downgraded` is semantic — AUTO_MERGE rows on a version downgrade — so
    // we filter in JS after the read rather than translating to AUTO_MERGE in
    // SQL (that would also pull in non-downgrade auto-merged rows).
    // `exported` lives on AttestationDownload, not CveTriageLog — handled
    // separately by post-merge filtering below.
    if (filter.action !== 'downgraded') {
      conditions.push({ mergeDecision: ACTION_TO_DECISION[filter.action] });
    }
  }
  if (filter.actor) {
    conditions.push({ actor: filter.actor });
  }

  // Per-scope (plan: option b): every signed-in user sees their own rows
  // (`userId = session.id`) AND legacy fixture rows (`userId IS NULL`).
  const where = {
    AND: [...conditions, { OR: [{ userId }, { userId: null }] }],
  };

  const [triageRows, downloadRows] = await Promise.all([
    prisma.cveTriageLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: filter.limit,
    }),
    // If the filter targets `exported` rows, only the attestation table
    // can contribute them.
    filter.action === 'exported'
      ? prisma.attestationDownload.findMany({
          where: { userId },
          orderBy: { createdAt: 'desc' },
          take: filter.limit,
        })
      : Promise.resolve([] as Awaited<ReturnType<typeof prisma.attestationDownload.findMany>>),
  ]);

  const triageItems = triageRows
    .map(toAuditRow)
    .filter((r) => (filter.severity ? r.severity === filter.severity : true))
    .filter((r) => (filter.action === 'downgraded' ? r.action === 'downgraded' : true));

  const attestationItems: AuditLogRow[] = downloadRows.map((row) =>
    attestationRowFromDownload(row),
  );

  // Merge by createdAt desc, then take the limit so the table caps cleanly.
  const merged = [...triageItems, ...attestationItems]
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0))
    .slice(0, filter.limit)
    .filter((r) => (filter.action === 'exported' ? r.action === 'exported' : true))
    .filter((r) => (filter.severity ? r.severity === filter.severity : true));

  return AuditLogList.parse({ items: merged, total: merged.length });
}

// RFC-4180 escape: wrap in quotes if the cell contains comma/quote/newline,
// doubling any internal quote.
function csvCell(value: string): string {
  if (value === '') return '';
  if (/[",\r\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

// CSV columns: keep every legacy column intact (forensic continuity for the
// NIS2/CRA evidence trail) AND append the new action / actor / event_kind
// columns requested by the brief.
const CSV_COLUMNS = [
  'created_at',
  'cve',
  'repo',
  'package',
  'from_version',
  'to_version',
  'severity',
  'test_outcome',
  'merge_decision',
  'pr_url',
  'event_kind',
  'action',
  'actor',
] as const;

export function buildAuditCsv(rows: AuditLogRow[]): string {
  const header = CSV_COLUMNS.map(csvCell).join(',');
  const body = rows
    .map((row) =>
      [
        row.createdAt,
        row.cveId ?? '',
        row.repo,
        row.packageName,
        row.fromVersion,
        row.toVersion,
        row.severity,
        row.testOutcome,
        row.mergeDecision,
        row.prUrl,
        row.eventKind,
        row.action,
        row.actor,
      ]
        .map(csvCell)
        .join(','),
    )
    .join('\n');
  return body.length > 0 ? `${header}\n${body}\n` : `${header}\n`;
}
