// @polsia:user-owned — server-only helpers for the Slack + PagerDuty
// integrations feature. Pure logic + a single outbound fetch helper. No
// Prisma, no network I/O beyond the canary send. Runs inside the
// `server-only` envelope so a stray client import fails the build.
//
// Slack and PagerDuty are very different shapes so the helpers are split:
//
//   - Slack: validates an incoming-webhook URL. The host is fixed
//     (`hooks.slack.com`), the path must match `services/T<id>/B<id>/<secret>`.
//     The URL itself encodes the secret, so it stays opaque — we never parse
//     the user-secret segment, never try to extract a key from it.
//
//   - PagerDuty: validates a 32-hex routing key OR a full events.pagerduty.com
//     URL. We resolve the URL down to a routing key because some users paste
//     the URL from their docs. The Events API v2 endpoint (`POST
//     https://events.pagerduty.com/v2/enqueue`) does NOT sign — authentication
//     is `routing_key` in the JSON body — so there is no signature helper.
//
// PagerDuty ships the destination URL (`events.pagerduty.com`), so SSRF is
// not a concern for that provider — we own the host. Slack's URL is opaque
// beyond the host regex; we still re-check the host at fetch time as belt-
// and-braces in case a future Slack infra change introduces a private IP.

import 'server-only';

/** Slack incoming-webhook host (fixed) and path shape. */
const SLACK_HOST = 'hooks.slack.com';
const SLACK_PATH_RE = /^\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[A-Za-z0-9]+$/;

const MAX_URL_LENGTH = 256;
const TIMEOUT_MS = 10_000;

/** PagerDuty routing key format. The v2 Events API documents the key as a
 *  32-character uppercase hex string. Allow lowercase too — humans copy/paste
 *  through a hex-cleaning pipeline that downcases. We uppercase internally. */
const PAGERDUTY_KEY_RE = /^[0-9a-f]{32}$/i;

const PAGERDUTY_HOST = 'events.pagerduty.com';
const PAGERDUTY_URL_RE = /^https:\/\/events\.pagerduty\.com\/v2\/enqueue\/?$/;

/** Shared transport result. Both canary helpers (dispatchSlack, dispatchPagerDuty)
 *  and the rule-trip helpers (buildRuleSlackPayload + dispatchPagerDutyForRule
 *  callers) return this so the route handlers can audit them with one shape. */
type DispatchResult = {
  status: 'delivered' | 'failed';
  statusCode: number | null;
  error: string | null;
};

export type SlackValidation = { ok: true; url: URL; host: string } | { ok: false; reason: string };

/** Validate an incoming-webhook URL. Host must be hooks.slack.com and path
 *  must follow /services/T…/B…/secret. */
export function validateSlackUrl(rawUrl: string): SlackValidation {
  if (typeof rawUrl !== 'string' || rawUrl.length === 0) {
    return { ok: false, reason: 'URL is required.' };
  }
  if (rawUrl.length > MAX_URL_LENGTH) {
    return { ok: false, reason: `URL must be ${MAX_URL_LENGTH} characters or fewer.` };
  }
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return { ok: false, reason: 'URL could not be parsed.' };
  }
  if (parsed.protocol !== 'https:') {
    return { ok: false, reason: 'URL must use HTTPS.' };
  }
  const host = parsed.hostname.trim().toLowerCase();
  if (host !== SLACK_HOST) {
    return { ok: false, reason: `Slack URL must be on ${SLACK_HOST}.` };
  }
  if (!SLACK_PATH_RE.test(parsed.pathname)) {
    return {
      ok: false,
      reason:
        'Slack URL must look like https://hooks.slack.com/services/T.../B.../... — the secret is in the path.',
    };
  }
  return { ok: true, url: parsed, host };
}

export type PagerDutyValidation = { ok: true; routingKey: string } | { ok: false; reason: string };

/** Validate a PagerDuty integration value. Accept either a bare 32-hex key
 *  OR a full https://events.pagerduty.com URL (the URL has no key in it —
 *  the user pastes one or the other). */
export function validatePagerDutyValue(raw: string): PagerDutyValidation {
  if (typeof raw !== 'string' || raw.length === 0) {
    return { ok: false, reason: 'Routing key is required.' };
  }
  const trimmed = raw.trim();
  if (trimmed.length > 256) {
    return { ok: false, reason: 'Routing key or URL must be 256 characters or fewer.' };
  }
  // Full URL form
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    let parsed: URL;
    try {
      parsed = new URL(trimmed);
    } catch {
      return { ok: false, reason: 'PagerDuty URL could not be parsed.' };
    }
    if (parsed.protocol !== 'https:') {
      return { ok: false, reason: 'PagerDuty URL must use HTTPS.' };
    }
    if (parsed.hostname.toLowerCase() !== PAGERDUTY_HOST) {
      return { ok: false, reason: `PagerDuty URL host must be ${PAGERDUTY_HOST}.` };
    }
    if (!PAGERDUTY_URL_RE.test(parsed.toString().replace(/\/$/, ''))) {
      return { ok: false, reason: 'PagerDuty URL must end at /v2/enqueue.' };
    }
    // The URL form does NOT carry a key — the user must paste the key
    // separately when copying a URL. Fall through to asking for the key.
    return {
      ok: false,
      reason:
        'Paste your 32-character PagerDuty integration key (the URL alone is the endpoint, not the key).',
    };
  }
  if (!PAGERDUTY_KEY_RE.test(trimmed)) {
    return {
      ok: false,
      reason:
        'PagerDuty integration key must be exactly 32 hexadecimal characters (the routing key from your PagerDuty service).',
    };
  }
  return { ok: true, routingKey: trimmed.toUpperCase() };
}

/** Compose the Slack incoming-webhook JSON body. Slack supports plain text
 *  via `text`; we send a `blocks` payload for richer presentation in Slack
 *  clients while keeping a fallback `text` so mobile notifications work. */
export function buildSlackPayload(args: {
  preview: { provider: 'slack' | 'pagerduty'; message: string; teamId: string; scope: string };
}): string {
  const { preview } = args;
  const text = preview.message;
  return JSON.stringify({
    text,
    blocks: [
      {
        type: 'section',
        text: { type: 'mrkdwn', text: `:white_check_mark: *Bivouac test notification* — ${text}` },
      },
      {
        type: 'context',
        elements: [
          {
            type: 'mrkdwn',
            text: `Provider: *${preview.provider}* · Team: *${preview.teamId}* · Scope: *${preview.scope}*`,
          },
        ],
      },
    ],
  });
}

/** Compose the PagerDuty Events API v2 body. Per the docs: a single named
 *  `routing_key` + a `event_action` of `trigger` + an `payload` block carrying
 *  the human-facing `summary` + `source` + `severity`. */
export function buildPagerDutyPayload(args: {
  routingKey: string;
  summary: string;
  source: string;
}): string {
  return JSON.stringify({
    routing_key: args.routingKey,
    event_action: 'trigger',
    payload: {
      summary: args.summary,
      source: args.source,
      severity: 'info',
    },
    dedup_key: `bivouac-test-${Date.now()}`,
  });
}

/** Send a Slack POST. Used by the canary "send test notification" only. */
export async function dispatchSlack(args: { url: URL; body: string }): Promise<DispatchResult> {
  return postPlainJson({
    url: args.url.toString(),
    headers: { 'user-agent': 'bivouac-integrations/1.0', 'x-bivouac-kind': 'slack-canary' },
    body: args.body,
  });
}

/** Send a PagerDuty events POST. */
export async function dispatchPagerDuty(args: { routingKey: string }): Promise<DispatchResult> {
  const body = buildPagerDutyPayload({
    routingKey: args.routingKey,
    summary: 'Bivouac test notification',
    source: 'bivouac-dashboard',
  });
  return postPlainJson({
    url: 'https://events.pagerduty.com/v2/enqueue',
    headers: { 'user-agent': 'bivouac-integrations/1.0', 'x-bivouac-kind': 'pagerduty-canary' },
    body,
  });
}

/** Slack payload for a real "page a human" rule-trip. Mirrors the shape of
 *  `buildSlackPayload` (section + context blocks, mrkdwn text) but interpolates
 *  the rule reason, repo identity, and PR link the brief mandates. The
 *  `blocks[0].text` carries the headline; `blocks[1]` (a `context` row)
 *  mirrors the team / scope / provider audit trail the canary payload includes.
 *  Returned as a JSON-encoded string so the Slack helper stays a single-call
 *  transport layer and the postPlainJson body matches the canary path. */
export function buildRuleSlackPayload(args: {
  provider: 'slack' | 'pagerduty';
  teamId: string;
  scope: string;
  repo: string;
  reason: string;
  prUrl: string;
}): string {
  const { provider, teamId, scope, repo, reason, prUrl } = args;
  const headline = `:rotating_light: ${reason} on ${repo}`;
  const contextLine = `*PR*: <${prUrl}|${prUrl}> · *Provider*: ${provider} · *Team*: ${teamId} · *Scope*: ${scope}`;
  return JSON.stringify({
    text: `${reason} on ${repo}`,
    blocks: [
      { type: 'section', text: { type: 'mrkdwn', text: `*${headline}*` } },
      {
        type: 'context',
        elements: [{ type: 'mrkdwn', text: contextLine }],
      },
    ],
  });
}

/** Sibling of `dispatchPagerDuty` (canary) that takes the full PagerDuty
 *  payload inputs the brief mandates: the `summary`, `source`, `severity`,
 *  and a `custom_details` block with the rule context (repo / reason / prUrl).
 *  Tagged with a distinct `dedup_key` prefix so the v2 endpoint bucketing is
 *  clearly distinguishable from the canary's `bivouac-test-…` keys. We do NOT
 *  retrofit `dispatchPagerDuty` — that would change canary semantics on
 *  /api/integrations/test. The shape matches PagerDuty's documented schema
 *  (`routing_key`, `event_action: 'trigger'`, `payload.{summary,source,
 *  severity}`, `custom_details`, `dedup_key`). */
export async function dispatchPagerDutyForRule(args: {
  routingKey: string;
  summary: string;
  source: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  customDetails: { repo: string; reason: string; prUrl: string };
}): Promise<DispatchResult> {
  const body = JSON.stringify({
    routing_key: args.routingKey,
    event_action: 'trigger',
    payload: {
      summary: args.summary,
      source: args.source,
      severity: args.severity,
      custom_details: args.customDetails,
    },
    dedup_key: `bivouac-rule-${Date.now()}`,
  });
  return postPlainJson({
    url: 'https://events.pagerduty.com/v2/enqueue',
    headers: {
      'user-agent': 'bivouac-integrations/1.0',
      'x-bivouac-kind': 'pagerduty-rule',
    },
    body,
  });
}

/** `runDay` prefix used for rule-triggered deliveries. Mirrors `canary-<ISO>`
 *  so the @@unique([integrationId, runDay]) contract still applies (the two
 *  prefixes can never collide) while making it trivial to filter audit rows
 *  to "real" deliveries vs manual canary probes. */
export function ruleRunDay(now: Date = new Date()): string {
  return `rule-${now.toISOString()}`;
}

/** Truncate a free-text error for the deliveries table / toast message.
 *  Mirrors previewError in src/lib/business/digest-webhook.ts. */
export function previewError(message: string | null | undefined, max: number = 140): string | null {
  if (!message) return null;
  if (message.length <= max) return message;
  return `${message.slice(0, max - 1)}…`;
}

/** Compose a stable `runDay` for a canary send. Mirrors canaryRunDay() in
 *  digest-webhook so each click writes a distinct IntegrationDelivery row. */
export function canaryRunDay(now: Date = new Date()): string {
  return `canary-${now.toISOString()}`;
}

async function postPlainJson(args: {
  url: string;
  headers: Record<string, string>;
  body: string;
}): Promise<{ status: 'delivered' | 'failed'; statusCode: number | null; error: string | null }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(args.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...args.headers },
      body: args.body,
      signal: controller.signal,
    });
    if (res.ok) return { status: 'delivered', statusCode: res.status, error: null };
    const detail = await res.text().catch(() => '');
    return {
      status: 'failed',
      statusCode: res.status,
      error: detail || `HTTP ${res.status}`,
    };
  } catch (err: unknown) {
    const message =
      err instanceof Error
        ? err.name === 'AbortError'
          ? `Request timed out after ${TIMEOUT_MS}ms`
          : err.message
        : 'Network error';
    return { status: 'failed', statusCode: null, error: message };
  } finally {
    clearTimeout(timer);
  }
}
