// @polsia:user-owned — typed wrapper over `GET /app/installations/{id}/repositories`.
// Walks the pagination so we always return the full list, not just page 1.

import 'server-only';
import { decodePrivateKeyPem, signAppJwt } from './jwt';

export interface GhRepoResponse {
  id: number;
  node_id: string;
  name: string;
  full_name: string;
  default_branch: string | null;
  private: boolean;
  visibility?: string | null;
  pushed_at?: string | null;
}

export interface ListedRepo {
  githubRepoId: bigint;
  githubNodeId: string;
  name: string;
  ownerHandle: string;
  defaultBranch: string;
  visibility: 'public' | 'private';
  pushedAt: string | null;
}

interface AppCredentials {
  appId: string;
  privateKeyB64: string;
}

interface PageResponse {
  repositories: GhRepoResponse[];
  total_count?: number;
}

async function fetchPage(
  installationId: string,
  perPage: number,
  page: number,
  creds: AppCredentials,
): Promise<PageResponse> {
  const pem = decodePrivateKeyPem(creds.privateKeyB64);
  const jwt = await signAppJwt({ appId: creds.appId, privateKeyPem: pem });
  const url = new URL(
    `https://api.github.com/app/installations/${encodeURIComponent(installationId)}/repositories`,
  );
  url.searchParams.set('per_page', String(perPage));
  url.searchParams.set('page', String(page));
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${jwt}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'bivouac-connect',
    },
    cache: 'no-store',
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`GitHub repos fetch failed (${res.status}): ${body}`);
  }
  return (await res.json()) as PageResponse;
}

const PER_PAGE = 100;

function splitOwner(fullName: string): { ownerHandle: string; name: string } {
  const idx = fullName.indexOf('/');
  if (idx === -1) return { ownerHandle: 'unknown', name: fullName };
  return {
    ownerHandle: fullName.slice(0, idx),
    name: fullName.slice(idx + 1),
  };
}

export async function listInstallationRepos(
  installationId: bigint | number | string,
  creds: AppCredentials,
): Promise<ListedRepo[]> {
  const all: ListedRepo[] = [];
  let page = 1;
  for (;;) {
    const data = await fetchPage(String(installationId), PER_PAGE, page, creds);
    for (const r of data.repositories) {
      if (!r.full_name || !r.node_id) continue;
      const { ownerHandle, name } = splitOwner(r.full_name);
      all.push({
        githubRepoId: BigInt(r.id),
        githubNodeId: r.node_id,
        name,
        ownerHandle,
        defaultBranch: r.default_branch ?? 'main',
        visibility: r.visibility === 'private' ? 'private' : 'public',
        pushedAt: r.pushed_at ?? null,
      });
    }
    if (data.repositories.length < PER_PAGE) break;
    page += 1;
    if (page > 50) {
      // Defensive cap — 5,000 repos is the GitHub-documented upper bound
      // for this endpoint per installation. If we hit this we know something
      // weird is happening and we stop rather than spinning forever.
      break;
    }
  }
  return all;
}
