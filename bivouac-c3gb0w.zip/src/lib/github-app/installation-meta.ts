// @polsia:user-owned — typed wrapper over the GitHub App REST endpoint
// `GET /app/installations/{installation_id}`. Uses a fresh RS256 App JWT
// from jwt.ts on each call. Returns the account info (login + type) we
// need to humanise the connect confirmation page.

import 'server-only';
import { decodePrivateKeyPem, signAppJwt } from './jwt';

export interface InstallationAccount {
  login: string;
  /** "User" or "Organization". GitHub may add more in future. */
  type: string;
}

interface AppCredentials {
  appId: string;
  privateKeyB64: string;
}

interface GithubInstallationResponse {
  id: number;
  account?: { login?: string; type?: string };
  app_id?: number;
}

async function fetchInstallation(
  installationId: string,
  creds: AppCredentials,
): Promise<GithubInstallationResponse> {
  const pem = decodePrivateKeyPem(creds.privateKeyB64);
  const jwt = await signAppJwt({ appId: creds.appId, privateKeyPem: pem });
  const url = `https://api.github.com/app/installations/${encodeURIComponent(installationId)}`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${jwt}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'bivouac-connect',
    },
    cache: 'no-store',
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`GitHub installation fetch failed (${res.status}): ${body}`);
  }
  return (await res.json()) as GithubInstallationResponse;
}

export async function getInstallation(
  installationId: bigint | number | string,
  creds: AppCredentials,
): Promise<InstallationAccount> {
  const resp = await fetchInstallation(String(installationId), creds);
  return {
    login: resp.account?.login ?? 'unknown',
    type: resp.account?.type ?? 'Unknown',
  };
}
