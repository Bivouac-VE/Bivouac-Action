// @polsia:user-owned — App-level GitHub JWT signer. Issues a short-lived
// RS256 JWT signed with the App's private key. GitHub accepts max 10-minute
// tokens; we mint at call time so we never hand back a stale one. Pure Node
// crypto — no external JWT dep.
//
// Usage:
//   const jwt = await signAppJwt({ appId, privateKeyPem });
//   fetch(..., { headers: { Authorization: `Bearer ${jwt}` } })
//
// The private key is stored base64-encoded in `GITHUB_APP_PRIVATE_KEY` (PEM
// newlines don't survive naive `.env` parsing). We decode at first use and
// hold the decoded form in a memoized slot for the rest of the process so
// subsequent JWT mints don't re-parse.

import 'server-only';
import { createSign } from 'node:crypto';

const MAX_AGE_SECONDS = 9 * 60; // 9 minutes — GitHub's maximum is 10.

interface SignArgs {
  appId: string;
  /** PEM private key, decoded (real newlines). */
  privateKeyPem: string;
}

function base64Url(input: Buffer | string): string {
  const buf = typeof input === 'string' ? Buffer.from(input, 'utf8') : input;
  return buf.toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

/** Sign a fresh App JWT for the given credentials. ~9 minute max-age. */
export async function signAppJwt({ appId, privateKeyPem }: SignArgs): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const payload = {
    iat: now,
    exp: now + MAX_AGE_SECONDS,
    iss: appId,
  };

  const encodedHeader = base64Url(JSON.stringify(header));
  const encodedPayload = base64Url(JSON.stringify(payload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;

  const signer = createSign('RSA-SHA256');
  signer.update(signingInput);
  signer.end();
  const signature = signer.sign(privateKeyPem);
  const encodedSig = base64Url(signature);

  return `${signingInput}.${encodedSig}`;
}

/**
 * Decode the base64-supplied PEM. Cached so a long-running process pays the
 * decode cost once per key. The cache key is a static `'default'` since
 * bivouac only ever has one App installed.
 */
const pemCache = new Map<string, string>();
export function decodePrivateKeyPem(b64: string, cacheKey = 'default'): string {
  const cached = pemCache.get(cacheKey);
  if (cached) return cached;
  const pem = Buffer.from(b64, 'base64').toString('utf8');
  pemCache.set(cacheKey, pem);
  return pem;
}

/** Reset the cache — used by tests, not by production code. */
export function _resetPemCache(): void {
  pemCache.clear();
}
