// @polsia:user-owned — short-lived HS256 state JWT for the GitHub App install
// round-trip. The connect route signs an `inst: 'bivouac-connect'` payload
// binding the call to `session.user.id`; the callback verifies it. 10-min
// expiry: window covers a reasonable end-to-end install pause and is short
// enough that a stolen URL isn't useful.

import 'server-only';
import { createHmac, timingSafeEqual } from 'node:crypto';

export const INSTALL_STATE_VERSION = 'bivouac-connect-v1';

export interface InstallStatePayload {
  userId: string;
  nonce: string;
  /** Absolute unix-time the JWT was issued (for debugging only). */
  iat: number;
  /** Absolute unix-time the JWT expires. */
  exp: number;
}

export interface SignInstallStateArgs {
  userId: string;
  secret: string;
  ttlSeconds?: number;
  /** Injectable clock for tests. Defaults to Date.now(). */
  now?: () => number;
  /** Override the nonce — tests only. */
  nonce?: string;
}

const DEFAULT_TTL_SECONDS = 10 * 60;

function base64Url(input: Buffer | string): string {
  const buf = typeof input === 'string' ? Buffer.from(input, 'utf8') : input;
  return buf.toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

/** Sign a state JWT for the connect round-trip. */
export function signInstallState({
  userId,
  secret,
  ttlSeconds = DEFAULT_TTL_SECONDS,
  now = Date.now,
  nonce,
}: SignInstallStateArgs): string {
  const issuedAt = Math.floor(now() / 1000);
  const exp = issuedAt + ttlSeconds;
  const payload: InstallStatePayload = {
    userId,
    nonce: nonce ?? Math.random().toString(36).slice(2, 12),
    iat: issuedAt,
    exp,
  };
  const header = { alg: 'HS256', typ: 'JWT', ver: INSTALL_STATE_VERSION };
  const encodedHeader = base64Url(JSON.stringify(header));
  const encodedPayload = base64Url(JSON.stringify(payload));
  const signingInput = `${encodedHeader}.${encodedPayload}`;
  const sig = createHmac('sha256', secret).update(signingInput).digest();
  return `${signingInput}.${base64Url(sig)}`;
}

export type VerifyResult =
  | { ok: true; payload: InstallStatePayload }
  | { ok: false; reason: 'malformed' | 'bad-signature' | 'expired' | 'wrong-user' };

export interface VerifyInstallStateArgs {
  token: string;
  secret: string;
  /** Required `userId` — the caller MUST be the same user who initiated. */
  currentUserId: string;
  /** Injectable clock for tests. */
  now?: () => number;
}

export function verifyInstallState({
  token,
  secret,
  currentUserId,
  now = Date.now,
}: VerifyInstallStateArgs): VerifyResult {
  const parts = token.split('.');
  if (parts.length !== 3) return { ok: false, reason: 'malformed' };
  const [encodedHeader, encodedPayload, encodedSig] = parts as [string, string, string];

  const signingInput = `${encodedHeader}.${encodedPayload}`;
  const expectedSig = createHmac('sha256', secret).update(signingInput).digest();
  let providedSig: Buffer;
  try {
    providedSig = Buffer.from(
      encodedSig
        .replace(/-/g, '+')
        .replace(/_/g, '/')
        .padEnd(encodedSig.length + 4 - (encodedSig.length % 4), '='),
      'base64',
    );
  } catch {
    return { ok: false, reason: 'bad-signature' };
  }
  if (expectedSig.length !== providedSig.length || !timingSafeEqual(expectedSig, providedSig)) {
    return { ok: false, reason: 'bad-signature' };
  }

  let payload: InstallStatePayload;
  try {
    const json = Buffer.from(
      encodedPayload
        .replace(/-/g, '+')
        .replace(/_/g, '/')
        .padEnd(encodedPayload.length + 4 - (encodedPayload.length % 4), '='),
      'base64',
    ).toString('utf8');
    payload = JSON.parse(json) as InstallStatePayload;
  } catch {
    return { ok: false, reason: 'malformed' };
  }
  if (typeof payload.exp !== 'number' || Math.floor(now() / 1000) > payload.exp) {
    return { ok: false, reason: 'expired' };
  }
  if (payload.userId !== currentUserId) {
    return { ok: false, reason: 'wrong-user' };
  }
  return { ok: true, payload };
}
