// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'Bivouac';
// TODO: confirm this fits Twitter's 200-char hard limit and SERP snippet cap (~155 chars).
export const siteDescription =
  'Your first patch PR in 10 minutes. Connect GitHub → choose your policy → Bivouac finds an issue → Patch PR → Tests → Merge. No credit card, no sales call.';

// PWA + social-share colors. HEX only (the oklch() tokens in globals.css aren't
// readable here) — set to match your brand seed.
export const brandVisual = {
  /** PWA browser-UI / status-bar color. */
  themeColor: '#c2410c',
  /** PWA splash + install background. */
  backgroundColor: '#0f0f10',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#0f0f10',
    foreground: '#fafaf9',
    /** Second line under the site name; '' hides it. */
    tagline: 'The 24/7 on-call agent for dependency triage.',
  },
} as const;
