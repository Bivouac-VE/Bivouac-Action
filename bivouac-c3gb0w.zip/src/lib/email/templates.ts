// @polsia:user-owned — your email templates. Edit, add, or delete freely.
// Each template returns { subject, html, text }; send it via the framework transport:
//   import { sendEmail } from '@/lib/email/send';
//   import { welcomeEmail, teamInviteEmail, passwordResetEmail } from '@/lib/email/templates';
//   await sendEmail({ to: user.email, ...passwordResetEmail({ ... }) });
// renderEmail() is a plain inline-styled shell — email clients drop <style>/<link>, so style inline.
// renderEmail() auto-escapes its heading/body/cta/footer, so pass RAW values (don't escapeHtml() them
// first — that double-escapes). escapeHtml() is only for when you hand-build an html string yourself.

/** Subject + rendered bodies — spread into sendEmail({ to, ... }). */
export interface EmailContent {
  subject: string;
  html: string;
  text?: string;
}

export interface RenderEmailOptions {
  heading: string;
  /** Body paragraphs (plain text; escaped for you). */
  body: string[];
  /** Optional call-to-action button. */
  cta?: { label: string; url: string };
  /** Optional footer line under the divider. */
  footer?: string;
}

/** Escape a value for safe interpolation into an HTML attribute or text node. */
export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Wrap content in a minimal, inline-styled email shell. Restyle to match the brand. */
export function renderEmail(options: RenderEmailOptions): { html: string; text: string } {
  const paragraphs = options.body
    .map(
      (line) =>
        `<p style="margin:0 0 16px;color:#333333;font-size:15px;line-height:1.6;">${escapeHtml(line)}</p>`,
    )
    .join('');
  const button = options.cta
    ? `<p style="margin:24px 0 0;"><a href="${escapeHtml(options.cta.url)}" style="display:inline-block;padding:10px 20px;background:#111111;color:#ffffff;text-decoration:none;font-size:15px;">${escapeHtml(options.cta.label)}</a></p>`
    : '';
  const footer = options.footer
    ? `<div style="margin-top:24px;padding-top:16px;border-top:1px solid #e5e5e5;color:#999999;font-size:12px;">${escapeHtml(options.footer)}</div>`
    : '';
  const html = [
    '<div style="max-width:560px;margin:0 auto;padding:24px;font-family:Arial,Helvetica,sans-serif;">',
    `<h1 style="margin:0 0 16px;color:#111111;font-size:22px;">${escapeHtml(options.heading)}</h1>`,
    paragraphs,
    button,
    footer,
    '</div>',
  ].join('');
  const text = [
    options.heading,
    '',
    ...options.body,
    ...(options.cta ? ['', `${options.cta.label}: ${options.cta.url}`] : []),
    ...(options.footer ? ['', options.footer] : []),
  ].join('\n');
  return { html, text };
}

// ─── App templates ───

/** Welcome email for a new signup. */
export function welcomeEmail(input: { name: string; ctaUrl?: string }): EmailContent {
  const { html, text } = renderEmail({
    heading: `Welcome, ${input.name}!`,
    body: ["Thanks for signing up — we're glad you're here."],
    cta: input.ctaUrl ? { label: 'Get started', url: input.ctaUrl } : undefined,
    footer: 'You received this because you created an account.',
  });
  return { subject: 'Welcome aboard', html, text };
}

/** Generic notification email. */
export function notificationEmail(input: {
  subject: string;
  title: string;
  lines: string[];
  cta?: { label: string; url: string };
}): EmailContent {
  const { html, text } = renderEmail({ heading: input.title, body: input.lines, cta: input.cta });
  return { subject: input.subject, html, text };
}

/** Password-reset email — sent when a user requests a reset link via
 * `/forgot-password`. The `resetUrl` is the full URL better-auth builds
 * (already encodes the token); the link is single-use and expires. */
export function passwordResetEmail(input: { name: string; resetUrl: string }): EmailContent {
  const { html, text } = renderEmail({
    heading: 'Reset your Bivouac password',
    body: [
      `Hi ${input.name || 'there'}, we received a request to reset the password for your account.`,
      "If you didn't ask for this, you can safely ignore this email — your password stays the same.",
      'The link below expires, so use it soon.',
    ],
    cta: { label: 'Reset password', url: input.resetUrl },
    footer: 'You received this because someone used the password reset form for your address.',
  });
  return { subject: 'Reset your password', html, text };
}

/** Daily digest — summarize the previous 24 hours of patch activity for
 *  every connected repo, grouped per-repo. The brief's tally taxonomy:
 *  - `autoMerged` = AUTO_MERGE rows on CveTriageLog whose `mergeDecision`
 *    was approved by the agent.
 *  - `cveOpened`  = any new CVE/BREAKING row landed in the window (a CVE
 *    response that was opened — distinct from a row already at a decision).
 *  - `humanOverrides` = rows on HumanOverride where a human reviewer took
 *    over the call (paged reviewer closed the loop / downgraded a branch).
 *
 *  We render through `renderEmail`'s paragraph shell for the text/plain
 *  path AND emit a per-repo summary table in the HTML body so per-day
 *  counts are at-a-glance instead of buried in prose. Values are escaped
 *  explicitly via escapeHtml so repo names/handles can never smuggle a
 *  tag into the cell. */
export interface DigestRepoTally {
  repo: string;
  autoMerged: number;
  cveOpened: number;
  humanOverrides: number;
}

export interface DigestSection {
  heading: string;
  items: DigestRepoTally[];
}

export interface DigestEmailInput {
  name: string;
  /** UTC date string `YYYY-MM-DD` representing the day the digest covers. */
  day: string;
  /** Pre-grouped by repo — usually one section, but the API lets the cron
   *  split by signal source if it wants (CVE rows vs human overrides). */
  sections: DigestSection[];
  /** Deep link into the attest surface for that day's records. */
  attestDeepLink: string;
}

export function digestEmail(input: DigestEmailInput): EmailContent {
  const heading = `Daily digest — ${input.day}`;

  let totalAutoMerged = 0;
  let totalCveOpened = 0;
  let totalHumanOverrides = 0;
  for (const section of input.sections) {
    for (const item of section.items) {
      totalAutoMerged += item.autoMerged;
      totalCveOpened += item.cveOpened;
      totalHumanOverrides += item.humanOverrides;
    }
  }

  const reposInDigest = input.sections.reduce((acc, s) => acc + s.items.length, 0);

  const lead = [
    `Hi ${input.name || 'there'} — here is what happened in the last 24 hours for your connected repositories.`,
    reposInDigest > 0
      ? `Across ${reposInDigest} repo(s): ${totalAutoMerged} auto-merged, ${totalCveOpened} CVE response(s) opened, ${totalHumanOverrides} human override(s).`
      : 'No patch activity in the last 24 hours for your connected repositories.',
  ];

  // Per-repo flat lines that go into the paragraph shell (the existing
  // renderEmail plumbing keeps them safe — escapeHtml runs there on render).
  const perRepoLines: string[] = [];
  for (const section of input.sections) {
    if (section.heading) perRepoLines.push(`— ${section.heading} —`);
    for (const item of section.items) {
      perRepoLines.push(
        `${item.repo}: ${item.autoMerged} auto-merged · ${item.cveOpened} CVE opened · ${item.humanOverrides} human override`,
      );
    }
  }

  const body = [...lead, ...perRepoLines, "See today's records on the attestation page."];

  const render = renderEmail({
    heading,
    body,
    cta: { label: "Open today's attestation", url: input.attestDeepLink },
    footer:
      'You received this because you opted in to the daily digest — turn it off in dashboard settings.',
  });

  // Build the per-repo summary table for the HTML body and splice it in
  // immediately before the CTA `<p>` block. Values are escapeHtml'd here so
  // a hostile ownerHandle / repo name can't smuggle a tag into the cell.
  const sectionsHtml = input.sections
    .map((section) => {
      const sectionHeading = section.heading
        ? `<h2 style="margin:24px 0 8px;color:#111111;font-size:16px;">${escapeHtml(section.heading)}</h2>`
        : '';
      const rows = section.items
        .map(
          (item) =>
            `<tr>
              <td style="padding:6px 12px 6px 0;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;">${escapeHtml(item.repo)}</td>
              <td style="padding:6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(String(item.autoMerged))}</td>
              <td style="padding:6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(String(item.cveOpened))}</td>
              <td style="padding:6px 0 6px 12px;color:#333333;font-size:14px;border-bottom:1px solid #eeeeee;text-align:right;">${escapeHtml(String(item.humanOverrides))}</td>
            </tr>`,
        )
        .join('');
      return `${sectionHeading}
        <table cellpadding="0" cellspacing="0" role="presentation" style="width:100%;border-collapse:collapse;margin-bottom:8px;">
          <thead>
            <tr>
              <th align="left" style="padding:6px 12px 6px 0;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Repo</th>
              <th align="right" style="padding:6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Auto-merged</th>
              <th align="right" style="padding:6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">CVE opened</th>
              <th align="right" style="padding:6px 0 6px 12px;color:#666666;font-size:12px;text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid #dddddd;">Human override</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>`;
    })
    .join('');

  // Splice the per-repo table between the paragraph block and the CTA +
  // footer block. renderEmail's html is a flat concatenation; the markers
  // we follow are the opening `<p style="margin:24px 0 0;"><a …` for the
  // CTA and the `<div style="margin-top:24px;…` for the footer (when the
  // CTA is absent).
  const sectionBlock = sectionsHtml;
  const ctaMarker = '<p style="margin:24px 0 0;"><a';
  const ctaIndex = render.html.indexOf(ctaMarker);
  const footerMarker = '<div style="margin-top:24px;';
  let html: string;
  if (ctaIndex >= 0) {
    html = `${render.html.slice(0, ctaIndex)}${sectionBlock}${render.html.slice(ctaIndex)}`;
  } else {
    const footerIndex = render.html.indexOf(footerMarker);
    if (footerIndex >= 0) {
      html = `${render.html.slice(0, footerIndex)}${sectionBlock}${render.html.slice(footerIndex)}`;
    } else {
      // No CTA, no footer — append.
      html = `${render.html}${sectionBlock}`;
    }
  }

  return { subject: `Daily digest — ${input.day}`, html, text: render.text };
}

/** Team-seat invite email — sent when an admin invites a teammate. */
export function teamInviteEmail(input: {
  inviterName: string;
  inviterEmail: string;
  teamName: string;
  roleLabel: string;
  acceptUrl: string;
  expiresAt: Date;
}): EmailContent {
  const expiry = input.expiresAt.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
  const { html, text } = renderEmail({
    heading: `${input.inviterName} invited you to ${input.teamName}`,
    body: [
      `${input.inviterName} (${input.inviterEmail}) just invited you to join ${input.teamName} on Bivouac as ${input.roleLabel}.`,
      `Accept the invite by creating an account — the link expires ${expiry}.`,
      "Once you're in, you'll see the team's repos from your dashboard.",
    ],
    cta: { label: 'Accept invite', url: input.acceptUrl },
    footer:
      "If you weren't expecting this email you can safely ignore it — the link stops working on its own.",
  });
  return { subject: `You're invited to ${input.teamName}`, html, text };
}
