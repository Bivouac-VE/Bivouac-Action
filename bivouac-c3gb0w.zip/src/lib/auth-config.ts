// @polsia:user-owned — configure better-auth here (spread into betterAuth() by @/lib/auth).
// Add emailAndPassword options, plugins, session, socialProviders, databaseHooks, etc.
// Framework owns db/secret/baseURL/admin() + the owner-admin grant (no-op if set here).
//
// Welcome email / signup side-effect (runs alongside the owner-admin grant — install `email`):
//   import { sendEmail } from '@/lib/email/send';
//   databaseHooks: { user: { create: { after: async (user) => {
//     await sendEmail({ to: user.email, subject: 'Welcome', html: '<p>Welcome!</p>' }).catch(() => {});
//   } } } },
// Add a plugin: `plugins: [organization()]` (admin() is added for you).
//
// Per-user fields (a `username`, profile, prefs): don't add a column to `User` (auth.prisma
// is locked) or use `user.additionalFields` (needs that locked column). Make a user-owned
// `prisma/schema/profile.prisma` (model UserProfile { userId String @unique /* fields */ },
// scalar userId) and create the row at signup:
//   import { prisma } from '@/lib/db';
//   databaseHooks: { user: { create: { after: async (user) => {
//     await prisma.userProfile.create({ data: { userId: user.id } }).catch(() => {});
//   } } } },

import type { BetterAuthOptions } from 'better-auth';
import { prisma } from '@/lib/db';
import { sendEmail } from '@/lib/email/send';
import { passwordResetEmail } from '@/lib/email/templates';
import { env } from '@/lib/env';

// GitHub OAuth — read directly from process.env so the provider is only ENABLED
// when both env vars are present. Better-auth uses these at runtime to build
// the /api/auth/sign-in/social/github redirect and the /api/auth/callback/github
// handler. Optional here = app boots without them; with them missing, the
// Continue-with-GitHub button still renders but the redirect will surface an
// error (the user falls back to email sign-up). Production-deploy injects
// BOTH vars through the Polsia app-secret store; missing them in production is
// a config bug, not a runtime check we silence.
const githubClientId = process.env.GITHUB_CLIENT_ID;
const githubClientSecret = process.env.GITHUB_CLIENT_SECRET;

/**
 * Post-signup hook: if the new user has an outstanding TeamInvitation whose
 * email matches, convert it into a Membership in the SAME step. Idempotent —
 * the same hook can be invoked twice without double-seating (we use
 * `updateMany` keyed on the invite token so the WHERE fails the second time).
 *
 * Runs AFTER better-auth writes the `User` row, so `user.email` is the
 * canonical match key.
 *
 * Owner special case: when `env.POLSIA_OWNER_EMAIL` is set AND the signing-up
 * user matches it, seat that user as a team `admin` BEFORE the invite branch
 * runs. Without this, the very first signup (the workspace owner) has no
 * Membership row, so /dashboard/team renders as read-only and the owner
 * cannot invite anyone from their first session. Co-located with the invite
 * hook rather than `src/lib/auth.ts` (framework-owned) since this file is the
 * single user-owned extension point for post-signup seating behavior — both
 * the OWNER-grant and the invite-conversion share the same "place a new user
 * into a team seat" responsibility.
 */
async function convertPendingInviteToMembership(user: {
  id: string;
  email: string;
}): Promise<void> {
  const email = user.email.toLowerCase();

  const ownerEmail = env.POLSIA_OWNER_EMAIL?.trim().toLowerCase();
  if (ownerEmail && ownerEmail.length > 0 && email === ownerEmail) {
    // upsert is idempotent against duplicate signup races (the @@unique([userId])
    // would 500 on a plain `create` for a re-signup). invitedById is null
    // because the owner self-seats — there is no inviter row. Done BEFORE
    // the invite branch so a stray invite row for the owner email can't
    // overwrite the admin role with a non-admin one.
    await prisma.membership.upsert({
      where: { userId: user.id },
      update: { role: 'admin' },
      create: { userId: user.id, role: 'admin' },
    });
    return;
  }
  const invite = await prisma.teamInvitation.findFirst({
    where: {
      email,
      acceptedAt: null,
      revokedAt: null,
    },
    orderBy: { createdAt: 'desc' },
  });
  if (!invite) return;

  // Idempotency: if someone already accepted the invite for some other user,
  // or the row was just raced, `updateMany` with the token guard returns 0.
  const stamped = await prisma.teamInvitation.updateMany({
    where: { id: invite.id, acceptedAt: null, revokedAt: null },
    data: { acceptedAt: new Date() },
  });
  if (stamped.count === 0) return;

  // Promote the new user into a seated member at the same role. Membership has
  // @@unique([userId]) so we use upsert — race-safe.
  await prisma.membership.upsert({
    where: { userId: user.id },
    update: { role: invite.role },
    create: {
      userId: user.id,
      role: invite.role,
      invitedById: invite.invitedById,
    },
  });
}

export const authConfig: BetterAuthOptions = {
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
    minPasswordLength: 8,
    // better-auth calls this when /api/auth/forget-password fires. The `url`
    // arg is the full, token-bearing reset link (better-auth appends `?token=…`
    // to the `redirectTo` we pass at request time); delegate to sendEmail.
    // Swallow errors so a transient email-proxy hiccup doesn't break the
    // forgot-password submit — same swallow pattern as the `after` hook below.
    sendResetPassword: async ({ user: resetUser, url }) => {
      try {
        await sendEmail({
          to: resetUser.email,
          ...passwordResetEmail({ name: resetUser.name, resetUrl: url }),
        });
      } catch {
        // Best-effort — the verification token is still in the DB, so the user
        // can retry from /forgot-password. A failed send is silent on purpose
        // (avoids leaking which addresses are registered).
      }
    },
  },
  socialProviders:
    githubClientId && githubClientSecret
      ? {
          github: {
            clientId: githubClientId,
            clientSecret: githubClientSecret,
          },
        }
      : {},
  // Allow the same email to sign in via either method (email+password OR
  // GitHub OAuth). Without this, better-auth creates a separate account per
  // provider and a user who first signs up with email can't sign in with
  // GitHub for the same address. `trustedProviders` restricts auto-linking to
  // GitHub so a stray OAuth provider can't silently claim an existing email.
  account: {
    accountLinking: {
      enabled: true,
      trustedProviders: ['github'],
    },
  },
  databaseHooks: {
    user: {
      create: {
        // Runs after better-auth writes the User row. We swallow errors so a
        // transient Prisma hiccup doesn't block the sign-up flow.
        after: async (user) => {
          try {
            await convertPendingInviteToMembership({
              id: user.id,
              email: user.email,
            });
          } catch {
            // Best-effort — the user is still created, they just don't get a
            // team seat. An admin can resend / re-issue the invite later.
          }
        },
      },
    },
  },
};
