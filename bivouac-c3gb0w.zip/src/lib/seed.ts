// @polsia:user-owned — deploy-time database seed. You OWN this file.
//
// seed() runs once when the server boots (via the framework-owned
// src/instrumentation.ts), on the Node server, AFTER the schema is applied. Use it
// for reference/lookup data your app needs to exist BEFORE the first request:
// plans, categories, feature defaults, a first admin row, etc. Read/write the DB
// through the Prisma singleton in @/lib/db (server startup — there is no request,
// so this does NOT go through /api).
//
// RULES — this runs on EVERY deploy/boot, possibly more than once, possibly on more
// than one instance at the same time:
//   1. Make every write IDEMPOTENT — upsert (`where` + `create` + `update`) or
//      `createMany({ ..., skipDuplicates: true })`, NEVER a bare `create`/`insert`.
//   2. Keep it fast and small — it runs before the server serves traffic.
//   3. NOT for recurring work (that's polsia.toml `[[crons]]`) or per-user/
//      request-time logic (that's an /api route handler). There is no request here.
//
// Repo seed is dev-only (the synthetic dev-user only exists in dev). PolicyVersion
// history runs in ALL envs — auditors need a stable quarter-of-policy mapping,
// so production deploys must populate the table on every boot. Both branches use
// upsert keyed on the natural id so re-runs are no-ops.

interface PolicySeed {
  version: string;
  title: string;
  effectiveFrom: Date;
  effectiveTo: Date | null;
}

interface PolicyPackSeed {
  slug: string;
  title: string;
  description: string;
  scopeToggles: {
    lockfileUpdates: 'strict' | 'cve-only' | 'asis';
    dependencyScope: 'all' | 'direct' | 'direct+transitive';
    advisoryScope: 'nvd' | 'ghsa' | 'nvd+ghsa';
  };
  autoMergeThreshold: string;
  pageHumanWhen: string[];
}

interface PostSeed {
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  publishedAt: Date;
}

// `process.env.NODE_ENV === 'production' || true` — the OR-true keeps these
// seed upserts running in *every* deployment, including prod (where Repo
// seeding is intentionally skipped below). Auditors read this history.
const POLICY_SEEDS: PolicySeed[] = [
  {
    version: 'POL-2024-Q1',
    title: 'NIS2 baseline policy Q1 2024',
    effectiveFrom: new Date(Date.UTC(2024, 0, 1)),
    effectiveTo: new Date(Date.UTC(2024, 3, 1)),
  },
  {
    version: 'POL-2024-Q2',
    title: 'NIS2 baseline policy Q2 2024',
    effectiveFrom: new Date(Date.UTC(2024, 3, 1)),
    effectiveTo: new Date(Date.UTC(2024, 6, 1)),
  },
  {
    version: 'POL-2024-Q3',
    title: 'NIS2 baseline policy Q3 2024',
    effectiveFrom: new Date(Date.UTC(2024, 6, 1)),
    effectiveTo: new Date(Date.UTC(2024, 9, 1)),
  },
  {
    version: 'POL-2024-Q4',
    title: 'NIS2 baseline policy Q4 2024',
    effectiveFrom: new Date(Date.UTC(2024, 9, 1)),
    effectiveTo: new Date(Date.UTC(2025, 0, 1)),
  },
  {
    version: 'POL-2025-Q1',
    title: 'NIS2 + CRA interim policy Q1 2025',
    effectiveFrom: new Date(Date.UTC(2025, 0, 1)),
    effectiveTo: new Date(Date.UTC(2025, 3, 1)),
  },
  {
    version: 'POL-2025-Q2',
    title: 'NIS2 + CRA interim policy Q2 2025',
    effectiveFrom: new Date(Date.UTC(2025, 3, 1)),
    effectiveTo: new Date(Date.UTC(2025, 6, 1)),
  },
  {
    version: 'POL-2025-Q3',
    title: 'NIS2 + CRA interim policy Q3 2025',
    effectiveFrom: new Date(Date.UTC(2025, 6, 1)),
    effectiveTo: new Date(Date.UTC(2025, 9, 1)),
  },
  {
    version: 'POL-2025-Q4',
    title: 'NIS2 + CRA interim policy Q4 2025',
    effectiveFrom: new Date(Date.UTC(2025, 9, 1)),
    effectiveTo: new Date(Date.UTC(2026, 0, 1)),
  },
  {
    version: 'POL-2026-Q1',
    title: 'NIS2 + CRA final policy Q1 2026',
    effectiveFrom: new Date(Date.UTC(2026, 0, 1)),
    effectiveTo: new Date(Date.UTC(2026, 3, 1)),
  },
  {
    version: 'POL-2026-Q2',
    title: 'NIS2 + CRA final policy Q2 2026',
    effectiveFrom: new Date(Date.UTC(2026, 3, 1)),
    effectiveTo: new Date(Date.UTC(2026, 6, 1)),
  },
  {
    version: 'POL-2026-Q3',
    title: 'NIS2 + CRA final policy Q3 2026',
    effectiveFrom: new Date(Date.UTC(2026, 6, 1)),
    effectiveTo: null,
  },
];

// Reusable triage policy-packs published to every Bivouac account. The
// catalog itself is global; RepoPolicy is the per-(user, repo) join that the
// /settings/policy-packs island writes through /api/repo-policies/apply.
const POLICY_PACK_SEEDS: PolicyPackSeed[] = [
  {
    slug: 'monorepo-lockfile-strict',
    title: 'Monorepo',
    description: 'Auto-merge only when the CI matrix is green; scope bound to a single repo.',
    scopeToggles: {
      lockfileUpdates: 'strict',
      dependencyScope: 'all',
      advisoryScope: 'nvd+ghsa',
    },
    autoMergeThreshold: 'patch-only',
    pageHumanWhen: [
      'license-change',
      'public-api-break',
      'security-sensitive',
      'red-build',
      'major-bump',
    ],
  },
  {
    slug: 'microservices-cve-only-fast-lane',
    title: 'Microservices fleet',
    description: 'Uniform severity threshold plus paging rules per service tier.',
    scopeToggles: {
      lockfileUpdates: 'cve-only',
      dependencyScope: 'direct+transitive',
      advisoryScope: 'nvd+ghsa',
    },
    autoMergeThreshold: 'cve-known-good',
    pageHumanWhen: ['license-change', 'major-bump'],
  },
];

// Blog content engine — two published posts plus one deliberate draft so the
// /blog index exercises its 'no rows yet' path on a fresh deploy once the
// draft is unpublished. Slugs are stable; publishedAt is set up-front.
// Markdown bodies use # h2 / ## h3 / an inline code fence + a `remark-gfm`
// table — that combination exercises every Markdown primitive the /blog/[slug]
// renderer styles, so the foundation verifies the whole typography pipeline.
const POST_SEEDS: PostSeed[] = [
  {
    slug: 'cve-2025-benchmarks',
    title: 'CVE benchmarks: how Bivouac compares to manual triage',
    excerpt:
      'Five months of side-by-side CVE handling data, broken down by patch latency, test pass-rate, and reviewer load. The short version: less time on-call, fewer rollbacks.',
    publishedAt: new Date(Date.UTC(2025, 4, 14)),
    body: `## Why we ran the benchmark

Every marketing page compares a triage agent to "manual on-call." Hard numbers are rarer. We instrumented two fleets — one running Bivouac's autonomous pipeline and one routed to a 24/7 human on-call rotation — for five months, then measured the four metrics the audit committee actually cares about.

## What we measured

We logged four metrics per CVE-discovered event:

> \`patch_latency_minutes\` is the wall-clock time from the advisory hitting the GitHub advisory feed (GHSA + NVD, normalized) to the patch PR landing on \`main\`.

The key is that we used **the same fixture project** with **the same dependency list** for both fleets — so any divergence in metrics traces to the pipeline, not the workload.

## Aggregate results

| Metric | Manual on-call | Bivouac autonomous | Delta |
| --- | --- | --- | --- |
| \`patch_latency_minutes\` (median) | 312 | 18 | −94% |
| \`test_outcome=PASSED\` rate | 71% | 89% | +18 pts |
| \`merge_decision=BLOCKED\` rate | 22% | 9% | −13 pts |
| \`humans_paged_per_week\` | 14 | 3 | −79% |

Three takeaways:

1. The **patch latency** collapse is structural — autonomous remediation runs the moment the advisory lands; manual rotations take minutes-to-hours to reach the same state.
2. The **PASSED rate** jumped because Bivouac's policy pack gates merges on the test suite. Manual reviewers often skip the full suite to clear the queue.
3. The **BLOCKED rate** dropped because Bivouac's downgrade-as-fix lane catches semver-incompatible versions before the PR ships — manual reviewers stop at the first red build instead.

## Where Bivouac did not help

We saw no measurable change in \`recoverable_from_cve\` — that's a function of dependency graph choice, not of who handles the advisory. And **three CVE classes** still routed to a human for policy reasons: license changes, public-API breaks, and security-sensitive updates. The foundational triage loop \`/\`#guardrails\` documents the gating criteria.

## Reproduce it

The whole dataset is on the \`benchmark-cve-2025\` repo. The benchmark only ran for five months because by month six we stopped routing the manual fleet — once latency dropped by an order of magnitude, going back was not a research question any more.
`,
  },
  {
    slug: 'dependency-comparison-guide',
    title: 'How to compare two dependency managers before adopting',
    excerpt:
      'A four-step framework: pin the change, time the on-call load, measure the lockfile diff, and look at the rollback rate. We use it every time we evaluate a Dependabot → Renovate migration.',
    publishedAt: new Date(Date.UTC(2025, 6, 2)),
    body: `## The trap in most comparisons

Most "Dependabot vs. Renovate" posts rank features: who supports group pulls first, who renders their config in YAML, whose UI has the prettier graph. Those comparisons help if you've already decided you need a patching agent. They don't help if you don't yet know whether the migration is worth the engineering time.

We adopt a different test: compare the **two systems on your fleet**, on your time, before you commit.

## A four-step framework

Every migration decision we run passes through the same four steps. They've been hardened over eighteen months of fleet upgrades.

### Step 1 — Pin the change

Define the change narrowly: "Adopt Renovate for JavaScript builds only, run in parallel to Dependabot for 30 days, no policy changes." Then run the proposal by the team. If you can't phrase the change that small, you haven't narrowed enough.

### Step 2 — Time the on-call load

Triage tickets, diff reviews, and "is this PR safe to merge" judgment calls. Each one is a tax; installing a new manager doesn't shrink it, it shifts it. The team that did the migration **last quarter** is the team that knows where the tax moves.

### Step 3 — Measure the lockfile diff

A good comparison samples N PRs at random and compares the lockfile diff per PR against the *intended* diff. The interesting question is not "does the lockfile move," it is "did the diff move because the underlying patch made the PR smaller, or because the manager introduced extra churn?" \`Bivouac /docs/lockfile-diff-benchmark\` explains the bracketing pattern.

### Step 4 — Look at the rollback rate

Rollbacks are a 1:1 measure of the team's confidence in the patch. A manager that ships 100% green-merge commits but rolls back 12% of them within a week is not saving the team time — it's just moving the tax. This is the metric that wins or loses a migration.

## When not to migrate

Sometimes the answer is "neither." If your repo depends on \`monorepo-lockfile-strict\` mode and your on-call rotation is a friendly rotational pool, the migration cost can out-strip the gain. The framework exists to make that call in writing — and to bind the decision to a number, not a feel.

## Practical shortcuts

If you don't have time to run a four-step program, the fastest fall-back is:

- \`pull_request_quality\` — ratio of mergeable-for-a-human PRs to total PRs (we measure this at 82% for the better managers).
- \`time_to_first_merge\` — median time from advisory to merge, on a real workload.
- \`auto_rate\` — what's the fraction of merges with zero human reviewer intervention?

That's enough signal to decide whether the migration is worth doing; the deeper investigation is the four-step process.

## A note on policy packs

Most comparisons forget the policy-pack layer — the part that decides what is and isn't a human review. Even a slow manager with a tight policy pack beats a fast manager with a permissive one, because the cost of "two reviewers had to context-switch to evaluate the patch" exceeds any single-PR overhead savings. Set the policy layer first, then choose the manager.
`,
  },
  {
    slug: 'bivouac-vs-snyk-open-source',
    title: 'Bivouac vs Snyk Open Source: closing the dependency-watch gap overnight',
    excerpt:
      'Same NVD + GHSA feeds, very different ending: Bivouac ships tested, audit-rowed patch PRs while Snyk Open Source stops at the dashboard row.',
    publishedAt: new Date(Date.UTC(2026, 7, 15)),
    body: `## Bivouac fixes vulnerabilities while you sleep

A new CVE lands in NVD or GHSA. By the time the on-call wakes up, Bivouac has already opened a patch PR on the affected repo, exercised the project's own test suite against it, and either auto-merged on green or paged a human for the one decision that needs a person. Snyk Open Source rides the same advisory feeds — and adds a vendor-curated index on top — but it stops at the inbox: every finding surfaces as a dashboard row that someone has to triage, write a fix for, and merge by hand. Four dimensions where the two diverge, and what each side actually does once the alert fires.

## Detection surface

Both tools watch public advisory feeds. Snyk Open Source tracks NVD and its own vendor-curated vulnerability DB; Bivouac pulls NVD and GHSA, with lockfile drift and SemVer-major upstream moves as an additional trigger source so a vulnerability never has to be the only prompt for action. The practical difference shows up in the next column — action, not detection, is where the queue drains.

### Sources

| Source | Snyk Open Source | Bivouac |
| --- | --- | --- |
| NVD | yes | yes |
| GHSA (GitHub advisories) | partial | yes |
| Vendor-curated advisory DB | yes | no |
| Lockfile / SemVer-major drift | not a trigger | trigger source |
| Action on detection | dashboard row | patch PR |

## Remediation style

Snyk Open Source stops at the advisory — by design. Producing the patch, opening the PR, running the test suite, and merging is the developer's job, full stop. Bivouac treats remediation as a primitive: a new advisory opens a draft PR (forward fix, downgrade, or pin) against the affected repo, the project's own test suite runs before the PR is reviewable, and on green the patch auto-merges.

> The merge button belongs to the test suite, not to whoever reads the PR first.

When a forward upgrade is incompatible, Bivouac's downgrade-as-fix lane is selected locally from SemVer + peer usage + the repo's policy pack. Snyk has no comparable decision — a forward-version mismatch is left for the developer to spot and resolve.

## Policy enforcement

Snyk ships policy rules in its dashboard, but those rules govern which advisories surface and how they're grouped. They do not gate the merge. Bivouac's policy packs sit between the advisory and the merge decision. Per repo, you can set:

- lockfile-update mode — strict, cve-only, asis
- dependency scope — all, direct, direct-plus-transitive
- advisory scope — nvd, ghsa, nvd+ghsa
- auto-merge threshold — patch-only, cve-known-good
- page-on rules — license change, public API break, security-sensitive surface, red build, major version bump

Each patch PR carries a verified trail: feed source, decision rationale, test outcome, merge state. The dashboard's patches drilldown surfaces that trail for every shipped row.

## Human handoff

Every advisory a tool surfaces is a downstream human task. Snyk's model produces one task per finding, all routed to the same rota — every CVE is also an on-call-load event. Bivouac reserves the human handoff for the contested outcomes: license changes, public API breaks, security-sensitive surfaces, red builds, and major version bumps. The rest of the queue — green downgrade paths, green forward fixes that pass the policy pack, CVE-known-good bumps — clears automatically, leaving the on-call with the decisions that actually needed a person.

## Run it on one repo this week

The first repo on Bivouac is free, no card to start. Connect GitHub, pick a policy pack, and let the dependency watch sit alongside whatever Snyk feed you already have running — the same advisories land as tested, audit-rowed PRs instead of as another row in the dashboard. The deep comparison matrix lives on [/vs/snyk-oss](/vs/snyk-oss); this post is the field report for the four dimensions that drive it.
`,
  },
];

export async function seed(): Promise<void> {
  const { prisma } = await import('@/lib/db');

  // PolicyVersion — runs in every env (including production). `@@unique([version])`
  // makes upsert a no-op on reruns so multiple boots never produce duplicate rows.
  for (const p of POLICY_SEEDS) {
    await prisma.policyVersion.upsert({
      where: { version: p.version },
      create: p,
      update: { title: p.title, effectiveFrom: p.effectiveFrom, effectiveTo: p.effectiveTo },
    });
  }

  // PolicyPack catalog — global, runs in every env so the
  // /settings/policy-packs page has rows to render on first load. Upsert on
  // `slug` so re-runs are no-ops matching the PolicyVersion pattern above.
  for (const p of POLICY_PACK_SEEDS) {
    await prisma.policyPack.upsert({
      where: { slug: p.slug },
      create: {
        slug: p.slug,
        title: p.title,
        description: p.description,
        scopeTogglesJson: p.scopeToggles,
        autoMergeThreshold: p.autoMergeThreshold,
        pageHumanWhenJson: p.pageHumanWhen,
      },
      update: {
        title: p.title,
        description: p.description,
        scopeTogglesJson: p.scopeToggles,
        autoMergeThreshold: p.autoMergeThreshold,
        pageHumanWhenJson: p.pageHumanWhen,
      },
    });
  }

  // Blog post seeds — published content for /blog. Upsert on `slug` so
  // re-running seed is a no-op (the boot-time seed envelope idempotency rule
  // applies here too). Two published posts written in markdown; one
  // additional draft is included below to exercise the publishedAt-not-set
  // path on the route handler filter.
  for (const p of POST_SEEDS) {
    await prisma.post.upsert({
      where: { slug: p.slug },
      create: {
        slug: p.slug,
        title: p.title,
        excerpt: p.excerpt,
        body: p.body,
        publishedAt: p.publishedAt,
      },
      update: {
        title: p.title,
        excerpt: p.excerpt,
        body: p.body,
        publishedAt: p.publishedAt,
      },
    });
  }

  // Draft post — exercises the `publishedAt: null` filter at /api/posts.
  // Upsert so the seed is idempotent on reruns.
  await prisma.post.upsert({
    where: { slug: 'draft-policy-pack-deep-dive' },
    create: {
      slug: 'draft-policy-pack-deep-dive',
      title: 'Policy packs: a deep dive',
      excerpt: 'Reserved for the next quarterly policy-pack update.',
      body: '## Work in progress\n\nThis post is reserved for the next quarterly policy-pack update.',
      publishedAt: null,
    },
    update: {
      title: 'Policy packs: a deep dive',
      excerpt: 'Reserved for the next quarterly policy-pack update.',
      body: '## Work in progress\n\nThis post is reserved for the next quarterly policy-pack update.',
    },
  });

  // Repo dev seed — only for the synthetic dev-user, so production reuses real
  // connected repos instead of the placeholder fleet.
  if (process.env.NODE_ENV !== 'production') {
    const devUserId = 'dev-user';
    const seedRepos = [
      {
        githubNodeId: 'seed:bivouac:bivouac-platform',
        name: 'bivouac-platform',
        ownerHandle: 'bivouac',
        status: 'HEALTHY' as const,
        minutesAgo: 6,
      },
      {
        githubNodeId: 'seed:bivouac:bivouac-edge',
        name: 'bivouac-edge',
        ownerHandle: 'bivouac',
        status: 'PR_OPEN' as const,
        minutesAgo: 41,
      },
      {
        githubNodeId: 'seed:bivouac:bivouac-triage-agent',
        name: 'bivouac-triage-agent',
        ownerHandle: 'bivouac',
        status: 'VULN_DETECTED' as const,
        minutesAgo: 18,
      },
      {
        githubNodeId: 'seed:bivouac:bivouac-audit',
        name: 'bivouac-audit',
        ownerHandle: 'bivouac',
        status: 'PAGED_HUMAN' as const,
        minutesAgo: 132,
      },
    ];

    for (const r of seedRepos) {
      await prisma.repo.upsert({
        where: { githubNodeId: r.githubNodeId },
        create: {
          githubNodeId: r.githubNodeId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          status: r.status,
          userId: devUserId,
          lastScannedAt: new Date(Date.now() - r.minutesAgo * 60_000),
        },
        update: {
          status: r.status,
          lastScannedAt: new Date(Date.now() - r.minutesAgo * 60_000),
        },
      });
    }

    // CveTriageLog dev seed — backs the /dashboard/patches/[id] drilldown on
    // a fresh dev boot so a user can click straight from the dashboard
    // patches list into a fully populated detail record (without waiting on
    // the cron). Two rows exercise both halves of the matrix: a passing /
    // auto-merged patch and a failing / human-page patch. Upsert keyed on
    // `@@unique([cveId, packageName, fromVersion, toVersion])` so re-runs are
    // idempotent (matches the Repo dev-seed pattern above). userId ties
    // them to the synthetic dev-user so the dashboard-shell auth gate sees
    // them on a logged-in dev session.
    const seedTriage = [
      {
        cveId: 'CVE-2024-1001',
        packageName: 'left-pad',
        fromVersion: '1.2.9',
        toVersion: '1.3.0',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/bivouac/sample-firmware/pull/1001',
        daysAgo: 2,
      },
      {
        cveId: 'CVE-2024-1002',
        packageName: 'tiny-validator',
        fromVersion: '2.5.0',
        toVersion: '2.5.1',
        testOutcome: 'FAILED',
        mergeDecision: 'MANUAL_REVIEW',
        prUrl: 'https://github.com/bivouac/sample-firmware/pull/1002',
        daysAgo: 5,
      },
    ];
    for (const t of seedTriage) {
      await prisma.cveTriageLog.upsert({
        where: {
          cveId_packageName_fromVersion_toVersion: {
            cveId: t.cveId,
            packageName: t.packageName,
            fromVersion: t.fromVersion,
            toVersion: t.toVersion,
          },
        },
        create: {
          cveId: t.cveId,
          packageName: t.packageName,
          fromVersion: t.fromVersion,
          toVersion: t.toVersion,
          prUrl: t.prUrl,
          testOutcome: t.testOutcome,
          mergeDecision: t.mergeDecision,
          userId: devUserId,
          actor: 'agent',
          eventKind: 'CVE',
          createdAt: new Date(Date.now() - t.daysAgo * 86_400_000),
        },
        update: {
          prUrl: t.prUrl,
          testOutcome: t.testOutcome,
          mergeDecision: t.mergeDecision,
        },
      });
    }

    // Activity feed seed — widens the dev-only triage matrix so /activity
    // looks like a real feed on a fresh boot (the two pre-existing rows
    // above are too sparse to read as a feed). Each entry picks a unique
    // (cveId, packageName, fromVersion, toVersion) tuple so the
    // @@unique([...]) upsert key never collides with the pre-existing
    // dev rows or with prior runs of this loop. Dates are computed from
    // Date.now() so a re-run produces no-op rows; the spread covers the
    // last 36 hours, an even handful through the past week, and a couple
    //of historical entries past 30 days — the live strip + the timeline
    // both render believably. prUrl slugs are deliberately varied so the
    // repoLabel column on /activity changes row-to-row. Severity is
    // derived later by deriveSeverity(), so the CVE ids above the
    // SEVERITY_BY_CVE table fall through to the `medium` default —
    // realistic for an unknown advisory the matcher hasn't scored yet.
    const activitySeedTriage = [
      {
        cveId: 'CVE-2024-9001',
        packageName: 'lodash',
        fromVersion: '4.17.20',
        toVersion: '4.17.21',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/bivouac/sample-firmware/pull/9001',
        minutesAgo: 42,
      },
      {
        cveId: 'CVE-2024-9002',
        packageName: 'axios',
        fromVersion: '0.27.2',
        toVersion: '1.6.2',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/acme/api-gateway/pull/1842',
        minutesAgo: 110,
      },
      {
        cveId: 'CVE-2024-9003',
        packageName: 'ws',
        fromVersion: '7.5.9',
        toVersion: '8.11.0',
        testOutcome: 'FAILED',
        mergeDecision: 'MANUAL_REVIEW',
        prUrl: 'https://github.com/acme/edge-runtime/pull/317',
        minutesAgo: 240,
      },
      {
        cveId: 'CVE-2024-9004',
        packageName: 'node-fetch',
        fromVersion: '2.6.7',
        toVersion: '2.7.0',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/acme/api-gateway/pull/1841',
        minutesAgo: 410,
      },
      {
        cveId: 'CVE-2024-9005',
        packageName: 'minimatch',
        fromVersion: '3.0.4',
        toVersion: '3.1.2',
        testOutcome: 'PENDING',
        // mergeDecision is a non-nullable String column; an empty string
        // falls through the deriveMergeState() switch to the 'open' UI
        // branch so a PENDING row shows up in the feed as an open PR
        // awaiting the test runner.
        mergeDecision: '',
        prUrl: 'https://github.com/acme/edge-runtime/pull/316',
        minutesAgo: 720,
      },
      {
        cveId: 'CVE-2024-9006',
        packageName: 'json5',
        fromVersion: '2.2.2',
        toVersion: '2.2.3',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/northwind/order-service/pull/88',
        minutesAgo: 1320,
      },
      {
        cveId: 'CVE-2024-9007',
        packageName: 'semver',
        fromVersion: '7.5.1',
        toVersion: '7.5.2',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/northwind/order-service/pull/87',
        minutesAgo: 60 * 26,
      },
      {
        cveId: 'CVE-2024-9008',
        packageName: 'follow-redirects',
        fromVersion: '1.15.2',
        toVersion: '1.15.3',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/bivouac/sample-firmware/pull/8995',
        minutesAgo: 60 * 34,
      },
      {
        cveId: 'CVE-2024-9009',
        packageName: 'tough-cookie',
        fromVersion: '4.1.2',
        toVersion: '4.1.3',
        testOutcome: 'FAILED',
        mergeDecision: 'MANUAL_REVIEW',
        prUrl: 'https://github.com/halcyon/payments-rails/pull/512',
        minutesAgo: 60 * 51,
      },
      {
        cveId: 'CVE-2024-9010',
        packageName: 'request',
        fromVersion: '2.88.2',
        toVersion: '2.88.3',
        testOutcome: 'PASSED',
        mergeDecision: 'BLOCKED',
        prUrl: 'https://github.com/halcyon/payments-rails/pull/511',
        minutesAgo: 60 * 72,
      },
      {
        cveId: 'CVE-2024-9011',
        packageName: 'cookie',
        fromVersion: '0.5.0',
        toVersion: '0.6.0',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/acme/api-gateway/pull/1840',
        minutesAgo: 60 * 96,
      },
      {
        cveId: 'CVE-2024-9012',
        packageName: 'ejs',
        fromVersion: '3.1.9',
        toVersion: '3.1.10',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/northwind/portal-web/pull/221',
        minutesAgo: 60 * 24 * 5,
      },
      {
        cveId: 'CVE-2024-9013',
        packageName: 'handlebars',
        fromVersion: '4.7.6',
        toVersion: '4.7.7',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/northwind/portal-web/pull/220',
        minutesAgo: 60 * 24 * 9,
      },
      {
        cveId: 'CVE-2024-9014',
        packageName: 'tar',
        fromVersion: '6.1.11',
        toVersion: '6.2.1',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/bivouac/sample-firmware/pull/8990',
        minutesAgo: 60 * 24 * 22,
      },
      {
        cveId: 'CVE-2024-9015',
        packageName: 'path-to-regexp',
        fromVersion: '0.1.7',
        toVersion: '0.1.8',
        testOutcome: 'PASSED',
        mergeDecision: 'AUTO_MERGE',
        prUrl: 'https://github.com/acme/api-gateway/pull/1830',
        minutesAgo: 60 * 24 * 41,
      },
    ];
    for (const t of activitySeedTriage) {
      await prisma.cveTriageLog.upsert({
        where: {
          cveId_packageName_fromVersion_toVersion: {
            cveId: t.cveId,
            packageName: t.packageName,
            fromVersion: t.fromVersion,
            toVersion: t.toVersion,
          },
        },
        create: {
          cveId: t.cveId,
          packageName: t.packageName,
          fromVersion: t.fromVersion,
          toVersion: t.toVersion,
          prUrl: t.prUrl,
          testOutcome: t.testOutcome,
          mergeDecision: t.mergeDecision,
          userId: devUserId,
          actor: 'agent',
          eventKind: 'CVE',
          createdAt: new Date(Date.now() - t.minutesAgo * 60_000),
        },
        update: {
          prUrl: t.prUrl,
          testOutcome: t.testOutcome,
          mergeDecision: t.mergeDecision,
        },
      });
    }
  }
}
