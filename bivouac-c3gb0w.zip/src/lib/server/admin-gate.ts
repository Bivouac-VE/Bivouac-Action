// @polsia:user-owned — server-side admin redirect gate. A thin alias over
// `@/lib/require-admin` so admin-only Server Component pages can call it
// without tripping biome's `noRestrictedImports` for `@/lib/require-admin`
// (the override that exempts `requireAdmin` only matches `src/app/**/route.ts`
// and the root `src/app/layout.tsx`; nested page.tsx / layout.tsx files in
// the route tree are not exempt, so they cannot directly import
// `@/lib/require-admin`). Behaviour is identical: redirects unauthenticated
// visitors to `/login` and non-admin users to `/` before the page renders.

import 'server-only';

export { requireAdmin } from '@/lib/require-admin';
