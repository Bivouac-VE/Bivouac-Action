// @polsia:user-owned — server-side auth gate helper for proxy.ts. Returns the
// redirect Response when the visitor is anonymous AND the route is gated
// (/dashboard/**); returns null to let the request through.
//
// Kept here (NOT in proxy.ts) so the actual `@/lib/auth` import lives under
// src/lib/** — the biome `noRestrictedImports` override allows server-only
// imports from /api route handlers and src/lib but NOT from proxy.ts at the
// workspace root. proxy.ts's middleware_chain slot calls this helper.

import 'server-only';
import { type NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';

const GATED_PREFIX = '/dashboard';

export async function dashboardAuthGate(request: NextRequest): Promise<NextResponse | null> {
  if (!request.nextUrl.pathname.startsWith(GATED_PREFIX)) {
    return null;
  }
  const session = await auth.api.getSession({ headers: request.headers });
  if (session) return null;
  const returnTo =
    request.nextUrl.pathname + (request.nextUrl.search ? request.nextUrl.search : '');
  const loginUrl = new URL('/login', request.url);
  loginUrl.searchParams.set('returnTo', returnTo);
  return NextResponse.redirect(loginUrl);
}
