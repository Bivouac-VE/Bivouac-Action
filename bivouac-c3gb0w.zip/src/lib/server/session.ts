// @polsia:user-owned — server helper for the current session, used by /api/checkout
// + /api/repos to decide the authed vs anonymous branch. Returns null when
// anonymous, or the better-auth session user when signed in.
//
// Server-only: imports `auth` (which imports `server-only`) + `next/headers`,
// so this file must NEVER be imported by a client component. Route handlers in
// src/app/api/* call it on the server side only.

import { headers } from 'next/headers';
import { auth } from '@/lib/auth';

export interface SessionInfo {
  userId: string;
}

export async function getSession(): Promise<SessionInfo | null> {
  const session = await auth.api.getSession({ headers: await headers() });
  return session?.user ? { userId: session.user.id } : null;
}
