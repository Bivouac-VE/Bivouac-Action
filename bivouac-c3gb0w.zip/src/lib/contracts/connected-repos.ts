// @polsia:user-owned — shared zod contracts for the "pick ONE repo" flow at
// /dashboard/connect/repo. The POST write endpoint and the client island
// import the same shapes so a drift surfaces as a tsc/ZodError rather than
// silent JSON drift.

import { z } from 'zod';

// installation_id arrives as a numeric string (Prisma BigInt ← JSON).
// Restrict to digit-only so we never feed a malformed id into Prisma.
const BigIntString = z.string().regex(/^\d+$/, 'expected numeric string');

// /api/connected-repos POST body — single repo pick. The picker lets users
// pick at most ONE repo per install (the brief calls out the singular path,
// kept distinct from /dashboard/repos/connect's multi-toggle surface).
export const ConnectedRepoSelectInput = z.object({
  installationId: BigIntString,
  githubNodeId: z.string().min(1),
  githubRepoId: BigIntString,
  name: z.string().min(1),
  ownerHandle: z.string().min(1),
  defaultBranch: z.string().min(1),
});
export type ConnectedRepoSelectInput = z.infer<typeof ConnectedRepoSelectInput>;

// Per-write ack so the picker island can render the saved row shape (and the
// dashboard knows the redirect-destination) without another fetch.
export const ConnectedRepoSelectResult = z.object({
  saved: z.number().int().nonnegative(),
  repo: z.object({
    id: z.string(),
    name: z.string(),
    ownerHandle: z.string(),
    defaultBranch: z.string(),
  }),
});
export type ConnectedRepoSelectResult = z.infer<typeof ConnectedRepoSelectResult>;
