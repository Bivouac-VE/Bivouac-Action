// @polsia:user-owned — shared zod contract for the dashboard repos listing.
// Imported by BOTH the /api/dashboard/repos route handler AND the client
// page so a shape change surfaces as a tsc/ZodError instead of silent JSON
// drift. Client-importable (zod only — no server-only imports here).

import { z } from 'zod';
import { RepoStatusEnum } from './repos';

// Install-status taxonomy comes from GitHubAppInstallation + selection rows
// at the API boundary; the column itself is decorative (color-coded) — the
// real signal is whether the App's installation is still active for this
// repo's `githubNodeId`.
export const InstallStatusEnum = z.enum(['connected', 'needs_reinstall', 'pending']);
export type InstallStatus = z.infer<typeof InstallStatusEnum>;

// Activity stream surfaced in the table. "watching" means the agent scanned
// this repo in the last 24h (i.e. actively on duty); the other kinds are the
// fallback when no recent scan — last scan is the last fact we know about
// this repo until a patch lands.
export const ActivityKindEnum = z.enum(['watching', 'last_scan', 'last_patch', 'paged']);
export type ActivityKind = z.infer<typeof ActivityKindEnum>;

// Brief-facing overlay badge sourced from the most recent qualifying
// CveTriageLog row for the repo (or, as a fall-through, the bare Repo.status).
// `monitored` is the steady-state resting badge when no triage signal wins;
// `vuln_detected` covers a bare VULN_DETECTED repo with no qualifying triage
// row yet; the three action kinds (`patch_open`, `patch_merged`, `paged_human`)
// are derived from the user's audit log. `label` is pre-formatted server-side
// in a fixed locale so hydration is deterministic; `at` is the ISO timestamp
// of the underlying event (or Repo.lastScannedAt for `monitored`). One row
// only ever renders one badge.
export const PatchBadgeKindEnum = z.enum([
  'monitored',
  'vuln_detected',
  'patch_open',
  'patch_merged',
  'paged_human',
]);
export type PatchBadgeKind = z.infer<typeof PatchBadgeKindEnum>;

export const RepoRow = z.object({
  id: z.string(),
  name: z.string(),
  ownerHandle: z.string(),
  githubNodeId: z.string(),
  defaultBranch: z.string(),
  status: RepoStatusEnum,
  installStatus: InstallStatusEnum,
  // ISO string of the most recent agent activity timestamp (scan or patch).
  // Null only for repos not yet scanned.
  lastActivityAt: z.string().nullable(),
  // Human-readable activity cell text, pre-formatted server-side (locale-
  // stable so hydration is deterministic).
  activityLabel: z.string(),
  activityKind: ActivityKindEnum,
  // Brief-facing status chip. Derived from CveTriageLog per-repo and dated
  // to the most recent underlying event. This is the canonical badge to
  // surface to the user; `status` above remains the canonical Repo-level
  // fact for other surfaces (admin/audit).
  patchBadge: z.object({
    kind: PatchBadgeKindEnum,
    label: z.string(),
    at: z.string().nullable(),
  }),
});
export type RepoRow = z.infer<typeof RepoRow>;

export const DashboardReposList = z.object({ items: z.array(RepoRow) });
export type DashboardReposList = z.infer<typeof DashboardReposList>;
