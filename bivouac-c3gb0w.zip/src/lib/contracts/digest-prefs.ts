// @polsia:user-owned — shared zod contract for the per-user dashboard digest
// opt-in toggle and the cron-side `lastDigestSentAt` watermark that keeps
// the daily cron idempotent. Single source of truth shared by
// /api/digest-prefs (server) and the DigestPrefsCard client island. A
// shape change surfaces as a tsc/ZodError rather than silent JSON drift.
// Client-importable (zod only — no server-only imports here).

import { z } from 'zod';

/** GET response — current opt-in state + watermark. */
export const DigestPrefs = z.object({
  digestOptIn: z.boolean(),
  /** ISO timestamp of the last daily digest the cron sent to this user,
   *  or null if no digest has shipped yet. */
  lastDigestSentAt: z.string().nullable(),
});
export type DigestPrefs = z.infer<typeof DigestPrefs>;

/** PATCH body — caller flips the toggle. The watermark is server-managed. */
export const DigestPrefsInput = z.object({
  digestOptIn: z.boolean(),
});
export type DigestPrefsInput = z.infer<typeof DigestPrefsInput>;
