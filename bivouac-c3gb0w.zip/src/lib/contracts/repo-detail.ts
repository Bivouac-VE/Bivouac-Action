// @polsia:user-owned — shared zod contract for the per-repo drilldown at
// /dashboard/repos/[id]. Single source of truth shared by the /api/dashboard
// route handler and the <RepoDetail/> client island. A shape change surfaces
// as a tsc/ZodError instead of silent JSON drift. Client-importable (zod only
// — no server-only imports here).
//
// Re-exports PatchList / AuditLogList for the island's per-tab fetches so a
// client listing path never re-imports the contract module from another file.
// CRON_SCHEDULE is the single canonical placeholder for `polsia.toml`'s
// `[[crons]]` entry — if the schedule changes, this constant changes in
// lockstep so a code search finds both call sites at once.

import { z } from 'zod';
import { AutoMergePolicy as AutoMergePolicySchema } from './auto-merge-policy';

// Single canonical cron schedule. Mirrors `polsia.toml`:
//
//   [[crons]]
//   name = "cve-triage-poll"
//   schedule = "0 8 * * *"
//
// Keep these two literals aligned — updating one without the other silently
// desynchronizes the "Polling cadence" copy on the /dashboard/repos/[id]
// "Detection settings" tab from the platform's actual job.
export const CRON_SCHEDULE = '0 8 * * *';

// Per-repo drilldown header. Carries everything needed for the static chrome
// (identity, status, active pack, the user's global policy summary as it
// applies to this repo, and the polling cadence derived from the schedule).
// The patches + audit tabs each speak their own contract — this header
// doesn't bundle row arrays.
export const RepoDetailHeader = z.object({
  id: z.string(),
  name: z.string(),
  ownerHandle: z.string(),
  defaultBranch: z.string(),
  status: z.enum(['HEALTHY', 'VULN_DETECTED', 'PR_OPEN', 'PAGED_HUMAN']),
  activePack: z
    .object({
      packSlug: z.string(),
      packTitle: z.string(),
    })
    .nullable(),
  // The user's global auto-merge policy as it applies to this repo. The
  // per-repo drilldown surfaces the same fields the <PolicyBadge/> already
  // shows in the nav bar, so the chip uses the same vocabulary.
  policy: z.object({
    scopeMode: AutoMergePolicySchema.shape.scopeMode,
    minSeverity: AutoMergePolicySchema.shape.minSeverity,
    defaultAction: AutoMergePolicySchema.shape.defaultAction,
  }),
  cronSchedule: z.string(),
});
export type RepoDetailHeader = z.infer<typeof RepoDetailHeader>;

export { AuditLogList, type AuditLogRow } from './audit-log';
// Re-export so the island's tabs don't have to fan-out into contracts/ just
// to fetch themselves. Importing these via this barrel keeps the data-plane
// rule explicit.
export {
  PatchList,
  type PatchListItem,
  type PatchMergeState,
  type PatchSeverity,
} from './patches';
