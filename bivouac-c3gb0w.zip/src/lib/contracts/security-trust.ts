// @polsia:user-owned — shared zod contract for the public
// /api/security-trust resource. Imported by both the route handler (validates
// before serialising) and the SecurityTrustContent client island (parses the
// JSON response). Keep this module zod-only — no server-only imports — so it's
// safe to import from `'use client'` files.
import { z } from 'zod';

export const SecurityTrustSection = z.object({
  id: z.string(),
  eyebrow: z.string(),
  title: z.string(),
  body: z.string(),
});

export const SecurityTrustFaqItem = z.object({
  q: z.string(),
  a: z.string(),
});

export const SecurityTrustDocument = z.object({
  sections: z.array(SecurityTrustSection),
  faq: z.array(SecurityTrustFaqItem),
});

export type SecurityTrustSection = z.infer<typeof SecurityTrustSection>;
export type SecurityTrustFaqItem = z.infer<typeof SecurityTrustFaqItem>;
export type SecurityTrustDocument = z.infer<typeof SecurityTrustDocument>;
