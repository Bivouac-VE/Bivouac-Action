// @polsia:user-owned — shared zod contract for the /insights dashboard.
// Single source of truth shared by the three /api/insights/* handlers and the
// <InsightsBoard/> client island. Client-importable (zod only — no server-only
// imports here).

import { z } from 'zod';

export const InsightsRangeDaysEnum = z.union([z.literal(7), z.literal(30), z.literal(90)]);
export type InsightsRangeDays = z.infer<typeof InsightsRangeDaysEnum>;

export const KpiTile = z.object({
  label: z.string(),
  value: z.string(),
  hint: z.string().nullable(),
});
export type KpiTile = z.infer<typeof KpiTile>;

// Numeric payloads behind each tile — kept so the UI can render tooltips and
// future variations without re-fetching, and so the contract drift is loud.
export const KpiNumerics = z.object({
  patchesOpened: z.number().int().nonnegative(),
  autoMergeCount: z.number().int().nonnegative(),
  manualReviewCount: z.number().int().nonnegative(),
  blockedCount: z.number().int().nonnegative(),
  mttpDays: z.number().nullable(),
});
export type KpiNumerics = z.infer<typeof KpiNumerics>;

export const InsightsOverview = z.object({
  rangeDays: InsightsRangeDaysEnum,
  tiles: z.object({
    mttp: KpiTile,
    patchesOpened: KpiTile,
    autoMergeRate: KpiTile,
    humanOverrideRate: KpiTile,
  }),
  numerics: KpiNumerics,
  connectedRepoCount: z.number().int().nonnegative(),
});
export type InsightsOverview = z.infer<typeof InsightsOverview>;

export const PatchesByWeekPoint = z.object({
  // ISO date (YYYY-MM-DD) of the Monday that anchors the week bucket.
  weekStart: z.string(),
  count: z.number().int().nonnegative(),
});
export type PatchesByWeekPoint = z.infer<typeof PatchesByWeekPoint>;

export const PatchesByWeekSeries = z.object({
  rangeDays: InsightsRangeDaysEnum,
  points: z.array(PatchesByWeekPoint),
});
export type PatchesByWeekSeries = z.infer<typeof PatchesByWeekSeries>;

export const SeverityBucketEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type SeverityBucket = z.infer<typeof SeverityBucketEnum>;

export const SeverityBreakdownPoint = z.object({
  severity: SeverityBucketEnum,
  count: z.number().int().nonnegative(),
});
export type SeverityBreakdownPoint = z.infer<typeof SeverityBreakdownPoint>;

export const SeverityBreakdownSeries = z.object({
  rangeDays: InsightsRangeDaysEnum,
  points: z.array(SeverityBreakdownPoint),
});
export type SeverityBreakdownSeries = z.infer<typeof SeverityBreakdownSeries>;
