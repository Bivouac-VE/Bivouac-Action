// @polsia:user-owned — shared zod contract for the per-step onboarding status
// exposed at GET /api/onboarding/status. Single source of truth shared by the
// route handler AND the OnboardingBanner client island so a shape change is a
// tsc / ZodError, not silent JSON drift. Client-importable (zod only — no
// server-only imports here).

import { z } from 'zod';

export const OnboardingSteps = z.object({
  REPO_CONNECTED: z.boolean(),
  POLICY_CHOSEN: z.boolean(),
  FIRST_PR_SEEN: z.boolean(),
});
export type OnboardingSteps = z.infer<typeof OnboardingSteps>;

export const OnboardingStatus = z.object({
  steps: OnboardingSteps,
  complete: z.boolean(),
});
export type OnboardingStatus = z.infer<typeof OnboardingStatus>;
