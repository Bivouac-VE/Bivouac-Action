// @polsia:user-owned — shared zod contract for the public /demo board. Single
// source of truth shared by GET /api/demo and the client island that renders
// the before/after narrative. Mirrors the shape of demo-bivouac/ledger.json.

import { z } from 'zod';

const cveId = z.string().regex(/^CVE-\d{4}-\d+$/, 'CVE id must look like CVE-YYYY-NNNN');

export const Decision = z.enum(['AUTO_MERGE', 'FLAGGED', 'REJECTED']);
export type Decision = z.infer<typeof Decision>;

export const BeforeEntry = z.object({
  id: z.string().min(1),
  package: z.string().min(1),
  ecosystem: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  type: z.enum(['SECURITY', 'PATCH', 'MINOR', 'MAJOR']),
  cveId: cveId.nullable(),
  title: z.string().min(1),
  prUrl: z.string().url(),
  reason: z.string().min(1),
});
export type BeforeEntry = z.infer<typeof BeforeEntry>;

export const AfterEntry = z.object({
  id: z.string().min(1),
  package: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  decision: Decision,
  reasoning: z.string().min(1),
  testOutcome: z.enum(['PASSED', 'PENDING', 'FAILED']),
});
export type AfterEntry = z.infer<typeof AfterEntry>;

export const BeforeBlock = z.object({
  openDependabotPRs: z.number().int().nonnegative(),
  securityAdvisories: z.number().int().nonnegative(),
  breakingMajors: z.number().int().nonnegative(),
  summary: z.string().min(1),
});
export type BeforeBlock = z.infer<typeof BeforeBlock>;

export const AfterBlock = z.object({
  analyzed: z.number().int().nonnegative(),
  autoMerged: z.number().int().nonnegative(),
  flaggedForReview: z.number().int().nonnegative(),
  rejected: z.number().int().nonnegative(),
  vulnerabilitiesRemaining: z.number().int().nonnegative(),
  breakingMajorsRemaining: z.number().int().nonnegative(),
  testsRun: z.number().int().nonnegative(),
  testsPass: z.number().int().nonnegative(),
  summary: z.string().min(1),
});
export type AfterBlock = z.infer<typeof AfterBlock>;

export const DemoState = z.object({
  generatedAt: z.string().min(1),
  before: BeforeBlock,
  after: AfterBlock,
  beforeEntries: z.array(BeforeEntry),
  afterEntries: z.array(AfterEntry),
});
export type DemoState = z.infer<typeof DemoState>;
