// @polsia:user-owned — shared zod contracts for the multi-repo policy-packs
// page at /dashboard/policy/packs. Each pack's targeting list is composed
// server-side from the global PolicyPack catalog and the caller's connected
// repos + per-repo RepoPolicy joins, and shipped to the client island through
// this contract. Shape drift surfaces as a ZodError instead of silent JSON
// drift. Client-importable (zod only — no server-only imports here).

import { z } from 'zod';
import { PageHumanRule, ScopeToggles } from '@/lib/contracts/policy-packs';

export const PackVariant = z.enum(['monorepo', 'microservices-fleet']);
export type PackVariant = z.infer<typeof PackVariant>;

export const PackTargetingItem = z.object({
  repoId: z.string(),
  repoName: z.string(),
  ownerHandle: z.string(),
  currentPackSlug: z.string().nullable(),
  currentPackTitle: z.string().nullable(),
  divergent: z.boolean(),
});
export type PackTargetingItem = z.infer<typeof PackTargetingItem>;

export const PackTargeting = z.object({
  slug: z.string(),
  variant: PackVariant,
  title: z.string(),
  description: z.string(),
  scopeToggles: ScopeToggles,
  autoMergeThreshold: z.string(),
  pageHumanWhen: z.array(PageHumanRule),
  items: z.array(PackTargetingItem),
  divergentCount: z.number().int().nonnegative(),
});
export type PackTargeting = z.infer<typeof PackTargeting>;

export const PackTargetingList = z.object({ packs: z.array(PackTargeting) });
export type PackTargetingList = z.infer<typeof PackTargetingList>;
