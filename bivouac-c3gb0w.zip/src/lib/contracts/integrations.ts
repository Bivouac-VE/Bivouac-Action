// @polsia:user-owned — shared zod contracts for /api/integrations/* and the
// /dashboard/settings/integrations island. Single source of truth shared
// between the route handlers (server) and the React island (client). Shape
// change surfaces here as a tsc/ZodError rather than silent JSON drift.
//
// Client-importable — zod only, no server-only imports.

import { z } from 'zod';

/** Slack incoming webhook URL or PagerDuty routing key / URL. */
export const ProviderEnum = z.enum(['slack', 'pagerduty']);
export type Provider = z.infer<typeof ProviderEnum>;

/** "team" applies the row to every repo on the team; "repo:<repoId>" is an
 *  override for one specific repo. Server-side we codify scope as
 *  `{ kind: 'team' } | { kind: 'repo'; repoId: string }`. */
export const IntegrationScopeUnion = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('team') }),
  z.object({ kind: z.literal('repo'), repoId: z.string().min(1) }),
]);
export type IntegrationScope = z.infer<typeof IntegrationScopeUnion>;

/** Wire-format scope (what we send over JSON — keeps the URL-encoded body
 *  human-readable when debugging). The route handler turns this back into
 *  IntegrationScope via wireToScope below. */
export const IntegrationScopeWire = z.union([
  z.literal('team'),
  z.string().regex(/^repo:[^:]+$/, 'scope must be "team" or "repo:<id>"'),
]);
export type IntegrationScopeWire = z.infer<typeof IntegrationScopeWire>;

export function scopeToWire(scope: IntegrationScope): IntegrationScopeWire {
  return scope.kind === 'team' ? 'team' : `repo:${scope.repoId}`;
}

export function wireToScope(raw: string): IntegrationScope | null {
  if (raw === 'team') return { kind: 'team' };
  if (raw.startsWith('repo:')) {
    const repoId = raw.slice('repo:'.length);
    if (!repoId) return null;
    return { kind: 'repo', repoId };
  }
  return null;
}

/** One configured integration row — flattened for the UI. `IntegrationItem`
 *  serves as both the zod schema (parsed by the route handler + the client
 *  island) and the inferred TypeScript type. Same dual-export shape as
 *  DigestWebhookConfig in src/lib/contracts/digest-webhook.ts so the
 *  apiFetch `schema` option can parse AND give a typed result back. */
export const IntegrationItem = z.object({
  /** DB id (return for delete operations and audit linkage). */
  id: z.string(),
  provider: ProviderEnum,
  scope: IntegrationScopeWire,
  repoSlug: z.string().nullable(),
  valuePreview: z.string(),
  updatedAt: z.string(),
});
export type IntegrationItem = z.infer<typeof IntegrationItem>;

export const IntegrationList = z.object({ items: z.array(IntegrationItem) });
export type IntegrationList = z.infer<typeof IntegrationList>;

/** PUT /api/integrations request body. */
export const IntegrationUpsertInput = z.object({
  provider: ProviderEnum,
  scope: IntegrationScopeWire,
  /** The raw provider value. URL for Slack; bare 32-hex routing key OR a
   *  full events.pagerduty.com URL for PagerDuty. Validated by the route
   *  handler against the provider's shape and values.length upper bound. */
  value: z.string().min(1).max(256),
});
export type IntegrationUpsertInput = z.infer<typeof IntegrationUpsertInput>;

/** POST /api/integrations/test response. */
export const IntegrationTestResult = z.object({
  status: z.enum(['delivered', 'failed']),
  statusCode: z.number().int().nullable(),
  error: z.string().nullable(),
  runDay: z.string(),
});
export type IntegrationTestResult = z.infer<typeof IntegrationTestResult>;

/** POST /api/integrations/rule-trigger request body. Caller specifies which
 *  connected repo the rule tripped on and the integration lookup walks the
 *  per-repo override → team-wide fallback precedence that the brief mandates.
 *  `reason` is a free-text label ("License change", "High-severity CVE", …) —
 *  the value coming from the matching PageHumanRule enum on the policy pack
 *  and surfaced in the message, but the brief keeps it open as a string so
 *  the route can enrich later without a contract bump. */
export const RuleTriggerInput = z.object({
  provider: ProviderEnum,
  scope: IntegrationScopeWire,
  repoId: z.string().min(1),
  reason: z.string().min(1).max(200),
  prUrl: z.string().url(),
});
export type RuleTriggerInput = z.infer<typeof RuleTriggerInput>;

/** POST /api/integrations/rule-trigger response. `noOp` is the brief-mandated
 *  fallback when neither a per-repo override nor a team-wide config exists —
 *  it's distinct from a `delivered: false` that means we tried and the
 *  endpoint returned an error. `resolvedScope` echoes whether the lookup
 *  fell back to team (or stayed at the per-repo override) so the UI can
 *  render which integration actually fired. */
export const RuleTriggerResult = z.object({
  delivered: z.boolean(),
  noOp: z.boolean(),
  noOpReason: z.string().nullable(),
  provider: ProviderEnum,
  resolvedScope: IntegrationScopeWire,
  runDay: z.string(),
  statusCode: z.number().int().nullable(),
  error: z.string().nullable(),
});
export type RuleTriggerResult = z.infer<typeof RuleTriggerResult>;
