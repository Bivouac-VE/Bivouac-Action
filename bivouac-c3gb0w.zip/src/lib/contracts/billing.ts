// @polsia:user-owned — shared zod contracts for the /settings/billing surface.
//
// Client-importable (zod only, no server-only imports). The same schemas are
// parsed by the route handlers (state, checkout, sync) AND the client island
// so a shape drift surfaces as a ZodError instead of silent wrong UI.

import { z } from 'zod';
import { PricingPlanSlug, type PricingPlanSlug as PricingPlanSlugT } from '@/lib/contracts/pricing';

export const BillingPlanSlug = PricingPlanSlug;
export type BillingPlanSlug = PricingPlanSlugT;

// SLA add-on slugs as they appear on Stripe checkout metadata + persisted rows.
// Pricing-side copy lives in src/lib/business/plans.ts (PricingPlan.slaAddons).
export const BillingAddonSlug = z.enum(['+24h-critical-sla', '+business-hours-paging']);
export type BillingAddonSlug = z.infer<typeof BillingAddonSlug>;

export const BillingPlanStatus = z.enum(['ACTIVE', 'CANCELLED', 'PAST_DUE']);
export type BillingPlanStatus = z.infer<typeof BillingPlanStatus>;

export const BillingAddon = z.object({
  id: z.string(),
  slug: BillingAddonSlug,
  label: z.string().min(1),
  monthlyUsd: z.number().int().min(0),
});
export type BillingAddon = z.infer<typeof BillingAddon>;

export const BillingPlanRecord = z.object({
  id: z.string(),
  slug: BillingPlanSlug,
  monthlyPerRepoUsd: z.number().int().min(1),
  paidRepoCount: z.number().int().min(0).nullable(),
  repoLimit: z.number().int().nullable(),
  status: BillingPlanStatus,
  currentPeriodEnd: z.string().nullable(),
  cancelAtPeriodEnd: z.boolean(),
});
export type BillingPlanRecord = z.infer<typeof BillingPlanRecord>;

export const BillingState = z.object({
  plan: BillingPlanRecord.nullable(),
  repoCount: z.number().int().min(0),
  addons: z.array(BillingAddon),
});
export type BillingState = z.infer<typeof BillingState>;

export const BillingCheckoutRequest = z.object({
  planId: BillingPlanSlug,
  addons: z.array(BillingAddonSlug).optional(),
});
export type BillingCheckoutRequest = z.infer<typeof BillingCheckoutRequest>;

// Discriminated response mirrors the public /api/checkout shape so the client
//   can reuse the same redirect/toast branching.
export const BillingCheckoutResponseCheckout = z.object({
  ok: z.literal('checkout'),
  url: z.string().url(),
});
export const BillingCheckoutResponseError = z.object({
  ok: z.literal('error'),
  error: z.string().min(1),
});
export const BillingCheckoutResponse = z.discriminatedUnion('ok', [
  BillingCheckoutResponseCheckout,
  BillingCheckoutResponseError,
]);
export type BillingCheckoutResponse = z.infer<typeof BillingCheckoutResponse>;

export const BillingSyncRequest = z.object({
  sessionId: z.string().min(1),
  planId: BillingPlanSlug,
  addons: z.array(BillingAddonSlug).optional(),
});
export type BillingSyncRequest = z.infer<typeof BillingSyncRequest>;

// ---- Invoice history (GET /api/billing/invoices) ---------------------------
//
// One row per Stripe payment event the platform returned for the signed-in
// user's email. `amountUsd` / `description` are nullable because the upstream
// feed occasionally returns a row without them — callers MUST tolerate that.
//
// `hostedInvoiceUrl` — Stripe's hosted invoice URL — is nullable AND almost
// always null: the Polsia payment-events feed does not surface it, and the
// Stripe SDK is forbidden by the platform. The field is kept on the contract
// so a future enhancement (or a row with `verification_url`) can hydrate it
// without a contract-breaking change. Callers MUST tolerate `null`.

export const InvoiceRecord = z.object({
  id: z.number().int(),
  stripeCheckoutSessionId: z.string().nullable(),
  amountUsd: z.number().nullable(),
  description: z.string().nullable(),
  occurredAt: z.string(),
  hostedInvoiceUrl: z.string().nullable(),
});
export type InvoiceRecord = z.infer<typeof InvoiceRecord>;

export const BillingInvoicesResponse = z.object({
  invoices: z.array(InvoiceRecord),
});
export type BillingInvoicesResponse = z.infer<typeof BillingInvoicesResponse>;

// ---- Subscription status (used by the Stripe proxy only) ------------------
//
// Subset of `SubscriptionStatusResult` from the stripe-billing module
// (framework-owned schema). The /dashboard/billing island currently reaches
// this via /api/billing/state + /api/billing/portal (which already mirror
// Stripe's state into the local BillingPlan row); the contract stays reserved
// for future callers that want a direct status snapshot.

export const SubscriptionStatus = z.object({
  active: z.boolean(),
  currentPeriodEnd: z.string().nullable(),
  plan: z.string().nullable(),
  monthlyAmount: z.number().nullable(),
});
export type SubscriptionStatus = z.infer<typeof SubscriptionStatus>;

// ---- Stripe-hosted customer portal (GET /api/billing/portal-session) ------
//
// The Polsia billing proxy does NOT expose Stripe's hosted customer portal,
// so this route surfaces its availability + a fallback URL (`url`) the
// island can open. The island handles the "no portal" branch with a toast so
// the spec contract is `{ url, available }` — `available: false` means the
// hosted portal is not yet wired and the caller should fall back to the
// in-app cancel + Switch-plan-to-Starter flow.

export const PortalSessionResponse = z.object({
  url: z.string(),
  available: z.boolean(),
});
export type PortalSessionResponse = z.infer<typeof PortalSessionResponse>;

// ---- Cancel / sync mirror (POST /api/billing/portal) ------------------------
//
// Route mirrors Stripe subscription state into the local BillingPlan row. The
// route returns the freshly-mirrored flag so the client island can flip its UI
// without waiting for the next state refetch.

export const PortalSyncResponse = z.object({
  cancelAtPeriodEnd: z.boolean(),
  currentPeriodEnd: z.string().nullable(),
});
export type PortalSyncResponse = z.infer<typeof PortalSyncResponse>;
