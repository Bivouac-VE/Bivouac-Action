// @polsia:user-owned — shared zod contract for the patch detail feature.
// Single source of truth shared by the route handlers and the client islands;
// a shape change is a tsc/ZodError instead of silent JSON drift. Client-importable
// (zod only — no server-only imports here).

import { z } from 'zod';

export const PatchSeverityEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type PatchSeverity = z.infer<typeof PatchSeverityEnum>;

export const PatchTestOutcomeEnum = z.enum(['queued', 'running', 'pass', 'fail']);
export type PatchTestOutcome = z.infer<typeof PatchTestOutcomeEnum>;

export const PatchMergeStateEnum = z.enum(['auto-merged', 'open', 'declined', 'paged-human']);
export type PatchMergeState = z.infer<typeof PatchMergeStateEnum>;

export const PatchFileStatusEnum = z.enum(['added', 'modified', 'deleted']);
export type PatchFileStatus = z.infer<typeof PatchFileStatusEnum>;

export const PatchPolicyActionEnum = z.enum([
  'auto-merge',
  'open-pr-wait',
  'page-human',
  'decline',
]);
export type PatchPolicyAction = z.infer<typeof PatchPolicyActionEnum>;

export const PatchListItem = z.object({
  id: z.string(),
  title: z.string().min(1),
  cveId: z.string().min(1),
  packageName: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  severity: PatchSeverityEnum,
  mergeState: PatchMergeStateEnum,
  createdAt: z.string(),
});
export type PatchListItem = z.infer<typeof PatchListItem>;

export const PatchList = z.object({ items: z.array(PatchListItem) });
export type PatchList = z.infer<typeof PatchList>;

export const PatchFileDiff = z.object({
  path: z.string().min(1),
  diff: z.string().min(1),
  status: PatchFileStatusEnum,
});
export type PatchFileDiff = z.infer<typeof PatchFileDiff>;

export const PatchPolicyRule = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  action: PatchPolicyActionEnum,
  pagedHuman: z.boolean(),
});
export type PatchPolicyRule = z.infer<typeof PatchPolicyRule>;

export const PatchDetail = PatchListItem.extend({
  targetRepo: z.string().min(1),
  prUrl: z.string().min(1),
  testOutcome: PatchTestOutcomeEnum,
  testLog: z.string().min(1),
  policyRule: PatchPolicyRule,
  files: z.array(PatchFileDiff).min(1),
  testsRun: z.number().int().nonnegative(),
  testsPassed: z.number().int().nonnegative(),
  testsFailed: z.number().int().nonnegative(),
  rationale: z.string().min(1),
});
export type PatchDetail = z.infer<typeof PatchDetail>;
