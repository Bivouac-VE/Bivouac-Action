// @polsia:user-owned — shared zod contracts for the /settings/team surface.
// Client-importable (zod only, no server-only imports). The same schemas are
// parsed by the route handlers (state, members, invites) AND the client
// islands so shape drift surfaces as a ZodError instead of silent wrong UI.

import { z } from 'zod';

// Wire-side role keys. Prisma's `TeamRole` enum stores these exact strings;
// the UI maps them to display labels via ROLE_TONE below.
export const TeamRoleEnum = z.enum(['admin', 'viewer', 'on_call']);
export type TeamRoleEnum = z.infer<typeof TeamRoleEnum>;

// Display + tone catalog for roles. Pure data — no server-only imports — so
// both client islands AND route handlers (which use `label` for the invite
// email subject) can import this. Co-located here next to the wire schema so
// the label can never drift from the enum.
export interface RolePresentation {
  label: string;
  /** Inline Tailwind classes for the tone of the role's <Badge/> surface. */
  toneClass: string;
  /** Human description of what the role can do on /settings/team. */
  blurb: string;
}

export const ROLE_TONE: Record<TeamRoleEnum, RolePresentation> = {
  admin: {
    label: 'Admin',
    toneClass: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
    blurb: 'Manage members, invite teammates, and route on-call.',
  },
  viewer: {
    label: 'Viewer',
    toneClass: 'border-border bg-muted/40 text-foreground',
    blurb: 'Read-only access to the team dashboard.',
  },
  on_call: {
    label: 'On-call',
    toneClass: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    blurb: 'Paged for contested decisions and red builds.',
  },
};

export const MemberItem = z.object({
  /** Membership row id. */
  id: z.string().min(1),
  /** Better-auth User id (scalar FK). */
  userId: z.string().min(1),
  email: z.string().min(1),
  name: z.string().min(1),
  role: TeamRoleEnum,
  joinedAt: z.string(),
});
export type MemberItem = z.infer<typeof MemberItem>;

export const PendingInviteItem = z.object({
  id: z.string().min(1),
  email: z.string().min(1),
  role: TeamRoleEnum,
  /** Last attempted email send status — `null` while still pending send. */
  lastSendStatus: z.enum(['sent', 'failed']).nullable(),
  invitedAt: z.string(),
  expiresAt: z.string(),
});
export type PendingInviteItem = z.infer<typeof PendingInviteItem>;

// Combined state endpoint so the page can render in one round-trip rather
// than waterfall GETs.
export const TeamState = z.object({
  tier: z.enum(['ok', 'no-plan', 'wrong-tier']),
  currentUser: z.object({
    userId: z.string().min(1),
    email: z.string().min(1),
    name: z.string().min(1),
    /** Is the signed-in user a team admin (owns the Membership.admin role). */
    isTeamAdmin: z.boolean(),
    /**
     * Caller's Membership.role — `null` when the user has no seat (wrong-tier,
     * unaffiliated, or signed in via an account that never got the OWNER-grant).
     * Nav gating reads this on top of `isTeamAdmin` so a viewer-tier caller can't
     * see admin-only surfaces just because the platform-admin plugin flagged
     * them.
     */
    teamRole: TeamRoleEnum.nullable(),
  }),
  members: z.array(MemberItem),
  pendingInvites: z.array(PendingInviteItem),
});
export type TeamState = z.infer<typeof TeamState>;

// POST /api/team/invites payload — invite a teammate by email + role.
export const InviteCreate = z.object({
  email: z.string().email().toLowerCase(),
  role: TeamRoleEnum,
});
export type InviteCreate = z.infer<typeof InviteCreate>;

// POST /api/team/invites response — returns the created invite row + the
// initial send status. Email failures persist the row anyway so the admin can
// "Resend" from the pending-invites island.
export const InviteCreateResponse = z.object({
  invite: PendingInviteItem.extend({
    lastSendStatus: z.enum(['sent', 'failed']),
  }),
  /** Recipient-relative URL embedded into the invite email (client-safe). */
  acceptUrl: z.string().url(),
});
export type InviteCreateResponse = z.infer<typeof InviteCreateResponse>;

// PATCH /api/team/members/[userId] payload — change a seated member's role.
export const MemberRoleUpdate = z.object({
  role: TeamRoleEnum,
});
export type MemberRoleUpdate = z.infer<typeof MemberRoleUpdate>;
