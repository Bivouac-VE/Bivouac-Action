// @polsia:user-owned — shared zod contract for the public /status page.
// Single source of truth shared by the GET /api/status route handler and the
// <StatusBoard/> client island; a shape change surfaces as a tsc/ZodError,
// not silent JSON drift. Client-importable (zod only — no server-only
// imports here).

import { z } from 'zod';

// Overall operational state for the banner. The route handler computes this
// from cron-recency heuristics; the page shows the matching label + tone.
// `unknown` is reserved: never returned by the loader today, but keep the
// slot so a future schema-mismatch fallback doesn't crash the page.
export const StatusOverallEnum = z.enum(['healthy', 'delayed', 'down', 'no-data', 'unknown']);
export type StatusOverall = z.infer<typeof StatusOverallEnum>;

export const StatusHeadline = z.object({
  overall: StatusOverallEnum,
  // Short banner headline (read-only — the loader picks the wording).
  label: z.string(),
  // One-sentence detail the banner reads below the label.
  detail: z.string(),
  // ISO-8601 UTC of the most recent triage row, or null when no data.
  lastSeenAt: z.string().nullable(),
  // Calendar days (UTC) between now and lastSeenAt, rounded down.
  daysSinceLastSeen: z.number().int().nonnegative().nullable(),
});
export type StatusHeadline = z.infer<typeof StatusHeadline>;

// Per-cell bucket on the 90-day strip.
// `day` is YYYY-MM-DD (UTC); `patchesCount` is the count of CveTriageLog rows
// whose createdAt falls in that day. Today may be empty pre-cron, so we
// classify it as 'stale' (not 'down') — see the loader for the rule.
export const UptimeDayStatusEnum = z.enum(['up', 'stale', 'down']);
export type UptimeDayStatus = z.infer<typeof UptimeDayStatusEnum>;

export const UptimeDay = z.object({
  day: z.string(),
  status: UptimeDayStatusEnum,
  patchesCount: z.number().int().nonnegative(),
});
export type UptimeDay = z.infer<typeof UptimeDay>;

export const UptimeBars = z.object({
  fromDay: z.string(),
  toDay: z.string(),
  // Exactly 90 entries — the loader guarantees this.
  days: z.array(UptimeDay).length(90),
});
export type UptimeBars = z.infer<typeof UptimeBars>;

// Brief's wording for the action column: AUTO_MERGE→auto-merged,
// MANUAL_REVIEW→paged, BLOCKED→declined. Mirrors the audit-log mapping so
// the /status table reads identically to /dashboard/audit.
export const StatusActionEnum = z.enum(['auto-merged', 'paged', 'declined']);
export type StatusAction = z.infer<typeof StatusActionEnum>;

export const StatusSeverityEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type StatusSeverity = z.infer<typeof StatusSeverityEnum>;

export const StatusEventKindEnum = z.enum(['CVE', 'BREAKING']);
export type StatusEventKind = z.infer<typeof StatusEventKindEnum>;

export const IncidentRow = z.object({
  id: z.string(),
  createdAt: z.string(),
  cveId: z.string().nullable(),
  packageName: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  severity: StatusSeverityEnum,
  action: StatusActionEnum,
  prUrl: z.string().url(),
  // Detection→PR latency, in hours, computed in the loader as
  // (snapshot.generatedAt - row.createdAt) / 3600000. Null when the source
  // data is malformed (negative clock-skew sentinels).
  detectionToPrLatencyHours: z.number().nullable(),
});
export type IncidentRow = z.infer<typeof IncidentRow>;

export const RecentIncidents = z.object({
  items: z.array(IncidentRow),
});
export type RecentIncidents = z.infer<typeof RecentIncidents>;

// 30-day rollup used for the secondary "summary" tile bar.
export const StatusSummary30d = z.object({
  // Total triage rows in the trailing 30 days.
  patches: z.number().int().nonnegative(),
  // Subset with mergeDecision in {AUTO_MERGE}.
  autoMerged: z.number().int().nonnegative(),
  // Subset with mergeDecision in {MANUAL_REVIEW}.
  paged: z.number().int().nonnegative(),
  // Median (not mean) over the row age — closer to a SLO-friendly number
  // than a mean that a single outlier pulls. null when the window is empty.
  medianLatencyHours: z.number().nullable(),
});
export type StatusSummary30d = z.infer<typeof StatusSummary30d>;

// Top-level payload assembled by the loader, parsed by the route handler,
// validated by the client island. generatedAt is the time of the snapshot so
// the page can show "as of HH:MM UTC" without lying about freshness.
export const StatusSnapshot = z.object({
  generatedAt: z.string(),
  headline: StatusHeadline,
  uptime: UptimeBars,
  recentIncidents: RecentIncidents,
  summary30d: StatusSummary30d,
});
export type StatusSnapshot = z.infer<typeof StatusSnapshot>;
