// @polsia:user-owned — public blog contract.
// Shared by the /api/posts route handlers and the client islands
// reading them. `isoString` lets the route emit DateTime as ISO strings
// over the JSON wire (Date objects don't serialize) while the run-time
// type back on the client is just a string.

import { z } from 'zod';

const isoString = z.string().regex(/^\d{4}-\d{2}-\d{2}T.+Z$/, 'must be an ISO-8601 UTC timestamp');

export const PostSummary = z.object({
  id: z.string(),
  slug: z.string(),
  title: z.string(),
  excerpt: z.string(),
  publishedAt: isoString,
});

export const PostSummaryList = z.object({
  items: z.array(PostSummary),
});

export const Post = PostSummary.extend({
  body: z.string(),
});

export type PostSummary = z.infer<typeof PostSummary>;
export type PostSummaryList = z.infer<typeof PostSummaryList>;
export type Post = z.infer<typeof Post>;
