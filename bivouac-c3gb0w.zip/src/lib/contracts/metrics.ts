// @polsia:user-owned — shared zod contract for the /dashboard/metrics board.
// Single source of truth shared by the /api/metrics/summary + /api/metrics
// handlers and the <MetricsBoard/> client island. Client-importable (zod only —
// no server-only imports here). The InsightsRangeDaysEnum is re-exported from
// @/lib/contracts/insights so the legacy summary endpoint stays on one date-
// range vocabulary; the new compliance board uses its own 30/60/90 vocabulary.

import { z } from 'zod';
import { InsightsRangeDaysEnum } from '@/lib/contracts/insights';

export { InsightsRangeDaysEnum };
export type { InsightsRangeDays } from '@/lib/contracts/insights';

// Date-range vocabulary for the compliance metrics board. Distinct from
// InsightsRangeDays (7/30/90) per the brief — the compliance dashboard is a
// longer-horizon surface and never offers a 7-day view.
export const MetricsRangeDaysEnum = z.union([z.literal(30), z.literal(60), z.literal(90)]);
export type MetricsRangeDays = z.infer<typeof MetricsRangeDaysEnum>;

export const KpiTile = z.object({
  label: z.string(),
  value: z.string(),
  hint: z.string().nullable(),
});
export type KpiTile = z.infer<typeof KpiTile>;

export const PatchesPerMonthPoint = z.object({
  // ISO date (YYYY-MM-01) of the first day of the month bucket (UTC).
  monthStart: z.string(),
  count: z.number().int().nonnegative(),
});
export type PatchesPerMonthPoint = z.infer<typeof PatchesPerMonthPoint>;

export const MttpTrendPoint = z.object({
  monthStart: z.string(),
  // Average age in days over terminal-decision rows whose createdAt falls in
  // this calendar month; null when there were no terminal-decision rows.
  mttpDays: z.number().nullable(),
});
export type MttpTrendPoint = z.infer<typeof MttpTrendPoint>;

export const PatchesPerMonthSeries = z.object({
  rangeDays: InsightsRangeDaysEnum,
  points: z.array(PatchesPerMonthPoint),
});
export type PatchesPerMonthSeries = z.infer<typeof PatchesPerMonthSeries>;

export const MttpTrendSeries = z.object({
  rangeDays: InsightsRangeDaysEnum,
  points: z.array(MttpTrendPoint),
});
export type MttpTrendSeries = z.infer<typeof MttpTrendSeries>;

export const MetricsSummary = z.object({
  rangeDays: InsightsRangeDaysEnum,
  tiles: z.object({
    mttp: KpiTile,
    autoMergeRate: KpiTile,
    humanOverrideRate: KpiTile,
    patchesPerMonth: KpiTile,
  }),
  patchesPerMonthSeries: PatchesPerMonthSeries,
  mttpTrendSeries: MttpTrendSeries,
  connectedRepoCount: z.number().int().nonnegative(),
  // ISO date (YYYY-MM-DD) boundaries for the selected window — used by the
  // client island to build the "View underlying audit rows" deep link.
  from: z.string(),
  to: z.string(),
});
export type MetricsSummary = z.infer<typeof MetricsSummary>;

// === Compliance dashboard surface (= brief) =================================

// One point on a daily series. `date` is the UTC calendar day the bucket
// covers (YYYY-MM-DD). `hours` carries the metric value for that day; null
// when the day had zero contributing rows so the chart can leave a gap.
export const DailyPoint = z.object({
  date: z.string(),
  value: z.number().nullable(),
});
export type DailyPoint = z.infer<typeof DailyPoint>;

// Same shape as DailyPoint but a guaranteed-finite rate in [0, 1] — the rate
// denominator is non-zero for every emitted point so the chart line never
// leaves a gap in either series.
export const RatePoint = z.object({
  date: z.string(),
  value: z.number().min(0).max(1),
});
export type RatePoint = z.infer<typeof RatePoint>;

// Daily series wrapper. Heterogeneous points: MTTP is nullable (gaps); auto-
// merge + override are rates (always finite). Modelling them with a union of
// point shapes keeps the contract honest without forcing a sentinel value.
export const DailySeries = z.object({
  rangeDays: MetricsRangeDaysEnum,
  points: z.array(z.union([DailyPoint, RatePoint])),
});
export type DailySeries = z.infer<typeof DailySeries>;

// Per-repo breakdown row. MTTP is in hours so the table reads naturally next
// to the chart's "% auto-merged" / "% human-override" columns; null when the
// repo had no terminal rows in the window. Sparkline is the last twelve weeks
// of weekly MTTP in hours (values from the same proxy definition as the
// daily point — see loadComplianceMetrics); null entries leave the line
// broken so quiet weeks still read as a "kicked back to baseline" gap.
export const RepoBreakdownRow = z.object({
  repoId: z.string(),
  fullName: z.string(),
  mttpHours: z.number().nullable(),
  autoMergeRate: z.number().min(0).max(1),
  overrideRate: z.number().min(0).max(1),
  patchCount: z.number().int().nonnegative(),
  sparkMttpHours: z.array(z.number().nullable()),
});
export type RepoBreakdownRow = z.infer<typeof RepoBreakdownRow>;

// Composite payload the /dashboard/metrics board reads. Three daily series
// (MTTP, auto-merge rate, override rate) plus the per-repo breakdown. Range
// is mirrored at the top level so the client can label the toggle without a
// second parse.
export const ComplianceMetrics = z.object({
  rangeDays: MetricsRangeDaysEnum,
  from: z.string(),
  to: z.string(),
  connectedRepoCount: z.number().int().nonnegative(),
  mttpSeries: DailySeries,
  autoMergeSeries: DailySeries,
  overrideSeries: DailySeries,
  repos: z.array(RepoBreakdownRow),
});
export type ComplianceMetrics = z.infer<typeof ComplianceMetrics>;
