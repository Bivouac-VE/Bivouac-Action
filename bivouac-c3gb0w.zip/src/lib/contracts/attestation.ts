// @polsia:user-owned — shared zod contract for the /attestation export.
// Single source of truth shared by /api/attestation/* route handlers AND the
// AttestationPicker client island. Client-importable (zod only — no server-only
// imports here).

import { z } from 'zod';

export const QuarterIdEnum = z.string().regex(/^\d{4}-Q[1-4]$/);
export type QuarterId = z.infer<typeof QuarterIdEnum>;

export const SeverityBucketEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type SeverityBucket = z.infer<typeof SeverityBucketEnum>;

export const SeverityCounts = z.object({
  low: z.number().int().nonnegative(),
  medium: z.number().int().nonnegative(),
  high: z.number().int().nonnegative(),
  critical: z.number().int().nonnegative(),
});
export type SeverityCounts = z.infer<typeof SeverityCounts>;

export const PatchEvent = z.object({
  id: z.string(),
  createdAt: z.string(),
  cveId: z.string(),
  packageName: z.string(),
  fromVersion: z.string(),
  toVersion: z.string(),
  severity: SeverityBucketEnum,
  testOutcome: z.enum(['PASSED', 'FAILED', 'ERRORED', 'PENDING']),
  mergeDecision: z.enum(['AUTO_MERGE', 'MANUAL_REVIEW', 'BLOCKED']),
  repo: z.string(),
  prUrl: z.string().url(),
  isHumanOverride: z.boolean(),
  // Upstream fix reference. The CRON doesn't store the SHA of the upstream
  // patch commit yet, so we echo the PR number from the PR URL's last path
  // segment when no head SHA is recorded — deterministic for the same row
  // and good enough for an auditor linking to the same PR. Left null when
  // nothing in the URL identifies a single upstream PR.
  upstreamSha: z.string().nullable(),
});
export type PatchEvent = z.infer<typeof PatchEvent>;

export const Override = z.object({
  id: z.string(),
  decidedAt: z.string(),
  cveId: z.string(),
  packageName: z.string(),
  fromVersion: z.string(),
  toVersion: z.string(),
  severity: SeverityBucketEnum,
  repo: z.string(),
  prUrl: z.string().url(),
  mergeDecision: z.enum(['MANUAL_REVIEW', 'BLOCKED']),
  actorEmail: z.string().nullable(),
  reason: z.string().nullable(),
});
export type Override = z.infer<typeof Override>;

export const PolicyVersion = z.object({
  id: z.string(),
  version: z.string(),
  title: z.string(),
  effectiveFrom: z.string(),
  effectiveTo: z.string().nullable(),
});
export type PolicyVersion = z.infer<typeof PolicyVersion>;

export const MttpMetric = z.object({
  // The mean-time-to-patch value, in days (float), or null when zero patches.
  // Computed against the end-of-quarter timestamp so the same repo+quarter
  // yields the SAME number across calls — an auditor can replay the byte-for-
  // byte bundle and get the same attestation hash.
  valueDays: z.number().nullable(),
  // Sample size the MTTP was computed from.
  sampleSize: z.number().int().nonnegative(),
  // The reference timestamp MTTP was measured against.
  asOf: z.string(),
  // The exact derivation so an auditor can reproduce the number.
  derivation: z.string(),
});
export type MttpMetric = z.infer<typeof MttpMetric>;

export const AttestationMeta = z.object({
  repoId: z.string(),
  ownerHandle: z.string(),
  name: z.string(),
  quarter: QuarterIdEnum,
  // The signed-in user id requesting the bundle. Auditor's footer (timestamp,
  // repo id, user id, bundle hash) — explicitly written into BOTH the meta
  // payload AND the hash input so a verifier can confirm who asked for the
  // file, not just the repo / quarter content.
  userId: z.string(),
  // When the bundle was assembled. NOT part of the attestation hash input —
  // the hash covers the content of the bundle (events, counts, mttp, overrides,
  // policy). The ISO stamp lets an auditor see "this bundle was generated at
  // X" but doesn't have to fold into the cryptographic signature.
  generatedAt: z.string(),
  policyVersion: PolicyVersion,
});
export type AttestationMeta = z.infer<typeof AttestationMeta>;

// SBOM rollup included with the bundle so an auditor has a numeric anchor
// for "what code were these patches touching" — total vs touched vs the split
// across ecosystems (npm, pypi, …). Pre-aggregated from `CveTriageLog`
// (distinct packageName) — the bundle does NOT carry the full SBOM artifact.
export const SbomSummary = z.object({
  packagesTouched: z.number().int().nonnegative(),
  totalPackages: z.number().int().nonnegative(),
  ecosystems: z.record(z.string(), z.number().int().nonnegative()),
});
export type SbomSummary = z.infer<typeof SbomSummary>;

export const AttestationBundle = z.object({
  meta: AttestationMeta,
  counts: z.object({
    patches: SeverityCounts,
    overrides: z.number().int().nonnegative(),
  }),
  cveIdsRemediated: z.array(z.string()),
  mttp: MttpMetric,
  overrides: z.array(Override),
  patchEvents: z.array(PatchEvent),
  sbom: SbomSummary,
  // The attestation hash covers every other top-level field. It is NOT itself
  // included in the hash input — verifying is `sha256(canonicalize(bundle))`
  // and comparing to the value here.
  attestation: z.object({ hash: z.string() }),
});
export type AttestationBundle = z.infer<typeof AttestationBundle>;

export const AttestationSummary = z.object({
  meta: AttestationMeta,
  counts: z.object({
    patches: SeverityCounts,
    overrides: z.number().int().nonnegative(),
  }),
  cveIdsRemediated: z.array(z.string()),
  mttp: MttpMetric,
  overrides: z.array(Override),
  sbom: SbomSummary,
});
export type AttestationSummary = z.infer<typeof AttestationSummary>;

export const AttestationPreviewRequest = z.object({
  repoId: z.string(),
  quarter: QuarterIdEnum,
});
export type AttestationPreviewRequest = z.infer<typeof AttestationPreviewRequest>;

export const QuarterList = z.object({ items: z.array(QuarterIdEnum) });
export type QuarterList = z.infer<typeof QuarterList>;
