// @polsia:user-owned — shared zod contract for the public /activity live
// feed. Single source of truth shared by the GET /api/activity route
// handler and the <ActivityFeed/> client island; a shape change surfaces
// as a tsc/ZodError, not silent JSON drift. Client-importable (zod only —
// no server-only imports here).
//
// The feed is a marketing/social-proof surface: a buyer can see the agent
// actually doing the work, not just being told. Severity derives from the
// same `deriveSeverity` table the patch list uses (visual continuity with
// /dashboard/patches). Merge state mirrors `PatchListItem.mergeState`
// verbatim so the row badges read identically across surfaces.

import { z } from 'zod';

// Mirrors `PatchSeverity` — derives from the same CVE table in
// business/patches.ts so the row badge vocabulary matches the
// /dashboard/patches list one-for-one.
export const ActivitySeverityEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type ActivitySeverity = z.infer<typeof ActivitySeverityEnum>;

// Persistent DB enum (AUTO_MERGE / MANUAL_REVIEW / BLOCKED / undefined) →
// UI-side merge-state noun, matching `PatchMergeState`.
export const ActivityMergeStateEnum = z.enum(['auto-merged', 'open', 'declined', 'paged-human']);
export type ActivityMergeState = z.infer<typeof ActivityMergeStateEnum>;

// UI-side health of the cron from the perspective of the feed strip —
// derived in the business layer from row-recency on `CveTriageLog`. Most
// "live" pages use a heartbeat and report "no data" until enough rows
// exist; here we report a three-state health dot from row age alone
// (matches /api/status' heuristic so the two surfaces never disagree).
export const ActivityDotStateEnum = z.enum(['green', 'amber', 'red']);
export type ActivityDotState = z.infer<typeof ActivityDotStateEnum>;

// One row in the activity timeline. id is always present (row PK);
// cveId may be null when the row is an upstream-breaking-change event
// that landed via eventKind='BREAKING'.
export const ActivityFeedItem = z.object({
  id: z.string(),
  cveId: z.string().nullable(),
  packageName: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  severity: ActivitySeverityEnum,
  mergeState: ActivityMergeStateEnum,
  // Derived from the prUrl owner/repo slug (no schema column). UI displays
  // it as a small chip in the row so a visitor can scan which repo the
  // patch landed in. Null when the slug can't be parsed (legacy row
  // without a github.com url) — the UI falls back to a generic chip.
  repoLabel: z.string().nullable(),
  createdAt: z.string(),
  // Time from row append-now (now − createdAt), formatted in hours as a
  // float. The UI rounds for display; the contract carries the source
  // number so analytics can pick it up unchanged.
  timeToPatchHours: z.number().nonnegative(),
});
export type ActivityFeedItem = z.infer<typeof ActivityFeedItem>;

// Tiny sub-envelope carried in the same response so the "Live now" strip
// paints in lock-step with the feed (no follow-up /api call). All three
// fields fall through to safe defaults when no rows exist yet so the
// page never throws on a fresh boot.
export const ActivityLive = z.object({
  // ISO timestamp of the most recent triage row, or null when no rows.
  lastTriageAt: z.string().nullable(),
  // Number of triage rows whose createdAt falls within the last 24h.
  patchesLast24h: z.number().int().nonnegative(),
  // Health dot for the strip ('green' healthy, 'amber' delayed, 'red' down).
  dotState: ActivityDotStateEnum,
});
export type ActivityLive = z.infer<typeof ActivityLive>;

export const ActivityFeed = z.object({
  items: z.array(ActivityFeedItem),
  live: ActivityLive,
});
export type ActivityFeed = z.infer<typeof ActivityFeed>;
