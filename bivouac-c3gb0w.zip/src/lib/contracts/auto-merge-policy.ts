// @polsia:user-owned — shared zod contract for the per-caller auto-merge
// configuration at /dashboard/policy. Single source of truth shared by
// /api/policy, the client islands (form + header badge), and the server-side
// reader at /lib/guardrails/load.ts. Shape drift surfaces as a ZodError
// instead of silent JSON drift. Client-importable (zod only — no server-only
// imports here).

import { z } from 'zod';

// Mutually exclusive scope: which trigger surface drives auto-merge.
export const AutoMergeScope = z.enum(['cve-only', 'breaking-change-only', 'both']);
export type AutoMergeScope = z.infer<typeof AutoMergeScope>;

// CVSS floor mapping — informational only here; the routing logic lives in
// the agent/triage layer. The form shows the floor next to each tier so
// buyers understand the cutoff they're setting.
export const SeverityCutoff = z.enum(['low', 'medium', 'high', 'critical']);
export type SeverityCutoff = z.infer<typeof SeverityCutoff>;

// Default action when no guardrail blocks and the diff is in scope.
export const DefaultAction = z.enum(['auto-merge', 'open-pr-wait', 'page-human']);
export type DefaultAction = z.infer<typeof DefaultAction>;

// Kind of auto-merge guardrail row. Each kind determines whether a pattern is
// required (`touches-path` / `has-label`), optional (`free-text`), or absent
// (`tests-fail`).
export const GuardrailKind = z.enum(['tests-fail', 'touches-path', 'has-label', 'free-text']);
export type GuardrailKind = z.infer<typeof GuardrailKind>;

export const GuardrailRule = z.object({
  id: z.string().min(1),
  kind: GuardrailKind,
  pattern: z.string(),
});
export type GuardrailRule = z.infer<typeof GuardrailRule>;

export const PackageList = z.array(z.string().min(1)).max(200);
export type PackageList = z.infer<typeof PackageList>;

// Display helper — CVSS lower bound per tier (informational).
export const SEVERITY_CVSS_FLOOR: Record<SeverityCutoff, string> = {
  low: 'CVSS ≥ 0.1',
  medium: 'CVSS ≥ 4.0',
  high: 'CVSS ≥ 7.0',
  critical: 'CVSS ≥ 9.0',
};

// Display helper — short tier label for the header badge.
export const SEVERITY_SHORT_LABEL: Record<SeverityCutoff, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

// Display helper — short scope label for the header badge.
export const SCOPE_SHORT_LABEL: Record<AutoMergeScope, string> = {
  'cve-only': 'CVE-only',
  'breaking-change-only': 'Breaking-change-only',
  both: 'CVE + breaking-change',
};

export const DEFAULT_ACTION_LABEL: Record<DefaultAction, string> = {
  'auto-merge': 'Auto-merge',
  'open-pr-wait': 'Open PR and wait',
  'page-human': 'Page a human',
};

export const GUARDRAIL_KIND_LABEL: Record<GuardrailKind, string> = {
  'tests-fail': 'Tests fail',
  'touches-path': 'Touches path',
  'has-label': 'Has label',
  'free-text': 'Free-text rule',
};

export const GUARDRAIL_KIND_DESCRIPTION: Record<GuardrailKind, string> = {
  'tests-fail': 'Block auto-merge when the CI run for the diff is red.',
  'touches-path':
    'Block auto-merge when the diff touches a path glob (e.g. `/auth/**`, `**/payments.ts`).',
  'has-label': 'Block auto-merge when the PR carries a label (e.g. `needs-review`).',
  'free-text':
    'A free-form rule evaluated by Bivouac (e.g. "skip on Fridays"). Provide the rule text.',
};

// Read shape: the persisted row for the caller.
export const AutoMergePolicy = z.object({
  userId: z.string(),
  scopeMode: AutoMergeScope,
  minSeverity: SeverityCutoff,
  pageOnLicenseFlip: z.boolean(),
  pageOnTransitiveCve: z.boolean(),
  pageOnContestedApi: z.boolean(),
  defaultAction: DefaultAction,
  autoMergeGuardrails: z.array(GuardrailRule),
  packageAllowlist: PackageList,
  packageDenylist: PackageList,
  maxDependencyDepth: z.number().int().min(0).max(20),
  updatedAt: z.string(),
});
export type AutoMergePolicy = z.infer<typeof AutoMergePolicy>;

// Write shape: PATCH body from the form (no userId — owner is the session).
export const AutoMergePolicyInput = z.object({
  scopeMode: AutoMergeScope,
  minSeverity: SeverityCutoff,
  pageOnLicenseFlip: z.boolean(),
  pageOnTransitiveCve: z.boolean(),
  pageOnContestedApi: z.boolean(),
  defaultAction: DefaultAction,
  autoMergeGuardrails: z.array(GuardrailRule),
  packageAllowlist: PackageList,
  packageDenylist: PackageList,
  maxDependencyDepth: z.number().int().min(0).max(20),
});
export type AutoMergePolicyInput = z.infer<typeof AutoMergePolicyInput>;

// Sentinel defaults seeded into a brand-new row on first GET.
export const AUTO_MERGE_DEFAULTS = {
  scopeMode: 'both',
  minSeverity: 'high',
  pageOnLicenseFlip: true,
  pageOnTransitiveCve: true,
  pageOnContestedApi: true,
  defaultAction: 'open-pr-wait',
  autoMergeGuardrails: [],
  packageAllowlist: [],
  packageDenylist: [],
  maxDependencyDepth: 0,
} as const satisfies AutoMergePolicyInput;

// Normalize a row that may have been stored before the additional columns
// existed (defensive — every new column has a @default, so prisma will hand
// us a fully populated row, but old rows may carry `null` JSON values).
export function parseAutoMergePolicyRow(row: {
  userId: string;
  scopeMode: string;
  minSeverity: string;
  pageOnLicenseFlip: boolean;
  pageOnTransitiveCve: boolean;
  pageOnContestedApi: boolean;
  defaultAction: string;
  autoMergeGuardrailsJson: unknown;
  packageAllowlistJson: unknown;
  packageDenylistJson: unknown;
  maxDependencyDepth: number;
  updatedAt: Date;
}): AutoMergePolicy {
  return AutoMergePolicy.parse({
    userId: row.userId,
    scopeMode: row.scopeMode,
    minSeverity: row.minSeverity,
    pageOnLicenseFlip: row.pageOnLicenseFlip,
    pageOnTransitiveCve: row.pageOnTransitiveCve,
    pageOnContestedApi: row.pageOnContestedApi,
    defaultAction: row.defaultAction,
    autoMergeGuardrails: asGuardrailList(row.autoMergeGuardrailsJson),
    packageAllowlist: asStringList(row.packageAllowlistJson),
    packageDenylist: asStringList(row.packageDenylistJson),
    maxDependencyDepth: row.maxDependencyDepth,
    updatedAt: row.updatedAt.toISOString(),
  });
}

function asGuardrailList(value: unknown): GuardrailRule[] {
  if (Array.isArray(value)) return value as GuardrailRule[];
  return [];
}

function asStringList(value: unknown): string[] {
  if (Array.isArray(value))
    return value.filter((entry): entry is string => typeof entry === 'string');
  return [];
}
