// @polsia:user-owned — shared zod contract for the /dashboard/alerts feed. The
// alert feed reuses the same data source as /dashboard/audit (CveTriageLog)
// but is gated strictly to on-call duty: any high/critical severity row whose
// merge decision qualifies as "escalate to a human" surfaces here so the on-
// call sees a short, actionable stream instead of the full audit log.
//
// Client-importable (zod only — no server-only imports here).

import { z } from 'zod';

export const AlertSeverityEnum = z.enum(['high', 'critical']);
export type AlertSeverity = z.infer<typeof AlertSeverityEnum>;

export const AlertActionEnum = z.enum(['red_build', 'contested_decision', 'merge_blocked']);
export type AlertAction = z.infer<typeof AlertActionEnum>;

export const AlertEntry = z.object({
  id: z.string().min(1),
  /** ISO timestamp of the underlying event. */
  at: z.string(),
  repo: z.string().min(1),
  severity: AlertSeverityEnum,
  action: AlertActionEnum,
  /** Short human-readable summary for the on-call (e.g. "CVE-2024-1001 broke the red build"). */
  summary: z.string().min(1),
  /** Deep link back to /dashboard/audit with the relevant filter preset applied. */
  deepLinkHref: z.string().min(1),
});
export type AlertEntry = z.infer<typeof AlertEntry>;

export const AlertList = z.object({
  alerts: z.array(AlertEntry),
});
export type AlertList = z.infer<typeof AlertList>;
