// @polsia:user-owned — shared zod contracts for /api/digest-webhook/* and the
// /dashboard/settings/webhooks island. Single source of truth shared between
// the route handlers (server) and the React island (client). A shape change
// surfaces as a tsc/ZodError rather than silent JSON drift.
//
// Client-importable — zod only, no server-only imports.

import { z } from 'zod';

/** GET /api/digest-webhook response — current configuration + last write. */
export const DigestWebhookConfig = z.object({
  url: z.string().nullable(),
  enabled: z.boolean(),
  /// ISO of the last row mutation; null when the row has just been seeded.
  updatedAt: z.string().nullable(),
});
export type DigestWebhookConfig = z.infer<typeof DigestWebhookConfig>;

/** PUT /api/digest-webhook request body. */
export const DigestWebhookInput = z.object({
  url: z.string().min(1).max(165),
  enabled: z.boolean(),
});
export type DigestWebhookInput = z.infer<typeof DigestWebhookInput>;

/** POST /api/digest-webhook/test response. */
export const DigestWebhookTestResult = z.object({
  status: z.enum(['delivered', 'failed']),
  statusCode: z.number().int().nullable(),
  /// Human-readable error (network failure, validation, etc.). null on success.
  error: z.string().nullable(),
  /// Echo of `runDay` so the UI can locate the row in the deliveries table.
  runDay: z.string(),
});
export type DigestWebhookTestResult = z.infer<typeof DigestWebhookTestResult>;

/** Single delivery row — flatten-shape of DigestDelivery + a truncated URL. */
export const DigestDeliveryRow = z.object({
  id: z.string(),
  runDay: z.string(),
  status: z.enum(['delivered', 'failed', 'pending']),
  attempts: z.number().int(),
  lastStatusCode: z.number().int().nullable(),
  /// Truncated to ~140 chars server-side so the UI doesn't need to guess.
  lastError: z.string().nullable(),
  sentAt: z.string().nullable(),
  createdAt: z.string(),
  /// First 60 chars of the destination URL + ellipsis when truncated.
  urlPreview: z.string(),
});
export type DigestDeliveryRow = z.infer<typeof DigestDeliveryRow>;

/** GET /api/digest-webhook/deliveries response. */
export const DigestDeliveryList = z.object({
  items: z.array(DigestDeliveryRow),
});
export type DigestDeliveryList = z.infer<typeof DigestDeliveryList>;
