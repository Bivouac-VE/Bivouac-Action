// @polsia:user-owned — shared zod contract for the user's connected repos.
// Imported by BOTH the /api/repos route handler AND the client grid so a
// shape change is a tsc/ZodError instead of silent JSON drift. Client-importable
// (zod only — no server-only imports here).

import { z } from 'zod';

// GitHub installation / repo ids are 64-bit integers; Prisma BigInt serialises
// them as numeric strings over JSON. Restrict to digit-only so we never feed a
// malformed id into a Prisma BigInt column or a GitHub URL.
const BigIntString = z.string().regex(/^\d+$/, 'expected numeric string');

export const RepoStatusEnum = z.enum(['HEALTHY', 'VULN_DETECTED', 'PR_OPEN', 'PAGED_HUMAN']);
export type RepoStatus = z.infer<typeof RepoStatusEnum>;

export const Repo = z.object({
  id: z.string(),
  name: z.string(),
  ownerHandle: z.string(),
  lastScannedAt: z.string().nullable(),
  status: RepoStatusEnum,
  activePack: z
    .object({
      packSlug: z.string(),
      packTitle: z.string(),
    })
    .nullable(),
});
export type Repo = z.infer<typeof Repo>;

export const RepoList = z.object({ items: z.array(Repo) });
export type RepoList = z.infer<typeof RepoList>;

// /api/repos POST body. `installationId` is the BigInt-string installation the
// repos were selected from (must belong to the caller); `repos` is the enabled
// set on submit — can be empty if the user toggled everything off.
export const RepoSelectInput = z.object({
  installationId: BigIntString,
  repos: z.array(
    z.object({
      githubNodeId: z.string().min(1),
      githubRepoId: BigIntString,
      name: z.string().min(1),
      ownerHandle: z.string().min(1),
      defaultBranch: z.string().min(1),
    }),
  ),
});
export type RepoSelectInput = z.infer<typeof RepoSelectInput>;

// Per-repo ack of what got persisted so the picker island can show a precise
// summary rather than re-reading state on success.
export const RepoSelectResult = z.object({
  saved: z.number().int().nonnegative(),
  removed: z.number().int().nonnegative(),
  appliedPackSlug: z.string().nullable(),
});
export type RepoSelectResult = z.infer<typeof RepoSelectResult>;

// /api/github/installation/[installationId]/repos — the picker GET. `installationId`
// is echoed on each item so the client island doesn't have to track it
// separately when submitting. `visibility` + `pushedAt` are passed through
// from GitHub but are NOT persisted — the picker is the last place they're
// needed (the `Repo` table has no column for them).
export const GithubInstallationRepo = z.object({
  installationId: BigIntString,
  githubNodeId: z.string().min(1),
  githubRepoId: BigIntString,
  name: z.string().min(1),
  ownerHandle: z.string().min(1),
  defaultBranch: z.string().min(1),
  visibility: z.enum(['public', 'private']),
  pushedAt: z.string().nullable(),
});
export type GithubInstallationRepo = z.infer<typeof GithubInstallationRepo>;

export const GithubInstallationRepoList = z.object({
  items: z.array(GithubInstallationRepo),
});
export type GithubInstallationRepoList = z.infer<typeof GithubInstallationRepoList>;
