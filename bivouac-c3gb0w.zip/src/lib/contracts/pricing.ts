// @polsia:user-owned — shared zod contract for the public pricing surface.
//
// Client-importable: zod only, no server-only imports. The same schema is
// parsed by the page island, the route handler, and any future admin reader.

import { z } from 'zod';

export const PricingPlanSlug = z.enum(['free', 'starter', 'team', 'enterprise']);
export type PricingPlanSlug = z.infer<typeof PricingPlanSlug>;

export const PricingFeatureHighlight = z.enum(['autonomous-patch', 'downgrade-as-fix']);
export type PricingFeatureHighlight = z.infer<typeof PricingFeatureHighlight>;

export const PricingFeature = z.object({
  label: z.string().min(1),
  body: z.string().min(1),
  highlight: PricingFeatureHighlight.optional(),
});
export type PricingFeature = z.infer<typeof PricingFeature>;

export const PricingSlaAddon = z.object({
  badge: z.string().min(1),
  tooltip: z.string().min(1),
});
export type PricingSlaAddon = z.infer<typeof PricingSlaAddon>;

export const PricingCtaLabel = z.enum(['Start free', 'Subscribe', 'Talk to sales']);
export type PricingCtaLabel = z.infer<typeof PricingCtaLabel>;

export const PricingPlan = z.object({
  slug: PricingPlanSlug,
  name: z.string().min(1),
  eyebrow: z.string().min(1),
  monthlyPerRepoUsd: z.number().int().min(0),
  includedActiveRepos: z.union([z.number().int().min(1), z.literal('unlimited')]),
  features: z.array(PricingFeature).min(1),
  slaAddons: z.array(PricingSlaAddon),
  ctaLabel: PricingCtaLabel,
  priceFootnote: z.string().min(1),
});
export type PricingPlan = z.infer<typeof PricingPlan>;

export const PricingPlans = z.array(PricingPlan).min(1);
export type PricingPlans = z.infer<typeof PricingPlans>;

// POST /api/checkout input — the planId slug is the only client-trusted field.
// The route handler resolves plan and computes the price server-side.
export const CheckoutSessionCreate = z.object({
  planId: PricingPlanSlug,
});
export type CheckoutSessionCreate = z.infer<typeof CheckoutSessionCreate>;

// Discriminated response on `ok`. The route returns one of three shapes:
//   - { ok: 'checkout', url }       — go to hosted Stripe Checkout
//   - { ok: 'redirect', redirectTo } — go to mailto or /signup
//   - { ok: 'error', error }         — surface in a toast
export const CheckoutResponseCheckout = z.object({
  ok: z.literal('checkout'),
  url: z.string().url(),
});
export const CheckoutResponseRedirect = z.object({
  ok: z.literal('redirect'),
  redirectTo: z.string().min(1),
});
export const CheckoutResponseError = z.object({
  ok: z.literal('error'),
  error: z.string().min(1),
});
export const CheckoutResponse = z.discriminatedUnion('ok', [
  CheckoutResponseCheckout,
  CheckoutResponseRedirect,
  CheckoutResponseError,
]);
export type CheckoutResponse = z.infer<typeof CheckoutResponse>;
