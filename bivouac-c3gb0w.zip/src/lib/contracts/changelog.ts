// @polsia:user-owned — shared zod contract for the public /api/changelog
// resource. Imported by both the route handler (validates before serialising)
// and the ChangelogTimeline client island (parses the JSON response). Keep
// this module zod-only — no server-only imports — so it's safe to import
// from `'use client'` files.
import { z } from 'zod';

export const ChangelogLink = z.object({
  label: z.string().min(1),
  href: z.string().url(),
});

export const ChangelogTag = z.enum(['Hero', 'Pricing', 'Dashboard', 'Content', 'Tooling']);

export const ChangelogEntry = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'must be YYYY-MM-DD'),
  monthBucket: z.string().regex(/^\d{4}-\d{2}$/, 'must be YYYY-MM'),
  tag: ChangelogTag,
  title: z.string(),
  summary: z.string(),
  links: z.array(ChangelogLink).optional(),
});

export const ChangelogList = z.object({
  items: z.array(ChangelogEntry),
});

export type ChangelogLink = z.infer<typeof ChangelogLink>;
export type ChangelogTag = z.infer<typeof ChangelogTag>;
export type ChangelogEntry = z.infer<typeof ChangelogEntry>;
export type ChangelogList = z.infer<typeof ChangelogList>;
