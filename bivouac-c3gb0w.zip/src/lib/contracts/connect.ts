// @polsia:user-owned — shared zod contracts for the GitHub App install handoff.
// The install URL payload and the per-install listing flow through the same
// file so a shape change surfaces as a ZodError, not silent JSON drift.

import { z } from 'zod';

// installation_id / repo id arrive as numeric strings (Prisma BigInt → JSON
// wire-format). Restrict to digit-only so we never feed a malformed id into
// GitHub's endpoint.
const BigIntString = z.string().regex(/^\d+$/, 'expected numeric string');

// /api/connect/install-url → client island. `appId?` is present when the App
// is fully configured (ID + key + slug all present); absence ⇒ render the
// operator-facing "not configured" alert.
export const ConnectInstallUrl = z.object({
  url: z.string().url(),
  appName: z.string().min(1),
  appId: z.string().min(1).optional(),
});
export type ConnectInstallUrl = z.infer<typeof ConnectInstallUrl>;

// /api/connect/installs → confirmation page. One entry per installation
// the calling user owns.
export const ConnectGitHubAccount = z.object({
  login: z.string().min(1),
  type: z.string().min(1),
});
export type ConnectGitHubAccount = z.infer<typeof ConnectGitHubAccount>;

export const ConnectRepo = z.object({
  githubRepoId: BigIntString,
  githubNodeId: z.string().min(1),
  name: z.string().min(1),
  ownerHandle: z.string().min(1),
  defaultBranch: z.string().min(1),
  selectedAt: z.string().nullable(),
});
export type ConnectRepo = z.infer<typeof ConnectRepo>;

export const ConnectInstallationWithRepos = z.object({
  installationId: BigIntString,
  account: ConnectGitHubAccount,
  installedAt: z.string().nullable(),
  repos: z.array(ConnectRepo),
});
export type ConnectInstallationWithRepos = z.infer<typeof ConnectInstallationWithRepos>;

export const ConnectInstallationList = z.object({
  items: z.array(ConnectInstallationWithRepos),
});
export type ConnectInstallationList = z.infer<typeof ConnectInstallationList>;
