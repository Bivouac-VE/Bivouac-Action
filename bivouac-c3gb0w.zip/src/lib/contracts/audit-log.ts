// @polsia:user-owned — shared zod contract for the /dashboard/audit log
// viewer. Single source of truth shared by the /api/audit-log route handler
// AND the client island; a shape change surfaces as a tsc/ZodError, not
// silent JSON drift. Client-importable (zod only — no server-only imports
// here).

import { z } from 'zod';

export const AuditLogSeverityEnum = z.enum(['low', 'medium', 'high', 'critical']);
export type AuditLogSeverity = z.infer<typeof AuditLogSeverityEnum>;

// Brief's wording for the action column: AUTO_MERGE→auto-merged,
// MANUAL_REVIEW→paged, BLOCKED→declined, attestation export→exported.
// `downgraded` is derived in the business layer (toVersion < fromVersion on
// an AUTO_MERGE row). `exported` is recorded when a user downloads a signed
// attestation bundle so the /dashboard/audit page can show that the action
// happened. Persisted mergeDecision enum stays uppercase (cron + existing
// fixtures); the business layer maps and the UI shows the short noun.
export const AuditLogActionEnum = z.enum([
  'auto-merged',
  'downgraded',
  'paged',
  'declined',
  'exported',
]);
export type AuditLogAction = z.infer<typeof AuditLogActionEnum>;

// Brief's wording for "agent or attributed to a human". Persisted as plain
// string with default `"agent"` so cron rows (and any legacy fixture rows)
// read as Agent without a backfill.
export const AuditLogActorEnum = z.enum(['agent', 'human']);
export type AuditLogActor = z.infer<typeof AuditLogActorEnum>;

// Event kind -- covers CVE rows, upstream-breaking-change rows that surface
// as <package> ⚠ Breaking in the table, AND attestation-export rows when a
// user downloads a signed bundle from /dashboard/attest.
export const AuditLogEventKindEnum = z.enum(['CVE', 'BREAKING', 'ATTESTATION']);
export type AuditLogEventKind = z.infer<typeof AuditLogEventKindEnum>;

export const AuditLogRow = z.object({
  id: z.string(),
  createdAt: z.string(),
  cveId: z.string().nullable(),
  packageName: z.string().min(1),
  fromVersion: z.string().min(1),
  toVersion: z.string().min(1),
  severity: AuditLogSeverityEnum,
  testOutcome: z.enum(['PASSED', 'FAILED', 'ERRORED', 'PENDING']),
  mergeDecision: z.enum(['AUTO_MERGE', 'MANUAL_REVIEW', 'BLOCKED']),
  action: AuditLogActionEnum,
  actor: AuditLogActorEnum,
  eventKind: AuditLogEventKindEnum,
  repo: z.string().min(1),
  prUrl: z.string().url(),
  // ATTESTATION rows carry an additional payload the renderer uses to show
  // quarter/format/hash AND to wire the re-export link back to
  // /dashboard/attest with the same repo + quarter picker state. For triage
  // rows (CVE / BREAKING) the field is null.
  details: z
    .object({
      quarter: z.string(),
      repoId: z.string(),
      ownerHandle: z.string(),
      repoName: z.string(),
      format: z.string(),
      bundleHash: z.string(),
    })
    .nullable()
    .optional(),
});
export type AuditLogRow = z.infer<typeof AuditLogRow>;

export const AuditLogList = z.object({
  items: z.array(AuditLogRow),
  total: z.number().int().nonnegative(),
});
export type AuditLogList = z.infer<typeof AuditLogList>;

// URL-search-param shape for the filter controls. Values are intentionally
// permissive so an empty/unknown query string falls through to a default.
// `repo` is an array of slugs so a user can narrow to multiple connected
// repos at once. `null` means "no filter".
export const AuditLogFilter = z.object({
  repo: z.array(z.string().min(1)).nullable(),
  cveId: z.string().nullable(),
  from: z.string().nullable(),
  to: z.string().nullable(),
  severity: AuditLogSeverityEnum.nullable(),
  action: AuditLogActionEnum.nullable(),
  actor: AuditLogActorEnum.nullable(),
  limit: z.number().int().positive(),
});
export type AuditLogFilter = z.infer<typeof AuditLogFilter>;
