// @polsia:user-owned — shared zod contracts for /settings/policy-packs.
// Single source of truth shared between the route handlers
// (/api/policy-packs, /api/repo-policies/apply) and the client island. Shape
// drift surfaces as a ZodError instead of silent JSON drift. Client-importable
// (zod only — no server-only imports here).

import { z } from 'zod';

export const ScopeToggles = z.object({
  lockfileUpdates: z.enum(['strict', 'cve-only', 'asis']),
  dependencyScope: z.enum(['all', 'direct', 'direct+transitive']),
  advisoryScope: z.enum(['nvd', 'ghsa', 'nvd+ghsa']),
});
export type ScopeToggles = z.infer<typeof ScopeToggles>;

export const PageHumanRule = z.enum([
  'high-severity-cve',
  'license-change',
  'public-api-break',
  'security-sensitive',
  'red-build',
  'major-bump',
  'minor-bump',
]);
export type PageHumanRule = z.infer<typeof PageHumanRule>;

export const PolicyPack = z.object({
  slug: z.string(),
  title: z.string(),
  description: z.string(),
  scopeToggles: ScopeToggles,
  autoMergeThreshold: z.string(),
  pageHumanWhen: z.array(PageHumanRule),
});
export type PolicyPack = z.infer<typeof PolicyPack>;

export const PolicyPackList = z.object({ items: z.array(PolicyPack) });
export type PolicyPackList = z.infer<typeof PolicyPackList>;

export const ApplyPolicyInput = z.object({
  packSlug: z.string().min(1),
  repoIds: z.array(z.string().min(1)).min(1),
});
export type ApplyPolicyInput = z.infer<typeof ApplyPolicyInput>;

export const ApplyPolicyApplied = z.object({
  repoId: z.string(),
  packSlug: z.string(),
  packTitle: z.string(),
});
export type ApplyPolicyApplied = z.infer<typeof ApplyPolicyApplied>;

export const ApplyPolicyResult = z.object({
  applied: z.array(ApplyPolicyApplied),
});
export type ApplyPolicyResult = z.infer<typeof ApplyPolicyResult>;
