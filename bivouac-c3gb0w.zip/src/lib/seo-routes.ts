// @polsia:user-owned — programmatic SEO URLs for /sitemap.xml: dynamic [slug]
// pages (e.g. /champions/[slug]) that aren't in the nav menu. Edit this file,
// never src/app/sitemap.ts (framework-owned). Return one entry per page with an
// app-absolute `path` ('/...'); may be async to fetch data. Return [] if none.
//
//   export async function seoRoutes(): Promise<SeoRoute[]> {
//     const items = await getItems();
//     return items.map((i) => ({ path: `/items/${i.slug}`, priority: 0.6 }));
//   }
import type { MetadataRoute } from 'next';

/** App-absolute `path` (e.g. /items/aatrox) + optional Next sitemap fields. */
export type SeoRoute = { path: string } & Omit<MetadataRoute.Sitemap[number], 'url'>;

export async function seoRoutes(): Promise<SeoRoute[]> {
  // Pull published blog post slugs. `publishedAt: { not: null }` mirrors the
  // public listing filter at /api/posts — drafts never appear in the sitemap.
  //
  // The build prerenders /sitemap.xml from this function. On a deploy where
  // the Post table hasn't been pushed yet, the query raises P2021 (which we
  // surface as a missing table); without this guard the build fails. We
  // treat P2021 the same as "no published posts" — list-only routes still
  // ship, the blog index page links to the seeded posts at runtime.
  let posts: { slug: string; publishedAt: Date | null }[] = [];
  try {
    const { prisma } = await import('@/lib/db');
    posts = await prisma.post.findMany({
      where: { publishedAt: { not: null } },
      select: { slug: true, publishedAt: true },
    });
  } catch (error) {
    const code = (error as { code?: string } | null)?.code;
    if (code !== 'P2021') throw error; // anything other than "table missing" is a real bug
  }

  return [
    { path: '/vs/dependabot', priority: 0.6 },
    { path: '/vs/renovate', priority: 0.6 },
    { path: '/vs/snyk-oss', priority: 0.6 },
    { path: '/vs/copilot-autofix', priority: 0.6 },
    { path: '/vs/copilot-coding-agent', priority: 0.6 },
    { path: '/changelog', priority: 0.6 },
    ...posts.map((p) => ({
      path: `/blog/${p.slug}`,
      lastModified: (p.publishedAt ?? new Date(0)).toISOString(),
      priority: 0.6,
    })),
  ];
}
