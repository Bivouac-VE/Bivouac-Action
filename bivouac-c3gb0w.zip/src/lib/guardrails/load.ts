// @polsia:user-owned — server-only reader for the per-caller auto-merge
// policy. Subsequent agent actions (the agent/triage layer that decides
// whether to auto-merge a given diff) call this to fetch the authoritative
// row for a user. The /api/policy GET/PATCH and the dashboard form island
// do NOT call this — they read/write via the dedicated data plane. This
// helper exists so agent code has a single, typed read API that returns the
// same zod-parsed shape the UI sees, and so it can't accidentally bypass the
// contract by hand-reading Prisma.
//
// Returns AUTO_MERGE_DEFAULTS if no row exists yet — callers always get a
// fully-populated shape (zod-validated) regardless of seed state.

import 'server-only';
import type { z } from 'zod';
import {
  AUTO_MERGE_DEFAULTS,
  AutoMergePolicy as AutoMergePolicySchema,
  parseAutoMergePolicyRow,
} from '@/lib/contracts/auto-merge-policy';
import { prisma } from '@/lib/db';

type AutoMergePolicy = z.infer<typeof AutoMergePolicySchema>;

export async function loadPolicyForUser(userId: string): Promise<AutoMergePolicy> {
  if (!userId) {
    return defaultsPolicy(userId);
  }

  const row = await prisma.autoMergePolicy.findUnique({ where: { userId } });
  if (!row) {
    return defaultsPolicy(userId);
  }
  return parseAutoMergePolicyRow(row);
}

function defaultsPolicy(userId: string): AutoMergePolicy {
  return AutoMergePolicySchema.parse({
    userId,
    ...AUTO_MERGE_DEFAULTS,
    updatedAt: new Date(0).toISOString(),
  });
}
