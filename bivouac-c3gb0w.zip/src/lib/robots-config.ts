// @polsia:user-owned — crawl rules merged into /robots.txt (robots.ts is
// framework-owned). Applied only when the deploy is indexable (SEO_INDEXABLE).
// Public marketing routes (/, /pricing, /blog, /vs, /triage) stay crawlable;
// authenticated / internal paths are disallowed so crawlers don't burn budget
// on auth walls, route handlers, or compliance-only surfaces.
export const robotsConfig = {
  /** Paths to keep out of search even when indexable. */
  disallow: [
    '/api',
    '/dashboard',
    '/settings',
    '/connect',
    '/attestation',
    '/insights',
    '/patches',
  ] as string[],
  /** Optional crawl-delay (seconds) for the default user-agent. */
  crawlDelay: undefined as number | undefined,
};
