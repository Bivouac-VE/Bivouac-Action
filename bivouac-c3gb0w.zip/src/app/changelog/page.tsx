// @polsia:user-owned — Public /changelog route. Server Component: the page
// exports per-page metadata only and renders the `<ChangelogTimeline/>` client
// island that fetches through /api/changelog. No data fetch in the render
// layer — no `fetch`, no Prisma, no `groupByMonthDescending` call.

import { pageMetadata } from '@/lib/seo-metadata';
import { siteName } from '@/lib/site';
import { ChangelogTimeline } from './ChangelogTimeline';

export const metadata = pageMetadata({
  title: 'Changelog',
  description: `Every shipping change to ${siteName} — features, fixes, and improvements — grouped by month so prospects can see velocity and existing users can find what's new.`,
  path: '/changelog',
});

export default function ChangelogPage() {
  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Shipped recently</p>
        <h1 className="font-display text-h1 text-balance text-foreground">The Bivouac changelog</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Every feature, fix, and infrastructure change shipped recently — for prospects evaluating
          velocity, and for existing users looking for what just landed. Grouped by month in
          reverse-chronological order.
        </p>
      </header>

      <ChangelogTimeline />
    </main>
  );
}
