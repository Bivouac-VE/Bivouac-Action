// @polsia:user-owned — /changelog client island. Fetches the public
// /api/changelog payload through apiFetch + the shared zod contract, then
// groups entries by month bucket and renders one section per bucket. Lives in
// a client component so the Server Component can stay metadata-only (the data
// plane rule keeps fetching off the page body).
'use client';

import { useEffect, useMemo, useState } from 'react';
import { ChangelogEntryCard } from '@/components/custom/changelog/changelog-entry';
import { apiFetch } from '@/lib/api-client';
import { type ChangelogEntry, ChangelogList } from '@/lib/contracts/changelog';
import { type ChangelogMonthBucket, groupByMonthDescending } from '../../../content/changelog';

type State =
  | { kind: 'loading' }
  | { kind: 'ready'; entries: ChangelogEntry[] }
  | { kind: 'empty' }
  | { kind: 'error'; message: string };

export function ChangelogTimeline() {
  const [state, setState] = useState<State>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch('/api/changelog', { schema: ChangelogList })
      .then((data) => {
        if (!active) return;
        setState(
          data.items.length === 0 ? { kind: 'empty' } : { kind: 'ready', entries: data.items },
        );
      })
      .catch(() => {
        if (!active) return;
        setState({ kind: 'error', message: 'Could not load the changelog. Please try again.' });
      });
    return () => {
      active = false;
    };
  }, []);

  // Memoize the projection so a re-render that doesn't change `entries` doesn't
  // rebuild the month-bucket array on every keystroke or theme change.
  const buckets = useMemo<ChangelogMonthBucket[]>(
    () => (state.kind === 'ready' ? groupByMonthDescending(state.entries) : []),
    [state],
  );

  if (state.kind === 'loading') {
    return (
      <p className="text-body text-muted-foreground" aria-live="polite">
        Loading…
      </p>
    );
  }

  if (state.kind === 'error') {
    return (
      <p className="text-body text-destructive" role="alert">
        {state.message}
      </p>
    );
  }

  if (state.kind === 'empty') {
    return (
      <p className="text-body text-muted-foreground">Nothing shipped yet — check back soon.</p>
    );
  }

  return (
    <div className="flex flex-col gap-10">
      {buckets.map((bucket) => (
        <section key={bucket.monthBucket} className="flex flex-col gap-4">
          <h2 className="font-display text-h3 tracking-tight text-foreground">{bucket.label}</h2>
          <ol className="flex flex-col gap-3">
            {bucket.entries.map((entry) => (
              <li key={`${entry.date}-${entry.title}`}>
                <ChangelogEntryCard entry={entry} />
              </li>
            ))}
          </ol>
        </section>
      ))}
    </div>
  );
}
