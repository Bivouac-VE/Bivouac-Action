// @polsia:user-owned — Public /activity route. Server Component that only
// exports per-page metadata + composes the client island; the data fetch
// is done by apiFetch from the <ActivityFeed/> island against the matching
// /api/activity route handler. The page never awaits Prisma / apiFetch —
// that work lives in the island (matches the /api/patches + /api/status
// public-read pattern).

import type { Metadata } from 'next';
import { ActivityFeed } from '@/components/custom/activity/activity-feed';

export const metadata: Metadata = {
  title: 'Activity — live CVE patches',
  description:
    'A reverse-chronological feed of recent agent actions across connected repos: every CVE patch PR, its merged/blocked/paged outcome, the pin it bumped, and the time between detection and merge.',
  alternates: { canonical: '/activity' },
  openGraph: {
    title: 'Activity — live CVE patches · Bivouac',
    description:
      'A live, public feed of recent agent actions across connected repos. Every CVE patch PR, its outcome, and the time between detection and merge — no sign-in required.',
    url: '/activity',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Activity — live CVE patches · Bivouac',
    description:
      'A live, public feed of recent agent actions across connected repos. Every CVE patch PR, its outcome, and the time between detection and merge.',
  },
};

export default function ActivityPage() {
  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Live activity</p>
        <h1 className="font-display text-h1 text-balance text-foreground">
          What the agent did, just now.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          A reverse-chronological feed of every patch PR the agent has opened across connected repos
          — the CVE, the pinned package, the target repo, the time-to-patch, and what happened to
          the PR. No sign-in; reads straight from the same audit log the dashboard uses. Refresh to
          pull the next batch.
        </p>
      </header>

      <ActivityFeed />
    </main>
  );
}
