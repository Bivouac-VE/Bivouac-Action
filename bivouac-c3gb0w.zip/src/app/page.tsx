// @polsia:user-owned — Bivouac landing page served at /. Server Component:
// literal copy + composition; no data fetch in the render layer. The auth-aware
// primary CTA in <LandingHero/> and <LandingFinalCta/> is a tiny client island
// that reads the better-auth session via useSession() and chooses the destination.

import type { Metadata } from 'next';
import { LandingBuyerFaq } from '@/components/custom/landing/landing-buyer-faq';
import { LandingBuyerPersonas } from '@/components/custom/landing/landing-buyer-personas';
import { LandingCapabilityMatrix } from '@/components/custom/landing/landing-capability-matrix';
import { LandingComparison } from '@/components/custom/landing/landing-comparison';
import { LandingComparisonTable } from '@/components/custom/landing/landing-comparison-table';
import { LandingCompliance } from '@/components/custom/landing/landing-compliance';
import { LandingCostComparison } from '@/components/custom/landing/landing-cost-comparison';
import { LandingCveWalkthrough } from '@/components/custom/landing/landing-cve-walkthrough';
import { LandingEarlyAccess } from '@/components/custom/landing/landing-early-access';
import { LandingEscalationGuardrails } from '@/components/custom/landing/landing-escalation-guardrails';
import { LandingFaq } from '@/components/custom/landing/landing-faq';
import { LandingFinalCta } from '@/components/custom/landing/landing-final-cta';
import { LandingHero } from '@/components/custom/landing/landing-hero';
import { LandingHowBivouacWorks } from '@/components/custom/landing/landing-how-bivouac-works';
import { LandingHowItWorks } from '@/components/custom/landing/landing-how-it-works';
import { LandingPricingTease } from '@/components/custom/landing/landing-pricing-tease';
import { LandingTalkToUs } from '@/components/custom/landing/landing-talk-to-us';
import { siteDescription, siteName, siteUrl } from '@/lib/site';

export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  alternates: { canonical: '/' },
  openGraph: {
    title: siteName,
    description: siteDescription,
    url: '/',
    images: [
      {
        url: '/opengraph-image',
        width: 1200,
        height: 630,
        alt: siteName,
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: siteName,
    description: siteDescription,
    images: ['/opengraph-image'],
  },
};

export default function LandingPage() {
  const organizationLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: siteName,
    url: `${siteUrl}/`,
    description: siteDescription,
    logo: `${siteUrl}/icon.svg`,
  };
  const softwareApplicationLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: siteName,
    url: `${siteUrl}/`,
    description:
      'Autonomous pull requests powered by AI agents with built-in CVE detection and breaking-change detection to keep production safe.',
    applicationCategory: 'DeveloperApplication',
    operatingSystem: 'Web',
  };
  return (
    <main className="flex flex-col">
      <script
        type="application/ld+json"
        id="software-application-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand/seo modules and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareApplicationLd) }}
      />
      <script
        type="application/ld+json"
        id="organization-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand/seo modules and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd) }}
      />
      <LandingHero />
      <LandingCveWalkthrough />
      <LandingEscalationGuardrails />
      <LandingCostComparison />
      <LandingBuyerPersonas />
      <LandingComparison />
      <LandingCompliance />
      <LandingFaq />
      <LandingHowItWorks />
      <LandingComparisonTable />
      <LandingHowBivouacWorks />
      <LandingCapabilityMatrix />
      <LandingEarlyAccess />
      <LandingPricingTease />
      <LandingTalkToUs />
      <LandingBuyerFaq />
      <LandingFinalCta />
    </main>
  );
}
