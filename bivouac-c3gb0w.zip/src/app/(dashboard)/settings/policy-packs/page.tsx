// @polsia:user-owned — Server Component for /settings/policy-packs.
//
// Per data-plane rules this page only exports metadata and renders a single
// client island. The island owns the entire fetch (loading/empty/error/data)
// so the page never imports server-only modules (Prisma, next/headers,
// requireAuth) — those live strictly in /api/policy-packs and
// /api/repo-policies/apply.

import type { Metadata } from 'next';
import { PolicyPacksIsland } from '@/components/custom/policy-packs/policy-packs-island';

export const metadata: Metadata = {
  title: 'Policy packs',
  description: 'Reusable triage policies you can apply to one or more repos at once.',
  alternates: { canonical: '/settings/policy-packs' },
  robots: { index: false },
};

export default function PolicyPacksSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <PolicyPacksIsland />
    </div>
  );
}
