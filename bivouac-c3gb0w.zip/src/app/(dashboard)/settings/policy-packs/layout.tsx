// @polsia:user-owned — auth-gated layout for /settings/policy-packs. Mirrors
// /settings/billing and /settings/team: the page is wrapped in the dashboard
// shell so anonymous visitors land on the loading/redirect screen and
// signed-in users see the policy-packs UI inside the chrome.

import type { ReactNode } from 'react';
import { DashboardShell } from '@/components/custom/dashboard/dashboard-shell';

export default function SettingsPolicyPacksLayout({ children }: { children: ReactNode }) {
  return <DashboardShell>{children}</DashboardShell>;
}
