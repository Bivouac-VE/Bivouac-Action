// @polsia:user-owned — Server Component for /settings/team.
//
// Per data-plane rules this page only exports metadata and renders a single
// client island. The island owns the entire fetch (loading/empty/with-plan)
// so the page never imports server-only modules (Prisma, next/headers,
// requireAuth) — those live strictly in /api/team/**.

import type { Metadata } from 'next';
import { TeamSettingsView } from '@/components/team/team-settings-view';

export const metadata: Metadata = {
  title: 'Team',
  description:
    'Manage multi-seat access for your Bivouac team. Invite teammates, change roles, and remove members from your Team or Enterprise plan.',
  alternates: { canonical: '/settings/team' },
  robots: { index: false },
};

export default function TeamSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <TeamSettingsView />
    </div>
  );
}
