// @polsia:user-owned — auth-gated layout for /settings/team. Mirrors
// /settings/billing: the page is wrapped in the dashboard shell so anonymous
// visitors land on the loading/redirect screen and signed-in users see the
// team settings inside the chrome.

import type { ReactNode } from 'react';
import { DashboardShell } from '@/components/custom/dashboard/dashboard-shell';

export default function SettingsTeamLayout({ children }: { children: ReactNode }) {
  return <DashboardShell>{children}</DashboardShell>;
}
