// @polsia:user-owned — Server Component for /settings/billing.
//
// Per data-plane rules this page only exports metadata and renders a single
// client island. The island owns the entire fetch (loading/empty/with-plan/
// error) so the page never imports server-only modules (Prisma, next/headers,
// requireAuth) — those live strictly in /api/billing/**.

import type { Metadata } from 'next';
import { BillingSettingsView } from '@/components/custom/billing/billing-settings-view';

export const metadata: Metadata = {
  title: 'Billing',
  description: 'Switch tiers, manage SLA add-ons, and review your invoice history.',
  alternates: { canonical: '/settings/billing' },
  robots: { index: false },
};

export default function BillingSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <BillingSettingsView />
    </div>
  );
}
