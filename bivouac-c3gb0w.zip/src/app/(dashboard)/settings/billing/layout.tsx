// @polsia:user-owned — auth-gated layout for /settings/billing. Wraps the
// page in the dashboard shell so anonymous visitors land on the loading/redirect
// screen and signed-in users see the settings UI inside the chrome.

import type { ReactNode } from 'react';
import { DashboardShell } from '@/components/custom/dashboard/dashboard-shell';

export default function SettingsBillingLayout({ children }: { children: ReactNode }) {
  return <DashboardShell>{children}</DashboardShell>;
}
