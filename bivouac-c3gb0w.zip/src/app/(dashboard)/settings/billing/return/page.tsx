// @polsia:user-owned — return page after Stripe Checkout.
//
// Server Component: parses session_id + plan + addons from the query string,
// exports metadata, renders the <BillingReturnIsland/> which POSTs
// /api/billing/sync and router.replace('/settings/billing').

import type { Metadata } from 'next';
import { BillingReturnIsland } from '@/components/custom/billing/billing-return-island';

export const metadata: Metadata = {
  title: 'Returning from checkout',
  description: 'Reconciling your Stripe Checkout session against your Bivouac billing plan.',
  alternates: { canonical: '/settings/billing/return' },
  robots: { index: false },
};

function parseAddons(raw: string | undefined): string[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

export default async function BillingReturnPage({
  searchParams,
}: {
  searchParams: Promise<{ session_id?: string; plan?: string; addons?: string }>;
}) {
  const params = await searchParams;
  const sessionId = params.session_id ?? '';
  const plan = params.plan ?? '';
  const addons = parseAddons(params.addons);
  return (
    <div className="flex flex-col gap-section">
      <BillingReturnIsland sessionId={sessionId} plan={plan} addons={addons} />
    </div>
  );
}
