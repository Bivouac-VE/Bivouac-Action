// @polsia:user-owned — Server Component for /dashboard/repos/[id]. Mirrors
// the /dashboard/patches/[id] page shape line-for-line: exports per-page
// metadata (no 'use client' so the metadata export stays valid per POL-2616)
// and delegates the data fetch + render to the <RepoDetail/> client island.
// The page itself never awaits Prisma / apiFetch / server-only modules —
// that's the island's job. The dashboard-shell that wraps every
// /(dashboard)/dashboard/** route already redirects unauthenticated users
// to /login, so no per-page gate is needed here.

import type { Metadata } from 'next';
import { RepoDetail } from '@/components/custom/dashboard/repo-detail';

export const metadata: Metadata = {
  title: 'Repository — Dashboard',
  description:
    "One connected repository's recent patches, activity feed, and detection settings — the per-repo drilldown from the dashboard repositories list.",
  alternates: { canonical: '/dashboard/repos' },
};

export default async function DashboardRepoDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <main className="container-page flex flex-col gap-section py-section">
      <RepoDetail id={id} />
    </main>
  );
}
