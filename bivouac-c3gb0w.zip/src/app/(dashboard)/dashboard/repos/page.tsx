// @polsia:user-owned — Server Component for /dashboard/repos. Exposes
// per-page metadata (no 'use client' so the metadata export stays valid
// per POL-2616) and renders the <ReposList/> client island which owns
// the fetch + loading/error/empty branches.

import type { Metadata } from 'next';
import { ReposList } from '@/components/custom/dashboard/repos-list';

export const metadata: Metadata = {
  title: 'Repositories — Bivouac dashboard',
  description:
    'Every GitHub repository you have connected to Bivouac, with install health, most-recent agent activity, and live triage status.',
  alternates: { canonical: '/dashboard/repos' },
};

export default function DashboardReposPage() {
  return (
    <div className="flex flex-col gap-section">
      <ReposList />
    </div>
  );
}
