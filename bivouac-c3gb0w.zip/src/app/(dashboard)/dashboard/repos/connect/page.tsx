// @polsia:user-owned — Server Component for /dashboard/repos/connect. The
// second leg of the connect-a-repo journey: after the GitHub App install
// completes, this page lists the repos granted access and lets the user
// toggle the enabled set before persisting. Renders the metadata-exporting
// wrapper + the <RepoSelectCard/> client island; the (dashboard)/dashboard/
// layout wraps the whole tree in <DashboardShell/> automatically.

import type { Metadata } from 'next';
import { RepoSelectCard } from '@/components/custom/dashboard/repo-select-card';

export const metadata: Metadata = {
  title: 'Pick repositories — Bivouac dashboard',
  description:
    'Pick which repositories the freshly-completed Bivouac GitHub App install should put on watch. Toggle the enabled set, then continue to the dashboard.',
  alternates: { canonical: '/dashboard/repos/connect' },
  // Confirmation step in a per-installation onboarding flow — transient and
  // not useful in a search index.
  robots: { index: false, follow: false },
};

export default function DashboardReposConnectPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Onboarding</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Pick the repositories to put on watch.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          GitHub just handed the Bivouac App access to the repos below. Toggle any off you
          don&apos;t want on watch, then continue — Bivouac starts scanning each one on its default
          branch within the next minute.
        </p>
      </header>

      <RepoSelectCard />
    </div>
  );
}
