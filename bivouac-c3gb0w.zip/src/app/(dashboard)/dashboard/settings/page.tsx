// @polsia:user-owned — Server Component for /dashboard/settings. Per the
// data-plane rule: only exports metadata and renders the client island —
// never imports prisma, requireAuth, next/headers, or any server-only
// module.
//
// The dashboard layout at src/app/(dashboard)/dashboard/layout.tsx already
// wraps this page in the auth-gated <DashboardShell/>, so the island lands
// inside the same nav + sign-in surface as the other dashboard pages.

import type { Metadata } from 'next';
import Link from 'next/link';
import { DigestPrefsCard } from '@/components/custom/dashboard/digest-prefs-card';
import { Button } from '@/components/ui/button';

export const metadata: Metadata = {
  title: 'Settings — Dashboard',
  description:
    'Configure your dashboard preferences: opt in or out of the daily digest email that summarises the last 24 hours of patch activity for your connected repositories.',
  alternates: { canonical: '/dashboard/settings' },
  robots: { index: false },
};

export default function DashboardSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Settings</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Dashboard settings</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Control how Bivouac keeps you in the loop. The daily digest lands each morning at
          08:00&nbsp;UTC and summarises the previous 24 hours of patch activity — auto-merged
          patches, CVE responses opened, and any human pages or overrides — with per-repo tallies
          and a deep link into the day’s attestation records.
        </p>
      </header>

      <DigestPrefsCard />

      <section
        aria-labelledby="webhook-delivery-link"
        className="flex flex-col gap-3 rounded-lg border border-border/70 bg-muted/20 px-4 py-5 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex flex-col gap-1">
          <h2 id="webhook-delivery-link" className="text-base font-semibold text-foreground">
            Webhook delivery
          </h2>
          <p className="text-sm text-muted-foreground">
            Mirror the daily digest to a Slack-compatible URL — POST the same JSON summary payload
            to your endpoint with HMAC signing, a canary test ping, and a delivery log for audit.
          </p>
        </div>
        <div className="shrink-0">
          <Button asChild variant="outline" size="sm">
            <Link href="/dashboard/settings/webhooks">Configure webhook</Link>
          </Button>
        </div>
      </section>

      <section
        aria-labelledby="integrations-link"
        className="flex flex-col gap-3 rounded-lg border border-border/70 bg-muted/20 px-4 py-5 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex flex-col gap-1">
          <h2 id="integrations-link" className="text-base font-semibold text-foreground">
            Integrations
          </h2>
          <p className="text-sm text-muted-foreground">
            Pipe alerts into your on-call surface — Slack incoming-webhook or PagerDuty Events API
            v2. Set a team-wide default for one or both providers and override it for a specific
            repo when only some pages should land in a side channel.
          </p>
        </div>
        <div className="shrink-0">
          <Button asChild variant="outline" size="sm">
            <Link href="/dashboard/settings/integrations">Configure integrations</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
