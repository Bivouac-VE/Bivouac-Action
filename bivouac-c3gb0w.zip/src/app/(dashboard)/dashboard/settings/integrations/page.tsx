// @polsia:user-owned — Server Component for /dashboard/settings/integrations.
// Per the data-plane rule: only exports `metadata` and renders the client
// island — never imports prisma, requireAuth, next/headers, or any server-
// only module. Admin gating lives inside the API handlers that back the
// island; non-admin visitors will hit 403s on every fetch and the island
// renders an "Admin only" state.

import type { Metadata } from 'next';
import { IntegrationsSettings } from '@/components/custom/dashboard/integrations-settings';

export const metadata: Metadata = {
  title: 'Integrations — Settings',
  description:
    'Configure Slack incoming-webhook or PagerDuty Events API v2 alerting integrations for your team. Override the default per repository. Includes a manual test notification and a per-integration delivery log.',
  alternates: { canonical: '/dashboard/settings/integrations' },
  robots: { index: false },
};

export default function IntegrationsSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Settings · Integrations</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Integrations</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Pipe alerts into your on-call surface — Slack incoming-webhook or PagerDuty Events API v2
          — as soon as the agent fires a notification. Set a team-wide default for one or both
          providers, then override it for a specific repository when only some pages should land in
          a side channel. Hit <em>Send test notification</em> on a saved integration to confirm
          delivery end-to-end.
        </p>
      </header>
      <IntegrationsSettings />
    </div>
  );
}
