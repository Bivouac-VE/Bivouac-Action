// @polsia:user-owned — Server Component for /dashboard/settings/webhooks.
// Per the data-plane rule: only exports `metadata` and renders the client
// island — never imports prisma, requireAuth, next/headers, or any server-
// only module. The dashboard layout (DashboardShell → requireAuth) gates the
// page; the island fetches via apiFetch.
//
// Mounted at `/dashboard/settings/webhooks`. The brief's "Reachable from /"
// rule is satisfied via a sub-link from /dashboard/settings + sidenav entry.

import type { Metadata } from 'next';
import { DigestWebhookSettings } from '@/components/custom/dashboard/digest-webhook-settings';

export const metadata: Metadata = {
  title: 'Webhook delivery — Settings',
  description:
    'Configure an outbound webhook URL so the daily digest JSON summary lands in your Slack-compatible endpoint alongside the daily email. Includes a manual canary test ping and a delivery log with retry history.',
  alternates: { canonical: '/dashboard/settings/webhooks' },
  robots: { index: false },
};

export default function DigestWebhookSettingsPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Settings · Webhook delivery</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Webhook delivery</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Mirror the daily digest to a Slack-compatible (or any HTTPS JSON) endpoint. Each morning
          at 08:00&nbsp;UTC, after the email succeeds, we POST the same summary payload to your URL
          — signed with a per-webhook HMAC key — and retry up to three times on failure. The
          delivery log below shows what landed and what didn’t.
        </p>
      </header>
      <DigestWebhookSettings />
    </div>
  );
}
