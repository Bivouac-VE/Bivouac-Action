// @polsia:user-owned — Server Component for /dashboard/patches/[id]. Exports
// per-page metadata (since 'use client' would invalidate the metadata export)
// and delegates the data fetch + render to the <PatchDetail/> client island.
// The page never awaits Prisma / apiFetch — that's the island's job. The
// dashboard-shell that wraps every /(dashboard)/dashboard/** route already
// redirects unauthenticated users to /login, so no per-page gate needed.

import type { Metadata } from 'next';
import { PatchDetail } from '@/components/custom/patches/patch-detail';

export const metadata: Metadata = {
  title: 'Patch',
  description:
    'One agent-opened patch PR end-to-end: title, target repo, linked CVE, severity, the list of files with per-file unified diffs, passing/failing test counts, merge state, and the rationale behind the merge decision.',
  alternates: { canonical: '/dashboard/patches' },
};

export default async function DashboardPatchDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <main className="container-page flex flex-col gap-6 py-section">
      <PatchDetail id={id} />
    </main>
  );
}
