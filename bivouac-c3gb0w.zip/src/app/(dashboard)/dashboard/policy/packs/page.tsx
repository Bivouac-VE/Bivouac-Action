// @polsia:user-owned — Server Component for /dashboard/policy/packs. Per the
// data-plane rule: only exports `metadata` and renders the client island —
// never imports prisma, next/headers, requireAuth, or any server-only module.
// The parent (dashboard)/dashboard/layout.tsx wraps this in <DashboardShell/>.

import type { Metadata } from 'next';
import { PolicyPacksMultiIsland } from '@/components/custom/dashboard/policy-packs-multi-island';

export const metadata: Metadata = {
  title: 'Multi-repo policy packs — Dashboard',
  description:
    'Apply a starter policy pack across your connected repos in one click: Monorepo for single-repo CI-matrix alignment, Microservices fleet for uniform severity and paging rules.',
  alternates: { canonical: '/dashboard/policy/packs' },
};

export default function DashboardPolicyPacksPage() {
  return <PolicyPacksMultiIsland />;
}
