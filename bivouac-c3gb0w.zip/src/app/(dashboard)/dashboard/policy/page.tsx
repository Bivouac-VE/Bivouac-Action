// @polsia:user-owned — Server Component for /dashboard/policy. Per the data-plane
// rule: only exports `metadata` and renders the client island — never imports
// prisma, requireAuth, next/headers, or any server-only module.

import type { Metadata } from 'next';
import { AutoMergePolicyForm } from '@/components/custom/dashboard/auto-merge-policy-form';

export const metadata: Metadata = {
  title: 'Auto-merge policy — Dashboard',
  description:
    'Configure how aggressively Bivouac merges for the repositories on watch: trigger scope, CVSS floor, and human-page edge cases.',
  alternates: { canonical: '/dashboard/policy' },
};

export default function DashboardPolicyPage() {
  return <AutoMergePolicyForm />;
}
