// @polsia:user-owned — Server Component for /dashboard/audit. Exports
// per-page metadata (so the SEO template still resolves) and delegates the
// data fetch + filter UI to the <AuditLogView/> client island. The page
// itself never awaits Prisma / apiFetch — that's the island's job.

import type { Metadata } from 'next';
import { AuditLogView } from '@/components/custom/audit/audit-log-view';

export const metadata: Metadata = {
  title: 'Audit log',
  description:
    'Every patch event for the connected repositories: detected advisory, opened patch, test result, merge decision — including who took the action, the agent or a paged reviewer. Filter by repo, CVE id, date range, severity, action, or actor, and export the current view as CSV for SOC 2 / NIS2 / CRA evidence flows.',
  alternates: { canonical: '/dashboard/audit' },
};

export default function AuditPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Audit</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Triage audit log</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Every event recorded for your connected repositories: advisory detected, patch opened,
          test run, and the merge decision that followed — whether the agent took the call or it was
          attributed to a human. Filter the set and download it as CSV when you need to share the
          trail with auditors.
        </p>
      </header>

      <AuditLogView />
    </div>
  );
}
