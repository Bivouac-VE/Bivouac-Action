// @polsia:user-owned — /dashboard/audit layout. Wraps the page in the
// auth-gated dashboard shell so the filter controls, table, and CTA all
// arrive on the same authed chrome as /dashboard, /dashboard/repos, and
// /dashboard/policy.

import type { ReactNode } from 'react';
import { DashboardShell } from '@/components/custom/dashboard/dashboard-shell';

export default function AuditLayout({ children }: { children: ReactNode }) {
  return <DashboardShell>{children}</DashboardShell>;
}
