// @polsia:user-owned — client island for /dashboard/attest. Owns:
//  - repo + quarter picker state (the parent page stays a Server Component
//    that only exports `metadata`)
//  - the /api/attestation/{repos,quarters,preview} fetches with zod-validated
//    contracts from @/lib/contracts/{attestation,repos}
//  - a tokened re-fetch when (repoId, quarter) changes so a late-arriving
//    stale preview never overwrites a fresh one
//  - the rendered toolbar slots + summary view + "Generate JSON / Generate
//    PDF" anchor buttons (target=_blank so the GET triggers a download)
//  - pending / error / empty branches (no repos connected, no quarters,
//    preview failed)
//
// The page itself stays a Server Component that exports metadata only.

'use client';

import { AlertTriangle, Download, FileJson, GitBranch, RefreshCcw } from 'lucide-react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AttestationPreviewToolbar } from '@/components/custom/attestation/AttestationPreviewToolbar';
import { AttestationSummaryView } from '@/components/custom/attestation/AttestationSummary';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { apiFetch } from '@/lib/api-client';
import {
  type AttestationSummary,
  AttestationSummary as AttestationSummarySchema,
  type QuarterId,
  QuarterList,
} from '@/lib/contracts/attestation';
import { type Repo, RepoList } from '@/lib/contracts/repos';

type ReposState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'ready'; data: Repo[] }
  | { status: 'error'; message: string };

type QuartersState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'ready'; items: QuarterId[] }
  | { status: 'error'; message: string };

type PreviewState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'ready'; data: AttestationSummary }
  | { status: 'error'; message: string };

const ALL_VALUE = '__all__';

function buildExportHref(repoId: string, quarter: QuarterId, format: 'json' | 'pdf'): string {
  const params = new URLSearchParams({ repoId, quarter, format });
  return `/api/attestation/export?${params.toString()}`;
}

function PreviewError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Alert variant="destructive" className="border-destructive/40">
      <AlertTriangle className="size-4" aria-hidden="true" />
      <AlertTitle>Could not load the attestation preview.</AlertTitle>
      <AlertDescription>
        {message}{' '}
        <button
          type="button"
          onClick={onRetry}
          className="underline decoration-dotted underline-offset-4 hover:text-foreground"
        >
          Retry
        </button>
      </AlertDescription>
    </Alert>
  );
}

function PickerError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Alert variant="destructive" className="border-destructive/40">
      <AlertTriangle className="size-4" aria-hidden="true" />
      <AlertTitle>Could not load attestation data.</AlertTitle>
      <AlertDescription>
        {message}{' '}
        <button
          type="button"
          onClick={onRetry}
          className="underline decoration-dotted underline-offset-4 hover:text-foreground"
        >
          Retry
        </button>
      </AlertDescription>
    </Alert>
  );
}

function EmptyReposState() {
  return (
    <div className="flex flex-col gap-3 rounded-md border border-dashed border-border/70 bg-card/60 p-6">
      <div className="flex items-center gap-2">
        <GitBranch aria-hidden="true" className="size-4 text-muted-foreground" />
        <p className="text-sm font-medium text-foreground">No repositories connected.</p>
      </div>
      <p className="text-sm text-muted-foreground">
        Connect a GitHub repository first, then come back to export a quarterly attestation bundle.{' '}
        <Button asChild variant="link" size="sm" className="px-0">
          <Link href="/dashboard/repos">Connect a repository</Link>
        </Button>
      </p>
    </div>
  );
}

function PreviewSkeleton() {
  return (
    <div
      className="flex flex-col gap-3 rounded-md border border-border/70 bg-card/80 p-5"
      aria-busy="true"
    >
      <p className="text-sm text-muted-foreground">Assembling attestation preview…</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-24 animate-pulse rounded-md border border-border/60 bg-muted/40"
          />
        ))}
      </div>
    </div>
  );
}

export function AttestationBoard() {
  const searchParams = useSearchParams();
  const initialRepoId = searchParams.get('repoId') ?? '';
  const initialQuarter = searchParams.get('quarter') ?? '';

  const [reposState, setReposState] = useState<ReposState>({ status: 'idle' });
  const [quartersState, setQuartersState] = useState<QuartersState>({ status: 'idle' });
  const [previewState, setPreviewState] = useState<PreviewState>({ status: 'idle' });

  const [selectedRepoId, setSelectedRepoId] = useState<string>(initialRepoId);
  const [selectedQuarter, setSelectedQuarter] = useState<string>(initialQuarter);

  const previewTokenRef = useRef(0);

  const loadRepos = useCallback(async () => {
    setReposState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/attestation/repos', { schema: RepoList });
      setReposState({ status: 'ready', data: data.items });
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'Could not load repositories.';
      setReposState({ status: 'error', message: reason });
    }
  }, []);

  const loadQuarters = useCallback(async () => {
    setQuartersState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/attestation/quarters', { schema: QuarterList });
      const items = data.items as QuarterId[];
      setQuartersState({ status: 'ready', items });
      setSelectedQuarter((prev) =>
        prev.length > 0 && items.includes(prev as QuarterId) ? prev : (items[0] ?? ''),
      );
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'Could not load quarters.';
      setQuartersState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void loadRepos();
    void loadQuarters();
  }, [loadRepos, loadQuarters]);

  useEffect(() => {
    if (reposState.status !== 'ready') return;
    const has = reposState.data.some((r) => r.id === selectedRepoId);
    if (!has && reposState.data.length > 0) {
      const first = reposState.data[0];
      if (first) setSelectedRepoId(first.id);
    }
  }, [reposState, selectedRepoId]);

  const selectedQuarterTyped = useMemo<QuarterId | ''>(() => {
    if (selectedQuarter.length === 0) return '';
    return selectedQuarter as QuarterId;
  }, [selectedQuarter]);

  const readyForPreview = selectedRepoId.length > 0 && selectedQuarterTyped.length > 0;

  const runPreview = useCallback(async () => {
    if (!readyForPreview) {
      setPreviewState({ status: 'idle' });
      return;
    }
    const myToken = ++previewTokenRef.current;
    setPreviewState({ status: 'loading' });
    try {
      const data = await apiFetch<AttestationSummary>('/api/attestation/preview', {
        schema: AttestationSummarySchema,
        method: 'POST',
        body: JSON.stringify({ repoId: selectedRepoId, quarter: selectedQuarterTyped }),
      });
      if (previewTokenRef.current !== myToken) return;
      setPreviewState({ status: 'ready', data });
    } catch (err) {
      if (previewTokenRef.current !== myToken) return;
      const reason = err instanceof Error ? err.message : 'Could not load the attestation preview.';
      setPreviewState({ status: 'error', message: reason });
    }
  }, [readyForPreview, selectedRepoId, selectedQuarterTyped]);

  useEffect(() => {
    void runPreview();
  }, [runPreview]);

  const canDownload = readyForPreview && previewState.status === 'ready';
  const jsonHref = canDownload
    ? buildExportHref(selectedRepoId, selectedQuarterTyped as QuarterId, 'json')
    : '#';
  const pdfHref = canDownload
    ? buildExportHref(selectedRepoId, selectedQuarterTyped as QuarterId, 'pdf')
    : '#';

  const repos = reposState.status === 'ready' ? reposState.data : ([] as Repo[]);
  const reposEmpty = reposState.status === 'ready' && repos.length === 0;
  const quarters = quartersState.status === 'ready' ? quartersState.items : [];
  const quartersEmpty = quartersState.status === 'ready' && quarters.length === 0;

  return (
    <div className="flex flex-col gap-section">
      <AttestationPreviewToolbar
        repoSlot={
          <Select
            value={selectedRepoId.length > 0 ? selectedRepoId : ALL_VALUE}
            onValueChange={(value) => setSelectedRepoId(value === ALL_VALUE ? '' : value)}
            disabled={reposState.status !== 'ready'}
          >
            <SelectTrigger id="attestation-repo" aria-label="Repository">
              <SelectValue
                placeholder={
                  reposState.status === 'loading'
                    ? 'Loading repositories…'
                    : reposState.status === 'idle'
                      ? 'Loading…'
                      : 'Select a repository'
                }
              />
            </SelectTrigger>
            <SelectContent>
              {repos.length > 0 ? (
                repos.map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    {r.ownerHandle}/{r.name}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value={ALL_VALUE} disabled>
                  {reposState.status === 'loading' ? 'Loading…' : 'No repositories'}
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        }
        quarterSlot={
          <Select
            value={selectedQuarter.length > 0 ? selectedQuarter : ALL_VALUE}
            onValueChange={(value) => setSelectedQuarter(value === ALL_VALUE ? '' : value)}
            disabled={quartersState.status !== 'ready'}
          >
            <SelectTrigger id="attestation-quarter" aria-label="Quarter">
              <SelectValue
                placeholder={
                  quartersState.status === 'loading'
                    ? 'Loading quarters…'
                    : quartersState.status === 'idle'
                      ? 'Loading…'
                      : 'Select a quarter'
                }
              />
            </SelectTrigger>
            <SelectContent>
              {quarters.length > 0 ? (
                quarters.map((q) => (
                  <SelectItem key={q} value={q}>
                    {q}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value={ALL_VALUE} disabled>
                  {quartersState.status === 'loading' ? 'Loading…' : 'No quarters'}
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        }
        actionSlot={
          <div className="flex flex-wrap gap-2">
            <Button asChild size="default" variant="outline" className="gap-1.5">
              <Link
                href={jsonHref}
                target="_blank"
                rel="noopener"
                aria-disabled={!canDownload}
                tabIndex={canDownload ? 0 : -1}
                onClick={(event) => {
                  if (!canDownload) event.preventDefault();
                }}
              >
                <FileJson aria-hidden="true" className="size-4" />
                Generate JSON
              </Link>
            </Button>
            <Button asChild size="default" variant="outline" className="gap-1.5">
              <Link
                href={pdfHref}
                target="_blank"
                rel="noopener"
                aria-disabled={!canDownload}
                tabIndex={canDownload ? 0 : -1}
                onClick={(event) => {
                  if (!canDownload) event.preventDefault();
                }}
              >
                <Download aria-hidden="true" className="size-4" />
                Generate PDF
              </Link>
            </Button>
            <Button
              type="button"
              size="default"
              variant="ghost"
              className="gap-1.5"
              disabled={!readyForPreview || previewState.status === 'loading'}
              onClick={() => {
                void runPreview();
              }}
            >
              <RefreshCcw aria-hidden="true" className="size-4" />
              Refresh
            </Button>
          </div>
        }
        errorSlot={
          previewState.status === 'error' ? (
            <PreviewError message={previewState.message} onRetry={runPreview} />
          ) : reposState.status === 'error' ? (
            <PickerError
              message={reposState.message}
              onRetry={() => {
                void loadRepos();
              }}
            />
          ) : quartersState.status === 'error' ? (
            <PickerError
              message={quartersState.message}
              onRetry={() => {
                void loadQuarters();
              }}
            />
          ) : undefined
        }
      />

      {reposEmpty ? <EmptyReposState /> : null}

      {reposState.status === 'ready' &&
      quartersState.status === 'ready' &&
      !reposEmpty &&
      !quartersEmpty ? (
        previewState.status === 'ready' ? (
          <AttestationSummaryView data={previewState.data} />
        ) : previewState.status === 'loading' ? (
          <PreviewSkeleton />
        ) : null
      ) : null}
    </div>
  );
}
