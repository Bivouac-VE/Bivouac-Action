// @polsia:user-owned — Server Component for /dashboard/attest. Exports
// per-page metadata focused on NIS2/CRA evidence handoff, gates access to
// admins via requireAdmin(), and delegates the repo + quarter picker, KPI
// tiles, and download buttons to the <AttestationBoard/> client island. The
// page itself never awaits Prisma / apiFetch — that's the island's job.

import type { Metadata } from 'next';
import { requireAdmin } from '@/lib/server/admin-gate';
import { AttestationBoard } from './_components/AttestationBoard';

export const metadata: Metadata = {
  title: 'Attestation export',
  description:
    'Generate a signed attestation bundle for a connected repository and a calendar quarter — every patch event, test outcome, merge vs human-override decision, CVE id, and SBOM rollup — as a downloadable JSON or branded PDF. Built for the audit handoff NIS2 and CRA require: a deterministic hash so the same data replays the same attestation.',
  alternates: { canonical: '/dashboard/attest' },
};

export default async function AttestationPage() {
  await requireAdmin();
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Attestation</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Attestation export</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Pick a connected repository and a calendar quarter, then download a signed bundle — every
          patch event, test run, merge decision and human override, plus the SBOM rollup — as JSON
          or a branded PDF. The PDF cover page stamps the same hash the JSON carries inside, so an
          auditor can verify the two against each other.
        </p>
      </header>

      <AttestationBoard />
    </div>
  );
}
