// @polsia:user-owned — return page after Stripe Checkout on /dashboard/billing.
//
// Mirrors src/app/(dashboard)/settings/billing/return/page.tsx structurally,
// but routes the post-sync redirect through the dashboard billing surface
// instead of the settings subtree. Server Component: parses session_id +
// plan + addons from the query string, exports metadata, renders the
// <BillingDashboardReturnIsland/> which POSTs /api/billing/sync and
// router.replace('/dashboard/billing').

import type { Metadata } from 'next';
import { BillingDashboardReturnIsland } from '@/components/custom/dashboard/billing-return-island';

export const metadata: Metadata = {
  title: 'Returning from checkout — Dashboard',
  description: 'Reconciling your Stripe Checkout session against your Bivouac billing plan.',
  alternates: { canonical: '/dashboard/billing/return' },
  robots: { index: false },
};

function parseAddons(raw: string | undefined): string[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

export default async function DashboardBillingReturnPage({
  searchParams,
}: {
  searchParams: Promise<{ session_id?: string; plan?: string; addons?: string }>;
}) {
  const params = await searchParams;
  const sessionId = params.session_id ?? '';
  const plan = params.plan ?? '';
  const addons = parseAddons(params.addons);
  return (
    <div className="flex flex-col gap-section">
      <BillingDashboardReturnIsland sessionId={sessionId} plan={plan} addons={addons} />
    </div>
  );
}
