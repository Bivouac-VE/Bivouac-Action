// @polsia:user-owned — Server Component for /dashboard/billing.
//
// Thin shell that exports `metadata` (the page is a Server Component so the
// metadata export stays valid) and renders the <BillingView/> client island.
// The island owns the fetch (loading/unauthed/error/empty/ready) so this
// page never imports server-only modules (Prisma, next/headers, requireAuth).
// All App Router + auth gating is supplied by the existing
// (dashboard)/dashboard/layout.tsx → <DashboardShell/> + /api/team/state.

import type { Metadata } from 'next';
import { BillingView } from '@/components/custom/dashboard/billing-view';

export const metadata: Metadata = {
  title: 'Billing — Dashboard',
  description:
    'Workspace subscription management: plan tier, per-repo price, renewal date, Stripe customer portal access, and the last 6 invoices pulled from Stripe.',
  alternates: { canonical: '/dashboard/billing' },
  robots: { index: false },
};

export default function DashboardBillingPage() {
  return (
    <div className="flex flex-col gap-section">
      <BillingView />
    </div>
  );
}
