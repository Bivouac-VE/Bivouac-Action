// @polsia:user-owned — Server Component for /dashboard/team.
//
// Per data-plane rules this page only exports metadata and renders a single
// client island. The island owns the fetch (loading/error/unauthed/ready)
// so the page itself never imports server-only modules (Prisma, next/headers,
// requireAuth) — those live strictly in /api/team/**.

import type { Metadata } from 'next';
import { TeamManagementView } from '@/components/team/team-management-view';

export const metadata: Metadata = {
  title: 'Team',
  description:
    'Manage multi-seat access for your Bivouac team: invite teammates by email, change seated members’ roles inline between admin, on-call, and viewer, and review pending invitations from one screen.',
  alternates: { canonical: '/dashboard/team' },
  robots: { index: false },
};

export default function TeamPage() {
  return (
    <div className="flex flex-col gap-section">
      <TeamManagementView />
    </div>
  );
}
