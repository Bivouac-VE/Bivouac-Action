// @polsia:user-owned — Server Component for /dashboard. Exposes per-page
// metadata (no 'use client' so the metadata export stays valid per POL-2616)
// and composes the first-run <ConnectFirstRepoPanel/> island plus the
// existing <RepoCardsGrid/> and <PatchListCard/> client islands. The
// first-repo panel hides the moment REPO_CONNECTED flips true; the page
// itself stays a Server Component that exports metadata.

import type { Metadata } from 'next';
import { ConnectFirstRepoPanel } from '@/components/custom/dashboard/connect-first-repo-panel';
import { RepoCardsGrid } from '@/components/custom/dashboard/repo-cards-grid';
import { PatchListCard } from '@/components/custom/patches/patch-list-card';

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'Connected GitHub repositories and their live triage status.',
  alternates: { canonical: '/dashboard' },
};

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-section">
      <ConnectFirstRepoPanel />
      <RepoCardsGrid />
      <PatchListCard />
    </div>
  );
}
