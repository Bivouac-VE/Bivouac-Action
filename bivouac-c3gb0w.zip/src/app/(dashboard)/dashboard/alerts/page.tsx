// @polsia:user-owned — Server Component for /dashboard/alerts. Exports
// per-page metadata (so the SEO template resolves) and delegates the fetch
// to the <AlertFeedView/> client island. The page never imports server-only
// modules; the /api/alerts handler is the only data path.

import type { Metadata } from 'next';
import { AlertFeedView } from '@/components/custom/team/alert-feed-view';

export const metadata: Metadata = {
  title: 'On-call alerts',
  description:
    'High-severity patch events that need a human — red builds, contested decisions, and merge blocks — surfaced from the audit log so the on-call sees only the events that require action.',
  alternates: { canonical: '/dashboard/alerts' },
  robots: { index: false },
};

export default function AlertsPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">On-call</p>
        <h1 className="font-display text-h1 text-balance text-foreground">On-call alerts</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          High-severity patch events from the triage audit log: red builds that failed tests,
          contested decisions that need a human reviewer, and merge blocks where the agent
          intentionally refused to take the action. Each row links back to the full audit entry.
        </p>
      </header>

      <AlertFeedView />
    </div>
  );
}
