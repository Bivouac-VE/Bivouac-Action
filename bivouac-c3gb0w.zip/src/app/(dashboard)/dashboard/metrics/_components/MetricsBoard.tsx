// @polsia:user-owned — Thin Server-Component wrapper for /dashboard/metrics.
// All data fetching + UI logic lives in the client island
// <ComplianceMetricsBoard/>; this layer exists so the directory page can
// stay a Server Component that exports `metadata` cleanly.

import { ComplianceMetricsBoard } from '@/components/custom/metrics/compliance-metrics-board';

export function MetricsBoard() {
  return <ComplianceMetricsBoard />;
}
