// @polsia:user-owned — Server Component for /dashboard/metrics. Exports
// per-page metadata (so the SEO template still resolves) and delegates all
// data fetch + filter UI to the <MetricsBoard/> client island. The page
// itself never awaits Prisma / apiFetch — that's the island's job.

import type { Metadata } from 'next';
import { MetricsBoard } from './_components/MetricsBoard';

export const metadata: Metadata = {
  title: 'Compliance metrics',
  description:
    'Mean time to patch, auto-merge rate, and human-override rate for your connected repositories, with a 30/60/90-day toggle and a per-repo breakdown table.',
  alternates: { canonical: '/dashboard/metrics' },
};

export default function MetricsPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Compliance</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Metrics</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Three headline series — mean time to patch, how much of that work the agent handles on its
          own, and how often a human takes the call — plus a per-repo breakdown so reviewers can
          trace compliance trends back to the connected repositories.
        </p>
      </header>

      <MetricsBoard />
    </div>
  );
}
