// @polsia:user-owned — Server Component for /connect/repo. The "pick ONE
// repo" step in the Connect-a-repo flow: the GitHub App install returns to
// /connect/confirm, and the user is sent here with `?installation_id=…`
// to select a single repository to put on watch. Exposes per-page metadata
// (no 'use client' so the metadata export stays valid) and renders the
// <RepoPicker/> client island, which owns the fetch + the search + the
// upsert + the redirect to /dashboard/repos. Data plane: all reads/writes
// go through /api, never server-side in this file.

import type { Metadata } from 'next';
import { RepoPicker } from '@/components/custom/connect/repo-picker';

export const metadata: Metadata = {
  title: 'Pick a repository',
  description:
    'Select one repository from the GitHub App install to put on watch with Bivouac. Name, visibility, default branch, and last activity shown for every repo the install granted access to.',
  alternates: { canonical: '/connect/repo' },
  // Confirmation step in a per-installation onboarding flow — transient and
  // not useful in a search index.
  robots: { index: false, follow: false },
};

export default function ConnectRepoPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Onboarding</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Pick a repository to put on watch.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          GitHub just handed the Bivouac App access to the repos below. Pick one to put on active
          watch — Bivouac scopes it to its default branch, only reads{' '}
          <span className="font-mono">code</span>, <span className="font-mono">contents</span>, and{' '}
          <span className="font-mono">pull requests</span>, and scopes every triage PR to just that
          repo.
        </p>
      </header>

      <RepoPicker />
    </div>
  );
}
