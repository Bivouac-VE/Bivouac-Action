// @polsia:user-owned — Server Component for /connect. Exposes per-page
// metadata (no 'use client' so the metadata export stays valid) and renders
// the <ConnectInstallCard/> client island which owns the fetch + state
// machine for the install URL.

import type { Metadata } from 'next';
import { ConnectInstallCard } from '@/components/custom/connect/connect-install-card';

export const metadata: Metadata = {
  title: 'Connect a repo',
  description:
    'Install the Bivouac GitHub App to put a repository on watch. Read-only repo metadata, contents read & write, and pull-request write are the only scopes requested.',
  alternates: { canonical: '/connect' },
};

export default function ConnectPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Onboarding</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Connect a repository to Bivouac
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          The Bivouac GitHub App installs on your GitHub org or user in one click. Review the scopes
          we ask for, then continue to GitHub to grant access.
        </p>
      </header>

      <ConnectInstallCard />
    </div>
  );
}
