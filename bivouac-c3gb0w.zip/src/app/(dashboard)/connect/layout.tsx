// @polsia:user-owned — /connect layout. Wraps the page in the auth-gated
// dashboard shell so the empty-state CTA and the "Connect another repo"
// footer both arrive at the same authed surface.

import type { ReactNode } from 'react';
import { DashboardShell } from '@/components/custom/dashboard/dashboard-shell';

export default function ConnectLayout({ children }: { children: ReactNode }) {
  return <DashboardShell>{children}</DashboardShell>;
}
