// @polsia:user-owned — Server Component for /connect/confirm. Renders the
// per-installation confirmation panel (which GitHub account the App was
// installed on, which repos got enrolled, CTAs to the dashboard + back to
// /connect) inside the auth-gated dashboard shell.

import type { Metadata } from 'next';
import { ConnectConfirmCard } from '@/components/custom/connect/connect-confirm-card';

export const metadata: Metadata = {
  title: 'Connect — confirmed',
  description:
    'Bivouac GitHub App installed successfully. The selected repositories are now on watch.',
  alternates: { canonical: '/connect/confirm' },
  // Don't index confirmation pages — they're transient per-installation.
  robots: { index: false, follow: false },
};

export default function ConnectConfirmPage() {
  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Onboarding</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Bivouac GitHub App installed.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          The repositories you selected on GitHub just landed on watch — Bivouac starts scanning
          each one on its default branch within the next minute.
        </p>
      </header>

      <ConnectConfirmCard />
    </div>
  );
}
