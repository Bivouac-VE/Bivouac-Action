// @polsia:user-owned — Server Component for /insights. Exports per-page
// metadata (so the SEO template still resolves) and delegates all data fetch
// + filter UI to the <InsightsBoard/> client island. The page itself never
// awaits Prisma / apiFetch — that's the island's job.

import type { Metadata } from 'next';
import { InsightsBoard } from '@/components/custom/insights/insights-board';

export const metadata: Metadata = {
  title: 'Insights',
  description: 'Compliance metrics over your connected repos.',
  alternates: { canonical: '/insights' },
};

export default function InsightsPage() {
  return <InsightsBoard />;
}
