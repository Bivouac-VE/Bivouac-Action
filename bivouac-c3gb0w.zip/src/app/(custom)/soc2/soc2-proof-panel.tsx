// @polsia:user-owned — "proof" panel for the SOC 2 page. Server component.
// Two stacked panels: the signed attestation export card (mirrors the CRA /
// NIS2 proof panel with a unique sha256 pill), and below it the public
// /activity feed embed so the SOC 2 buyer can inspect the continuous-monitoring
// evidence stream directly. The <ActivityFeed/> island already owns its own
// loading / error / empty branches, so this section stays a Server Component.

import { ArrowUpRight, Binary } from 'lucide-react';
import Link from 'next/link';
import { ActivityFeed } from '@/components/custom/activity/activity-feed';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export function Soc2ProofPanel() {
  return (
    <section className="section bg-muted/30">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Proof, not a promise</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            One signed bundle per quarter — replayable, hash-verifiable.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Pick a connected repo and a calendar quarter from{' '}
            <span className="font-mono">/dashboard/attest</span> and download the bundle. Every CC7
            / CC8 / CC9 patch event, test outcome, merge vs human override, CVE id, and SBOM rollup
            is in the same JSON — and on the cover of the branded PDF. The attestation hash is
            deterministic, so the same data always hashes to the same root. Your auditor&apos;s
            replay matches yours, byte for byte. Bivouac produces the evidence; the certification is
            your team&apos;s, earned in your audit.
          </p>
        </div>

        <Card className="relative overflow-hidden border-brand-500/30 bg-card">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 size-72 rounded-full bg-brand-500/10 blur-3xl"
          />
          <CardContent className="relative flex flex-col gap-6 p-8 md:flex-row md:items-center md:justify-between md:p-10">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                  <Binary className="size-4" aria-hidden />
                </span>
                <span className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                  Signed attestation export
                </span>
              </div>
              <p className="max-w-2xl text-body text-foreground">
                Quarter-scoped, deterministic-hashed, downloadable as JSON or PDF. The bundle is the
                artifact your Type II auditor replays — Trust Services Criteria coverage, decision
                provenance, and SBOM provenance all live in the same signed root.
              </p>
              <div className="rounded-md border border-border bg-background/60 px-4 py-3 font-mono text-caption text-muted-foreground">
                <span className="select-none text-brand-700 dark:text-brand-300">
                  sha256:&nbsp;
                </span>
                4a7e91…c6b4&nbsp;f23d88…91e7&nbsp;9b2c4d…7e51&nbsp;75a83e…0c2f
              </div>
            </div>

            <Button asChild size="lg" className="gap-2 shadow-brand">
              <Link href="/dashboard/attest">
                Open the signed export
                <ArrowUpRight className="size-4" aria-hidden />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <div className="flex flex-col gap-5">
          <div className="flex flex-col gap-2">
            <p className="text-eyebrow">Continuous monitoring — the live stream</p>
            <h3 className="font-display text-h2 text-balance text-foreground">
              What the agent did, just now — public, signed timestamps, no sign-in to inspect.
            </h3>
            <p className="max-w-3xl text-body text-muted-foreground">
              CC4.1 (continuous monitoring) is the cheapest control to claim and the hardest one to
              evidence. Bivouac publishes a live, per-row trail at{' '}
              <span className="font-mono">/activity</span> — every triage, test, and merge decision
              stamped as it happens. No login required to inspect.
            </p>
          </div>

          <Card className="border-border bg-card">
            <CardContent className="p-6 md:p-7">
              <ActivityFeed />
            </CardContent>
          </Card>

          <div className="flex justify-start">
            <Button asChild variant="outline" size="sm" className="gap-2">
              <Link href="/activity">
                Open /activity
                <ArrowUpRight className="size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
