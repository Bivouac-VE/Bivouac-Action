// @polsia:user-owned — SOC 2 obligations map. Server component: two columns
// (TSC CC reference + how Bivouac addresses each), static copy. Mirrors the
// CRA / NIS2 obligations map shell.

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type Obligation = {
  ref: string;
  title: string;
  bivouac: string;
};

const OBLIGATIONS: Obligation[] = [
  {
    ref: 'CC7.1',
    title: 'System operations — detect / respond to vulnerabilities and upstream changes',
    bivouac:
      'A new CVE or upstream breaking change fires a signal within minutes. The policy pack pre-classifies the move (forward fix, downgrade, pin), and the merge row carries the upstream disclosure date and the fix timestamp — so the auditor can verify the signal-to-fix clock on every row.',
  },
  {
    ref: 'CC7.2',
    title: 'Anomaly detection & response — a process for identifying and dispositioning CVEs',
    bivouac:
      'Each merge row IS the disposition record: test outcome, policy-pack decision, merge-vs-human-override flag, and the auto-merged / paged-human / declined classification. There is no separate log to reconcile — the disposition is the row.',
  },
  {
    ref: 'CC8.1',
    title: 'Change management — authorize, test, and document changes to the system',
    bivouac:
      'Patch PRs open against the actual repo, run the actual test suite, and merge only on green. The full chain — signal, policy-pack decision, test run, merge — is one signed row per CVE, not a separate paper trail to keep aligned with the code.',
  },
  {
    ref: 'CC9.1',
    title: 'Risk mitigation — identify, select, and develop risk-mitigation activities',
    bivouac:
      'Forward fix, downgrade, and pin are pre-classified per policy pack; the chosen direction is recorded on the merge row BEFORE code is touched. License-sensitive and security-sensitive moves stop at a human; the override is itself a row in the bundle.',
  },
  {
    ref: 'CC9.2',
    title:
      'Vendor & supplier risk — assess and manage third-party providers and upstream components',
    bivouac:
      "A transitive SBOM rollup is generated per quarter from what actually shipped — vendor, version, parent edge, and support-period stamp are in the same signed root. The auditor doesn't have to ask for the SBOM separately; it ships with the change-control evidence.",
  },
  {
    ref: 'CC4.1',
    title: 'Continuous monitoring — ongoing evaluation of system and configuration changes',
    bivouac:
      'A daily triage cron opens a patch PR within minutes of a signal; the public /activity feed is the live evidence stream; the quarterly signed attestation is the bounded-period snapshot. Continuous monitoring stops being a separate program to staff.',
  },
];

export function Soc2ObligationsMap() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">TSC CC mapped to the merge log</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            What SOC 2 asks for, and what Bivouac already records.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            The controls on the left are Trust Services Criteria CC7 / CC8 / CC9. The matchings on
            the right are what your auditor replays when they ask for evidence — already captured
            per merge, no end-of-quarter rebuild required. Bivouac supports your SOC 2 evidence
            workflow; Bivouac is itself not certified against the framework.
          </p>
        </div>

        <Card className="overflow-hidden border-border bg-card">
          <CardHeader className="border-b border-border bg-muted/40 pb-3">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr]">
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                SOC 2 control
              </CardTitle>
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                Bivouac evidence
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ol className="divide-y divide-border">
              {OBLIGATIONS.map((row) => (
                <li key={row.ref} className="grid grid-cols-1 gap-4 p-6 md:grid-cols-[1fr_1fr]">
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                      {row.ref}
                    </span>
                    <p className="text-body text-foreground">{row.title}</p>
                  </div>
                  <p className="text-body text-muted-foreground">{row.bivouac}</p>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
