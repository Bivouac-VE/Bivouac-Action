// @polsia:user-owned — SOC 2 landing hero. Server component: literal copy
// addressing a SOC 2 buyer (security / DevOps lead preparing for a Type II
// audit), the auth-aware primary CTA as a client island, and an outline link
// to the existing signed export page (/dashboard/attest). Three siblings
// (CRA / NIS2 / SOC 2) reuse the same shell; visual motif differs (`soc2-rings`).

import { ArrowRight, ClipboardCheck } from 'lucide-react';
import Link from 'next/link';
import { PrimaryCtaButton } from '@/components/custom/landing/landing-primary-cta-button';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export function Soc2Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 hidden md:block" aria-hidden>
        <svg
          viewBox="0 0 800 600"
          className="absolute -right-32 -top-24 h-[820px] w-[820px] text-brand-500/15"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative concentric rings</title>
          <defs>
            <pattern id="soc2-rings" width="56" height="56" patternUnits="userSpaceOnUse">
              <circle cx="28" cy="28" r="22" strokeWidth="0.35" />
            </pattern>
          </defs>
          <circle cx="400" cy="300" r="290" strokeWidth="1" />
          <circle cx="400" cy="300" r="220" strokeWidth="1" />
          <circle cx="400" cy="300" r="150" strokeWidth="1" />
          <circle cx="400" cy="300" r="80" strokeWidth="1.25" />
          <circle cx="400" cy="300" r="14" fill="currentColor" />
          <rect x="110" y="10" width="580" height="580" fill="url(#soc2-rings)" opacity="0.55" />
          <path d="M 400 10 L 400 590" strokeWidth="0.5" strokeDasharray="3 5" />
          <path d="M 110 300 L 690 300" strokeWidth="0.5" strokeDasharray="3 5" />
        </svg>
      </div>

      <div className="container-page relative flex flex-col gap-10 pt-section-lg pb-section md:pt-section-xl">
        <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
          <ClipboardCheck className="size-3 text-brand-700 dark:text-brand-300" aria-hidden />
          <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
            SOC 2 evidence
          </span>
        </Badge>

        <h1 className="max-w-4xl font-display text-display text-balance text-foreground">
          The audit trail your SOC 2 Type II auditor already wants to see — generated as a side
          effect of the merge.
        </h1>

        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Trust Services Criteria CC7, CC8, and CC9 turn dependency-risk and change-control into
          auditable controls. Bivouac records every CVE → fix → test → merge decision with a
          deterministic hash, then bundles a signed export per quarter. The auditor replays the
          file; same input, same root, byte for byte. Evidence for your audit, not a Bivouac
          certification.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <PrimaryCtaButton signedInLabel="Open dashboard" signedOutLabel="Start free" />
          <Button asChild size="lg" variant="outline" className="gap-2">
            <Link href="/dashboard/attest">
              See the signed export
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-border pt-6 text-caption text-muted-foreground">
          <span>CC7.1 · system monitoring</span>
          <span>CC7.2 · anomaly detection &amp; response</span>
          <span>CC8.1 · change management</span>
          <span>CC9.2 · vendor / supplier risk</span>
        </div>
      </div>
    </section>
  );
}
