// @polsia:user-owned — /soc2 landing page. Server Component; exports per-page
// metadata, schema.org WebPage payload, and composes six sibling sections
// (Hero, ObligationsMap, ProofPanel, EvidenceTrail, Faq, FinalCta). No
// `await fetch`/`await prisma` — content is static and the auth-aware CTA is a
// tiny client island.

import type { Metadata } from 'next';
import { siteName, siteUrl } from '@/lib/site';
import { Soc2EvidenceTrail } from './soc2-evidence-trail';
import { Soc2Faq } from './soc2-faq';
import { Soc2FinalCta } from './soc2-final-cta';
import { Soc2Hero } from './soc2-hero';
import { Soc2ObligationsMap } from './soc2-obligations-map';
import { Soc2ProofPanel } from './soc2-proof-panel';

export const metadata: Metadata = {
  title: 'Bivouac for SOC 2',
  description:
    "Trust Services Criteria CC7 / CC8 / CC9 evidence — every CVE → fix → test → merge decision recorded with deterministic hashing, signed per quarter, exportable from /dashboard/attest for your team's SOC 2 audit pack. Bivouac itself is not SOC 2 certified.",
  alternates: { canonical: '/soc2' },
  openGraph: {
    title: 'Bivouac for SOC 2',
    description:
      "TSC CC7 / CC8 / CC9 dependency-risk evidence, exported as a signed bundle per quarter for your team's audit pack — every patch attached to a deterministic hash, replayed by your SOC 2 auditor. Bivouac itself is not SOC 2 certified.",
    url: '/soc2',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bivouac for SOC 2',
    description:
      "TSC CC7 / CC8 / CC9 dependency-risk evidence, exported as a signed bundle per quarter for your team's audit pack — every patch attached to a deterministic hash, replayed by your SOC 2 auditor. Bivouac itself is not SOC 2 certified.",
  },
};

export default function Soc2Page() {
  const webPageLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Bivouac for SOC 2',
    url: `${siteUrl}/soc2`,
    publisher: { '@type': 'Organization', name: siteName },
    description:
      'How Bivouac produces SOC 2 Trust Services Criteria evidence for dependency-risk and change-management controls: every CVE → fix → test → merge decision recorded with deterministic hashing, bundled per quarter, and downloadable from /dashboard/attest for replay by a SOC 2 Type II auditor. Bivouac itself is not SOC 2 certified.',
  };
  return (
    <main className="flex flex-col">
      <script
        type="application/ld+json"
        id="soc2-webpage-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand module and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageLd) }}
      />
      <Soc2Hero />
      <Soc2ObligationsMap />
      <Soc2ProofPanel />
      <Soc2EvidenceTrail />
      <Soc2Faq />
      <Soc2FinalCta />
    </main>
  );
}
