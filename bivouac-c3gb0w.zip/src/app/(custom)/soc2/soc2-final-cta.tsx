// @polsia:user-owned — Final conversion panel on /soc2. Server component that
// reuses the auth-aware <PrimaryCtaButton/> client island from the landing
// page so the conversion route is consistent across regulatory landing pages.

import { PrimaryCtaButton } from '@/components/custom/landing/landing-primary-cta-button';

export function Soc2FinalCta() {
  return (
    <section className="section-lg">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-lg border border-brand-500/30 bg-gradient-to-br from-brand-500/10 via-background to-background p-10 md:p-14">
          <div
            aria-hidden
            className="absolute -right-20 -top-20 size-72 rounded-full bg-brand-500/15 blur-3xl"
          />
          <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
            <div className="flex flex-col gap-3">
              <p className="text-eyebrow">Generate, sign, ship</p>
              <h2 className="font-display text-h1 text-balance text-foreground">
                Generate your first SOC 2 signed attestation this quarter.
              </h2>
              <p className="max-w-xl text-body-lg text-muted-foreground">
                Connect a repo, merge a patch, and the bundle hashes itself. By the time your Type
                II auditor opens the export, the file is already self-verifying. Bivouac produces
                the evidence your team hands to the auditor — it isn&apos;t itself SOC 2 certified.
              </p>
            </div>

            <div className="flex flex-col gap-3 md:items-end">
              <PrimaryCtaButton signedInLabel="Open dashboard" signedOutLabel="Start free" />
              <p className="text-small text-muted-foreground md:text-right">
                Free for the first repo. No card to start.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
