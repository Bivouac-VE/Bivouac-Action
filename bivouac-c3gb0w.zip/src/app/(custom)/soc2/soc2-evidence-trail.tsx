// @polsia:user-owned — SOC 2 vertical evidence trail. Server component, static
// copy, no fetch. Same four-step shape as the CRA / NIS2 trail but framed for
// the SOC 2 Type II controls — signal fires, policy pack decides, test outcome
// recorded, merge or human override.

import { GitMerge, ListChecks, Radar, ShieldAlert } from 'lucide-react';

const STEPS: {
  step: string;
  title: string;
  body: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    step: '01',
    title: 'Signal fires',
    body: 'New CVE, upstream breaking change, or package-registry advisory on a watched repo. The signal carries the upstream disclosure date and severity so the SOC 2 signal-to-fix clock on CC7.1 starts from a real timestamp, not a quarterly narrative.',
    icon: Radar,
  },
  {
    step: '02',
    title: 'Policy pack decides',
    body: 'Forward fix, downgrade, or pin chosen locally — license posture, peer usage, and security-sensitive surfaces reviewed BEFORE any code is touched. The chosen direction is recorded on the merge row before the PR exists, satisfying CC9.1 risk-mitigation at the source.',
    icon: ListChecks,
  },
  {
    step: '03',
    title: 'Test outcome recorded',
    body: 'Project test suite runs against the draft PR; pass/fail attaches to the merge row, not just the resulting commit. CC8.1 change-control only counts a CVE as "addressed" if the patch actually shipped — the row proves it.',
    icon: ShieldAlert,
  },
  {
    step: '04',
    title: 'Merge or human override',
    body: 'Auto-merge on green; security-sensitive surfaces and license-sensitive moves stop at a human. The override is itself a row in the bundle (CC7.2) — the vendor, version, parent edge, and support-period stamp per merge are the SBOM provenance for CC9.2.',
    icon: GitMerge,
  },
];

export function Soc2EvidenceTrail() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">From signal to SOC 2 evidence</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            Four steps run end to end — the same trail your Type II auditor replays.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Nothing on this list is reconstructed at the end of the quarter. Every step is a row in
            the signed bundle, in order, with the policy-pack decision and the SBOM
            provenance/per-build software-bill-of-materials attached to the last one.
          </p>
        </div>

        <ol className="relative flex flex-col gap-6 pl-6 md:pl-10">
          <span aria-hidden className="absolute bottom-3 left-3 top-3 w-px bg-border md:left-5" />
          {STEPS.map((s) => (
            <li
              key={s.step}
              className="relative flex flex-col gap-3 rounded-lg border border-border bg-card p-6 shadow-md md:flex-row md:items-start md:gap-6 md:p-7"
            >
              <span
                aria-hidden
                className="absolute -left-3 top-7 inline-flex size-6 items-center justify-center rounded-full border border-border bg-background text-brand-700 shadow-sm md:-left-3.5 md:top-9"
              >
                <s.icon className="size-3" aria-hidden />
              </span>
              <div className="flex items-center gap-3 md:w-44 md:shrink-0">
                <span className="font-mono text-caption font-bold text-brand-700 dark:text-brand-300">
                  {s.step}
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="font-display text-h4 text-foreground">{s.title}</h3>
                <p className="text-body text-muted-foreground">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
