// @polsia:user-owned — SOC 2 buyer FAQ. Client island (uses the radix-backed
// <Accordion/>). Static literal copy; no apiFetch, no state.

'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ: { q: string; a: string }[] = [
  {
    q: 'Will our SOC 2 Type II auditor accept the signed export as evidence?',
    a: 'Yes — the export at /dashboard/attest is the artifact your auditor replays. Every patch event carries its CVE id, signal source, policy-pack decision, test outcome, merge-vs-human-override flag, and SBOM provenance. The attestation hash is deterministic, so the same data always hashes to the same root. Auditors verify the hash on the JSON and the same hash on the PDF cover; they match.',
  },
  {
    q: 'How does Bivouac help with CC7.1 / continuous monitoring?',
    a: 'A daily triage cron opens a patch PR within minutes of a signal. The public /activity feed is the live evidence stream — every triage, test, and merge decision stamped as it happens, with no sign-in required to inspect. The quarterly signed attestation is the bounded-period snapshot for the auditor. CC7.1 stops being a separate program to staff.',
  },
  {
    q: 'How does Bivouac handle CC9.2 / vendor & supplier risk?',
    a: 'A transitive SBOM rollup is generated per quarter from what actually shipped — vendor, version, parent edge, and support-period stamp are in the same signed root. The auditor does not have to ask for the SBOM separately; it ships with the change-control evidence in the same bundle. Direct and transitive edges are both covered, so downstream drift at a deep transitive edge is visible.',
  },
  {
    q: 'What happens when a patch PR fails tests? — change-control / rollback',
    a: 'The merge is blocked. The signal stays open, the failure is recorded on the merge row with the failing check name, and the on-call rotation is paged only when the contested decision is something the policy pack flagged as security-sensitive or license-sensitive. Nothing is silently dropped — the failed run is in the signed bundle, which is the right CC8.1 behavior: auditor should see the case was tried, not concealed.',
  },
  {
    q: 'Can we scope per business unit, or per supplier?',
    a: 'Yes. Connect repos per BU or per supplier, and pick a policy pack per repo. The signed bundle is per repo per quarter, and the SBOM rollup inside it filters to what you actually shipped — direct and transitive edges with versions, not just top-level dependencies. SOC 2 scope and supplier scope map to the same repo boundary.',
  },
  {
    q: 'Is the activity feed auditable — and is data isolated per tenant?',
    a: 'Yes to both. The /activity feed is a public, signed-timestamp surface; a scanner can verify the timestamps without an account. Repos, patch events, test outcomes, SBOM rollups, and the signed export are scoped per tenant. The attestation hash is computed over your rows, so two tenants generating the same data never produce the same root — there is no cross-tenant leak in the bundle.',
  },
];

export function Soc2Faq() {
  return (
    <section className="section relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 hidden md:block" aria-hidden>
        <svg
          viewBox="0 0 600 400"
          className="absolute -left-32 top-10 h-[480px] w-[480px] text-brand-500/10"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative isometric grid</title>
          <defs>
            <pattern id="soc2-iso-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 0 24 L 24 0 L 48 24 L 24 48 Z" strokeWidth="0.4" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="600" height="400" fill="url(#soc2-iso-grid)" />
        </svg>
      </div>

      <div className="container-page relative flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">SOC 2 buyer questions</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            The questions your Type II auditor and your VP Security will ask first.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Bivouac produces the evidence your team hands to the auditor — it isn&apos;t itself SOC
            2 certified.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card/80 backdrop-blur-sm">
          <Accordion type="single" collapsible className="px-2">
            {FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`soc2-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
