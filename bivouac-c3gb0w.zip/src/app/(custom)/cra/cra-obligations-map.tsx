// @polsia:user-owned — CRA obligations map. Server component: two columns
// (CRA article / annex references + how Bivouac addresses each), static copy.

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type Obligation = {
  ref: string;
  title: string;
  bivouac: string;
};

const OBLIGATIONS: Obligation[] = [
  {
    ref: 'Article 11(1)',
    title: 'Vulnerability handling — SBOM and coordinated disclosure for the support period',
    bivouac:
      'A complete SBOM is rebuilt every calendar quarter from what actually shipped — direct and transitive edges, vendor, version, parent chain. Disclosures attach to the package and version they affected; the support period is stamped per edge so the free-update window is never a guess.',
  },
  {
    ref: 'Article 11(2)',
    title: 'Free security updates and patches for the support period — address without delay',
    bivouac:
      'A new CVE fires a signal within minutes. The policy pack pre-classifies the move (forward fix, downgrade, pin), and a draft PR is opened against the real repo. The merge row carries the CVE id, the upstream disclosure date, the test outcome, and the fix timestamp — the audit trail for "addressed without delay" is the merge log, not a separate paper record.',
  },
  {
    ref: 'Annex I.2',
    title:
      'Secure-by-design — minimise attack surface, dependency risk, address known vulnerabilities',
    bivouac:
      'Every dependency edge is reviewed before a code change. License posture, peer usage, and security-sensitive surfaces are scored by the policy pack, and the chosen direction is recorded BEFORE code is touched. License-sensitive or security-sensitive moves stop at a human; the override is itself a row in the bundle.',
  },
  {
    ref: 'Annex I.1',
    title: 'Secure-by-default — secure configuration out of the box',
    bivouac:
      'Patch PRs run the actual project test suite on the actual upgrade path. Auto-merge is permitted only on green, so the default shipped configuration is always the tested configuration. The same merge-vs-override flag distinguishes "agent merged" from "human approved" on every widening.',
  },
  {
    ref: 'Article 13',
    title: 'Reporting obligations to ENISA on actively exploited vulnerabilities',
    bivouac:
      'Every patch row in the bundle is shaped like a report — CVE id, signal source, disclosure date, fix timestamp, classification. The signed export IS the evidence envelope your regulator and ENISA can replay; no second document has to be kept aligned with the code.',
  },
  {
    ref: 'Article 11(3)',
    title:
      '5-year support period obligation — manufacturers ensure effective handling through the lifetime',
    bivouac:
      'The support window is a per-edge stamp inside the SBOM rollup, not a global setting. The signed attestation includes a coverage table per repo for the chosen quarter; a vendor that slipped out of support is visible at quarter close, not after the regulator asks.',
  },
];

export function CraObligationsMap() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Article 11 + Annex I mapped to the merge log</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            What the CRA asks for, and what Bivouac already records.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            The obligations on the left are the regulation. The matchings on the right are what your
            auditor replays when they ask for evidence — already captured per merge, no
            end-of-quarter rebuild required. Bivouac supports your EU CRA evidence workflow; Bivouac
            is itself not certified against the framework.
          </p>
        </div>

        <Card className="overflow-hidden border-border bg-card">
          <CardHeader className="border-b border-border bg-muted/40 pb-3">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr]">
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                CRA obligation
              </CardTitle>
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                Bivouac evidence
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ol className="divide-y divide-border">
              {OBLIGATIONS.map((row) => (
                <li key={row.ref} className="grid grid-cols-1 gap-4 p-6 md:grid-cols-[1fr_1fr]">
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                      {row.ref}
                    </span>
                    <p className="text-body text-foreground">{row.title}</p>
                  </div>
                  <p className="text-body text-muted-foreground">{row.bivouac}</p>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
