// @polsia:user-owned — EU CRA vertical evidence trail. Server component,
// static copy, no fetch. Same four-step shape as the NIS2 trail but framed
// for Article 11 timelines — signal fires, policy pack decides, test outcome
// recorded, merge or human override + Article 13 SBOM provenance.

import { GitMerge, ListChecks, Radar, ShieldAlert } from 'lucide-react';

const STEPS: {
  step: string;
  title: string;
  body: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    step: '01',
    title: 'Signal fires',
    body: 'New CVE, ENISA advisory, or upstream breaking change on a watched repo. The signal carries the disclosure date and severity so Article 11(2) timelines have a clock to start from.',
    icon: Radar,
  },
  {
    step: '02',
    title: 'Policy pack decides',
    body: 'Forward fix, downgrade, or pin chosen locally — license posture, peer usage, and security-sensitive surfaces reviewed BEFORE any code is touched. The chosen direction is recorded on the merge row before the PR exists.',
    icon: ListChecks,
  },
  {
    step: '03',
    title: 'Test outcome recorded',
    body: 'Project test suite runs against the draft PR; pass/fail attaches to the merge row, not just the resulting commit. Article 11(2) only counts a CVE as "addressed" if the patch actually shipped — the row proves it.',
    icon: ShieldAlert,
  },
  {
    step: '04',
    title: 'Merge or human override',
    body: 'Auto-merge on green; security-sensitive surfaces stop at a human. Article 13 provenance — vendor, version, parent edge, support-period stamp — recorded per merge so the SBOM rollup is generated, not re-typed.',
    icon: GitMerge,
  },
];

export function CraEvidenceTrail() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">From signal to Article 11 evidence</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            Four steps run end to end — the same trail your notified body replays.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Nothing on this list is reconstructed at the end of the quarter. Every step is a row in
            the signed bundle, in order, with the policy-pack decision and the Article 13 SBOM
            provenance/per-build software-bill-of-materials attached to the last one.
          </p>
        </div>

        <ol className="relative flex flex-col gap-6 pl-6 md:pl-10">
          <span aria-hidden className="absolute bottom-3 left-3 top-3 w-px bg-border md:left-5" />
          {STEPS.map((s) => (
            <li
              key={s.step}
              className="relative flex flex-col gap-3 rounded-lg border border-border bg-card p-6 shadow-md md:flex-row md:items-start md:gap-6 md:p-7"
            >
              <span
                aria-hidden
                className="absolute -left-3 top-7 inline-flex size-6 items-center justify-center rounded-full border border-border bg-background text-brand-700 shadow-sm md:-left-3.5 md:top-9"
              >
                <s.icon className="size-3" aria-hidden />
              </span>
              <div className="flex items-center gap-3 md:w-44 md:shrink-0">
                <span className="font-mono text-caption font-bold text-brand-700 dark:text-brand-300">
                  {s.step}
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="font-display text-h4 text-foreground">{s.title}</h3>
                <p className="text-body text-muted-foreground">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
