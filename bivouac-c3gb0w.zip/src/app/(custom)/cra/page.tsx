// @polsia:user-owned — /cra landing page. Server Component; exports per-page
// metadata, schema.org WebPage payload, and composes the six sibling sections
// (Hero, ObligationsMap, ProofPanel, EvidenceTrail, Faq, FinalCta). No
// `await fetch`/`await prisma` — content is static and the auth-aware CTA is a
// tiny client island.

import type { Metadata } from 'next';
import { siteName, siteUrl } from '@/lib/site';
import { CraEvidenceTrail } from './cra-evidence-trail';
import { CraFaq } from './cra-faq';
import { CraFinalCta } from './cra-final-cta';
import { CraHero } from './cra-hero';
import { CraObligationsMap } from './cra-obligations-map';
import { CraProofPanel } from './cra-proof-panel';

export const metadata: Metadata = {
  title: 'Bivouac for EU CRA',
  description:
    'Article 11 vulnerability-handling and Annex I.2 dependency-risk evidence for the EU Cyber Resilience Act — every CVE → fix → test → merge decision recorded with deterministic hashing, signed per quarter, exportable from /dashboard/attest. Bivouac itself is not EU CRA certified.',
  alternates: { canonical: '/cra' },
  openGraph: {
    title: 'Bivouac for EU CRA',
    description:
      'EU Cyber Resilience Act vulnerability-handling evidence, exported as a signed bundle per quarter for your audit pack — every patch attached to a deterministic hash. Bivouac itself is not EU CRA certified.',
    url: '/cra',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bivouac for EU CRA',
    description:
      'EU Cyber Resilience Act vulnerability-handling evidence, exported as a signed bundle per quarter for your audit pack — every patch attached to a deterministic hash. Bivouac itself is not EU CRA certified.',
  },
};

export default function CraPage() {
  const webPageLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Bivouac for EU CRA',
    url: `${siteUrl}/cra`,
    publisher: { '@type': 'Organization', name: siteName },
    description:
      'How Bivouac produces EU Cyber Resilience Act vulnerability-handling and dependency-risk evidence: every CVE → fix → test → merge decision recorded with deterministic hashing, bundled per quarter, and downloadable from /dashboard/attest. Bivouac itself is not EU CRA certified.',
  };
  return (
    <main className="flex flex-col">
      <script
        type="application/ld+json"
        id="cra-webpage-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand module and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageLd) }}
      />
      <CraHero />
      <CraObligationsMap />
      <CraProofPanel />
      <CraEvidenceTrail />
      <CraFaq />
      <CraFinalCta />
    </main>
  );
}
