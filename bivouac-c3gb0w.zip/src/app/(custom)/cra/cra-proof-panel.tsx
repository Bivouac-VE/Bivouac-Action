// @polsia:user-owned — "proof" panel for the EU CRA page. Server component:
// links to the existing admin-gated signed attestation export at
// /dashboard/attest. Reuses the deterministic-hash + Binary visual language
// from the NIS2 proof panel.

import { ArrowUpRight, Binary } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export function CraProofPanel() {
  return (
    <section className="section bg-muted/30">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Proof, not a promise</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            One signed bundle per quarter — replayable, hash-verifiable.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Pick a connected repo and a calendar quarter from{' '}
            <span className="font-mono">/dashboard/attest</span> and download the bundle. Every
            Article 11 patch event, test outcome, merge vs human override, CVE id, and SBOM rollup —
            including the support-period stamp per dependency edge — is in the same JSON and on the
            cover of the branded PDF. The attestation hash is deterministic, so the same data always
            hashes to the same root. Your notified body&apos;s replay matches yours, byte for byte.
            Bivouac produces the evidence; the certification is your team&apos;s, earned in your
            audit.
          </p>
        </div>

        <Card className="relative overflow-hidden border-brand-500/30 bg-card">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 size-72 rounded-full bg-brand-500/10 blur-3xl"
          />
          <CardContent className="relative flex flex-col gap-6 p-8 md:flex-row md:items-center md:justify-between md:p-10">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                  <Binary className="size-4" aria-hidden />
                </span>
                <span className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                  Signed attestation export
                </span>
              </div>
              <p className="max-w-2xl text-body text-foreground">
                Quarter-scoped, deterministic-hashed, downloadable as JSON or PDF. The bundle is the
                only artifact your notified body needs — Article 11 coverage, decision provenance,
                support-period alignment, and SBOM provenance all live in the same signed root.
              </p>
              <div className="rounded-md border border-border bg-background/60 px-4 py-3 font-mono text-caption text-muted-foreground">
                <span className="select-none text-brand-700 dark:text-brand-300">
                  sha256:&nbsp;
                </span>
                7c1f4b…82d6&nbsp;a9e3c0…1158&nbsp;42d7ee…3b9c&nbsp;f8a1d2…09c4
              </div>
            </div>

            <Button asChild size="lg" className="gap-2 shadow-brand">
              <Link href="/dashboard/attest">
                Open the signed export
                <ArrowUpRight className="size-4" aria-hidden />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
