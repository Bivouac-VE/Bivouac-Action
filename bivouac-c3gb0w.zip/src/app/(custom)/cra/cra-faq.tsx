// @polsia:user-owned — EU CRA buyer FAQ. Client island (uses the radix-backed
// <Accordion/>). Static literal copy; no apiFetch, no state.

'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ: { q: string; a: string }[] = [
  {
    q: 'Does Article 11 evidence have to be separate from the SBOM rollup, or can they live in one bundle?',
    a: 'They live in one bundle. The signed export at /dashboard/attest contains every Article 11 patch event (signal, policy-pack decision, test outcome, merge vs human-override) alongside the per-quarter SBOM rollup, with the support-period stamp on each dependency edge. One signed root covers both — your notified body verifies one hash, not two reconcilable documents.',
  },
  {
    q: 'How granular is the SBOM — direct only, or transitive?',
    a: 'Transitive. The rollup is generated from the lockfile and the actual upgrade path that shipped, so a downgrade or pin on a deep transitive edge is visible. The merge row carries the parent edge that introduced each entry, so the chain leading to a vulnerable package version is replayable — not just the top-level direct dependencies.',
  },
  {
    q: 'How is the Article 11(2) "addressed without delay" timeline demonstrated?',
    a: 'Each patch row carries the upstream disclosure date and the merge timestamp in the same row. The time-to-merge is computed per CVE from those two stamps; the signed bundle includes a per-CVE timeliness view so "addressed without delay" is a distribution, not a promise.',
  },
  {
    q: 'What happens when a patch PR fails tests?',
    a: 'The merge is blocked. The signal stays open; the failure is recorded on the merge row with the failing check name. The on-call rotation is paged only when the contested decision is something the policy pack flagged as security-sensitive or license-sensitive. Nothing is silently dropped — the failed run itself is in the signed bundle, which is the right behavior for Article 11 disclosure: regulator should see the case was tried, not concealed.',
  },
  {
    q: 'How is the 5-year support-period obligation enforced?',
    a: 'The support window is a per-edge stamp inside the SBOM rollup, not a global setting. The signed attestation includes a coverage table per repo for the chosen quarter; a vendor that slipped out of support is visible at quarter close, not after the regulator asks. The Article 11(3) obligation is met by the rollup itself — no separate SLA document needed.',
  },
  {
    q: 'Is data isolated per tenant?',
    a: 'Yes. Repos, patch events, test outcomes, SBOM rollups, and the signed export are scoped per tenant. The attestation hash is computed over your rows, so two tenants generating the same data never produce the same root — there is no cross-tenant leak in the bundle.',
  },
];

export function CraFaq() {
  return (
    <section className="section relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 hidden md:block" aria-hidden>
        <svg
          viewBox="0 0 600 400"
          className="absolute -left-32 top-10 h-[480px] w-[480px] text-brand-500/10"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative isometric grid</title>
          <defs>
            <pattern id="cra-iso-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 0 24 L 24 0 L 48 24 L 24 48 Z" strokeWidth="0.4" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="600" height="400" fill="url(#cra-iso-grid)" />
        </svg>
      </div>

      <div className="container-page relative flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">CRA buyer questions</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            The questions your notified body and your VP Engineering will ask first.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Bivouac produces the evidence your team hands to the notified body — it isn&apos;t
            itself EU CRA certified.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card/80 backdrop-blur-sm">
          <Accordion type="single" collapsible className="px-2">
            {FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`cra-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
