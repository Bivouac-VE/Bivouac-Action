// @polsia:user-owned — CVE→PR triage log. Server Component that exports
// metadata + composes the client island. Reads happen via apiFetch from
// /api/cve-triage; no DB / fetch imports here.

import type { Metadata } from 'next';
import { CveTriageLogsTable } from '@/components/custom/cve-triage/logs-table';

export const metadata: Metadata = {
  title: 'CVE triage log',
  description:
    'Recent CVE→PR triage activity: vulnerable package, version pin proposed, PR URL, test outcome, and the auto-merge recommendation.',
};

export default function CveTriagePage() {
  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Dependency on watch</p>
        <h1 className="font-display text-h1 text-balance text-foreground">CVE triage log</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Each row is one match between the fixture project&apos;s pinned dependency and our
          hardcoded CVE manifest. The cron opens the PR, watches its test suite, and posts a single
          recommendation. The dashboard layer above this reads through the same endpoint.
        </p>
      </header>

      <CveTriageLogsTable />
    </main>
  );
}
