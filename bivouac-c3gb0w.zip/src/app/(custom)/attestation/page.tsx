// @polsia:user-owned — Server Component shell for /attestation. Exports
// per-page metadata only (no `await prisma`, no `await fetch`); the
// <AttestationPicker/> island owns all data fetch + interaction. The
// `requireAuth` redirect runs server-side before the page renders so an
// anonymous visitor lands on /login with a returnTo query — mirroring the
// dashboard redirect pattern. Without the redirect the picker would just
// blank out, which is the wrong failure mode for a compliance route.

import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/require-auth';
import { AttestationPicker } from './AttestationPicker.client';

export const metadata: Metadata = {
  title: 'Attestation',
  description:
    'Generate NIS2 / CRA attestation bundles for your audit pack from any connected repo × quarter — JSON and PDF, both signed. Bivouac is not NIS2 or CRA certified.',
  alternates: { canonical: '/attestation' },
};

export default async function AttestationPage() {
  const user = await getSessionUser();
  if (!user) {
    redirect('/login?returnTo=/attestation');
  }
  return <AttestationPicker />;
}
