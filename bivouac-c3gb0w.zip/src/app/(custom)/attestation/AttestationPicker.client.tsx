// @polsia:user-owned — client island for /attestation. Fetch wiring:
//   on mount → repo dropdown (GET /api/attestation/repos)
//            → quarter dropdown (GET /api/attestation/quarters)
//   submit    → preview (POST /api/attestation/preview)
//   download  → <a href="/api/attestation/export?…&format=json|pdf"> (native save)
//
// Two download buttons share (repoId, quarter) state. They're only revealed
// once a summary loads, so the browser's save dialog won't fire on an empty
// row set.

'use client';

import { AlertTriangle, CheckCircle2, FileJson, FileText, RefreshCcw } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { ZodType } from 'zod';
import { AttestationPreviewToolbar } from '@/components/custom/attestation/AttestationPreviewToolbar';
import { AttestationSummaryView } from '@/components/custom/attestation/AttestationSummary';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import type { AttestationSummary, QuarterId } from '@/lib/contracts/attestation';
import {
  AttestationSummary as AttestationSummarySchema,
  QuarterList as QuarterListSchema,
} from '@/lib/contracts/attestation';
import { RepoList } from '@/lib/contracts/repos';

const NONE_REPO = '__none__';
const NONE_QUARTER = '__none__';

type RepoListData = import('@/lib/contracts/repos').RepoList;
type QuarterListData = { items: QuarterId[] };

interface FetchState<T> {
  data: T | null;
  error: string | null;
  loaded: boolean;
}

async function loadOne<T>(
  schema: ZodType<T>,
  url: string,
  signal: AbortSignal,
): Promise<{ kind: 'ok'; data: T } | { kind: 'err'; error: string }> {
  try {
    const data = await apiFetch<T>(url, { schema, signal });
    return { kind: 'ok', data };
  } catch (err) {
    if (signal.aborted) return { kind: 'err', error: 'aborted' };
    return { kind: 'err', error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

export function AttestationPicker() {
  const [repos, setRepos] = useState<FetchState<RepoListData>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [quarters, setQuarters] = useState<FetchState<QuarterListData>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [summary, setSummary] = useState<FetchState<AttestationSummary>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [reloadKey, setReloadKey] = useState(0);
  const [repoId, setRepoId] = useState<string>(NONE_REPO);
  const [quarter, setQuarter] = useState<string>(NONE_QUARTER);
  const [previewing, setPreviewing] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    setRepos({ data: null, error: null, loaded: false });
    setQuarters({ data: null, error: null, loaded: false });

    void (async () => {
      const res = await loadOne(
        RepoListSchema,
        `/api/attestation/repos?_=${reloadKey}`,
        controller.signal,
      );
      if (!controller.signal.aborted) {
        if (res.kind === 'ok') setRepos({ data: res.data, error: null, loaded: true });
        else setRepos({ data: null, error: res.error, loaded: true });
      }
    })();
    void (async () => {
      const res = await loadOne(
        QuarterListDataSchema,
        `/api/attestation/quarters?_=${reloadKey}`,
        controller.signal,
      );
      if (!controller.signal.aborted) {
        if (res.kind === 'ok') setQuarters({ data: res.data, error: null, loaded: true });
        else setQuarters({ data: null, error: res.error, loaded: true });
      }
    })();

    return () => {
      controller.abort();
    };
  }, [reloadKey]);

  const canPreview = useMemo(
    () => repoId !== NONE_REPO && quarter !== NONE_QUARTER,
    [repoId, quarter],
  );
  const showSummary = summary.loaded && summary.data !== null;
  const showError = summary.loaded && summary.error !== null;

  async function handlePreview() {
    if (!canPreview || previewing) return;
    setPreviewing(true);
    setSummary({ data: null, error: null, loaded: false });
    try {
      const data = await apiFetch<AttestationSummary>('/api/attestation/preview', {
        method: 'POST',
        body: JSON.stringify({ repoId, quarter }),
        schema: AttestationSummarySchema,
      });
      setSummary({ data, error: null, loaded: true });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      if (message.includes('404')) {
        setSummary({
          data: null,
          error: 'Repository not found or no longer accessible.',
          loaded: true,
        });
      } else {
        setSummary({ data: null, error: message, loaded: true });
      }
    } finally {
      setPreviewing(false);
    }
  }

  const exportHref = useMemo(() => {
    if (repoId === NONE_REPO || quarter === NONE_QUARTER) return null;
    const params = new URLSearchParams({ repoId, quarter });
    return `/api/attestation/export?${params.toString()}`;
  }, [repoId, quarter]);

  const repositories = useMemo(() => repos.data?.items ?? [], [repos.data]);
  const quarterItems = useMemo(() => quarters.data?.items ?? [], [quarters.data]);
  const dropdownsError = repos.error ?? quarters.error ?? null;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <p className="text-eyebrow">Compliance attestation</p>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Generate a NIS2 / CRA evidence bundle for one repo × one quarter. Both bundles (JSON +
          PDF) are signed with a SHA-256 attestation hash so an auditor can verify the contents have
          not been altered after export. Bivouac produces the evidence; the certifications are your
          team&apos;s.
        </p>
      </div>

      <AttestationPreviewToolbar
        repoSlot={
          repos.loaded ? (
            <Select value={repoId} onValueChange={setRepoId}>
              <SelectTrigger className="w-full md:w-72">
                <SelectValue placeholder="Choose a repo" />
              </SelectTrigger>
              <SelectContent>
                {repositories.length === 0 ? (
                  <SelectItem value={NONE_REPO} disabled>
                    No connected repos yet
                  </SelectItem>
                ) : (
                  repositories.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.ownerHandle}/{r.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          ) : (
            <Skeleton className="h-9 w-72" />
          )
        }
        quarterSlot={
          quarters.loaded ? (
            <Select value={quarter} onValueChange={setQuarter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Quarter" />
              </SelectTrigger>
              <SelectContent>
                {quarterItems.length === 0 ? (
                  <SelectItem value={NONE_QUARTER} disabled>
                    No quarters with data
                  </SelectItem>
                ) : (
                  quarterItems.map((q) => (
                    <SelectItem key={q} value={q}>
                      {q}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          ) : (
            <Skeleton className="h-9 w-40" />
          )
        }
        actionSlot={
          <Button type="button" onClick={handlePreview} disabled={!canPreview || previewing}>
            {previewing ? 'Generating…' : 'Preview summary'}
          </Button>
        }
        errorSlot={
          dropdownsError ? (
            <p className="flex items-center gap-2 text-xs text-destructive">
              <AlertTriangle aria-hidden="true" className="size-3.5" />
              Could not load picker options.
              <button
                type="button"
                onClick={() => setReloadKey((k) => k + 1)}
                className="inline-flex items-center gap-1 underline-offset-2 hover:underline"
              >
                <RefreshCcw aria-hidden="true" className="size-3" />
                Retry
              </button>
            </p>
          ) : null
        }
      />

      {showSummary && summary.data ? <AttestationSummaryView data={summary.data} /> : null}

      {showError ? (
        <div className="flex items-start gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm">
          <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 text-destructive" />
          <div className="grid flex-1 gap-1">
            <p className="font-medium text-foreground">Couldn’t build that bundle.</p>
            <p className="text-muted-foreground">{summary.error}</p>
          </div>
        </div>
      ) : null}

      {showSummary && summary.data && exportHref ? (
        <div className="flex flex-col gap-3 rounded-md border border-border/70 bg-card/80 p-5">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 inline-flex size-7 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
              <CheckCircle2 aria-hidden="true" className="size-4" />
            </span>
            <div className="grid flex-1 gap-1">
              <p className="font-display text-h4 text-foreground">Bundle ready</p>
              <p className="text-xs text-muted-foreground">
                Both files embed the same SHA-256 attestation hash. Click to download — your browser
                will save them with audit-friendly filenames.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="secondary" size="sm">
              <a
                href={`${exportHref}&format=json`}
                download={`attestation-${summary.data.meta.quarter}.json`}
              >
                <FileJson aria-hidden="true" className="size-4" />
                Download JSON
              </a>
            </Button>
            <Button asChild variant="secondary" size="sm">
              <a
                href={`${exportHref}&format=pdf`}
                download={`attestation-${summary.data.meta.quarter}.pdf`}
              >
                <FileText aria-hidden="true" className="size-4" />
                Download PDF
              </a>
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

// Local handle aliases — the picker references them like direct names so a
// refactor-reading reader sees what schema each fetch is bound to without
// digging back into the useEffect.
const RepoListSchema = RepoList;
const QuarterListDataSchema = QuarterListSchema;
