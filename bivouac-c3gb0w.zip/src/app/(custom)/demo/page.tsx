// @polsia:user-owned — public /demo route. Server Component exports metadata
// and composes a single client island; no data fetch happens at render time.

import type { Metadata } from 'next';
import { DemoBoard } from '@/components/custom/demo-board';

const title = 'Remediation demo';
const description =
  'Public before/after board of Bivouac against a deliberately outdated Node sample: 6 open Dependabot PRs, 3 security advisories, 2 breaking majors → 4 auto-merged, 1 flagged, 1 rejected, 12/12 tests green.';

export const metadata: Metadata = {
  title,
  description,
  alternates: { canonical: '/demo' },
  openGraph: {
    title,
    description,
    url: '/demo',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title,
    description,
  },
};

export default function DemoPage() {
  return (
    <main className="container-page flex flex-col gap-10 py-section">
      <header className="flex flex-col gap-4">
        <p className="text-eyebrow">Bivouac in one scroll</p>
        <h1 className="font-display text-h1 text-balance text-foreground">
          From a stale Dependabot queue to a clean repo, in one pass.
        </h1>
        <p className="max-w-3xl text-body-lg text-muted-foreground">
          A tiny, deliberately outdated Node sample holds <em>6 open Dependabot PRs</em> — including
          3 security advisories and 2 breaking majors. Bivouac analyzes every PR against the
          project&apos;s policy pack and tests, then auto-merges the safe patches, flags the
          breaking majors the team should plan around, and rejects the destructive ones. The numbers
          below come from <code>demo-bivouac/ledger.json</code> — they cannot drift from the share
          snippets or the README.
        </p>
      </header>

      <DemoBoard />
    </main>
  );
}
