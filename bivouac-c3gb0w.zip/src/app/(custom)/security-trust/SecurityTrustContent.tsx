// @polsia:user-owned — /security-trust client island. Fetches the public
// /api/security-trust payload through apiFetch + the shared zod contract, then
// renders each pillar section and an FAQ accordion. Lives in a client component
// so the Server Component page can stay metadata-only (the data plane rule
// keeps fetching off the page body).
'use client';

import { KeyRound, Lock, ScrollText, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { apiFetch } from '@/lib/api-client';
import {
  SecurityTrustDocument,
  type SecurityTrustFaqItem,
  type SecurityTrustSection,
} from '@/lib/contracts/security-trust';

const SECTION_ICONS: Record<string, typeof ShieldCheck> = {
  'data-residency': ShieldCheck,
  'encryption-in-transit': Lock,
  'encryption-at-rest': KeyRound,
  'code-handling': Lock,
  'audit-log-posture': ScrollText,
  'soc2-posture': ShieldCheck,
};

type State =
  | { kind: 'loading' }
  | { kind: 'ready'; document: SecurityTrustDocument }
  | { kind: 'error'; message: string };

export function SecurityTrustContent() {
  const [state, setState] = useState<State>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch('/api/security-trust', { schema: SecurityTrustDocument })
      .then((data) => {
        if (!active) return;
        setState({ kind: 'ready', document: data });
      })
      .catch(() => {
        if (!active) return;
        setState({
          kind: 'error',
          message: 'Could not load the security & trust page. Please try again.',
        });
      });
    return () => {
      active = false;
    };
  }, []);

  if (state.kind === 'loading') {
    return (
      <p className="text-body text-muted-foreground" aria-live="polite">
        Loading…
      </p>
    );
  }

  if (state.kind === 'error') {
    return (
      <p className="text-body text-destructive" role="alert">
        {state.message}
      </p>
    );
  }

  const { sections, faq } = state.document;

  return (
    <div className="flex flex-col gap-12">
      <div className="flex flex-col gap-10">
        {sections.map((section) => (
          <SecurityTrustPillar key={section.id} section={section} />
        ))}
      </div>

      <SecurityTrustFaq items={faq} />
    </div>
  );
}

function SecurityTrustPillar({ section }: { section: SecurityTrustSection }) {
  const Icon = SECTION_ICONS[section.id] ?? ShieldCheck;
  return (
    <section
      id={section.id}
      className="flex flex-col gap-3 rounded-lg border border-border bg-card/60 p-6 shadow-sm"
    >
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border bg-background text-brand-600 dark:text-brand-300"
        >
          <Icon className="h-5 w-5" />
        </span>
        <p className="text-eyebrow text-brand-700 dark:text-brand-300">{section.eyebrow}</p>
      </div>
      <h2 className="font-display text-h3 text-balance text-foreground">{section.title}</h2>
      <p className="max-w-3xl text-body text-muted-foreground">{section.body}</p>
    </section>
  );
}

function SecurityTrustFaq({ items }: { items: SecurityTrustFaqItem[] }) {
  return (
    <section className="flex flex-col gap-6">
      <div className="flex flex-col gap-3">
        <p className="text-eyebrow">Buyer questions</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          The questions a security reviewer will ask first.
        </h2>
        <p className="max-w-3xl text-body-lg text-muted-foreground">
          The wording throughout this page is present-tense and evidence-ready on purpose — Bivouac
          itself is not SOC 2 certified.
        </p>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-card/80 backdrop-blur-sm">
        <Accordion type="single" collapsible className="px-2">
          {items.map((item, idx) => (
            <AccordionItem key={item.q} value={`security-trust-faq-${idx}`}>
              <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
