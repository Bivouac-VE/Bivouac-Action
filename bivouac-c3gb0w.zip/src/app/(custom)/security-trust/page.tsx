// @polsia:user-owned — Public /security-trust route. Server Component: the
// page exports per-page metadata and renders the header plus the
// `<SecurityTrustContent/>` client island that fetches through
// /api/security-trust. No data fetch in the render layer — no `fetch`, no
// Prisma, no zod parse — the island owns the contract.

import { pageMetadata } from '@/lib/seo-metadata';
import { siteName, siteUrl } from '@/lib/site';
import { SecurityTrustContent } from './SecurityTrustContent';

const PAGE_TITLE = 'Security & Trust';
const PAGE_DESCRIPTION =
  'How Bivouac protects customer code and data — data residency, encryption in transit and at rest, ephemeral clones and scoped tokens, the audit-log posture, and the SOC 2 wording we use on purpose. Bivouac itself is not SOC 2 certified; the wording is present-tense and evidence-ready.';

export const metadata = pageMetadata({
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  path: '/security-trust',
});

export default function SecurityTrustPage() {
  const webPageLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: PAGE_TITLE,
    url: `${siteUrl}/security-trust`,
    publisher: { '@type': 'Organization', name: siteName },
    description:
      'How Bivouac protects customer code and data — data residency, encryption in transit and at rest, ephemeral clones and scoped tokens, the audit-log posture, and the SOC 2 wording we use on purpose. Bivouac itself is not SOC 2 certified.',
  };
  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <script
        type="application/ld+json"
        id="security-trust-webpage-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand module and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageLd) }}
      />
      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Compliance narrative</p>
        <h1 className="font-display text-h1 text-balance text-foreground">
          Security &amp; Trust at {siteName}
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          How {siteName} protects customer code and data — the controls in place, the audit-log
          posture, and the SOC 2 wording we use on purpose. The evidence is yours to replay; the
          certification is not ours to claim yet.
        </p>
      </header>

      <SecurityTrustContent />
    </main>
  );
}
