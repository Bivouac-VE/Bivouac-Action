// @polsia:user-owned — /vs hub. Server Component that exports per-page
// `metadata` and composes the two client islands (hero + hub grid). No
// `await fetch`/`await prisma`—content is static.

import type { Metadata } from 'next';
import { VsHero } from '@/components/custom/vs/vs-hero';
import { VsHubGrid } from '@/components/custom/vs/vs-hub-grid';
import { VsMatrix } from '@/components/custom/vs/vs-matrix';

export const metadata: Metadata = {
  title: 'Compare',
  description:
    'Side-by-side comparisons of Bivouac vs Dependabot, Renovate, Snyk OSS, GitHub Copilot Autofix, and GitHub Copilot Coding Agent — every row cited from the same research that powers the landing page.',
  alternates: { canonical: '/vs' },
  openGraph: {
    title: 'Bivouac vs the tools already on watch',
    description:
      'Five deep comparisons, every row traced to a verbatim finding from the landing-page research.',
    url: '/vs',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bivouac vs the tools already on watch',
    description:
      'Five deep comparisons, every row traced to a verbatim finding from the landing-page research.',
  },
};

export default function VsHubPage() {
  return (
    <main className="flex flex-col">
      <VsHero />
      <VsMatrix />
      <VsHubGrid />
    </main>
  );
}
