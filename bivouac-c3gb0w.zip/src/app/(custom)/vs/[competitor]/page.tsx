// @polsia:user-owned — /vs/[competitor] detail page. Server Component.
// `generateStaticParams` enumerates the four supported slugs; unknown slugs
// hit `notFound()` so a typo produces a clean 404 instead of stale-only data.
// Per-page metadata wires canonical and Open Graph identity.

import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { VsDetailClient } from '@/components/custom/vs/vs-detail-client';
import {
  type CompetitorSlug,
  competitorOrder,
  competitorProfiles,
} from '@/lib/business/vs-comparison';
import { siteName } from '@/lib/site';

type Params = { competitor: string };

export async function generateStaticParams(): Promise<Params[]> {
  return competitorOrder.map((competitor) => ({ competitor }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { competitor } = await params;
  if (!(competitor in competitorProfiles)) {
    return { title: 'Not found' };
  }
  const profile = competitorProfiles[competitor as CompetitorSlug];
  const path = `/vs/${profile.slug}`;
  return {
    title: profile.navLabel,
    description: `${profile.oneLiner} Three dimensions, every row cited from the landing-page research.`,
    alternates: { canonical: path },
    openGraph: {
      title: `${profile.navLabel} · ${siteName}`,
      description: `${profile.oneLiner} Three dimensions, every row cited from the landing-page research.`,
      url: path,
    },
    twitter: {
      card: 'summary_large_image',
      title: `${profile.navLabel} · ${siteName}`,
      description: `${profile.oneLiner} Three dimensions, every row cited from the landing-page research.`,
    },
  };
}

function isCompetitorSlug(value: string): value is CompetitorSlug {
  return (competitorOrder as string[]).includes(value);
}

export default async function VsDetailPage({ params }: { params: Promise<Params> }) {
  const { competitor } = await params;
  if (!isCompetitorSlug(competitor)) {
    notFound();
  }
  const profile = competitorProfiles[competitor];
  return <VsDetailClient profile={profile} competitor={profile.slug} />;
}
