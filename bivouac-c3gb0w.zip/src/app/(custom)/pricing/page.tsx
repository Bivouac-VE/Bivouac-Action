// @polsia:user-owned — Bivouac /pricing page. Server Component.
// Exports metadata (SEO) and composes a single client island.
import { PricingClient } from '@/components/custom/pricing/pricing-client';
import { PricingHero } from '@/components/custom/pricing/pricing-hero';
import { PLANS } from '@/lib/business/plans';
import { pageMetadata } from '@/lib/seo-metadata';
import { siteName } from '@/lib/site';

export const metadata = pageMetadata({
  title: 'Pricing',
  description:
    'Four plans, billed per active repository. Free for your first repo — no card to start. Scale per repo, autonomous dependency triage, transparent per-repo pricing, SLA add-ons.',
  path: '/pricing',
});

export default function PricingPage() {
  const softwareApplicationLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: siteName,
    applicationCategory: 'DeveloperApplication',
    operatingSystem: 'Web',
    offers: PLANS.map((p) => ({
      '@type': 'Offer',
      name: p.name,
      price: p.monthlyPerRepoUsd,
      priceCurrency: 'USD',
      category: p.slug,
      description: p.eyebrow,
    })),
  };
  return (
    <main className="flex flex-col">
      <script
        type="application/ld+json"
        id="softwareapplication-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned plans catalog (pure data, no user input) and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareApplicationLd) }}
      />
      <PricingHero />
      <PricingClient />
    </main>
  );
}
