// @polsia:user-owned — minimal static policy pages for /policies/<slug>. Server
// component; literal copy only. Three slugs render distinct content; any other
// slug returns 404 via notFound().

import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

type PolicySlug = 'privacy' | 'terms' | 'security';

const POLICIES: Record<
  PolicySlug,
  { title: string; summary: string; sections: { heading: string; body: string }[] }
> = {
  privacy: {
    title: 'Privacy',
    summary: 'What Bivouac stores, what we look at on your GitHub repos, and what we never see.',
    sections: [
      {
        heading: 'What we collect from your repositories',
        body: 'Bivouac reads public and private advisory feed metadata, your repository dependency manifests (package.json, lockfiles, and equivalent files in your stack), and the events those produce — pull requests, runs, and merges. We do not read source code on your repositories except the manifests the triage loop needs to operate.',
      },
      {
        heading: 'Telemetry and session data',
        body: 'We record the signals we triage, the decisions we took, and the patch PRs we opened and merged — that is the audit trail you see in the dashboard. Session data is handled inside the Bivouac app; we do not resell or share repository telemetry with third parties.',
      },
      {
        heading: 'Contact',
        body: 'For data-subject requests, write to bivouac-c3gb0w@polsia.app.',
      },
    ],
  },
  terms: {
    title: 'Terms',
    summary:
      'What you can do with Bivouac, the SLAs you can quote, and the limits of the autonomous triage loop.',
    sections: [
      {
        heading: 'Scope of service',
        body: 'Bivouac operates an autonomous triage loop on repositories you connect to the platform. The agent may open patch PRs, run your test suite on a clean checkout, and auto-merge on green under the guardrails you set per repo. Anything not classified as routine pauses at a human review.',
      },
      {
        heading: 'Guardrails are conservative by default',
        body: 'License churn, public-API breakage, security-sensitive surfaces, and failed test builds always stop for a human. Every widening of what the agent handles unattended is opt-in per repository and recorded in the audit trail.',
      },
      {
        heading: 'Contact',
        body: 'For commercial terms or fleet pricing, write to bivouac-c3gb0w@polsia.app.',
      },
    ],
  },
  security: {
    title: 'Security',
    summary:
      'How Bivouac protects the credentials it needs, the audit trail it produces, and the evidence it exports.',
    sections: [
      {
        heading: 'Credentials',
        body: 'Bivouac uses a scoped GitHub App to read advisory feeds and open patch PRs. Repository tokens are stored encrypted at rest and only mounted when the triage loop needs them.',
      },
      {
        heading: 'Audit trail',
        body: 'Every signal we triage, every decision we took, every PR we opened and merged, and every test run that gated a merge is captured in the audit trail. The trail is exportable as evidence your team can use in SOC 2, NIS2, and EU Cyber Resilience Act reviews. Bivouac is itself not certified against these frameworks.',
      },
      {
        heading: 'Contact',
        body: 'For responsible-disclosure reports, write to bivouac-c3gb0w@polsia.app.',
      },
    ],
  },
};

const ORDER: readonly PolicySlug[] = ['privacy', 'terms', 'security'];

export function generateStaticParams(): { slug: string }[] {
  return ORDER.map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  if (!(slug in POLICIES)) return {};
  const policy = POLICIES[slug as PolicySlug];
  return {
    title: policy.title,
    description: policy.summary,
    alternates: { canonical: `/policies/${slug}` },
    openGraph: {
      title: `${policy.title} · Bivouac`,
      description: policy.summary,
      url: `/policies/${slug}`,
    },
    twitter: {
      card: 'summary',
      title: `${policy.title} · Bivouac`,
      description: policy.summary,
    },
  };
}

export default async function PolicyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!(slug in POLICIES)) notFound();
  const policy = POLICIES[slug as PolicySlug];

  return (
    <main className="flex flex-col">
      <section className="container-page flex flex-col gap-6 pt-section-lg pb-section">
        <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
          <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
            Policy
          </span>
        </Badge>
        <h1 className="font-display text-h1 text-balance text-foreground">{policy.title}</h1>
        <p className="max-w-3xl text-body-lg text-muted-foreground">{policy.summary}</p>
        <Separator />
        <div className="flex flex-col gap-8 max-w-3xl">
          {policy.sections.map((section) => (
            <div key={section.heading} className="flex flex-col gap-2">
              <h2 className="font-display text-h3 text-foreground">{section.heading}</h2>
              <p className="text-body text-muted-foreground">{section.body}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
