// @polsia:user-owned — /blog/[slug] Server Component. `generateMetadata` reads
// the published Post server-side (via the user-owned helper in
// src/lib/business/blog-meta.ts — the page never imports @/lib/db directly,
// so the biome noRestrictedImports gate stays green) and assembles the full
// SEO surface through src/lib/seo-metadata.ts: canonical URL, Open Graph
// (article, title, description, image, publishedTime, modifiedTime, authors),
// Twitter card (summary_large_image + image) — all driven by
// Post.title / excerpt / publishedAt. The matching BlogPosting JSON-LD
// payload is rendered by the page body itself (via `blogPostingLd`) so it
// ships in the SSR HTML and is unchanged on hydrate (no client-side JSON-LD
// upgrade is needed).
//
// `generateStaticParams` enumerates every published slug so the route is
// statically prerendered and the metadata + JSON-LD both ship in the initial
// HTML — the same response Googlebot, Rich Results test, and human visitors
// see.

import type { Metadata } from 'next';
import Link from 'next/link';
import { PostViewIsland } from '@/components/custom/blog/post-view';
import {
  listPublishedPostSlugs,
  loadPublishedPostMeta,
  type PostMeta,
} from '@/lib/business/blog-meta';
import { blogPostingLd, blogPostMetadata } from '@/lib/seo-metadata';

type Params = { slug: string };

export async function generateStaticParams(): Promise<Params[]> {
  const posts = await listPublishedPostSlugs();
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { slug } = await params;
  const post: PostMeta | null = await loadPublishedPostMeta(slug);
  if (!post) return {};
  return blogPostMetadata(post);
}

export default async function BlogPostPage({ params }: { params: Promise<Params> }) {
  const { slug } = await params;
  // Drive the BlogPosting JSON-LD from the same Post row metadata reads —
  // guarantees the structured-data payload is identical to what
  // generateMetadata surfaces in OG/Twitter so Rich Results test see one
  // canonical page. The /api/posts/[slug] route handler still owns the body
  // markdown rendered by the client island (separation of SEO metadata from
  // page render data).
  const post = await loadPublishedPostMeta(slug);
  const ldJson = post ? blogPostingLd(post, slug) : null;

  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <nav className="text-small text-muted-foreground">
        <Link
          href="/blog"
          className="underline decoration-dotted underline-offset-4 hover:text-foreground"
        >
          ← Back to the blog
        </Link>
      </nav>
      {ldJson ? (
        <script
          type="application/ld+json"
          // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; payload is server-derived from the published Post row and run through JSON.stringify (safe-encoded).
          dangerouslySetInnerHTML={{ __html: JSON.stringify(ldJson) }}
        />
      ) : null}
      <PostViewIsland slug={slug} />
    </main>
  );
}
