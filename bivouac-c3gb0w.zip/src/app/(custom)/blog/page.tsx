// @polsia:user-owned — /blog index. Server Component (exports metadata for
// SEO) composing the static header + the PostListIsland. No data fetch in
// the render layer; the client island reads /api/posts.

import { BlogHeader } from '@/components/custom/blog/blog-header';
import { PostListIsland } from '@/components/custom/blog/post-list';
import { pageMetadata } from '@/lib/seo-metadata';
import { siteDescription } from '@/lib/site';

export const metadata = pageMetadata({
  title: 'Blog',
  description: `Field reports from the Bivouac team — CVE handling benchmarks, dependency-manager comparisons, and what an autonomous triage loop does overnight. ${siteDescription}`,
  path: '/blog',
});

export default function BlogIndexPage() {
  return (
    <main className="flex flex-col">
      <BlogHeader />
      <section className="container-page mt-section flex flex-col gap-6">
        <PostListIsland />
      </section>
    </main>
  );
}
