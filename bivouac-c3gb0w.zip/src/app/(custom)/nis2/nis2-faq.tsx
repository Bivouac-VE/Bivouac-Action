// @polsia:user-owned — NIS2 buyer FAQ. Client island (uses the radix-backed
// <Accordion/>). Static literal copy; no apiFetch, no state.

'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ: { q: string; a: string }[] = [
  {
    q: 'Does Bivouac qualify as a tool my auditor will accept as evidence?',
    a: 'Yes — the signed export at /dashboard/attest is the artifact your auditor replays. Every patch event carries its CVE id, signal source, policy-pack decision, test outcome, merge-vs-human-override flag, and SBOM provenance. The attestation hash is deterministic, so the same data always hashes to the same root. Auditors verify the hash on the JSON and the same hash on the PDF cover; they match.',
  },
  {
    q: 'Can I scope by supplier, package ecosystem, or business unit?',
    a: 'Yes. Connect repos per BU or per supplier, and pick a policy pack per repo. The signed bundle is per repo per quarter, and the SBOM rollup inside it filters to what you actually shipped — direct and transitive edges with versions, not just top-level dependencies.',
  },
  {
    q: 'How do you handle the OES vs DSP distinction?',
    a: 'The data plane is the same in both regimes — patch event, test outcome, merge decision, SBOM provenance. What differs is reporting cadence and audience, which your policy pack encodes. Article 23 timelines are met because the merge log is the report; there is no separate paper trail to keep aligned with the code.',
  },
  {
    q: 'What happens when a patch PR fails tests?',
    a: 'The merge is blocked. The signal stays open, the failure is recorded against the same row in the merge log, and the on-call rotation is paged only when the contested decision is something the policy pack flagged as security-sensitive or license-sensitive. Nothing is silently dropped — the failed run is in the signed bundle with the failing check name.',
  },
  {
    q: 'Is data isolated per tenant?',
    a: 'Yes. Repos, patch events, test outcomes, SBOM rollups, and the signed export are scoped per tenant. The attestation hash is computed over your rows, so two tenants generating the same data never produce the same root — there is no cross-tenant leak in the bundle.',
  },
];

export function Nis2Faq() {
  return (
    <section className="section relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 hidden md:block" aria-hidden>
        <svg
          viewBox="0 0 600 400"
          className="absolute -left-32 top-10 h-[480px] w-[480px] text-brand-500/10"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative isometric grid</title>
          <defs>
            <pattern id="nis2-iso-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 0 24 L 24 0 L 48 24 L 24 48 Z" strokeWidth="0.4" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="600" height="400" fill="url(#nis2-iso-grid)" />
        </svg>
      </div>

      <div className="container-page relative flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">NIS2 buyer questions</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            The questions your auditor and your CISO will ask first.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Bivouac produces the evidence your team hands to the auditor — it isn&apos;t itself NIS2
            certified.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card/80 backdrop-blur-sm">
          <Accordion type="single" collapsible className="px-2">
            {FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`nis2-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
