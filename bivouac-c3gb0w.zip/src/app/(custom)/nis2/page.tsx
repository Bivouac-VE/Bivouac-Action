// @polsia:user-owned — /nis2 landing page. Server Component; exports per-page
// metadata, schema.org WebPage payload, and composes the six sibling sections
// (Hero, ObligationsMap, ProofPanel, EvidenceTrail, Faq, FinalCta). No
// `await fetch`/`await prisma` — content is static and the auth-aware CTA is a
// tiny client island.

import type { Metadata } from 'next';
import { siteName, siteUrl } from '@/lib/site';
import { Nis2EvidenceTrail } from './nis2-evidence-trail';
import { Nis2Faq } from './nis2-faq';
import { Nis2FinalCta } from './nis2-final-cta';
import { Nis2Hero } from './nis2-hero';
import { Nis2ObligationsMap } from './nis2-obligations-map';
import { Nis2ProofPanel } from './nis2-proof-panel';

export const metadata: Metadata = {
  title: 'Bivouac for NIS2',
  description:
    'Supply-chain and dependency-risk evidence for NIS2 — every CVE → fix → test → merge decision recorded with deterministic hashing, exportable per quarter from /dashboard/attest. Bivouac itself is not NIS2 certified.',
  alternates: { canonical: '/nis2' },
  openGraph: {
    title: 'Bivouac for NIS2',
    description:
      'NIS2 supply-chain and dependency-risk evidence, exported as a signed bundle per quarter for your audit pack — every merge attached to a deterministic hash. Bivouac itself is not NIS2 certified.',
    url: '/nis2',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bivouac for NIS2',
    description:
      'NIS2 supply-chain and dependency-risk evidence, exported as a signed bundle per quarter for your audit pack — every merge attached to a deterministic hash. Bivouac itself is not NIS2 certified.',
  },
};

export default function Nis2Page() {
  const webPageLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Bivouac for NIS2',
    url: `${siteUrl}/nis2`,
    publisher: { '@type': 'Organization', name: siteName },
    description:
      'How Bivouac produces NIS2 supply-chain and dependency-risk evidence: every CVE → fix → test → merge decision recorded with deterministic hashing, bundled per quarter, and downloadable from /dashboard/attest. Bivouac itself is not NIS2 certified.',
  };
  return (
    <main className="flex flex-col">
      <script
        type="application/ld+json"
        id="nis2-webpage-ldjson"
        // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; fields are server-derived from the user-owned brand module and run through JSON.stringify (safe-encoded), so the emitted HTML is a syntactically valid JSON object with zero injection surface.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageLd) }}
      />
      <Nis2Hero />
      <Nis2ObligationsMap />
      <Nis2ProofPanel />
      <Nis2EvidenceTrail />
      <Nis2Faq />
      <Nis2FinalCta />
    </main>
  );
}
