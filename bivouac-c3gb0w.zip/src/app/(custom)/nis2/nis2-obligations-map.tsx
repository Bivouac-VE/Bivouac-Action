// @polsia:user-owned — NIS2 obligations map. Server component: two columns
// (NIS2 article references + how Bivouac addresses each), static copy.

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type Obligation = {
  ref: string;
  title: string;
  bivouac: string;
};

const OBLIGATIONS: Obligation[] = [
  {
    ref: 'Article 21(2)(d)',
    title: 'Supply-chain security, including security-related aspects of supplier relationships',
    bivouac:
      'Every dependency edge — direct and transitive — is enumerated per quarter in the SBOM rollup, with the version that shipped to production tagged. Vendor advisories attach to the exact package and version they affected.',
  },
  {
    ref: 'Article 21(2)(e)',
    title: 'Security in network and information systems acquisition, development and maintenance',
    bivouac:
      'Patch PRs open against the actual project repo, run the actual test suite, and merge only when green. The full chain — signal, policy-pack decision, test run, merge — is recorded, not just the resulting commit.',
  },
  {
    ref: 'Article 21(2)(b)',
    title: 'Incident handling — prevention, detection, and response',
    bivouac:
      'A new CVE fires a signal within minutes. The policy pack pre-classifies the move (forward fix, downgrade, pin) and a draft PR is in front of you with the test outcome attached as a status check.',
  },
  {
    ref: 'Article 21(2)(c)',
    title: 'Business continuity and crisis management, including backup management',
    bivouac:
      'Auto-merged patch PRs keep the production tree green without waiting for an on-call rotation. The merge log shows who or what produced the decision — agent or human override — at every widening.',
  },
  {
    ref: 'Article 23',
    title: 'Reporting obligations — early warning, incident notification, and final report',
    bivouac:
      'Every patch carries its CVE id, the upstream disclosure date, and the merge timestamp in the same row. The signed bundle is the report — there is no separate paper trail to keep aligned with the code.',
  },
];

export function Nis2ObligationsMap() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Article 21 mapped to the merge log</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            What NIS2 asks for, and what Bivouac already records.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            The obligations on the left are the law. The matchings on the right are what your
            auditor replays when they ask for evidence — already captured per merge, no
            end-of-quarter rebuild required. Bivouac supports your NIS2 evidence workflow; Bivouac
            is itself not certified against the framework.
          </p>
        </div>

        <Card className="overflow-hidden border-border bg-card">
          <CardHeader className="border-b border-border bg-muted/40 pb-3">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr]">
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                NIS2 obligation
              </CardTitle>
              <CardTitle className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                Bivouac evidence
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ol className="divide-y divide-border">
              {OBLIGATIONS.map((row) => (
                <li key={row.ref} className="grid grid-cols-1 gap-4 p-6 md:grid-cols-[1fr_1fr]">
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                      {row.ref}
                    </span>
                    <p className="text-body text-foreground">{row.title}</p>
                  </div>
                  <p className="text-body text-muted-foreground">{row.bivouac}</p>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
