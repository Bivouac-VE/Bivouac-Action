// @polsia:user-owned — GET /api/attestation/quarters. Distinct quarters the
// signed-in user has data for, computed from CveTriageLog.createdAt scoped
// via prUrl-contains OR-clauses per `loadInsightsOverview` + the seeded
// PolicyVersion.effectiveFrom list + the current quarter (so a brand-new
// account isn't empty).

import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { listQuartersForUser } from '@/lib/business/attestation';
import { QuarterList } from '@/lib/contracts/attestation';

export const dynamic = 'force-dynamic';

async function requireAdminJson(): Promise<
  { ok: true; userId: string } | { ok: false; response: Response }
> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }),
    };
  }
  if (session.user.role !== 'admin') {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Forbidden' }, { status: 403 }),
    };
  }
  return { ok: true, userId: session.user.id };
}

export async function GET() {
  const gate = await requireAdminJson();
  if (!gate.ok) return gate.response;
  try {
    const items = await listQuartersForUser(gate.userId);
    return NextResponse.json(QuarterList.parse({ items }), { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
