// @polsia:user-owned — GET /api/attestation/export. Auth-gated download of the
// canonical bundle as JSON or PDF. Two branches:
//   - format=json → application/json with Content-Disposition: attachment
//   - format=pdf  → application/pdf via the installed pdf module's renderer
// Both bundles include the attestation hash embedded in the file body — the
// JSON has a top-level `attestation.hash` field; the PDF stamps it on the
// cover page.

import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { buildAttestationBundle } from '@/lib/business/attestation';
import { QuarterIdEnum } from '@/lib/contracts/attestation';
import { prisma } from '@/lib/db';
import { renderDocumentPdf } from '@/lib/pdf/client';
import type { DocumentSpec } from '@/lib/pdf/schema';

export const dynamic = 'force-dynamic';

const ALLOWED_FORMATS = new Set(['json', 'pdf']);

function badRequest(message: string): Response {
  return new Response(JSON.stringify({ error: message }), {
    status: 400,
    headers: { 'content-type': 'application/json' },
  });
}

async function requireAdminJson(): Promise<
  { ok: true; userId: string } | { ok: false; response: Response }
> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }),
    };
  }
  if (session.user.role !== 'admin') {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Forbidden' }, { status: 403 }),
    };
  }
  return { ok: true, userId: session.user.id };
}

export async function GET(req: Request) {
  const gate = await requireAdminJson();
  if (!gate.ok) return gate.response;
  const userId = gate.userId;
  try {
    const url = new URL(req.url);
    const repoId = url.searchParams.get('repoId');
    const quarter = url.searchParams.get('quarter');
    const format = url.searchParams.get('format') ?? 'json';

    if (!repoId) return badRequest('Missing repoId');
    const quarterParsed = QuarterIdEnum.safeParse(quarter);
    if (!quarterParsed.success) return badRequest('Invalid quarter');
    if (!ALLOWED_FORMATS.has(format)) return badRequest('Invalid format');

    const bundle = await buildAttestationBundle(userId, repoId, quarterParsed.data);
    if (!bundle) {
      return new Response(JSON.stringify({ error: 'Repository not found' }), {
        status: 404,
        headers: { 'content-type': 'application/json' },
      });
    }

    // Audit-row write BEFORE the response body: even if the streaming path
    // fails after this, the user did request the bundle, and the audit trail
    // records that fact. On create failure, return 500 before any bytes go
    // out so the user can retry from a consistent state.
    try {
      await prisma.attestationDownload.create({
        data: {
          userId,
          repoId: bundle.meta.repoId,
          ownerHandle: bundle.meta.ownerHandle,
          repoName: bundle.meta.name,
          quarter: bundle.meta.quarter,
          format,
          bundleHash: bundle.attestation.hash,
        },
      });
    } catch {
      return new Response(JSON.stringify({ error: 'Audit log write failed' }), {
        status: 500,
        headers: { 'content-type': 'application/json' },
      });
    }

    const baseName = `${bundle.meta.ownerHandle}-${bundle.meta.name}-${bundle.meta.quarter}`;
    const filename = `attestation-${baseName}.${format}`;

    if (format === 'json') {
      // Pretty-printed so a human auditor can read the file without tooling.
      const body = JSON.stringify(bundle, null, 2);
      return new Response(body, {
        status: 200,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-disposition': `attachment; filename="${filename}"`,
          'cache-control': 'no-store',
        },
      });
    }

    // format === 'pdf'
    const spec = buildPdfSpec(bundle);
    const bytes = await renderDocumentPdf(spec);
    // pdf-lib returns a Uint8Array; copy into a fresh ArrayBuffer-backed buffer
    // so Response accepts it across runtimes.
    const buffer = new Uint8Array(bytes);
    return new Response(buffer, {
      status: 200,
      headers: {
        'content-type': 'application/pdf',
        'content-disposition': `attachment; filename="${filename}"`,
        'content-length': String(buffer.byteLength),
        'cache-control': 'no-store',
      },
    });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return new Response('Internal Server Error', { status: 500 });
  }
}

function buildPdfSpec(
  bundle: import('@/lib/contracts/attestation').AttestationBundle,
): DocumentSpec {
  const metaRows: { label: string; value: string }[] = [
    { label: 'Repository', value: `${bundle.meta.ownerHandle}/${bundle.meta.name}` },
    { label: 'Repository id', value: bundle.meta.repoId },
    { label: 'User id', value: bundle.meta.userId },
    { label: 'Quarter', value: bundle.meta.quarter },
    { label: 'Generated', value: bundle.meta.generatedAt },
    { label: 'Policy version', value: bundle.meta.policyVersion.version },
    {
      label: 'Policy effective',
      value: `${bundle.meta.policyVersion.effectiveFrom.slice(0, 10)} → ${
        bundle.meta.policyVersion.effectiveTo
          ? bundle.meta.policyVersion.effectiveTo.slice(0, 10)
          : 'present'
      }`,
    },
    { label: 'Attestation hash', value: bundle.attestation.hash },
  ];

  const patchCount = Object.values(bundle.counts.patches).reduce((sum, n) => sum + n, 0);
  const lines: { label: string; value: string }[] = [
    {
      label: 'Patches opened',
      value: `${patchCount}  (low=${bundle.counts.patches.low}, medium=${bundle.counts.patches.medium}, high=${bundle.counts.patches.high}, critical=${bundle.counts.patches.critical})`,
    },
    { label: 'Human overrides', value: String(bundle.counts.overrides) },
    {
      label: 'Mean time to patch',
      value:
        bundle.mttp.valueDays === null
          ? '— (no terminal-decision samples)'
          : `${bundle.mttp.valueDays.toFixed(2)} days (n=${bundle.mttp.sampleSize})`,
    },
    { label: 'Remediated CVEs', value: String(bundle.cveIdsRemediated.length) },
    {
      label: 'SBOM rollup',
      value: `${bundle.sbom.packagesTouched} packages touched across ${
        Object.keys(bundle.sbom.ecosystems).length
      } ecosystem(s) (${Object.entries(bundle.sbom.ecosystems)
        .map(([eco, n]) => `${eco}=${n}`)
        .join(', ')})`,
    },
  ];

  const overrideList =
    bundle.overrides.length === 0
      ? [{ description: 'No human overrides in this quarter.' }]
      : bundle.overrides.map((o) => ({
          description: `${o.cveId}  ${o.packageName} ${o.fromVersion} → ${o.toVersion}  (${o.mergeDecision})  repo ${o.repo}`,
        }));

  const eventList =
    bundle.patchEvents.length === 0
      ? [{ description: 'No patch events in this quarter.' }]
      : bundle.patchEvents.map((e) => ({
          description: `${e.createdAt.slice(0, 10)}  ${e.cveId}  ${e.severity}  ${e.packageName} ${e.fromVersion} → ${e.toVersion}  upstreamRef=${e.upstreamSha ?? 'n/a'}  (${e.mergeDecision})`,
        }));

  const cveList =
    bundle.cveIdsRemediated.length === 0
      ? [{ description: 'No CVE IDs remediated in this quarter.' }]
      : bundle.cveIdsRemediated.map((id) => ({ description: id }));

  return {
    title: `Attestation — ${bundle.meta.ownerHandle}/${bundle.meta.name} — ${bundle.meta.quarter}`,
    subtitle: bundle.meta.policyVersion.title,
    meta: metaRows,
    lineItems: lines.map((l) => ({
      // The PDF schema only exposes `description`, so fold the value into the
      // line so a human auditor can read both halves off the cover page.
      description: `${l.label}: ${l.value}`,
      quantity: 1,
      // unitAmountCents is required by the schema; we paste a 0 here because
      // the attestation is purely informational — there is no charge.
      unitAmountCents: 0,
    })),
    notes: [
      ...overrideList.map((o) => `OVERRIDE: ${o.description}`),
      ...eventList.map((e) => `EVENT: ${e.description}`),
      ...cveList.map((c) => `CVE: ${c.description}`),
    ].join('\n'),
    footer: `Attestation hash: ${bundle.attestation.hash}`,
  };
}
