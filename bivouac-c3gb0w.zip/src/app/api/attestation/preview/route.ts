// @polsia:user-owned — POST /api/attestation/preview. Returns the lighter
// `AttestationSummary` (no patchEvents list) for the picked repo + quarter so
// the picker can render KPI tiles without dragging the full event log into the
// round-trip. Uses the same `buildAttestationBundle` so this is a STABLE preview
// of what the export will write.

import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { buildAttestationBundle, buildAttestationSummary } from '@/lib/business/attestation';
import { AttestationPreviewRequest } from '@/lib/contracts/attestation';

export const dynamic = 'force-dynamic';

async function requireAdminJson(): Promise<
  { ok: true; userId: string } | { ok: false; response: Response }
> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }),
    };
  }
  if (session.user.role !== 'admin') {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Forbidden' }, { status: 403 }),
    };
  }
  return { ok: true, userId: session.user.id };
}

export async function POST(req: Request) {
  const gate = await requireAdminJson();
  if (!gate.ok) return gate.response;
  try {
    const body = (await req.json()) as unknown;
    const parsed = AttestationPreviewRequest.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid request body', details: parsed.error.flatten() },
        { status: 400 },
      );
    }
    const bundle = await buildAttestationBundle(
      gate.userId,
      parsed.data.repoId,
      parsed.data.quarter,
    );
    if (!bundle) {
      return NextResponse.json({ error: 'Repository not found' }, { status: 404 });
    }
    return NextResponse.json(buildAttestationSummary(bundle), { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
