// @polsia:user-owned — GET /api/attestation/repos. Connected repos for the
// picker. Same shape and scoping as /api/repos so a change there rolls in
// automatically. Uses the dev-friendly session helper so the picker stays
// queryable during local development (server-side anon sees `dev-user`).

import 'server-only';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { RepoList } from '@/lib/contracts/repos';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function requireAdminJson(): Promise<
  { ok: true; userId: string } | { ok: false; response: Response }
> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }),
    };
  }
  if (session.user.role !== 'admin') {
    return {
      ok: false,
      response: NextResponse.json({ error: 'Forbidden' }, { status: 403 }),
    };
  }
  return { ok: true, userId: session.user.id };
}

export async function GET() {
  const gate = await requireAdminJson();
  if (!gate.ok) return gate.response;

  const rows = await prisma.repo.findMany({
    where: { userId: gate.userId },
    orderBy: { createdAt: 'desc' },
  });

  const payload = RepoList.parse({
    items: rows.map((r) => ({
      id: r.id,
      name: r.name,
      ownerHandle: r.ownerHandle,
      lastScannedAt: r.lastScannedAt?.toISOString() ?? null,
      status: r.status,
    })),
  });
  return NextResponse.json(payload, { status: 200 });
}
