// @polsia:user-owned — POST /api/digest-webhook/test. Manual canary: POSTs a
// fixed-shape summary payload to the user's saved URL exactly as the cron
// will at 08:00 UTC, with a per-webhook HMAC signing header. Returns the
// result (statusCode + truncated error) and writes a DigestDelivery row with
// `runDay = canary-<ISO>` so the UI can render it.
//
// Auth-gated via requireAuth; per-user row lookup scoped by user.id. 412 when
// the user hasn't configured a URL yet (mirrors the cron behaviour: nothing
// to dispatch).

import 'server-only';
import { NextResponse } from 'next/server';
import {
  canaryRunDay,
  previewError,
  signPayload,
  validateOutboundUrl,
} from '@/lib/business/digest-webhook';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

const TIMEOUT_MS = 10_000;

interface PostResult {
  status: 'delivered' | 'failed';
  statusCode: number | null;
  error: string | null;
}

async function postWithTimeout(
  url: string,
  headers: Record<string, string>,
  body: string,
): Promise<PostResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body,
      signal: controller.signal,
    });
    if (res.ok) return { status: 'delivered', statusCode: res.status, error: null };
    const detail = await res.text().catch(() => '');
    return {
      status: 'failed',
      statusCode: res.status,
      error: detail || `HTTP ${res.status}`,
    };
  } catch (err: unknown) {
    const message =
      err instanceof Error
        ? err.name === 'AbortError'
          ? `Request timed out after ${TIMEOUT_MS}ms`
          : err.message
        : 'Network error';
    return { status: 'failed', statusCode: null, error: message };
  } finally {
    clearTimeout(timer);
  }
}

function selfHost(): string | null {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? process.env.BETTER_AUTH_URL ?? '';
  if (!appUrl) return null;
  try {
    const parsed = new URL(appUrl);
    return parsed.hostname.trim().toLowerCase();
  } catch {
    return null;
  }
}

export async function POST(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  // Lazy import to keep server-only envelope tight on cold start.
  const { prisma } = await import('@/lib/db');

  const row = await prisma.digestWebhook.findUnique({ where: { userId: user.id } });
  if (!row || !row.url) {
    return NextResponse.json(
      { error: 'No webhook configured. Save a URL first.' },
      { status: 412 },
    );
  }

  // Re-validate at fetch time — DNS between SAVE and the canary could swing
  // into a private range. Same rule applies during the cron.
  const validation = await validateOutboundUrl(row.url, { selfHost: selfHost() });
  if (!validation.ok) {
    const runDay = canaryRunDay();
    await prisma.digestDelivery.create({
      data: {
        userId: user.id,
        webhookId: row.id,
        runDay,
        status: 'failed',
        attempts: 1,
        lastStatusCode: null,
        lastError: previewError(`SSRF check failed at fetch time: ${validation.reason}`),
        sentAt: null,
      },
    });
    return NextResponse.json(
      { status: 'failed', statusCode: null, error: validation.reason, runDay },
      { status: 200 },
    );
  }

  const now = new Date();
  const runDay = canaryRunDay(now);
  const body = JSON.stringify({
    kind: 'daily-digest-canary',
    day: now.toISOString().slice(0, 10),
    at: now.toISOString(),
    totals: { autoMerged: 0, cveOpened: 0, humanOverrides: 0 },
  });

  const headers: Record<string, string> = {
    'content-type': 'application/json',
    'user-agent': 'bivouac-digest-webhook/1.0',
    'x-bivouac-digest-kind': 'canary',
  };
  if (row.signingSecret) {
    headers['x-bivouac-digest-signature'] = signPayload(row.signingSecret, body);
  }

  let result: PostResult;
  try {
    result = await postWithTimeout(row.url, headers, body);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'network_error';
    result = { status: 'failed', statusCode: null, error: message };
  }

  await prisma.digestDelivery.create({
    data: {
      userId: user.id,
      webhookId: row.id,
      runDay,
      status: result.status,
      attempts: 1,
      lastStatusCode: result.statusCode,
      lastError: previewError(result.error),
      sentAt: result.status === 'delivered' ? now : null,
    },
  });

  return NextResponse.json(
    {
      status: result.status,
      statusCode: result.statusCode,
      error: result.error,
      runDay,
    },
    { status: 200 },
  );
}
