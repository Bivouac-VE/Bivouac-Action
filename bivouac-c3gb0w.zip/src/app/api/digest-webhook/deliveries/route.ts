// @polsia:user-owned — GET /api/digest-webhook/deliveries. Returns the user's
// most recent 20 DigestDelivery rows (cron + canary) joined to the URL prefix
// so the dashboard deliveries table doesn't need a second round-trip to
// DigestWebhook. Cascading delete is not modeled (digestWebhook has no
// `onDelete: Cascade` back-fk — User is framework-owned), so we LEFT JOIN
// manually via a second lookup rather than relying on a Prisma `include`.

import 'server-only';
import { NextResponse } from 'next/server';
import { previewError, previewUrl } from '@/lib/business/digest-webhook';
import { DigestDeliveryRow } from '@/lib/contracts/digest-webhook';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

const LIMIT = 20;

interface DeliveryWithUrl {
  id: string;
  runDay: string;
  status: string;
  attempts: number;
  lastStatusCode: number | null;
  lastError: string | null;
  sentAt: Date | null;
  createdAt: Date;
  url: string | null;
}

function toRow(item: DeliveryWithUrl) {
  const status = (['delivered', 'failed', 'pending'] as const).includes(
    item.status as 'delivered' | 'failed' | 'pending',
  )
    ? (item.status as 'delivered' | 'failed' | 'pending')
    : 'failed';
  return {
    id: item.id,
    runDay: item.runDay,
    status,
    attempts: item.attempts,
    lastStatusCode: item.lastStatusCode,
    lastError: previewError(item.lastError),
    sentAt: item.sentAt ? item.sentAt.toISOString() : null,
    createdAt: item.createdAt.toISOString(),
    urlPreview: previewUrl(item.url ?? '(no url)'),
  };
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const webhookRows = await prisma.digestWebhook.findMany({
    where: { userId: user.id },
    select: { id: true, url: true },
  });
  const urlByWebhookId = new Map<string, string>(webhookRows.map((r) => [r.id, r.url] as const));
  const webhookIds = webhookRows.map((r) => r.id);

  // No webhook yet — an empty list is still a valid response.
  const deliveryRows =
    webhookIds.length === 0
      ? []
      : await prisma.digestDelivery.findMany({
          where: { userId: user.id, webhookId: { in: webhookIds } },
          orderBy: { createdAt: 'desc' },
          take: LIMIT,
        });

  const items = deliveryRows.map((row) =>
    toRow({ ...row, url: urlByWebhookId.get(row.webhookId) ?? null }),
  );
  const parsed = { items: items.map((r) => DigestDeliveryRow.parse(r)) };

  return NextResponse.json(parsed, { status: 200 });
}
