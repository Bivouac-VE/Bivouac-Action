// @polsia:user-owned — GET + PUT /api/digest-webhook. Per-user configuration:
// the outbound URL, the enabled flag, and the last-write timestamp.
//
// Modeled on /api/digest-prefs — owner-scoped reads/writes, server-only,
// `dynamic = 'force-dynamic'`. Upserts a disabled row on first read so the
// GET never returns 404 (mirrors digest-prefs).

import 'server-only';
import { NextResponse } from 'next/server';
import { generateSigningSecret, validateOutboundUrl } from '@/lib/business/digest-webhook';
import { DigestWebhookInput } from '@/lib/contracts/digest-webhook';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

interface DigestWebhookRow {
  url: string;
  enabled: boolean;
  updatedAt: Date;
}

function toJson(row: DigestWebhookRow) {
  return {
    url: row.url,
    enabled: row.enabled,
    updatedAt: row.updatedAt.toISOString(),
  };
}

function selfHost(): string | null {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? process.env.BETTER_AUTH_URL ?? '';
  if (!appUrl) return null;
  try {
    const parsed = new URL(appUrl);
    return parsed.hostname.trim().toLowerCase();
  } catch {
    return null;
  }
}

async function loadOrSeedRow(user: SessionUser) {
  return prisma.digestWebhook.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      url: '',
      enabled: false,
      signingSecret: generateSigningSecret(),
    },
    update: {},
  });
}

export async function GET(_req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(_req);
  } catch (res) {
    return res as Response;
  }

  const row = await loadOrSeedRow(user);
  // Untouched, just-seeded rows show up blank in the UI.
  const isUntouched = row.url.length === 0 && !row.enabled;
  return NextResponse.json(
    {
      url: isUntouched ? null : row.url,
      enabled: row.enabled,
      updatedAt: isUntouched ? null : row.updatedAt.toISOString(),
    },
    { status: 200 },
  );
}

export async function PUT(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  let input: { url: string; enabled: boolean };
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    input = DigestWebhookInput.parse(json);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'invalid_request' },
      { status: 400 },
    );
  }

  const validation = await validateOutboundUrl(input.url, { selfHost: selfHost() });
  if (!validation.ok) {
    return NextResponse.json({ error: validation.reason }, { status: 400 });
  }

  const row = await prisma.digestWebhook.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      url: input.url,
      enabled: input.enabled,
      signingSecret: generateSigningSecret(),
    },
    update: {
      url: input.url,
      enabled: input.enabled,
    },
  });

  return NextResponse.json(toJson(row), { status: 200 });
}
