// @polsia:user-owned — GET /api/billing/portal-session. Tells the
// /dashboard/billing "Manage in Stripe" button where Stripe's hosted customer
// portal is and whether it's currently available.
//
// The Polsia billing proxy exposes subscription-state, fulfillment, and
// checkout (createCheckoutSession, verifyCheckoutSession, listPaymentEvents,
// getSubscriptionStatus) but NOT Stripe's hosted customer portal — the
// Stripe SDK is forbidden and no platform endpoint mints a portal URL today.
// So this route reports `available: false` and the island renders the same
// "use Switch plan → Starter to step down" copy that the /settings/billing
// surface already falls back to.
//
// Auth: 401 if anonymous (mirrors /api/billing/invoices + /api/billing/state).
// On any "billing not configured" error (StripeBillingConfigurationError /
// StripeBillingNotEnabledError / StripeBillingOnboardingError) the route
// still returns 200 with `available: false` so the UI can render the in-app
// fallback without a separate error arm. The island does not show a 5xx here
// — the user is signed-in; showing a 503 toast here would be worse UX than
// the friendly "portal is not wired yet" copy.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  PortalSessionResponse,
  type PortalSessionResponse as PortalSessionResponseT,
} from '@/lib/contracts/billing';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Stripe's hosted customer portal is not wired yet through the Polsia proxy;
  // surface the in-app fallback URL so a future wiring only has to flip
  // `available: true` and return a Stripe-hosted portal URL from a new endpoint.
  const payload: PortalSessionResponseT = PortalSessionResponse.parse({
    url: '/dashboard/billing',
    available: false,
  });
  const out = NextResponse.json(payload);
  out.headers.set('cache-control', 'no-store');
  return out;
}
