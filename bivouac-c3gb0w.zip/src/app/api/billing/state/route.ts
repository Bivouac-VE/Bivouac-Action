// @polsia:user-owned — GET /api/billing/state. Returns the caller's current
// plan, repo count, and active SLA add-ons for the /settings/billing surface.
// Always returns 200 + a nullable `plan` so the client island can show its
// "no plan yet" empty state without a special error arm.

import 'server-only';
import { NextResponse } from 'next/server';
import { BillingState, type BillingState as BillingStateT } from '@/lib/contracts/billing';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const [plan, repoCount, addonRows] = await Promise.all([
    prisma.billingPlan.findUnique({ where: { userId: session.userId } }),
    prisma.repo.count({ where: { userId: session.userId } }),
    prisma.billingAddon
      .findMany({
        where: { userId: session.userId },
        orderBy: { createdAt: 'asc' },
      })
      .catch(() => []),
  ]);

  const payload: BillingStateT = BillingState.parse({
    plan: plan
      ? {
          id: plan.id,
          slug: plan.slug,
          monthlyPerRepoUsd: plan.monthlyPerRepoUsd,
          paidRepoCount: plan.paidRepoCount,
          repoLimit: plan.repoLimit,
          status: plan.status,
          currentPeriodEnd: plan.currentPeriodEnd?.toISOString() ?? null,
          cancelAtPeriodEnd: plan.cancelAtPeriodEnd,
        }
      : null,
    repoCount,
    addons: addonRows.map((row) => ({
      id: row.id,
      slug: row.slug as '+24h-critical-sla' | '+business-hours-paging',
      label: row.label,
      monthlyUsd: row.monthlyUsd,
    })),
  });
  return NextResponse.json(payload);
}
