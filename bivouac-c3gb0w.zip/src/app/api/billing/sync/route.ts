// @polsia:user-owned — POST /api/billing/sync. Called by the post-Stripe
// return page (/dashboard/billing/return?session_id=...) to reconcile the
// checkout session against the authed user's BillingPlan / BillingAddon rows.
//
// Body shape matches @/lib/contracts/billing:BillingSyncRequest:
//   { sessionId, planId, addons?: string[] }
//
// Plan + addons are read from the return URL query (checkout writes them into
// the success URL; Stripe preserves them and only replaces {CHECKOUT_SESSION_ID}).
// verifyCheckoutSession does NOT echo session metadata, so we cannot rely on
// it — the URL-passed slugs are the source of truth.
//
// The repo count is re-read live from prisma.repo at sync time — Stripe may
// have landed minutes after the click and the user may have connected or
// disconnected a repo meanwhile — and stamped onto the BillingPlan row as
// `paidRepoCount`. This snapshot is what the dashboard surfaces as "Starter,
// N active repos" right after checkout.
//
// Idempotency:
//   - BillingPlan.stripeSessionId @unique rejects the same session twice.
//   - BillingPlan @@unique([userId]) — the route is a single user-scoped writer.
//   - BillingAddon rows are wiped per user before insert so a re-sync does
//     not stack duplicates.

import 'server-only';
import { NextResponse } from 'next/server';
import type { z } from 'zod';
import { resolvePlanQuote } from '@/lib/business/billing';
import {
  BillingState,
  type BillingState as BillingStateT,
  BillingSyncRequest,
} from '@/lib/contracts/billing';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';
import {
  StripeBillingConfigurationError,
  verifyCheckoutSession,
} from '@/lib/stripe-billing/client';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let parsed: z.infer<typeof BillingSyncRequest>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = BillingSyncRequest.parse(json);
  } catch {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  const sessionId = parsed.sessionId;
  const addonSlugs = parsed.addons ?? [];
  const repoCount = await prisma.repo.count({ where: { userId: session.userId } });
  const quote = resolvePlanQuote(parsed.planId, addonSlugs, repoCount);
  if (!quote) {
    return NextResponse.json({ error: 'invalid_plan' }, { status: 400 });
  }

  let verification: Awaited<ReturnType<typeof verifyCheckoutSession>>;
  try {
    verification = await verifyCheckoutSession({ sessionId });
  } catch (err) {
    if (err instanceof StripeBillingConfigurationError) {
      return NextResponse.json({ error: 'stripe_billing_not_configured' }, { status: 503 });
    }
    return NextResponse.json({ error: 'payment_verification_failed' }, { status: 502 });
  }
  if (!verification.verified) {
    return NextResponse.json(
      { ok: false, error: verification.error ?? 'verification_failed' },
      { status: 400 },
    );
  }

  const periodEnd = verification.payment?.paid_at ? new Date(verification.payment.paid_at) : null;

  const existing = await prisma.billingPlan.findUnique({
    where: { stripeSessionId: sessionId },
  });
  if (existing && existing.userId !== session.userId) {
    return NextResponse.json({ ok: false, error: 'forbidden' }, { status: 403 });
  }

  const planRecord = existing
    ? await prisma.billingPlan.update({
        where: { id: existing.id },
        data: {
          slug: quote.planSlug,
          monthlyPerRepoUsd: quote.base.monthlyPerRepoUsd,
          repoLimit: quote.repoLimit,
          paidRepoCount: quote.paidRepoCount,
          status: 'ACTIVE',
          ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
        },
      })
    : await prisma.billingPlan.create({
        data: {
          userId: session.userId,
          slug: quote.planSlug,
          monthlyPerRepoUsd: quote.base.monthlyPerRepoUsd,
          repoLimit: quote.repoLimit,
          paidRepoCount: quote.paidRepoCount,
          status: 'ACTIVE',
          stripeSessionId: sessionId,
          ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
        },
      });

  // Replace add-on rows so a re-sync does not stack duplicates.
  await prisma.billingAddon.deleteMany({ where: { userId: session.userId } });
  if (quote.addons.length > 0) {
    await prisma.billingAddon.createMany({
      data: quote.addons.map((a) => ({
        userId: session.userId,
        planId: planRecord.id,
        slug: a.slug,
        label: a.label,
        monthlyUsd: a.monthlyUsd,
      })),
    });
  }

  const [addons, liveRepoCount] = await Promise.all([
    prisma.billingAddon.findMany({
      where: { userId: session.userId },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.repo.count({ where: { userId: session.userId } }),
  ]);

  const payload: BillingStateT = BillingState.parse({
    plan: {
      id: planRecord.id,
      slug: planRecord.slug,
      monthlyPerRepoUsd: planRecord.monthlyPerRepoUsd,
      paidRepoCount: planRecord.paidRepoCount,
      repoLimit: planRecord.repoLimit,
      status: planRecord.status,
      currentPeriodEnd: planRecord.currentPeriodEnd?.toISOString() ?? null,
      cancelAtPeriodEnd: planRecord.cancelAtPeriodEnd,
    },
    repoCount: liveRepoCount,
    addons: addons.map((row) => ({
      id: row.id,
      slug: row.slug as '+24h-critical-sla' | '+business-hours-paging',
      label: row.label,
      monthlyUsd: row.monthlyUsd,
    })),
  });
  return NextResponse.json({ ok: true, state: payload });
}
