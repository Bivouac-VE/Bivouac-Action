// @polsia:user-owned — POST /api/billing/portal. Stripe state-sync for the
// "Cancel at period end" action on /settings/billing.
//
// ── Why this is a state-mirror, not a Stripe cancel command ──
// The Stripe-billing module exposes `createCheckoutSession`,
// `verifyCheckoutSession`, `getSubscriptionStatus`, and `listPaymentEvents`.
// It does NOT expose a Stripe-side cancel endpoint — there is no proxy route
// for it. The "Cancel at period end" button on /settings/billing is therefore
// a READ-SYNC, not a Stripe mutation:
//
//   1. Call getSubscriptionStatus({ email }) to ask Stripe what it knows about
//      this customer.
//   2. Treat an `active === false` payload (after a successful sync window) as
//      "scheduled to end" — mirror `cancelAtPeriodEnd` into the local
//      BillingPlan row.
//   3. Update `currentPeriodEnd` if Stripe returned one.
//
// The user-facing DOWNGRADE path is the Switch-plan-to-Starter card (Stripe
// ends the higher tier at period end automatically when the new subscription
// first renews). Document this clearly — do NOT pretend the button here issued
// a Stripe cancel call.
//
// ── Failure shape ──
// - 503 stripe_billing_not_configured — StripeBillingConfigurationError; UI
//   toast-maps to the same key as the other 503s.
// - 400 email_required_for_subscription_status — oauth-only account with no
//   email; can't query the platform feed.
// - 200 with whatever is true on the server today — never throw to the user.
//   We catch surprise errors and fall back to the most recently persisted
//   cancelAtPeriodEnd from the DB so the UI can at least render consistently.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  PortalSyncResponse,
  type PortalSyncResponse as PortalSyncResponseT,
} from '@/lib/contracts/billing';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';
import {
  getSubscriptionStatus,
  StripeBillingConfigurationError,
} from '@/lib/stripe-billing/client';

export const dynamic = 'force-dynamic';

async function readPersistedFlag(userId: string): Promise<PortalSyncResponseT> {
  const plan = await prisma.billingPlan.findUnique({
    where: { userId },
    select: { cancelAtPeriodEnd: true, currentPeriodEnd: true },
  });
  return PortalSyncResponse.parse({
    cancelAtPeriodEnd: plan?.cancelAtPeriodEnd ?? false,
    currentPeriodEnd: plan?.currentPeriodEnd?.toISOString() ?? null,
  });
}

export async function POST() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { email: true },
  });
  const email = user?.email ?? null;
  if (!email) {
    return NextResponse.json({ error: 'email_required_for_subscription_status' }, { status: 400 });
  }

  let cancelAtPeriodEnd = false;
  let currentPeriodEnd: string | null = null;
  try {
    const status = await getSubscriptionStatus({ email });
    // After a successful subscription-status read, treat inactive as
    // "scheduled to end". An active row with a returned `current_period_end`
    // is the live renewing timestamp.
    cancelAtPeriodEnd = !status.active;
    currentPeriodEnd = status.current_period_end ?? null;

    const periodEndDate = currentPeriodEnd ? new Date(currentPeriodEnd) : null;
    await prisma.billingPlan.update({
      where: { userId: session.userId },
      data: {
        cancelAtPeriodEnd,
        ...(periodEndDate ? { currentPeriodEnd: periodEndDate } : {}),
      },
    });
  } catch (err) {
    if (err instanceof StripeBillingConfigurationError) {
      return NextResponse.json({ error: 'stripe_billing_not_configured' }, { status: 503 });
    }
    // Surprise failure — return whatever the DB last believed. The UI never
    // gets a thrown error; the worst case is a stale `cancelAtPeriodEnd`.
    const fallback = await readPersistedFlag(session.userId);
    return NextResponse.json(fallback);
  }

  const payload: PortalSyncResponseT = PortalSyncResponse.parse({
    cancelAtPeriodEnd,
    currentPeriodEnd,
  });
  return NextResponse.json(payload);
}
