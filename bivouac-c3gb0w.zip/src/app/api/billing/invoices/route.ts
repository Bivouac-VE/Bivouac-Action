// @polsia:user-owned — GET /api/billing/invoices. Invoice history table for
// the /dashboard/billing + /settings/billing surfaces.
//
// 1. Auth gate via getSession() (next/headers lives here, not on the page).
// 2. Resolve the user's email from Better-Auth's User row.
// 3. listPaymentEvents(sinceCursor: 0, limit: 100) hits the platform feed.
// 4. Best-effort scope to events where type === 'payment_received' AND
//    customerEmail === user.email. Multi-account customers (one buyer email
//    mapping to multiple Stripe customers in the platform feed) may see
//    cross-account noise; documented in AGENT.md / plan as an MVP limit.
// 5. Drop to most-recent 6 and map to InvoiceRecord.
// 6. Validate through BillingInvoicesResponse so a shape drift throws ZodError
//    instead of silently flowing wrong rows to the client.
//
// `hostedInvoiceUrl` — Stripe's hosted invoice URL — is currently always
// `null` on every row: the Polsia payment-events feed does not surface it,
// and the Stripe SDK is forbidden by the platform. The contract reserves the
// slot so a future enhancement can hydrate it without a contract break.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  BillingInvoicesResponse,
  type BillingInvoicesResponse as BillingInvoicesResponseT,
  InvoiceRecord,
} from '@/lib/contracts/billing';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';
import { listPaymentEvents, StripeBillingConfigurationError } from '@/lib/stripe-billing/client';

export const dynamic = 'force-dynamic';

const INVOICE_PAGE_SIZE = 6;

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { email: true },
  });
  const email = user?.email ?? null;
  if (!email) {
    // No email → can't filter the platform feed; return an empty page rather
    // than 500'ing — the table's empty state is the honest UX here.
    const payload: BillingInvoicesResponseT = BillingInvoicesResponse.parse({ invoices: [] });
    return NextResponse.json(payload);
  }

  let result: Awaited<ReturnType<typeof listPaymentEvents>>;
  try {
    result = await listPaymentEvents({ sinceCursor: 0, limit: 100 });
  } catch (err) {
    if (err instanceof StripeBillingConfigurationError) {
      return NextResponse.json({ error: 'stripe_billing_not_configured' }, { status: 503 });
    }
    return NextResponse.json({ error: 'payment_events_unavailable' }, { status: 502 });
  }

  const invoices = result.events
    .filter((event) => event.type === 'payment_received' && event.customerEmail === email)
    .slice(0, INVOICE_PAGE_SIZE)
    .map((event) =>
      InvoiceRecord.parse({
        id: event.id,
        stripeCheckoutSessionId: event.stripeCheckoutSessionId,
        amountUsd: event.amountUsd,
        description: event.description,
        occurredAt: event.occurredAt,
        hostedInvoiceUrl: null,
      }),
    );

  const payload: BillingInvoicesResponseT = BillingInvoicesResponse.parse({ invoices });
  return NextResponse.json(payload);
}
