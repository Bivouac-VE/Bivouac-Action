// @polsia:user-owned — POST /api/billing/checkout. Authed "switch plan"
// flow backing the /dashboard/billing tier picker.
//
// 1. Resolve plan + addons + live repoCount server-side (prices never trust
//    the browser — the brief specifies "per-repo × monthly" → multiply
//    plan.monthlyPerRepoUsd by the caller's connected repoCount).
// 2. Create a recurring monthly Stripe Checkout subscription for the total.
// 3. Success URL lands on /dashboard/billing/return so the Stripe round-trip
//    reconciles the user's BillingPlan row, then router.replace() returns to
//    /dashboard/billing. Cancel URL lands directly on /dashboard/billing.
//
// Anonymous / unauthenticated callers → 401.
//
// Edge case: if the user has zero connected repos but tries to start a paid
// checkout (e.g. all repos disconnected while a paid row is still active), we
// return a 400 `no_active_repos` instead of opening a $0 Stripe session. The
// browser surfaces this as a toast.

import 'server-only';
import { NextResponse } from 'next/server';
import type { z } from 'zod';
import { resolvePlanQuote } from '@/lib/business/billing';
import {
  BillingCheckoutRequest,
  BillingCheckoutResponse,
  type BillingCheckoutResponse as BillingCheckoutResponseT,
} from '@/lib/contracts/billing';
import { prisma } from '@/lib/db';
import { env } from '@/lib/env';
import { getSession } from '@/lib/server/session';
import {
  createCheckoutSession,
  StripeBillingConfigurationError,
  StripeBillingNotEnabledError,
  StripeBillingOnboardingError,
} from '@/lib/stripe-billing/client';

export const dynamic = 'force-dynamic';

function appUrl(req: Request): string {
  const origin = req.headers.get('origin');
  if (origin) return origin.replace(/\/+$/, '');
  return env.NEXT_PUBLIC_APP_URL.replace(/\/+$/, '');
}

function respond(body: BillingCheckoutResponseT, status = 200) {
  return NextResponse.json(BillingCheckoutResponse.parse(body), { status });
}

async function loadAuthedUser() {
  const session = await getSession();
  if (!session) return null;
  return prisma.user.findUnique({
    where: { id: session.userId },
    select: { id: true, email: true },
  });
}

export async function POST(req: Request) {
  let parsed: z.infer<typeof BillingCheckoutRequest>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = BillingCheckoutRequest.parse(json);
  } catch {
    return respond({ ok: 'error', error: 'invalid_plan' }, 400);
  }

  const user = await loadAuthedUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const repoCount = await prisma.repo.count({ where: { userId: user.id } });
  const quote = resolvePlanQuote(parsed.planId, parsed.addons ?? [], repoCount);
  if (!quote) {
    return respond({ ok: 'error', error: 'no_active_repos' }, 400);
  }
  if (quote.totalUsd < 1) {
    return respond({ ok: 'error', error: 'invalid_plan' }, 400);
  }

  const base = appUrl(req);
  // Encode the chosen slugs into the success URL query string — Stripe replaces
  // {CHECKOUT_SESSION_ID} and preserves everything else, so /return can read
  // plan+addons off the query and POST them to /sync without trusting the
  // browser to remember what was picked minutes ago.
  const returnParams = new URLSearchParams({
    plan: quote.planSlug,
    ...(quote.addons.length > 0 ? { addons: quote.addons.map((a) => a.slug).join(',') } : {}),
  });
  const metadata: Record<string, string> = {
    plan: quote.planSlug,
    paidRepoCount: String(quote.paidRepoCount),
    ...(quote.addons.length > 0 ? { addons: quote.addons.map((a) => a.slug).join(',') } : {}),
  };
  const descriptionParts = [
    `${quote.base.name} plan, $${quote.base.monthlyPerRepoUsd}/active repo/month × ${quote.paidRepoCount} repo${quote.paidRepoCount === 1 ? '' : 's'}`,
    ...quote.addons.map((a) => `${a.label} $${a.monthlyUsd}/mo`),
  ];

  try {
    const result = await createCheckoutSession({
      amountUsd: quote.totalUsd,
      name: `${quote.base.name} plan + ${quote.addons.length} add-on(s)`,
      description: descriptionParts.join(' · '),
      recurring: { interval: 'month' },
      successUrl: `${base}/dashboard/billing/return?session_id={CHECKOUT_SESSION_ID}&${returnParams.toString()}`,
      cancelUrl: `${base}/dashboard/billing`,
      clientReferenceId: user.id,
      customerEmail: user.email,
      metadata,
    });
    return respond({ ok: 'checkout', url: result.url }, 200);
  } catch (err) {
    if (
      err instanceof StripeBillingNotEnabledError ||
      err instanceof StripeBillingOnboardingError ||
      err instanceof StripeBillingConfigurationError
    ) {
      const code =
        err instanceof StripeBillingNotEnabledError
          ? 'STRIPE_NOT_ENABLED'
          : err instanceof StripeBillingOnboardingError
            ? 'ONBOARDING_REQUIRED'
            : 'STRIPE_NOT_CONFIGURED';
      return respond({ ok: 'error', error: code }, 400);
    }
    return respond({ ok: 'error', error: 'checkout_failed' }, 400);
  }
}
