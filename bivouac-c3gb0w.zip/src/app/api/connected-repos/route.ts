// @polsia:user-owned — POST /api/connected-repos. The "pick ONE repo" flip-
// side of /api/github/installation/[installationId]/repos (the picker feed).
// Validates + IDOR-guards the pick, then upserts both:
//   - GitHubAppInstallationRepo (the per-install selection row the rest of
//     the pipeline reads from to know which repos to scan),
//   - Repo (the dashboard's "my connected repos" store the user is dropped
//     into after submit).
// `visibility` + `pushedAt` are NOT persisted — the picker is the last place
// they're useful and the `Repo` table has no columns for them.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  ConnectedRepoSelectInput,
  ConnectedRepoSelectResult,
} from '@/lib/contracts/connected-repos';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  let parsed: ReturnType<typeof ConnectedRepoSelectInput.parse>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = ConnectedRepoSelectInput.parse(json);
  } catch {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  const installationId = BigInt(parsed.installationId);

  // IDOR guard — the installation must belong to the caller.
  const installation = await prisma.gitHubAppInstallation.findFirst({
    where: { userId: user.id, installationId },
    select: { id: true },
  });
  if (!installation) {
    return NextResponse.json({ error: 'Installation not found' }, { status: 403 });
  }

  const now = new Date();

  const saved = await prisma.$transaction(async (tx) => {
    // 1. Per-install selection row — upsert by githubNodeId (globally unique).
    //    The pipeline reads `gitHubAppInstallationRepo` to know which repos
    //    to scan for this user on this install.
    await tx.gitHubAppInstallationRepo.upsert({
      where: { githubNodeId: parsed.githubNodeId },
      create: {
        installationId,
        userId: user.id,
        githubRepoId: BigInt(parsed.githubRepoId),
        githubNodeId: parsed.githubNodeId,
        name: parsed.name,
        ownerHandle: parsed.ownerHandle,
        defaultBranch: parsed.defaultBranch,
        selectedAt: now,
      },
      update: {
        installationId,
        userId: user.id,
        name: parsed.name,
        ownerHandle: parsed.ownerHandle,
        defaultBranch: parsed.defaultBranch,
      },
    });

    // 2. Dashboard's `Repo` row — this is what /dashboard/repos reads so the
    //    fresh pick shows up immediately on the redirect.
    const repo = await tx.repo.upsert({
      where: { githubNodeId: parsed.githubNodeId },
      select: { id: true },
      create: {
        userId: user.id,
        githubNodeId: parsed.githubNodeId,
        name: parsed.name,
        ownerHandle: parsed.ownerHandle,
        defaultBranch: parsed.defaultBranch,
        status: 'HEALTHY',
        lastScannedAt: null,
      },
      update: {
        userId: user.id,
        name: parsed.name,
        ownerHandle: parsed.ownerHandle,
        defaultBranch: parsed.defaultBranch,
      },
    });

    return repo;
  });

  const payload = {
    saved: 1,
    repo: {
      id: saved.id,
      name: parsed.name,
      ownerHandle: parsed.ownerHandle,
      defaultBranch: parsed.defaultBranch,
    },
  };
  return NextResponse.json(ConnectedRepoSelectResult.parse(payload), { status: 200 });
}
