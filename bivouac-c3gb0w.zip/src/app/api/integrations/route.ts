// @polsia:user-owned — GET + PUT + DELETE /api/integrations. Team-scoped
// configuration for Slack + PagerDuty alerting with an optional per-repo
// override. Access control: requireAuth + isTeamAdmin (mirrors
// /api/team/state/route.ts); non-admins see a 403.
//
// Model: one row per (teamId, provider, repoId) in TeamIntegration. The
// "team" scope is repoId="" (empty-string sentinel — see schema comment for
// why a non-null column beats a nullable one for this unique tuple). A
// per-repo override wins over the team row for matching repos when
// querying. Today the app is single-team so teamId is the literal sentinel
// "default" — the model stays correct if multi-tenancy is later added.

import 'server-only';
import { NextResponse } from 'next/server';
import { validatePagerDutyValue, validateSlackUrl } from '@/lib/business/integrations';
import { isTeamAdmin } from '@/lib/business/team';
import {
  type IntegrationItem,
  IntegrationList,
  IntegrationUpsertInput,
  wireToScope,
} from '@/lib/contracts/integrations';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

/** Stable team sentinel — single-team app today. If we ever become multi-
 *  tenant, this becomes the actual team id (the column already stores a
 *  string). */
const TEAM_SENTINEL = 'default';

/** Empty-string sentinel for the team-wide repoId slot. Non-null so the
 *  @@unique([teamId, provider, repoId]) constraint matches Postgres
 *  semantics correctly (a NULL is treated as DISTINCT and would let a row
 *  be duplicated). */
const TEAM_SCOPE_SENTINEL = '';

/** The Prisma generated compound-unique input requires `repoId: string`
 *  (not `string | null`). The schema column is non-null with a default of
 *  "", which gives us the same semantics. */
interface IntegrationRow {
  id: string;
  provider: string;
  repoId: string;
  slackUrl: string | null;
  pagerdutyKey: string | null;
  updatedAt: Date;
}

function teamScopeWire(): 'team' {
  return 'team';
}

function repoScopeWire(repoId: string): `repo:${string}` {
  return `repo:${repoId}`;
}

function isTeamScope(repoId: string): boolean {
  return repoId === TEAM_SCOPE_SENTINEL;
}

function toItem(row: IntegrationRow, repoSlugByRepoId: Map<string, string>): IntegrationItem {
  const scope: IntegrationItem['scope'] = isTeamScope(row.repoId)
    ? teamScopeWire()
    : repoScopeWire(row.repoId);
  const valuePreview =
    row.provider === 'slack'
      ? previewUrl(row.slackUrl ?? '')
      : row.provider === 'pagerduty'
        ? previewPagerDutyKey(row.pagerdutyKey ?? '')
        : '';
  return {
    id: row.id,
    provider: row.provider === 'pagerduty' ? 'pagerduty' : 'slack',
    scope,
    repoSlug: isTeamScope(row.repoId) ? null : (repoSlugByRepoId.get(row.repoId) ?? null),
    valuePreview,
    updatedAt: row.updatedAt.toISOString(),
  };
}

function previewUrl(url: string, max: number = 60): string {
  if (!url) return '';
  if (url.length <= max) return url;
  return `${url.slice(0, max - 1)}…`;
}

function previewPagerDutyKey(key: string): string {
  if (!key) return '';
  if (key.length <= 4) return '•'.repeat(key.length);
  return `${'•'.repeat(Math.max(0, key.length - 4))}${key.slice(-4)}`;
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }
  if (!(await isTeamAdmin(user.id))) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  const rows = await prisma.teamIntegration.findMany({
    where: { teamId: TEAM_SENTINEL },
    orderBy: [{ provider: 'asc' }, { repoId: 'asc' }],
  });
  const repoIds = Array.from(
    new Set(
      rows
        .map((r) => r.repoId)
        .filter((id): id is string => Boolean(id) && id !== TEAM_SCOPE_SENTINEL),
    ),
  );

  let slugByRepoId = new Map<string, string>();
  if (repoIds.length > 0) {
    const repos = await prisma.repo.findMany({
      where: { id: { in: repoIds } },
      select: { id: true, name: true, ownerHandle: true },
    });
    slugByRepoId = new Map(repos.map((r) => [r.id, `${r.ownerHandle}/${r.name}`]));
  }

  const items: IntegrationItem[] = rows.map((r) => toItem(r as IntegrationRow, slugByRepoId));

  return NextResponse.json(IntegrationList.parse({ items }), { status: 200 });
}

export async function PUT(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }
  if (!(await isTeamAdmin(user.id))) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  let input: { provider: 'slack' | 'pagerduty'; scope: string; value: string };
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    input = IntegrationUpsertInput.parse(json);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'invalid_request' },
      { status: 400 },
    );
  }
  const scope = wireToScope(input.scope);
  if (!scope) {
    return NextResponse.json({ error: 'Invalid scope.' }, { status: 400 });
  }

  if (input.provider === 'slack') {
    const validation = validateSlackUrl(input.value);
    if (!validation.ok) {
      return NextResponse.json({ error: validation.reason }, { status: 400 });
    }
  } else {
    const validation = validatePagerDutyValue(input.value);
    if (!validation.ok) {
      return NextResponse.json({ error: validation.reason }, { status: 400 });
    }
  }

  // Resolve the persisted repoId. Team scope → "" sentinel; repo scope →
  // the actual Repo.id. Confirm the repo row exists when this is an
  // override so a stale override can't stick around pointing at a
  // non-existent repo.
  const repoId = scope.kind === 'team' ? TEAM_SCOPE_SENTINEL : scope.repoId;
  if (scope.kind === 'repo') {
    const repo = await prisma.repo.findUnique({
      where: { id: repoId },
      select: { id: true },
    });
    if (!repo) {
      return NextResponse.json({ error: 'Repo not found.' }, { status: 404 });
    }
  }

  const slackUrlField = input.provider === 'slack' ? input.value : null;
  const pagerdutyKeyField =
    input.provider === 'pagerduty' ? validatePagerDutyValue(input.value) : null;
  const pagerdutyKey =
    input.provider === 'pagerduty' && pagerdutyKeyField?.ok ? pagerdutyKeyField.routingKey : null;

  const row = await prisma.teamIntegration.upsert({
    where: {
      teamId_provider_repoId: {
        teamId: TEAM_SENTINEL,
        provider: input.provider,
        repoId,
      },
    },
    create: {
      teamId: TEAM_SENTINEL,
      provider: input.provider,
      repoId,
      slackUrl: slackUrlField,
      pagerdutyKey,
    },
    update: {
      slackUrl: slackUrlField,
      pagerdutyKey,
    },
  });

  // Resolve repo slug for the response. Cheap because |repo overrides| is
  // bounded to O(repos) — max one findUnique per unique repo.
  const slugByRepoId = new Map<string, string>();
  if (!isTeamScope(repoId)) {
    const repo = await prisma.repo.findUnique({
      where: { id: repoId },
      select: { id: true, name: true, ownerHandle: true },
    });
    if (repo) slugByRepoId.set(repo.id, `${repo.ownerHandle}/${repo.name}`);
  }
  return NextResponse.json(toItem(row as IntegrationRow, slugByRepoId), { status: 200 });
}

export async function DELETE(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }
  if (!(await isTeamAdmin(user.id))) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  let body: { provider?: string; scope?: string };
  try {
    body = (await req.json().catch(() => ({}))) as { provider?: string; scope?: string };
  } catch {
    body = {};
  }
  const provider =
    body.provider === 'pagerduty' ? 'pagerduty' : body.provider === 'slack' ? 'slack' : null;
  if (!provider) {
    return NextResponse.json({ error: 'provider is required' }, { status: 400 });
  }
  const scope = wireToScope(body.scope ?? 'team');
  if (!scope) {
    return NextResponse.json({ error: 'Invalid scope.' }, { status: 400 });
  }

  const repoId = scope.kind === 'team' ? TEAM_SCOPE_SENTINEL : scope.repoId;

  await prisma.teamIntegration.deleteMany({
    where: {
      teamId: TEAM_SENTINEL,
      provider,
      repoId,
    },
  });

  return NextResponse.json({ ok: true }, { status: 200 });
}
