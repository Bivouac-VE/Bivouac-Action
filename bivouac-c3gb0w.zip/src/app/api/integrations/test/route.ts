// @polsia:user-owned — POST /api/integrations/test. Manual "send test
// notification" canary: dispatches a small sample payload to the configured
// Slack incoming-webhook OR the PagerDuty Events API v2 endpoint and writes
// one IntegrationDelivery row so the UI can surface the result.
//
// Access control: requireAuth + isTeamAdmin — same gate as /api/integrations
// so only a team admin can probe a webhook. Non-admins see 403. Mirrors the
// canary semantics of /api/digest-webhook/test (manual one-off; same row
// shape, canary-<ISO> runDay).
//
// We do NOT re-fetch the Slack URL with the SSRF harness — Slack's incoming-
// webhook host is fixed in code (hooks.slack.com), so re-validating here
// would only catch a future Slack infra change. We trust the validate-on-
// save path; the URL is opaque to us.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  buildSlackPayload,
  canaryRunDay,
  dispatchPagerDuty,
  dispatchSlack,
  previewError,
  validatePagerDutyValue,
  validateSlackUrl,
} from '@/lib/business/integrations';
import { isTeamAdmin } from '@/lib/business/team';
import {
  IntegrationTestResult,
  type IntegrationTestResult as IntegrationTestResultT,
  wireToScope,
} from '@/lib/contracts/integrations';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

/** Stable team sentinel — single-team app today. */
const TEAM_SENTINEL = 'default';

/** Empty-string sentinel for the team-wide repoId slot. Mirrors schema. */
const TEAM_SCOPE_SENTINEL = '';

export async function POST(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }
  if (!(await isTeamAdmin(user.id))) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  let body: { provider?: 'slack' | 'pagerduty'; scope?: string };
  try {
    body = (await req.json().catch(() => null)) ?? {};
  } catch {
    body = {};
  }
  const provider = body.provider;
  if (provider !== 'slack' && provider !== 'pagerduty') {
    return NextResponse.json({ error: 'provider must be slack or pagerduty' }, { status: 400 });
  }
  const scope = wireToScope(body.scope ?? 'team');
  if (!scope) {
    return NextResponse.json({ error: 'Invalid scope.' }, { status: 400 });
  }

  const repoId = scope.kind === 'team' ? TEAM_SCOPE_SENTINEL : scope.repoId;
  const scopeLabel = scope.kind === 'team' ? 'team' : `repo:${scope.repoId}`;

  const row = await prisma.teamIntegration.findUnique({
    where: {
      teamId_provider_repoId: {
        teamId: TEAM_SENTINEL,
        provider,
        repoId,
      },
    },
  });
  if (!row) {
    return NextResponse.json(
      { status: 'failed', statusCode: null, error: 'No integration configured. Save first.' },
      { status: 412 },
    );
  }

  // Validate the stored value at fetch time so a row that passed validation
  // on save and now has a stale shape (shouldn't happen — we only write
  // validated values — but defence-in-depth) still surfaces a sensible
  // error rather than a 500 from a malformed fetch URL. The two providers
  // have different success shapes — Slack carries a parsed URL, PagerDuty
  // carries the routing key — so we discriminate on provider rather than
  // trying to share a single union across them.
  type SlackOk = { ok: true; kind: 'slack'; url: URL };
  type PdOk = { ok: true; kind: 'pagerduty'; routingKey: string };
  type Bad = { ok: false; reason: string };
  let validated: SlackOk | PdOk | Bad;
  if (provider === 'slack') {
    const r = validateSlackUrl(row.slackUrl ?? '');
    validated = r.ok ? { ok: true, kind: 'slack', url: r.url } : { ok: false, reason: r.reason };
  } else {
    const r = validatePagerDutyValue(row.pagerdutyKey ?? '');
    validated = r.ok
      ? { ok: true, kind: 'pagerduty', routingKey: r.routingKey }
      : { ok: false, reason: r.reason };
  }

  const now = new Date();
  const runDay = canaryRunDay(now);

  if (!validated.ok) {
    await prisma.integrationDelivery.create({
      data: {
        integrationId: row.id,
        teamId: TEAM_SENTINEL,
        scope: scopeLabel,
        provider,
        runDay,
        status: 'failed',
        attempts: 1,
        lastStatusCode: null,
        lastError: previewError(`Stored value failed validation: ${validated.reason}`),
        sentAt: null,
      },
    });
    const payload: IntegrationTestResultT = {
      status: 'failed',
      statusCode: null,
      error: validated.reason,
      runDay,
    };
    return NextResponse.json(IntegrationTestResult.parse(payload), { status: 200 });
  }

  const dispatch =
    validated.kind === 'slack'
      ? dispatchSlack({
          url: validated.url,
          body: buildSlackPayload({
            preview: {
              provider,
              message: 'Bivouac test notification',
              teamId: TEAM_SENTINEL,
              scope: scopeLabel,
            },
          }),
        })
      : dispatchPagerDuty({
          routingKey: validated.routingKey,
        });

  const dispatchResult = await dispatch;

  await prisma.integrationDelivery.create({
    data: {
      integrationId: row.id,
      teamId: TEAM_SENTINEL,
      scope: scopeLabel,
      provider,
      runDay,
      status: dispatchResult.status,
      attempts: 1,
      lastStatusCode: dispatchResult.statusCode,
      lastError: previewError(dispatchResult.error),
      sentAt: dispatchResult.status === 'delivered' ? now : null,
    },
  });

  const payload: IntegrationTestResultT = {
    status: dispatchResult.status,
    statusCode: dispatchResult.statusCode,
    error: dispatchResult.error,
    runDay,
  };
  return NextResponse.json(IntegrationTestResult.parse(payload), { status: 200 });
}
