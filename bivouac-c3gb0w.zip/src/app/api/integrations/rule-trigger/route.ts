// @polsia:user-owned — POST /api/integrations/rule-trigger. Manual "send a
// page-a-human notification" trigger: a team admin picks a repo, a reason
// ("High-severity CVE", "Red build", …), and a PR URL, and the route
// dispatches the rule-context payload to the configured Slack or PagerDuty
// endpoint per the stored TeamIntegration row.
//
// Access control: requireAuth + isTeamAdmin — same gate as /api/integrations
// and /api/integrations/test; only a team admin can probe a webhook. Non-
// admins see 403.
//
// Lookup precedence (brief-mandated, mirrors /api/integrations/test):
//   1. a per-repo override `TeamIntegration` for the (provider, repoId).
//   2. a team-wide row with `repoId == ""` for the (provider).
//   3. NEITHER ⇒ no-op fallback. We deliberately return
//      { delivered:false, noOp:true, noOpReason:'no_integration' } instead of
//      attempting a fetch — this is the brief's "fallback no-op if no
//      webhook is configured for the team".
//
// Writes one `IntegrationDelivery` row per attempt (the per-repo or
// team-wide id we resolved to) with `runDay: 'rule-<ISO>'` — distinct from
// the canary 'canary-<ISO>' prefix so the @@unique([integrationId, runDay])
// contract preserves and audit listings can split the two streams.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  buildRuleSlackPayload,
  dispatchPagerDutyForRule,
  dispatchSlack,
  previewError,
  ruleRunDay,
  validatePagerDutyValue,
  validateSlackUrl,
} from '@/lib/business/integrations';
import { isTeamAdmin } from '@/lib/business/team';
import {
  RuleTriggerInput,
  type RuleTriggerInput as RuleTriggerInputT,
  RuleTriggerResult,
  type RuleTriggerResult as RuleTriggerResultT,
} from '@/lib/contracts/integrations';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

/** Stable team sentinel — single-team app today. */
const TEAM_SENTINEL = 'default';

/** Empty-string sentinel for the team-wide repoId slot. Mirrors schema. */
const TEAM_SCOPE_SENTINEL = '';

const NO_INTEGRATION_NO_OP = 'no_integration';

export async function POST(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }
  if (!(await isTeamAdmin(user.id))) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  let raw: unknown;
  try {
    raw = (await req.json().catch(() => null)) ?? {};
  } catch {
    raw = {};
  }
  let input: RuleTriggerInputT;
  try {
    input = RuleTriggerInput.parse(raw);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'invalid_request' },
      { status: 400 },
    );
  }

  const repo = await prisma.repo.findUnique({
    where: { id: input.repoId },
    select: { id: true, name: true, ownerHandle: true },
  });
  const repoLabel = repo ? `${repo.ownerHandle}/${repo.name}` : `repo:${input.repoId}`;
  const scopeLabel = input.scope === 'team' ? 'team' : `repo:${input.repoId}`;

  // Per-repo override (for `repo:<id>` scope) or the team-wide row (for the
  // team-scoped lookup) — one query, no `else`, no labels.
  let row = await prisma.teamIntegration.findUnique({
    where: {
      teamId_provider_repoId: {
        teamId: TEAM_SENTINEL,
        provider: input.provider,
        repoId: input.scope === 'team' ? TEAM_SCOPE_SENTINEL : input.repoId,
      },
    },
  });

  // Fall back to the team-wide row when a per-repo override was missing. We
  // honour a per-repo scope that asked for an override even though the team
  // row exists, but the missing override is the brief-mandated no-op.
  let resolvedScope: string = input.scope;
  if (!row && input.scope.startsWith('repo:')) {
    row = await prisma.teamIntegration.findUnique({
      where: {
        teamId_provider_repoId: {
          teamId: TEAM_SENTINEL,
          provider: input.provider,
          repoId: TEAM_SCOPE_SENTINEL,
        },
      },
    });
    resolvedScope = 'team';
  }

  if (!row) {
    const payload: RuleTriggerResultT = {
      delivered: false,
      noOp: true,
      noOpReason: NO_INTEGRATION_NO_OP,
      provider: input.provider,
      resolvedScope: input.scope,
      runDay: ruleRunDay(),
      statusCode: null,
      error: null,
    };
    return NextResponse.json(RuleTriggerResult.parse(payload), { status: 200 });
  }

  type SlackOk = { kind: 'slack'; url: URL };
  type PdOk = { kind: 'pagerduty'; routingKey: string };
  type Bad = { kind: 'invalid'; reason: string };
  let validated: SlackOk | PdOk | Bad;
  if (input.provider === 'slack') {
    const r = validateSlackUrl(row.slackUrl ?? '');
    validated = r.ok ? { kind: 'slack', url: r.url } : { kind: 'invalid', reason: r.reason };
  } else {
    const r = validatePagerDutyValue(row.pagerdutyKey ?? '');
    validated = r.ok
      ? { kind: 'pagerduty', routingKey: r.routingKey }
      : { kind: 'invalid', reason: r.reason };
  }

  const now = new Date();
  const runDay = ruleRunDay(now);

  if (validated.kind === 'invalid') {
    await prisma.integrationDelivery.create({
      data: {
        integrationId: row.id,
        teamId: TEAM_SENTINEL,
        scope: resolvedScope,
        provider: input.provider,
        runDay,
        status: 'failed',
        attempts: 1,
        lastStatusCode: null,
        lastError: previewError(`Stored value failed validation: ${validated.reason}`),
        sentAt: null,
      },
    });
    const payload: RuleTriggerResultT = {
      delivered: false,
      noOp: false,
      noOpReason: null,
      provider: input.provider,
      resolvedScope,
      runDay,
      statusCode: null,
      error: validated.reason,
    };
    return NextResponse.json(RuleTriggerResult.parse(payload), { status: 200 });
  }

  let dispatchResult: {
    status: 'delivered' | 'failed';
    statusCode: number | null;
    error: string | null;
  };
  if (validated.kind === 'slack') {
    dispatchResult = await dispatchSlack({
      url: validated.url,
      body: buildRuleSlackPayload({
        provider: input.provider,
        teamId: TEAM_SENTINEL,
        scope: scopeLabel,
        repo: repoLabel,
        reason: input.reason,
        prUrl: input.prUrl,
      }),
    });
  } else {
    dispatchResult = await dispatchPagerDutyForRule({
      routingKey: validated.routingKey,
      summary: `${input.reason} on ${repoLabel}`,
      source: 'bivouac-dashboard',
      severity: 'warning',
      customDetails: {
        repo: repoLabel,
        reason: input.reason,
        prUrl: input.prUrl,
      },
    });
  }

  await prisma.integrationDelivery.create({
    data: {
      integrationId: row.id,
      teamId: TEAM_SENTINEL,
      scope: resolvedScope,
      provider: input.provider,
      runDay,
      status: dispatchResult.status,
      attempts: 1,
      lastStatusCode: dispatchResult.statusCode,
      lastError: previewError(dispatchResult.error),
      sentAt: dispatchResult.status === 'delivered' ? now : null,
    },
  });

  const payload: RuleTriggerResultT = {
    delivered: dispatchResult.status === 'delivered',
    noOp: false,
    noOpReason: null,
    provider: input.provider,
    resolvedScope,
    runDay,
    statusCode: dispatchResult.statusCode,
    error: dispatchResult.error,
  };
  return NextResponse.json(RuleTriggerResult.parse(payload), { status: 200 });
}
