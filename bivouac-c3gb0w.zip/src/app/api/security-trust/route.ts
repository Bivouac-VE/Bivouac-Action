// @polsia:user-owned — public /api/security-trust route handler. Returns the
// seeded, security-trust payload to the public client island. `server-only`
// enforces the boundary at import time (so a stray `'use client'` import would
// fail compilation); the schema parses the response so a typo in the seed
// file surfaces as a 500 instead of silent drift.
import 'server-only';
import { NextResponse } from 'next/server';
import { SecurityTrustDocument } from '@/lib/contracts/security-trust';
import { securityTrustFaq, securityTrustSections } from '../../../../content/security-trust';

export async function GET() {
  const payload = SecurityTrustDocument.parse({
    sections: securityTrustSections,
    faq: securityTrustFaq,
  });
  return NextResponse.json(payload, { status: 200 });
}
