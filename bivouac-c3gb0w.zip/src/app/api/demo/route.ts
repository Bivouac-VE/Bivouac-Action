// @polsia:user-owned — public, link-shareable demo board loader. Reads the
// canonical ledger from the file system and validates it against the shared
// DemoState contract from @/lib/contracts/demo. No DB, no remote fetch — the
// ledger is the single source of truth for every number the /demo page shows.

import 'server-only';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { NextResponse } from 'next/server';
import { DemoState } from '@/lib/contracts/demo';

export const dynamic = 'force-dynamic';

async function readLedger(): Promise<unknown> {
  const filePath = path.join(process.cwd(), 'demo-bivouac', 'ledger.json');
  const raw = await readFile(filePath, 'utf8');
  return JSON.parse(raw);
}

export async function GET() {
  try {
    const json = await readLedger();
    const payload = DemoState.parse(json);
    return NextResponse.json(payload, { status: 200 });
  } catch {
    return NextResponse.json(
      { error: 'Demo ledger is unavailable.', detail: 'See server logs for the parse error.' },
      { status: 500 },
    );
  }
}
