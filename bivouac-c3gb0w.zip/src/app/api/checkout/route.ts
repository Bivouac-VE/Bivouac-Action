// @polsia:user-owned — POST /api/checkout for the public pricing surface.
//
// Server-side only. The route resolves a plan from the typed catalog and
// computes the price there — NEVER trusts an amount from the browser. The
// discriminated CheckoutResponse (200) is the auth branching signal: an
// anonymous visitor gets a `/signup?next=...&plan=...` redirect; an Enterprise
// "Talk to sales" click gets a mailto redirect; a logged-in Subscribe click
// gets the hosted Stripe Checkout URL. 400 carries `{ error }` for toasts.

import 'server-only';
import { NextResponse } from 'next/server';
import type { z } from 'zod';
import { findPlan } from '@/lib/business/plans';
import {
  CheckoutResponse,
  type CheckoutResponse as CheckoutResponseT,
  CheckoutSessionCreate,
} from '@/lib/contracts/pricing';
import { env } from '@/lib/env';
import { getSession } from '@/lib/server/session';
import {
  createCheckoutSession,
  StripeBillingConfigurationError,
  StripeBillingNotEnabledError,
  StripeBillingOnboardingError,
} from '@/lib/stripe-billing/client';

export const dynamic = 'force-dynamic';

const ENTERPRISE_MAILTO = 'mailto:bivouac-c3gb0w@polsia.app?subject=Bivouac%20Enterprise';

function appUrl(req: Request): string {
  const origin = req.headers.get('origin');
  if (origin) return origin.replace(/\/+$/, '');
  return env.NEXT_PUBLIC_APP_URL.replace(/\/+$/, '');
}

function respond(body: CheckoutResponseT, status = 200) {
  return NextResponse.json(CheckoutResponse.parse(body), { status });
}

export async function POST(req: Request) {
  let parsed: z.infer<typeof CheckoutSessionCreate>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = CheckoutSessionCreate.parse(json);
  } catch {
    return respond({ ok: 'error', error: 'invalid_plan' }, 400);
  }

  const plan = findPlan(parsed.planId);
  if (!plan) {
    return respond({ ok: 'error', error: 'invalid_plan' }, 400);
  }

  // Free — short-circuit before Stripe. No Stripe call: Free has no plan record
  // to charge. Hand the visitor to /signup with returnTo carrying the GitHub
  // App install step so a brand-new account still lands on first-repo.
  if (plan.ctaLabel === 'Start free' || plan.slug === 'free') {
    const search = new URLSearchParams({
      returnTo: '/dashboard/repos?welcome=first-repo',
      plan: 'free',
    });
    return respond({ ok: 'redirect', redirectTo: `/signup?${search.toString()}` }, 200);
  }

  // Verify the catalog invariant — every paid plan carries a positive price.
  // A $0 plan with a non-Free ctaLabel would silently bypass Stripe's $1
  // minimum; reject it instead.
  if (!Number.isFinite(plan.monthlyPerRepoUsd) || plan.monthlyPerRepoUsd < 1) {
    return respond({ ok: 'error', error: 'invalid_plan' }, 400);
  }

  // Enterprise: hand the visitor off to sales via mailto — no Stripe call.
  if (plan.ctaLabel === 'Talk to sales') {
    return respond({ ok: 'redirect', redirectTo: ENTERPRISE_MAILTO }, 200);
  }

  // Anonymous: redirect to /signup carrying the original pricing intent so the
  // authed user can land back here with plan context preserved. The key name
  // matches signup/page.tsx's `readReturnTo` helper, and the value is a
  // same-origin path (the open-redirect guard accepts '/pricing?plan=...').
  const session = await getSession();
  if (!session) {
    const search = new URLSearchParams({
      returnTo: `/pricing${plan.slug ? `?plan=${plan.slug}` : ''}`,
      plan: plan.slug,
    });
    return respond({ ok: 'redirect', redirectTo: `/signup?${search.toString()}` }, 200);
  }

  // Authed: create the hosted Stripe Checkout for this plan.
  const base = appUrl(req);
  try {
    const result = await createCheckoutSession({
      amountUsd: plan.monthlyPerRepoUsd,
      name: `${plan.name} (per active repo, monthly)`,
      description:
        'Per active repository, billed monthly. Cancel anytime. Adjust at the end of each billing period.',
      recurring: { interval: 'month' },
      successUrl: `${base}/settings/billing/return?session_id={CHECKOUT_SESSION_ID}&plan=${plan.slug}`,
      cancelUrl: `${base}/pricing`,
      clientReferenceId: session.userId,
      metadata: { plan: plan.slug },
    });
    return respond({ ok: 'checkout', url: result.url }, 200);
  } catch (err) {
    if (
      err instanceof StripeBillingNotEnabledError ||
      err instanceof StripeBillingOnboardingError ||
      err instanceof StripeBillingConfigurationError
    ) {
      const code =
        err instanceof StripeBillingNotEnabledError
          ? 'STRIPE_NOT_ENABLED'
          : err instanceof StripeBillingOnboardingError
            ? 'ONBOARDING_REQUIRED'
            : 'STRIPE_NOT_CONFIGURED';
      return respond({ ok: 'error', error: code }, 400);
    }
    return respond({ ok: 'error', error: 'checkout_failed' }, 400);
  }
}
