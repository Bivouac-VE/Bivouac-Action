// @polsia:user-owned — GET /api/patches. Returns a list of derived patch
// summaries, newest-first. Public read (the triage rows are intentionally
// scrapable on this read-only preview surface — the only thing exported
// outwardly is a derived summary of public GitHub PRs).

import 'server-only';
import { NextResponse } from 'next/server';
import { listPatches } from '@/lib/business/patches';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const rawLimit = Number.parseInt(url.searchParams.get('limit') ?? '', 10);
    const payload =
      Number.isFinite(rawLimit) && rawLimit > 0 ? await listPatches(rawLimit) : await listPatches();
    return NextResponse.json(payload, { status: 200 });
  } catch {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
