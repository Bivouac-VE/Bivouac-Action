// @polsia:user-owned — GET /api/patches/[id]. Returns the full derived
// detail for one patch — title, target repo, CVE link, severity, test
// outcome, merge state, the proposed unified diff, and the rationale
// paragraph. 404 on unknown id; the route handler wraps the sentinel
// `NotFound` thrown by the business helper into a typed 404 body.

import 'server-only';
import { NextResponse } from 'next/server';
import { getPatchDetail, NotFound } from '@/lib/business/patches';

export const dynamic = 'force-dynamic';

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const payload = await getPatchDetail(id);
    return NextResponse.json(payload, { status: 200 });
  } catch (err) {
    if (err instanceof NotFound) {
      return NextResponse.json({ error: 'Not Found' }, { status: 404 });
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
