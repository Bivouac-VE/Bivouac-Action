// @polsia:user-owned — /api/team/members/[userId] (team-admin only).
// PATCH -> change a seated member's role.
// DELETE -> remove a seated member from the team.
// Sole-admin protection: an admin cannot remove themselves (or the last admin).

import 'server-only';
import { NextResponse } from 'next/server';
import type { z } from 'zod';
import { isTeamAdmin } from '@/lib/business/team';
import { MemberRoleUpdate } from '@/lib/contracts/team';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

async function loadAuthedAdmin() {
  const session = await getSession();
  if (!session) {
    return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  }
  if (!(await isTeamAdmin(session.userId))) {
    return { error: NextResponse.json({ error: 'Forbidden' }, { status: 403 }) };
  }
  return { session };
}

export async function PATCH(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const auth = await loadAuthedAdmin();
  if ('error' in auth) return auth.error;

  let parsed: z.infer<typeof MemberRoleUpdate>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = MemberRoleUpdate.parse(json);
  } catch {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  const { userId } = await params;
  const member = await prisma.membership.findUnique({
    where: { userId },
    select: { id: true, role: true },
  });
  if (!member) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  // Sole-admin guard — can't demote the only admin.
  if (member.role === 'admin' && parsed.role !== 'admin') {
    const adminCount = await prisma.membership.count({ where: { role: 'admin' } });
    if (adminCount <= 1) {
      return NextResponse.json({ error: 'sole_admin_promote_first' }, { status: 409 });
    }
  }

  await prisma.membership.update({
    where: { userId },
    data: { role: parsed.role },
  });
  return new NextResponse(null, { status: 204 });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const auth = await loadAuthedAdmin();
  if ('error' in auth) return auth.error;

  const { userId } = await params;
  if (userId === auth.session.userId) {
    return NextResponse.json({ error: 'cannot_remove_self' }, { status: 409 });
  }

  const member = await prisma.membership.findUnique({
    where: { userId },
    select: { id: true, role: true },
  });
  if (!member) {
    // Idempotent: already removed — return 204.
    return new NextResponse(null, { status: 204 });
  }

  // Sole-admin guard — can't remove the only admin.
  if (member.role === 'admin') {
    const adminCount = await prisma.membership.count({ where: { role: 'admin' } });
    if (adminCount <= 1) {
      return NextResponse.json({ error: 'sole_admin_promote_first' }, { status: 409 });
    }
  }

  await prisma.membership.delete({ where: { userId } });
  return new NextResponse(null, { status: 204 });
}
