// @polsia:user-owned — DELETE /api/team/invites/[id] (team-admin only).
// Soft-deletes a pending invite by stamping revokedAt. We keep the row instead
// of hard-deleting so the audit trail isn't lost.

import 'server-only';
import { NextResponse } from 'next/server';
import { isTeamAdmin } from '@/lib/business/team';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  if (!(await isTeamAdmin(session.userId))) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { id } = await params;
  const row = await prisma.teamInvitation.findUnique({ where: { id } });
  if (!row) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  if (row.acceptedAt || row.revokedAt) {
    // Idempotent: already terminal. Don't error.
    return new NextResponse(null, { status: 204 });
  }

  await prisma.teamInvitation.update({
    where: { id },
    data: { revokedAt: new Date() },
  });
  return new NextResponse(null, { status: 204 });
}
