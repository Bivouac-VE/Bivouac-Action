// @polsia:user-owned — POST /api/team/invites (team-admin only).
//
// Persists an invite row + sends the invite email. Email failures STILL persist
// the row so the admin can "Resend" from the pending-invites island; the
// last-send status fields signal whether the initial send landed.

import 'server-only';
import { NextResponse } from 'next/server';
import { isTeamAdmin } from '@/lib/business/team';
import {
  InviteCreate,
  InviteCreateResponse,
  type InviteCreateResponse as InviteCreateResponseT,
  ROLE_TONE,
} from '@/lib/contracts/team';
import { prisma } from '@/lib/db';
import { sendEmail } from '@/lib/email/send';
import { teamInviteEmail } from '@/lib/email/templates';
import { env } from '@/lib/env';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

// Invite tokens are valid for 14 days. Long enough for someone to recheck email;
// short enough that abandoned invites don't pile up forever.
const INVITE_TTL_DAYS = 14;

function appBaseUrl(): string {
  return env.NEXT_PUBLIC_APP_URL.replace(/\/+$/, '');
}

function inviteAcceptUrl(token: string): string {
  // Team context lands on /signup?invite=<token> (route convention from brief).
  // sign-up auto-signs-in via authConfig; the post-signup hook in
  // src/lib/auth-config.ts converts this invite to a Membership.
  return `${appBaseUrl()}/signup?invite=${encodeURIComponent(token)}`;
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  if (!(await isTeamAdmin(session.userId))) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  let parsed: InviteCreate;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = InviteCreate.parse(json);
  } catch {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  // Conflict: a still-pending invite for this email blocks a re-invite so the
  // admin doesn't double-flood the recipient with the same email.
  const now = new Date();
  const existing = await prisma.teamInvitation.findFirst({
    where: {
      email: parsed.email,
      acceptedAt: null,
      revokedAt: null,
      expiresAt: { gt: now },
    },
    select: { id: true },
  });
  if (existing) {
    return NextResponse.json({ error: 'invite_already_pending' }, { status: 409 });
  }

  // Idempotency: if the same user (the invitee) was previously seated and
  // already has a Membership row, deny — they already belong.
  // We need to check email → userId via User.email.
  const existingUser = await prisma.user.findUnique({
    where: { email: parsed.email },
    select: { id: true },
  });
  if (existingUser) {
    const existingMembership = await prisma.membership.findUnique({
      where: { userId: existingUser.id },
      select: { id: true },
    });
    if (existingMembership) {
      return NextResponse.json({ error: 'already_a_member' }, { status: 409 });
    }
  }

  const expiresAt = new Date(now.getTime() + INVITE_TTL_DAYS * 86_400_000);
  const token = crypto.randomUUID();

  const created = await prisma.teamInvitation.create({
    data: {
      email: parsed.email,
      role: parsed.role,
      token,
      invitedById: session.userId,
      expiresAt,
    },
  });

  // Send the invite email. Persist send result on the row so the client can
  // surface a "send failed" pill — the admin can still revoke/resend.
  const inviter = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { name: true, email: true },
  });
  const acceptUrl = inviteAcceptUrl(token);
  const companyEmail = process.env.POLSIA_COMPANY_EMAIL ?? '';
  const response: InviteCreateResponseT = {
    invite: {
      id: created.id,
      email: created.email,
      role: created.role as InviteCreateResponseT['invite']['role'],
      lastSendStatus: 'sent',
      invitedAt: created.createdAt.toISOString(),
      expiresAt: created.expiresAt.toISOString(),
    },
    acceptUrl,
  };

  try {
    await sendEmail({
      to: created.email,
      ...teamInviteEmail({
        inviterName: inviter?.name ?? 'A teammate',
        inviterEmail: inviter?.email ?? companyEmail,
        teamName: 'Bivouac',
        roleLabel: ROLE_TONE[parsed.role].label,
        acceptUrl,
        expiresAt,
      }),
    });
    return NextResponse.json(InviteCreateResponse.parse(response), { status: 201 });
  } catch {
    // Send failed but row persisted — return success with failed status so the
    // admin sees a "send failed" pill and can hit Resend.
    response.invite.lastSendStatus = 'failed';
    return NextResponse.json(InviteCreateResponse.parse(response), { status: 201 });
  }
}
