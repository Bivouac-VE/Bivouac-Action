// @polsia:user-owned — GET /api/team/state. Combined snapshot the page island
// fetches on mount: tier eligibility, current user (incl. team-admin flag +
// team role), seated members, and pending invites. Single round-trip keeps the
// page from waterfalling several GETs on initial paint.

import 'server-only';
import { NextResponse } from 'next/server';
import { checkTeamTier, isTeamAdmin } from '@/lib/business/team';
import type { TeamState as TeamStateT } from '@/lib/contracts/team';
import { TeamRoleEnum } from '@/lib/contracts/team';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const [tier, callerIsTeamAdmin, callerMembershipRow] = await Promise.all([
    checkTeamTier(session.userId),
    isTeamAdmin(session.userId),
    prisma.membership.findUnique({
      where: { userId: session.userId },
      select: { role: true },
    }),
  ]);
  const callerTeamRole = callerMembershipRow
    ? (TeamRoleEnum.parse(callerMembershipRow.role) as TeamStateT['currentUser']['teamRole'])
    : null;

  // Members + invites only have meaning on the eligible tier. Always 200 with
  // a tier flag so the client island renders the right empty-state without an
  // error arm. On wrong-tier we still return the caller info so the empty CTA
  // can greet them.
  if (tier !== 'ok') {
    const caller = await prisma.user.findUnique({
      where: { id: session.userId },
      select: { id: true, email: true, name: true },
    });
    return NextResponse.json({
      tier,
      currentUser: caller
        ? { ...caller, isTeamAdmin: callerIsTeamAdmin, teamRole: callerTeamRole }
        : null,
      members: [],
      pendingInvites: [],
    });
  }

  // Seated members — join Membership.userId → User via two-step findMany
  // (User lives in the framework-locked auth.prisma, so there is no @relation
  // edge). Pull all live Membership rows, then resolve each userId to User.
  const memberships = await prisma.membership.findMany({
    orderBy: { joinedAt: 'asc' },
  });
  const memberUserIds = memberships.map((row) => row.userId);
  const memberUsers = memberUserIds.length
    ? await prisma.user.findMany({
        where: { id: { in: memberUserIds } },
        select: { id: true, email: true, name: true },
      })
    : [];
  const userById = new Map(memberUsers.map((u) => [u.id, u]));

  const members = memberships
    .map((row) => {
      const u = userById.get(row.userId);
      if (!u) return null;
      return {
        id: row.id,
        userId: row.userId,
        email: u.email,
        name: u.name,
        role: row.role as TeamStateT['members'][number]['role'],
        joinedAt: row.joinedAt.toISOString(),
      };
    })
    .filter((row): row is NonNullable<typeof row> => row !== null);

  // Pending invites — outstanding only (not accepted, not revoked, not expired).
  const now = new Date();
  const invites = await prisma.teamInvitation.findMany({
    where: {
      acceptedAt: null,
      revokedAt: null,
      expiresAt: { gt: now },
    },
    orderBy: { createdAt: 'desc' },
  });

  const caller = await prisma.user.findUnique({
    where: { id: session.userId },
    select: { id: true, email: true, name: true },
  });

  const payload: TeamStateT = {
    tier,
    currentUser: caller
      ? {
          userId: caller.id,
          email: caller.email,
          name: caller.name,
          isTeamAdmin: callerIsTeamAdmin,
          teamRole: callerTeamRole,
        }
      : {
          userId: session.userId,
          email: '',
          name: '',
          isTeamAdmin: callerIsTeamAdmin,
          teamRole: callerTeamRole,
        },
    members,
    pendingInvites: invites.map((row) => ({
      id: row.id,
      email: row.email,
      role: row.role as TeamStateT['pendingInvites'][number]['role'],
      lastSendStatus: null,
      invitedAt: row.createdAt.toISOString(),
      expiresAt: row.expiresAt.toISOString(),
    })),
  };
  return NextResponse.json(payload);
}
