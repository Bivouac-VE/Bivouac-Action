// @polsia:user-owned — GET /api/github/installation/[installationId]/repos.
// Returns the repos the GitHub App install granted access to, as listed via
// GitHub's `GET /app/installations/{id}/repositories`. Auth + IDOR guard +
// shared zod contract on the way out so the client picker island and the
// route handler cannot drift.
//
// IDOR guard: the installation_id must resolve to a `GitHubAppInstallation`
// row owned by the caller — 404 if not found, so a session that probes other
// installations only learns "not yours" and never "yes but you can't see
// them".

import 'server-only';
import { NextResponse } from 'next/server';
import { GithubInstallationRepoList } from '@/lib/contracts/repos';
import { prisma } from '@/lib/db';
import { env } from '@/lib/env';
import { listInstallationRepos } from '@/lib/github-app/repos';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(
  req: Request,
  { params }: { params: Promise<{ installationId: string }> },
) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const { installationId: installationIdRaw } = await params;
  if (!/^\d+$/.test(installationIdRaw)) {
    return NextResponse.json({ error: 'invalid installation_id' }, { status: 400 });
  }
  const installationId = installationIdRaw;

  const installation = await prisma.gitHubAppInstallation.findFirst({
    where: {
      userId: user.id,
      installationId: BigInt(installationId),
    },
    select: { id: true },
  });
  if (!installation) {
    return NextResponse.json({ error: 'Installation not found' }, { status: 404 });
  }

  const appId = env.GITHUB_APP_ID;
  const privateKey = env.GITHUB_APP_PRIVATE_KEY;
  if (!appId || !privateKey) {
    return NextResponse.json({ error: 'GitHub App is not fully configured' }, { status: 503 });
  }

  let repos: Awaited<ReturnType<typeof listInstallationRepos>>;
  try {
    repos = await listInstallationRepos(installationId, {
      appId,
      privateKeyB64: privateKey,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown GitHub error';
    return NextResponse.json(
      { error: 'Could not list installation repos', detail: message.slice(0, 200) },
      { status: 502 },
    );
  }

  const items = repos.map((r) => ({
    installationId,
    githubNodeId: r.githubNodeId,
    githubRepoId: r.githubRepoId.toString(),
    name: r.name,
    ownerHandle: r.ownerHandle,
    defaultBranch: r.defaultBranch,
    visibility: r.visibility,
    pushedAt: r.pushedAt,
  }));

  return NextResponse.json(GithubInstallationRepoList.parse({ items }), { status: 200 });
}
