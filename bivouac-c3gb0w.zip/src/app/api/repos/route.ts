// @polsia:user-owned — /api/repos. GET returns the connected repos for the
// current session (decorated with the active policy-pack via RepoPolicy);
// POST persists the user's enabled set from the repo-picker
// (/dashboard/repos/connect) and attaches the default scoped pack. Both
// always speak through the shared zod contracts so shape changes surface
// as a ZodError instead of silent drift.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  RepoList,
  RepoSelectInput,
  RepoSelectResult,
  type Repo as RepoT,
} from '@/lib/contracts/repos';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

// Default policy pack attached to every newly selected repo so triage starts
// under a known scope. The slug is seeded globally in POLICY_PACK_SEEDS; if
// the catalog row is missing on a fresh DB we silently skip the attach.
const DEFAULT_PACK_SLUG = 'monorepo-lockfile-strict';

export async function GET() {
  let user: SessionUser;
  try {
    user = await requireAuth();
  } catch (res) {
    return res as Response;
  }
  return getReposFor(user.id);
}

export async function POST(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  let parsed: ReturnType<typeof RepoSelectInput.parse>;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    parsed = RepoSelectInput.parse(json);
  } catch {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  const installationId = BigInt(parsed.installationId);

  // IDOR guard: the installation must belong to the caller.
  const installation = await prisma.gitHubAppInstallation.findFirst({
    where: { userId: user.id, installationId },
    select: { id: true },
  });
  if (!installation) {
    return NextResponse.json({ error: 'Installation not found' }, { status: 403 });
  }

  // Default pack catalog lookup — graceful no-op if the seed row is absent.
  const pack = await prisma.policyPack.findUnique({
    where: { slug: DEFAULT_PACK_SLUG },
    select: { slug: true },
  });

  const selectedNodeIds = parsed.repos.map((r) => r.githubNodeId);
  const now = new Date();

  // Existing selection rows for THIS installation — the delta is what
  // changed since the last persist. We compute remove = old \ new so the
  // DeleteMany can't over-delete rows owned by a different installation
  // (the githubNodeId global @unique does not, by itself, scope by owner).
  const oldSelectionRows = await prisma.gitHubAppInstallationRepo.findMany({
    where: { userId: user.id, installationId },
    select: { githubNodeId: true },
  });
  const oldSelectionNodeIds = oldSelectionRows.map((r) => r.githubNodeId);
  const selectionToRemove = oldSelectionNodeIds.filter((n) => !selectedNodeIds.includes(n));

  // Repo rows tied to this install are precisely the ones whose
  // githubNodeId appears in the OLD selection for this install on this
  // user. Repos bound to a different installation have a separate selection
  // row under a different installationId — those are not our concern here.
  const repoRowsToConsider =
    oldSelectionNodeIds.length === 0
      ? []
      : await prisma.repo.findMany({
          where: { userId: user.id, githubNodeId: { in: oldSelectionNodeIds } },
          select: { id: true, githubNodeId: true },
        });
  const reposToRemove = repoRowsToConsider
    .filter((r) => selectionToRemove.includes(r.githubNodeId))
    .map((r) => r.id);

  await prisma.$transaction(async (tx) => {
    // 1. Sync the per-install selection. drop rows that are no longer picked.
    if (selectionToRemove.length > 0) {
      await tx.gitHubAppInstallationRepo.deleteMany({
        where: {
          userId: user.id,
          installationId,
          githubNodeId: { in: selectionToRemove },
        },
      });
    }

    // 2. Upsert each selected repo into the per-install selection set.
    for (const r of parsed.repos) {
      await tx.gitHubAppInstallationRepo.upsert({
        where: { githubNodeId: r.githubNodeId },
        create: {
          installationId,
          userId: user.id,
          githubRepoId: BigInt(r.githubRepoId),
          githubNodeId: r.githubNodeId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
          selectedAt: now,
        },
        update: {
          installationId,
          userId: user.id,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
        },
      });
    }

    // 3. Remove Repo rows for deselected repos that came from THIS install.
    if (reposToRemove.length > 0) {
      await tx.repo.deleteMany({
        where: { userId: user.id, id: { in: reposToRemove } },
      });
    }

    // 4. Upsert each selected repo into the dashboard's `Repo` table so
    //    /dashboard/repos shows it with status badges right away.
    const upsertedRepoIds: string[] = [];
    for (const r of parsed.repos) {
      const row = await tx.repo.upsert({
        where: { githubNodeId: r.githubNodeId },
        select: { id: true },
        create: {
          userId: user.id,
          githubNodeId: r.githubNodeId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
          status: 'HEALTHY',
          lastScannedAt: null,
        },
        update: {
          userId: user.id,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
        },
      });
      upsertedRepoIds.push(row.id);
    }

    // 5. Attach the default scoped pack to every newly selected repo. The
    //    composite @@unique([userId, repoId]) is the at-most-one invariant.
    if (pack && upsertedRepoIds.length > 0) {
      for (const repoId of upsertedRepoIds) {
        await tx.repoPolicy.upsert({
          where: { userId_repoId: { userId: user.id, repoId } },
          create: {
            userId: user.id,
            repoId,
            packSlug: pack.slug,
            appliedAt: now,
          },
          update: {
            packSlug: pack.slug,
            appliedAt: now,
          },
        });
      }
    }
  });

  const payload = {
    saved: parsed.repos.length,
    removed: reposToRemove.length,
    appliedPackSlug: pack?.slug ?? null,
  };
  return NextResponse.json(RepoSelectResult.parse(payload), { status: 200 });
}

async function getReposFor(userId: string): Promise<NextResponse> {
  const rows = await prisma.repo.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  });

  // Look up the active pack per repo in one query, then lookup pack titles in
  // a second query. RepoPolicy is the per-caller join, PolicyPack is the
  // global catalog.
  const repoIds = rows.map((r) => r.id);
  const repoPolicies =
    repoIds.length === 0
      ? []
      : await prisma.repoPolicy.findMany({
          where: { userId, repoId: { in: repoIds } },
          select: { repoId: true, packSlug: true },
        });
  const packSlugs = Array.from(new Set(repoPolicies.map((p) => p.packSlug)));
  const packs =
    packSlugs.length === 0
      ? []
      : await prisma.policyPack.findMany({
          where: { slug: { in: packSlugs } },
          select: { slug: true, title: true },
        });
  const packBySlug = new Map(packs.map((p) => [p.slug, p.title]));
  const policyByRepo = new Map(repoPolicies.map((p) => [p.repoId, p.packSlug]));

  const items: RepoT[] = rows.map((r) => {
    const packSlug = policyByRepo.get(r.id);
    return {
      id: r.id,
      name: r.name,
      ownerHandle: r.ownerHandle,
      lastScannedAt: r.lastScannedAt?.toISOString() ?? null,
      status: r.status,
      activePack:
        packSlug && packBySlug.has(packSlug)
          ? { packSlug, packTitle: packBySlug.get(packSlug) ?? packSlug }
          : null,
    };
  });

  return NextResponse.json(RepoList.parse({ items }), { status: 200 });
}
