// @polsia:user-owned — public list of published posts. Read-only and anonymous;
// every row gated by `publishedAt: { not: null }` so drafts never surface here
// or in the sitemap. Returns the listing summary shape (no `body`); the per-post
// route at /api/posts/[slug] serves the full markdown.

import 'server-only';
import { NextResponse } from 'next/server';
import { PostSummaryList } from '@/lib/contracts/blog';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  const rows = await prisma.post.findMany({
    where: { publishedAt: { not: null } },
    orderBy: { publishedAt: 'desc' },
    select: { id: true, slug: true, title: true, excerpt: true, publishedAt: true },
  });

  const payload = PostSummaryList.parse({
    items: rows.map((r) => ({
      id: r.id,
      slug: r.slug,
      title: r.title,
      excerpt: r.excerpt,
      publishedAt: (r.publishedAt ?? new Date(0)).toISOString(),
    })),
  });

  return NextResponse.json(payload, {
    status: 200,
    headers: { 'cache-control': 'no-store' },
  });
}
