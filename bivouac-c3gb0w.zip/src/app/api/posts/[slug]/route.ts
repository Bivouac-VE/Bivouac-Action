// @polsia:user-owned — public single-post read. `where: { slug, publishedAt:
// { not: null } }` 404s on missing slug and on drafts alike (intentional: a
// draft must not surface via a guessed URL). Body is the full markdown that
// react-markdown renders on /blog/[slug].

import 'server-only';
import { NextResponse } from 'next/server';
import { Post } from '@/lib/contracts/blog';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(_req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const row = await prisma.post.findFirst({
    where: { slug, publishedAt: { not: null } },
    select: {
      id: true,
      slug: true,
      title: true,
      excerpt: true,
      body: true,
      publishedAt: true,
    },
  });

  if (!row) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  const payload = Post.parse({
    id: row.id,
    slug: row.slug,
    title: row.title,
    excerpt: row.excerpt,
    body: row.body,
    publishedAt: (row.publishedAt ?? new Date(0)).toISOString(),
  });

  return NextResponse.json(payload, {
    status: 200,
    headers: { 'cache-control': 'no-store' },
  });
}
