// @polsia:user-owned — GET /api/connect/install-url. Auth-gated: the connect
// round-trip is bound to a specific better-auth session so a stolen callback
// URL can't redirect onto itself. Returns the GitHub App install URL with a
// short-lived HS256 state JWT and an explicit `redirect_url` to
// `/api/connect/github/callback` — GitHub POSTs the user back to us on
// completion; the callback verifies state + persists the installation, then
// forwards the visitor to the /connect/confirm page.

import 'server-only';
import { NextResponse } from 'next/server';
import { ConnectInstallUrl } from '@/lib/contracts/connect';
import { env } from '@/lib/env';
import { signInstallState } from '@/lib/github-app/install-state';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function buildCallbackUrl(): string {
  const base = env.BETTER_AUTH_URL ?? env.NEXT_PUBLIC_APP_URL ?? '';
  const trimmed = base.replace(/\/$/, '');
  return `${trimmed}/api/connect/github/callback`;
}

function configured(): { ok: true } | { ok: false; reason: string } {
  const slug = env.GITHUB_APP_SLUG;
  const appId = env.GITHUB_APP_ID;
  const privateKey = env.GITHUB_APP_PRIVATE_KEY;
  const stateSecret = env.GITHUB_APP_STATE_SECRET;
  if (!slug) return { ok: false, reason: 'GITHUB_APP_SLUG is not configured' };
  if (!appId) return { ok: false, reason: 'GITHUB_APP_ID is not configured' };
  if (!privateKey) return { ok: false, reason: 'GITHUB_APP_PRIVATE_KEY is not configured' };
  if (!stateSecret) return { ok: false, reason: 'GITHUB_APP_STATE_SECRET is not configured' };
  return { ok: true };
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const cfg = configured();
  if (!cfg.ok) {
    return NextResponse.json({ error: cfg.reason }, { status: 503 });
  }
  const slug = env.GITHUB_APP_SLUG as string;
  const appId = env.GITHUB_APP_ID as string;
  const stateSecret = env.GITHUB_APP_STATE_SECRET as string;

  const state = signInstallState({ userId: user.id, secret: stateSecret });
  const redirectUrl = buildCallbackUrl();

  const install = new URL(`https://github.com/apps/${slug}/installations/new`);
  install.searchParams.set('state', state);
  install.searchParams.set('redirect_url', redirectUrl);

  const payload = ConnectInstallUrl.parse({
    url: install.toString(),
    appName: slug,
    appId,
  });
  return NextResponse.json(payload, { status: 200 });
}
