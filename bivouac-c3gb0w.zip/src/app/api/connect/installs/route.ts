// @polsia:user-owned — GET /api/connect/installs. Returns the calling user's
// GitHub App installations + their selected repos for the confirmation page.
// Owner-scoped via `where: { userId: user.id }` — never returns rows that
// belong to another session.

import 'server-only';
import { NextResponse } from 'next/server';
import { ConnectInstallationList } from '@/lib/contracts/connect';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const installations = await prisma.gitHubAppInstallation.findMany({
    where: { userId: user.id, uninstalledAt: null },
    orderBy: { installedAt: 'desc' },
  });

  const repoRows =
    installations.length === 0
      ? []
      : await prisma.gitHubAppInstallationRepo.findMany({
          where: {
            userId: user.id,
            installationId: { in: installations.map((i) => i.installationId) },
          },
          orderBy: { selectedAt: 'desc' },
        });

  const reposByInstall = new Map<string, typeof repoRows>();
  for (const r of repoRows) {
    const key = r.installationId.toString();
    const list = reposByInstall.get(key) ?? [];
    list.push(r);
    reposByInstall.set(key, list);
  }

  const items = installations.map((inst) => {
    const list = reposByInstall.get(inst.installationId.toString()) ?? [];
    return {
      installationId: inst.installationId.toString(),
      account: {
        login: inst.accountLogin,
        type: inst.accountType,
      },
      installedAt: inst.installedAt?.toISOString() ?? null,
      repos: list.map((r) => ({
        githubRepoId: r.githubRepoId.toString(),
        githubNodeId: r.githubNodeId,
        name: r.name,
        ownerHandle: r.ownerHandle,
        defaultBranch: r.defaultBranch,
        selectedAt: r.selectedAt?.toISOString() ?? null,
      })),
    };
  });

  return NextResponse.json(ConnectInstallationList.parse({ items }), { status: 200 });
}
