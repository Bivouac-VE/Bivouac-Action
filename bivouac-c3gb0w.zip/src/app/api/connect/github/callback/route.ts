// @polsia:user-owned — GET /api/connect/github/callback. GitHub redirects
// here with `installation_id` + `state` after the user completes the install.
// Flow: re-auth → verify `state` matches the calling user → use the App JWT
// to fetch installation metadata + selected repos → persist via the business
// helper → 302 to /connect/confirm with the installation_id so the page can
// fetch it.

import 'server-only';
import { NextResponse } from 'next/server';
import { persistInstallation } from '@/lib/business/connect';
import { env } from '@/lib/env';
import { verifyInstallState } from '@/lib/github-app/install-state';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function buildSiteOrigin(): string {
  const base = env.BETTER_AUTH_URL ?? env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';
  return base.replace(/\/$/, '');
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const url = new URL(req.url);
  const installationIdRaw = url.searchParams.get('installation_id');
  const state = url.searchParams.get('state');
  const setupAction = url.searchParams.get('setup_action');

  // Missing params → bail. We deliberately do NOT 302 to the dashboard here
  // because a partial callback is more interesting than silently succeeding.
  if (!installationIdRaw || !state) {
    const target = new URL(`${buildSiteOrigin()}/connect`);
    target.searchParams.set('error', 'missing_params');
    return NextResponse.redirect(target, { status: 302 });
  }

  const stateSecret = env.GITHUB_APP_STATE_SECRET;
  const appId = env.GITHUB_APP_ID;
  const privateKey = env.GITHUB_APP_PRIVATE_KEY;
  if (!stateSecret || !appId || !privateKey) {
    return NextResponse.json({ error: 'GitHub App is not fully configured' }, { status: 503 });
  }

  const verify = verifyInstallState({
    token: state,
    secret: stateSecret,
    currentUserId: user.id,
  });
  if (!verify.ok) {
    const target = new URL(`${buildSiteOrigin()}/connect`);
    target.searchParams.set('error', `state_${verify.reason}`);
    return NextResponse.redirect(target, { status: 302 });
  }

  // Validate the installation id is digit-only — `installation_id` arriving
  // as anything else (NaN, negative, string) is a sign of a tampered URL.
  if (!/^\d+$/.test(installationIdRaw)) {
    return NextResponse.json({ error: 'invalid installation_id' }, { status: 400 });
  }

  try {
    await persistInstallation({
      userId: user.id,
      installationId: BigInt(installationIdRaw),
      appCredentials: { appId, privateKeyB64: privateKey },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown persistence failure';
    const target = new URL(`${buildSiteOrigin()}/connect`);
    target.searchParams.set('error', 'persist_failed');
    target.searchParams.set('detail', message.slice(0, 120));
    return NextResponse.redirect(target, { status: 302 });
  }

  // Acknowledge setup_action only when GitHub actually sent it. We accept
  // both `install` and `update` so re-installs route through here too.
  const confirm = new URL(`${buildSiteOrigin()}/connect/confirm`);
  confirm.searchParams.set('installation_id', installationIdRaw);
  if (setupAction) confirm.searchParams.set('setup_action', setupAction);
  return NextResponse.redirect(confirm, { status: 302 });
}
