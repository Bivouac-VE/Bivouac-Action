// @polsia:user-owned — GET /api/activity. Public, unauthenticated feed of the
// most recent agent actions across connected repos. Backs the
// /activity page (which doubles as a shareable social-proof artifact —
// a buyer can see the agent actually doing the work). No requireAuth: the
// triage rows are intentionally scrapable on this read-only preview
// surface, matching the /api/patches + /api/status public-read convention
// (the only outward-exposed info is a derived summary of public GitHub PRs).
//
// The optional `?limit` query param tunes the response size; default 25
// keeps the page short, hard 100 keeps the response small enough that a
// cold-outreach link never balloons on a busy fleet.

import 'server-only';
import { NextResponse } from 'next/server';
import { loadActivityFeed } from '@/lib/business/activity';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const rawLimit = Number.parseInt(url.searchParams.get('limit') ?? '', 10);
    const payload =
      Number.isFinite(rawLimit) && rawLimit > 0
        ? await loadActivityFeed(rawLimit)
        : await loadActivityFeed();
    return NextResponse.json(payload, { status: 200 });
  } catch {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
