// @polsia:user-owned — /api/digest-prefs. Per-user dashboard settings: the
// daily-digest opt-in boolean + a watermark which the cron writes so that
// row doubles as "did I send today already?" idempotency.
//
// Modeled on src/app/api/policy/route.ts — owner-scoped reads/writes,
// server-only imports, `dynamic = 'force-dynamic'` to opt out of caching.

import 'server-only';
import { NextResponse } from 'next/server';
import { DigestPrefsInput } from '@/lib/contracts/digest-prefs';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

interface UserProfileRow {
  digestOptIn: boolean;
  lastDigestSentAt: Date | null;
}

function toJson(row: UserProfileRow) {
  return {
    digestOptIn: row.digestOptIn,
    lastDigestSentAt: row.lastDigestSentAt ? row.lastDigestSentAt.toISOString() : null,
  };
}

// Default for a fresh row — opt-in per the Prisma schema default (matches
// the brief's permissive default; the toggle UI sets it explicitly).
function defaultDigestOptIn(): boolean {
  return true;
}

export async function GET(_req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(_req);
  } catch (res) {
    return res as Response;
  }

  // upsert ensures a row is present on first visit so the GET never returns
  // a 404. The caller doesn't see a "first-visit" code path — the toggle
  // reads as if it had always existed (mirrors the /api/policy contract).
  const row = await prisma.userProfile.upsert({
    where: { userId: user.id },
    create: { userId: user.id, digestOptIn: defaultDigestOptIn() },
    update: {},
  });

  return NextResponse.json(toJson(row), { status: 200 });
}

export async function PATCH(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  let input: { digestOptIn: boolean };
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    input = DigestPrefsInput.parse(json);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'invalid_request' },
      { status: 400 },
    );
  }

  const row = await prisma.userProfile.upsert({
    where: { userId: user.id },
    create: { userId: user.id, digestOptIn: input.digestOptIn },
    update: { digestOptIn: input.digestOptIn },
  });

  return NextResponse.json(toJson(row), { status: 200 });
}
