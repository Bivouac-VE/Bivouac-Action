// @polsia:user-owned — public /api/changelog route handler. Returns the seeded,
// month-grouped payload to the public client island. `server-only` enforces the
// boundary at import time (so a stray `'use client'` import would fail
// compilation); the schema parses the response so a typo in the seed file
// surfaces as a 500 instead of silent drift.
import 'server-only';
import { NextResponse } from 'next/server';
import { ChangelogList } from '@/lib/contracts/changelog';
import { changelog } from '../../../../content/changelog';

export async function GET() {
  const payload = ChangelogList.parse({ items: changelog });
  return NextResponse.json(payload, { status: 200 });
}
