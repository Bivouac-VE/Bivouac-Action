// @polsia:user-owned — POST /api/repo-policies/apply. Apply a policy-pack to
// one or more of the caller's repos. Upserts a RepoPolicy row per repo
// (composite @@unique([userId, repoId]) so each repo has at most one active
// pack at a time). Returns the list of applied rows.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  ApplyPolicyInput,
  ApplyPolicyResult,
  type ApplyPolicyResult as ApplyPolicyResultT,
} from '@/lib/contracts/policy-packs';
import { prisma } from '@/lib/db';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    const user = await requireAuth(req);

    let parsed: ApplyPolicyInput;
    try {
      const json = (await req.json().catch(() => null)) ?? {};
      parsed = ApplyPolicyInput.parse(json);
    } catch {
      return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
    }

    // Every repoId must belong to the caller. One count query is cheaper
    // than a for-loop findUnique and surfaces IDOR attempts at the
    // authorization boundary.
    const ownedCount = await prisma.repo.count({
      where: { id: { in: parsed.repoIds }, userId: user.id },
    });
    if (ownedCount !== parsed.repoIds.length) {
      return NextResponse.json(
        { error: 'One or more repos are not connected to your account.' },
        { status: 403 },
      );
    }

    const pack = await prisma.policyPack.findUnique({
      where: { slug: parsed.packSlug },
      select: { slug: true, title: true },
    });
    if (!pack) {
      return NextResponse.json({ error: 'Policy pack not found.' }, { status: 404 });
    }

    const now = new Date();
    for (const repoId of parsed.repoIds) {
      await prisma.repoPolicy.upsert({
        where: { userId_repoId: { userId: user.id, repoId } },
        create: {
          userId: user.id,
          repoId,
          packSlug: pack.slug,
          appliedAt: now,
        },
        update: {
          packSlug: pack.slug,
          appliedAt: now,
        },
      });
    }

    const payload: ApplyPolicyResultT = {
      applied: parsed.repoIds.map((repoId) => ({
        repoId,
        packSlug: pack.slug,
        packTitle: pack.title,
      })),
    };

    return NextResponse.json(ApplyPolicyResult.parse(payload), { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
