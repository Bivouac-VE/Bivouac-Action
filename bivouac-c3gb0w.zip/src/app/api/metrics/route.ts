// @polsia:user-owned — GET /api/metrics. Auth-gated read of the three
// compliance headline series (MTTP, auto-merge rate, human-override rate)
// bucketed per-day over a 30/60/90-day window, plus the per-repo breakdown
// rows. Same per-user scoping + range-parsing pattern as the sibling
// /api/metrics/summary handler.

import 'server-only';
import { NextResponse } from 'next/server';
import { loadComplianceMetrics } from '@/lib/business/metrics';
import type { MetricsRangeDays } from '@/lib/contracts/metrics';
import { MetricsRangeDaysEnum } from '@/lib/contracts/metrics';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function parseWindow(value: string | null): MetricsRangeDays {
  const trimmed = (value ?? '').trim().toLowerCase();
  const candidate = trimmed.endsWith('d') ? trimmed.slice(0, -1) : trimmed;
  const parsed = MetricsRangeDaysEnum.safeParse(Number.parseInt(candidate, 10));
  return parsed.success ? parsed.data : 30;
}

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);
    const url = new URL(req.url);
    const windowParam = url.searchParams.get('window');
    if (windowParam !== null) {
      const candidate = (windowParam ?? '').trim().toLowerCase();
      const numeric = candidate.endsWith('d') ? candidate.slice(0, -1) : candidate;
      const parsed = MetricsRangeDaysEnum.safeParse(Number.parseInt(numeric, 10));
      if (!parsed.success) {
        return NextResponse.json(
          { error: 'Invalid window: must be 30, 60, or 90 days' },
          { status: 400 },
        );
      }
    }
    const rangeDays = parseWindow(windowParam);
    const payload = await loadComplianceMetrics(user.id, rangeDays);
    return NextResponse.json(payload, { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
