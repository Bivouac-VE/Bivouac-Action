// @polsia:user-owned — GET /api/metrics/summary. Auth-gated read of the four
// KPI tiles + the patches-per-month and MTTP-trend series for the selected
// date range. Same per-user scoping + range-parsing pattern as
// /api/insights/overview.

import 'server-only';
import { NextResponse } from 'next/server';
import { loadMetricsSummary } from '@/lib/business/metrics';
import { InsightsRangeDaysEnum } from '@/lib/contracts/insights';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function parseRange(value: string | null): 7 | 30 | 90 {
  const trimmed = (value ?? '').trim().toLowerCase();
  const candidate = trimmed.endsWith('d') ? trimmed.slice(0, -1) : trimmed;
  const parsed = InsightsRangeDaysEnum.safeParse(Number.parseInt(candidate, 10));
  return parsed.success ? parsed.data : 30;
}

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);
    const url = new URL(req.url);
    const rangeDays = parseRange(url.searchParams.get('range'));
    const payload = await loadMetricsSummary(user.id, rangeDays);
    return NextResponse.json(payload, { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
