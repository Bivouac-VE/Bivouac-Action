// @polsia:user-owned — GET /api/audit-log. Auth-gated, per-session read of
// the CveTriageLog table scoped by `userId` (per-user audit trail). The page
// itself never touches Prisma; this handler is the only data path.

import 'server-only';
import { NextResponse } from 'next/server';
import { listAudit, parseAuditFilter } from '@/lib/business/audit-log';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);
    const url = new URL(req.url);
    const filter = parseAuditFilter(url.searchParams);
    const payload = await listAudit(filter, user.id);
    return NextResponse.json(payload, { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
