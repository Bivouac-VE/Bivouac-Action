// @polsia:user-owned — GET /api/audit-log/export. Auth-gated CSV download of
// the currently-filtered audit-log rows; stable column order matches the
// /dashboard/audit table exactly. Browser-side rendering of the download is
// the responsibility of the page (a plain `<a href="...">` triggers it
// natively).

import 'server-only';
import { buildAuditCsv, listAudit, parseAuditFilter } from '@/lib/business/audit-log';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function utcFilenameStamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);
    const url = new URL(req.url);
    const filter = parseAuditFilter(url.searchParams);
    const payload = await listAudit(filter, user.id);
    const body = buildAuditCsv(payload.items);
    const filename = `audit-log-${utcFilenameStamp()}.csv`;
    return new Response(body, {
      status: 200,
      headers: {
        'content-type': 'text/csv; charset=utf-8',
        'content-disposition': `attachment; filename="${filename}"`,
        'cache-control': 'no-store',
      },
    });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return new Response('Internal Server Error', { status: 500 });
  }
}
