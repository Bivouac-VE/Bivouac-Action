// @polsia:user-owned — GET /api/onboarding/status. Owner-scoped onboarding
// progress reading the three signals a new user advances through:
// REPO_CONNECTED     → at least one Repo row owned by the caller
// POLICY_CHOSEN      → an explicit AutoMergePolicy row OR a non-default-pack
//                      RepoPolicy row (the auto-attached "monorepo-lockfile-
//                      strict" pack from POST /api/repos does NOT count, so a
//                      "passive" repo select doesn't flip step 2)
// FIRST_PR_SEEN      → at least one CveTriageLog row scoped to the caller
//
// The three counts fan out in one `Promise.all` so a single round trip shape
// satisfies the route. Reads only — no transaction.

import 'server-only';
import { NextResponse } from 'next/server';
import { OnboardingStatus } from '@/lib/contracts/onboarding-status';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

// MUST match the literal `DEFAULT_PACK_SLUG` declared in /api/repos POST so a
// "passive" repo select (the auto-attached default pack) does not flip step 2
// of the onboarding strip.
const DEFAULT_PACK_SLUG = 'monorepo-lockfile-strict';

export async function GET(_req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(_req);
  } catch (res) {
    return res as Response;
  }

  const userId = user.id;

  const [repoCount, policyRowCount, manualPolicyCount, triageRowCount] = await Promise.all([
    prisma.repo.count({ where: { userId } }),
    prisma.autoMergePolicy.count({ where: { userId } }),
    prisma.repoPolicy.count({
      where: { userId, packSlug: { not: DEFAULT_PACK_SLUG } },
    }),
    prisma.cveTriageLog.count({ where: { userId } }),
  ]);

  const steps = {
    REPO_CONNECTED: repoCount > 0,
    POLICY_CHOSEN: policyRowCount > 0 || manualPolicyCount > 0,
    FIRST_PR_SEEN: triageRowCount > 0,
  };
  const complete = steps.REPO_CONNECTED && steps.POLICY_CHOSEN && steps.FIRST_PR_SEEN;

  const payload = { steps, complete };
  return NextResponse.json(OnboardingStatus.parse(payload), { status: 200 });
}
