// @polsia:user-owned — GET /api/dashboard/repo-patches?repo=<id>.
// Returns the per-repo patch list for the caller, narrowed to a single Repo
// they own. The drilldown at /dashboard/repos/[id] "Recent patches" tab uses
// this; the global /api/patches endpoint stays the broader surface.
//
// Scoping: `prUrl contains ${owner/name}` is the existing CveTriageLog → Repo
// join pattern; the brief forbids a Prisma relation between Repo and
// CveTriageLog so we filter in the where-clause. Per-user / legacy-null
// attribution matches the audit log.

import 'server-only';
import { NextResponse } from 'next/server';
import { listRepoPatches, NotFound } from '@/lib/business/patches';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;

function clampLimit(raw: number | null): number {
  if (typeof raw !== 'number' || !Number.isFinite(raw) || raw <= 0) {
    return DEFAULT_LIMIT;
  }
  return Math.min(raw, MAX_LIMIT);
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const url = new URL(req.url);
  const repoId = url.searchParams.get('repo');
  if (!repoId) {
    return NextResponse.json({ error: 'repo query param required' }, { status: 400 });
  }

  const repo = await prisma.repo.findFirst({
    where: { id: repoId, userId: user.id },
    select: { id: true, name: true, ownerHandle: true },
  });
  if (!repo) {
    return NextResponse.json({ error: 'Repository not found' }, { status: 404 });
  }

  const rawLimit = Number.parseInt(url.searchParams.get('limit') ?? '', 10);
  const limit = clampLimit(Number.isFinite(rawLimit) ? rawLimit : null);

  try {
    const payload = await listRepoPatches({
      repoId: repo.id,
      ownerHandle: repo.ownerHandle,
      repoName: repo.name,
      userId: user.id,
      limit,
    });
    return NextResponse.json(payload, { status: 200 });
  } catch (err) {
    if (err instanceof NotFound) {
      return NextResponse.json({ error: 'Repository not found' }, { status: 404 });
    }
    throw err;
  }
}
