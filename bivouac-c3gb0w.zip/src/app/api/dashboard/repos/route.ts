// @polsia:user-owned — GET /api/dashboard/repos. Returns the connected repos
// for the current session, decorated with:
//   - installStatus: derived from GitHubAppInstallationRepo +
//     GitHubAppInstallation (active vs uninstalled) for the install column.
//   - lastActivityAt / activityKind / activityLabel: derived from Repo +
//     CveTriageLog; the activity column shows scanning cadence ("last seen").
//   - patchBadge (brief-facing): derived from the user's most recent
//     CveTriageLog row per repo, bucketed into the four brief badge kinds
//     (monitored / patch open / patch merged / paged human), with a
//     vuln-detected fall-through.
//
// Owner-scoped via `where: { userId: user.id }`; never returns rows that
// belong to another session. Speaks through the shared DashboardReposList
// contract so drift surfaces as a ZodError, not silent JSON poison.

import 'server-only';
import { NextResponse } from 'next/server';
import { repoSlugFromRow } from '@/lib/business/audit-log';
import {
  ActivityKindEnum,
  DashboardReposList,
  type PatchBadgeKind,
  type RepoRow,
} from '@/lib/contracts/dashboard-repos';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

function formatAbsoluteDate(d: Date): string {
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatRelativeFromNow(d: Date, now: Date): string {
  const diffMs = now.getTime() - d.getTime();
  if (Number.isNaN(diffMs)) return formatAbsoluteDate(d);
  const absMs = Math.abs(diffMs);
  const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
  if (absMs < 60_000) return rtf.format(0, 'minute');
  if (absMs < 60 * 60_000) return rtf.format(-Math.round(diffMs / 60_000), 'minute');
  if (absMs < 24 * 60 * 60_000) return rtf.format(-Math.round(diffMs / (60 * 60_000)), 'hour');
  if (absMs < 7 * 24 * 60 * 60_000)
    return rtf.format(-Math.round(diffMs / (24 * 60 * 60_000)), 'day');
  return formatAbsoluteDate(d);
}

function prNumberFromUrl(prUrl: string): string | null {
  const parts = prUrl.split('/').filter(Boolean);
  const last = parts[parts.length - 1];
  if (!last || !/^\d+$/.test(last)) return null;
  return last;
}

function deriveActivity(opts: {
  status: 'HEALTHY' | 'VULN_DETECTED' | 'PR_OPEN' | 'PAGED_HUMAN';
  lastScannedAt: Date | null;
  now: Date;
}): { kind: 'watching' | 'last_scan' | 'last_patch' | 'paged'; label: string; at: string | null } {
  if (opts.status === 'PAGED_HUMAN') {
    return {
      kind: ActivityKindEnum.enum.paged,
      label: 'Paged: awaiting human',
      at: opts.lastScannedAt?.toISOString() ?? null,
    };
  }

  if (!opts.lastScannedAt) {
    return { kind: ActivityKindEnum.enum.last_scan, label: 'Not yet scanned', at: null };
  }

  const ageMs = opts.now.getTime() - opts.lastScannedAt.getTime();
  if (ageMs >= 0 && ageMs <= TWENTY_FOUR_HOURS_MS) {
    return {
      kind: ActivityKindEnum.enum.watching,
      label: `Watching · scanned ${formatAbsoluteDate(opts.lastScannedAt)}`,
      at: opts.lastScannedAt.toISOString(),
    };
  }

  return {
    kind: ActivityKindEnum.enum.last_scan,
    label: `Last scan: ${formatAbsoluteDate(opts.lastScannedAt)}`,
    at: opts.lastScannedAt.toISOString(),
  };
}

interface TriageRow {
  id: string;
  cveId: string | null;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  createdAt: Date;
}

type BadgeBucket = PatchBadgeKind;

function classifyRow(row: TriageRow, now: Date): BadgeBucket | null {
  const ageMs = now.getTime() - row.createdAt.getTime();
  if (ageMs < 0 || ageMs > SEVEN_DAYS_MS) return null;

  // 1. Anything paged-human wins (overrides even a recent auto-merge — the
  //    human attention signal outranks a folded history event).
  if (row.mergeDecision === 'MANUAL_REVIEW' && row.testOutcome !== 'PASSED') {
    return 'paged_human';
  }

  // 2. Fresh auto-merge → "patch merged" (capped to 7 days so the badge
  //    doesn't drown the row forever after).
  if (row.mergeDecision === 'AUTO_MERGE') {
    return 'patch_merged';
  }

  // 3. Open PR — either no decision yet, or a non-passing test on a still-
  //    open PR. The PR must be recent (within 7d, otherwise stale noise).
  const isOpen =
    row.mergeDecision === null ||
    row.mergeDecision === 'PENDING' ||
    (row.testOutcome !== 'PASSED' &&
      (row.testOutcome === 'PENDING' ||
        row.testOutcome === 'FAILED' ||
        row.testOutcome === 'ERRORED'));
  if (isOpen) {
    return 'patch_open';
  }

  return null;
}

function derivePatchBadge(opts: {
  status: 'HEALTHY' | 'VULN_DETECTED' | 'PR_OPEN' | 'PAGED_HUMAN';
  lastScannedAt: Date | null;
  triageRow: TriageRow | null;
  now: Date;
}): { kind: BadgeBucket; label: string; at: string | null } {
  const cls = opts.triageRow ? classifyRow(opts.triageRow, opts.now) : null;

  if (cls === 'paged_human' && opts.triageRow) {
    const number = prNumberFromUrl(opts.triageRow.prUrl);
    const suffix = number ? `#${number}` : 'awaiting';
    return {
      kind: 'paged_human',
      label: `Paged human · ${suffix}`,
      at: opts.triageRow.createdAt.toISOString(),
    };
  }

  if (cls === 'patch_merged' && opts.triageRow) {
    return {
      kind: 'patch_merged',
      label: `Patch merged · ${formatRelativeFromNow(opts.triageRow.createdAt, opts.now)}`,
      at: opts.triageRow.createdAt.toISOString(),
    };
  }

  if (cls === 'patch_open' && opts.triageRow) {
    const number = prNumberFromUrl(opts.triageRow.prUrl);
    const suffix = number ? `#${number}` : 'open';
    return {
      kind: 'patch_open',
      label: `PR open · ${suffix}`,
      at: opts.triageRow.createdAt.toISOString(),
    };
  }

  if (opts.status === 'VULN_DETECTED') {
    return {
      kind: 'vuln_detected',
      label: 'Vulnerability detected · awaiting triage',
      at: opts.lastScannedAt?.toISOString() ?? null,
    };
  }

  if (opts.status === 'PR_OPEN') {
    return {
      kind: 'patch_open',
      label: 'PR open · awaiting tests',
      at: opts.lastScannedAt?.toISOString() ?? null,
    };
  }

  if (opts.status === 'PAGED_HUMAN') {
    return {
      kind: 'paged_human',
      label: 'Paged human · awaiting review',
      at: opts.lastScannedAt?.toISOString() ?? null,
    };
  }

  // HEALTHY, no qualifying triage row → "monitored". Borrow the
  // watching-vs-stale framing from the activity cell.
  if (!opts.lastScannedAt) {
    return { kind: 'monitored', label: 'Not yet scanned', at: null };
  }
  const ageMs = opts.now.getTime() - opts.lastScannedAt.getTime();
  if (ageMs >= 0 && ageMs <= TWENTY_FOUR_HOURS_MS) {
    return {
      kind: 'monitored',
      label: `Watching · scanned ${formatAbsoluteDate(opts.lastScannedAt)}`,
      at: opts.lastScannedAt.toISOString(),
    };
  }
  return {
    kind: 'monitored',
    label: `Last scan: ${formatAbsoluteDate(opts.lastScannedAt)}`,
    at: opts.lastScannedAt.toISOString(),
  };
}

export async function GET(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const repos = await prisma.repo.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
  });

  // Pull every install-selection row for this user; we don't have a Prisma
  // relation between Repo and GitHubAppInstallationRepo, so we join by the
  // githubNodeId (one repo may legitimately map to one install selection).
  const selections =
    repos.length === 0
      ? []
      : await prisma.gitHubAppInstallationRepo.findMany({
          where: {
            userId: user.id,
            githubNodeId: { in: repos.map((r) => r.githubNodeId) },
          },
          select: {
            githubNodeId: true,
            installationId: true,
          },
        });

  // Build a map of githubNodeId → installationId, then resolve each to the
  // parent installation to read uninstalledAt. Two queries total, scoped to
  // the user's installations.
  const installationIds = Array.from(new Set(selections.map((s) => s.installationId.toString())));
  const installations =
    installationIds.length === 0
      ? []
      : await prisma.gitHubAppInstallation.findMany({
          where: {
            userId: user.id,
            installationId: {
              in: installationIds.map((id) => BigInt(id)),
            },
          },
          select: { installationId: true, uninstalledAt: true },
        });
  const uninstalledByInstall = new Map<string, boolean>();
  for (const inst of installations) {
    uninstalledByInstall.set(inst.installationId.toString(), inst.uninstalledAt != null);
  }

  const selectionByNodeId = new Map(selections.map((s) => [s.githubNodeId, s.installationId]));

  // One `cveTriageLog` query for ALL the user's connected repos, joined by
  // `prUrl` containing `owner/name`. `prUrl` is unindexed; at per-user scale
  // (O(hundreds) of triage rows worst case) the contains-filter is fine —
  // the brief explicitly forbids a Prisma relation here.
  let triageRows: TriageRow[] = [];
  if (repos.length > 0) {
    triageRows = await prisma.cveTriageLog.findMany({
      where: {
        userId: user.id,
        OR: repos.map((r) => ({
          prUrl: { contains: `${r.ownerHandle}/${r.name}` },
        })),
      },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        cveId: true,
        prUrl: true,
        testOutcome: true,
        mergeDecision: true,
        createdAt: true,
      },
    });
  }

  // Bucket per repo: keep only the most-recent triage row per owner/repo
  // (newest wins; single bucket — we want the latest event, not the full
  // history — history lives on /dashboard/audit).
  const triageByRepo = new Map<string, TriageRow>();
  for (const row of triageRows) {
    const slug = repoSlugFromRow(row.prUrl);
    if (!slug) continue;
    const existing = triageByRepo.get(slug);
    if (!existing) {
      triageByRepo.set(slug, row);
    }
  }

  const repoKey = (r: { ownerHandle: string; name: string }): string =>
    `${r.ownerHandle}/${r.name}`;

  const now = new Date();

  const items: RepoRow[] = repos.map((r) => {
    const selection = selectionByNodeId.get(r.githubNodeId);
    let installStatus: 'connected' | 'needs_reinstall' | 'pending';
    if (!selection) {
      installStatus = 'needs_reinstall';
    } else {
      const uninstalled = uninstalledByInstall.get(selection.toString());
      installStatus = uninstalled ? 'needs_reinstall' : 'connected';
    }

    const activity = deriveActivity({ status: r.status, lastScannedAt: r.lastScannedAt, now });
    const triageRow = triageByRepo.get(repoKey(r)) ?? null;
    const patchBadge = derivePatchBadge({
      status: r.status,
      lastScannedAt: r.lastScannedAt,
      triageRow,
      now,
    });

    return {
      id: r.id,
      name: r.name,
      ownerHandle: r.ownerHandle,
      githubNodeId: r.githubNodeId,
      defaultBranch: r.defaultBranch,
      status: r.status,
      installStatus,
      lastActivityAt: activity.at,
      activityLabel: activity.label,
      activityKind: activity.kind,
      patchBadge,
    };
  });

  return NextResponse.json(DashboardReposList.parse({ items }), { status: 200 });
}
