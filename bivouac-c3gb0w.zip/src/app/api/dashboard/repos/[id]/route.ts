// @polsia:user-owned — GET /api/dashboard/repos/[id]. Single-repo read used
// by the /dashboard/repos/[id] drilldown page. Joins:
//   - repo identity + status
//   - active PolicyPack via RepoPolicy (the same join /api/repos uses)
//   - caller's global AutoMergePolicy (single per-user row) for the per-repo
//     header chip — the chip reads `scopeMode` + `minSeverity`, so we pass
//     those through typed rather than the raw row, keeping the handler
//     boundary tight.
//
// Returns 404 on unknown id and on ids that exist but belong to a different
// session — IDOR-safe by virtue of `where: { userId: user.id }`.

import 'server-only';
import { NextResponse } from 'next/server';
import { CRON_SCHEDULE, RepoDetailHeader } from '@/lib/contracts/repo-detail';
import { RepoStatusEnum } from '@/lib/contracts/repos';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  const { id } = await params;
  if (!id || typeof id !== 'string') {
    return NextResponse.json({ error: 'invalid_request' }, { status: 400 });
  }

  const repo = await prisma.repo.findFirst({
    where: { id, userId: user.id },
    select: {
      id: true,
      name: true,
      ownerHandle: true,
      defaultBranch: true,
      status: true,
    },
  });
  if (!repo) {
    return NextResponse.json({ error: 'Repository not found' }, { status: 404 });
  }

  // Active pack (optional — repos that pre-date the per-repo pack catalog join
  // still get a valid header, just with `activePack: null`).
  const repoPolicy = await prisma.repoPolicy.findUnique({
    where: { userId_repoId: { userId: user.id, repoId: repo.id } },
    select: { packSlug: true },
  });
  let activePack: { packSlug: string; packTitle: string } | null = null;
  if (repoPolicy) {
    const pack = await prisma.policyPack.findUnique({
      where: { slug: repoPolicy.packSlug },
      select: { slug: true, title: true },
    });
    if (pack) {
      activePack = { packSlug: pack.slug, packTitle: pack.title };
    }
  }

  // Caller's auto-merge policy. The table is upserted on first GET by /api/policy
  // — assume the row exists, but default the chip fields if it doesn't so this
  // endpoint never crashes on a shared env that pre-dates the seed upsert.
  const policyRow = await prisma.autoMergePolicy.findUnique({
    where: { userId: user.id },
    select: { scopeMode: true, minSeverity: true, defaultAction: true },
  });

  // Narrow the persisted `scopeMode` / `minSeverity` strings to the enums the
  // contract accepts. If a row carries a value the contract no longer
  // recognises (forward drift from a schema change), silently fall back to
  // the contract's most permissive defaults rather than 500-ing the header.
  const scopeEnum = zodSafeScope(policyRow?.scopeMode);
  const minSevEnum = zodSafeMinSeverity(policyRow?.minSeverity);
  const defaultActEnum = zodSafeDefaultAction(policyRow?.defaultAction);

  const payload = RepoDetailHeader.parse({
    id: repo.id,
    name: repo.name,
    ownerHandle: repo.ownerHandle,
    defaultBranch: repo.defaultBranch,
    status: RepoStatusEnum.parse(repo.status),
    activePack,
    policy: {
      scopeMode: scopeEnum,
      minSeverity: minSevEnum,
      defaultAction: defaultActEnum,
    },
    cronSchedule: CRON_SCHEDULE,
  });

  return NextResponse.json(payload, { status: 200 });
}

function zodSafeScope(value: string | undefined) {
  if (value === 'cve-only' || value === 'breaking-change-only' || value === 'both') {
    return value;
  }
  return 'both' as const;
}

function zodSafeMinSeverity(value: string | undefined) {
  if (value === 'low' || value === 'medium' || value === 'high' || value === 'critical') {
    return value;
  }
  return 'high' as const;
}

function zodSafeDefaultAction(value: string | undefined) {
  if (value === 'auto-merge' || value === 'open-pr-wait' || value === 'page-human') {
    return value;
  }
  return 'open-pr-wait' as const;
}
