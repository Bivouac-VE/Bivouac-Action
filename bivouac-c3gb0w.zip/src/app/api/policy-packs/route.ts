// @polsia:user-owned — GET /api/policy-packs. Returns the global catalog of
// triage policy-packs the /settings/policy-packs island renders. Auth-gated
// even though the catalog itself is global — the page lives inside the
// dashboard shell so anonymous visitors land on the redirect screen, and
// this endpoint mirrors that policy.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  PageHumanRule,
  PolicyPackList,
  type PolicyPack as PolicyPackT,
  ScopeToggles,
} from '@/lib/contracts/policy-packs';
import { prisma } from '@/lib/db';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    await requireAuth(req);

    const rows = await prisma.policyPack.findMany({
      orderBy: { title: 'asc' },
    });

    const items: PolicyPackT[] = rows.map((r) => ({
      slug: r.slug,
      title: r.title,
      description: r.description,
      scopeToggles: ScopeToggles.parse(r.scopeTogglesJson),
      autoMergeThreshold: r.autoMergeThreshold,
      pageHumanWhen: PageHumanRule.array().parse(r.pageHumanWhenJson),
    }));

    return NextResponse.json(PolicyPackList.parse({ items }), { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
