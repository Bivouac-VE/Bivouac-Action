// @polsia:user-owned — GET /api/policy-packs/targeting. Returns the two task-
// specified starter packs (Monorepo, Microservices fleet) each paired with the
// per-repo targeting list (current pack + divergent flag) for the caller.
// Read-only — the apply write goes through /api/repo-policies/apply.

import 'server-only';
import { NextResponse } from 'next/server';
import { PageHumanRule, ScopeToggles } from '@/lib/contracts/policy-packs';
import {
  PackTargeting,
  PackTargetingList,
  type PackVariant,
} from '@/lib/contracts/policy-packs-multi';
import { prisma } from '@/lib/db';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

// Slugs the brief asks to surface on /dashboard/policy/packs. The third
// existing seed ('public-oss-high-severity-human-page') is intentionally NOT
// in this list — the new island only renders the two task-specified packs.
const TARGET_SLUGS = ['monorepo-lockfile-strict', 'microservices-cve-only-fast-lane'] as const;

const VARIANT_BY_SLUG: Record<string, PackVariant> = {
  'monorepo-lockfile-strict': 'monorepo',
  'microservices-cve-only-fast-lane': 'microservices-fleet',
};

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);

    const packs = await prisma.policyPack.findMany({
      where: { slug: { in: [...TARGET_SLUGS] } },
    });
    // Stable order: monorepo first, then microservices fleet.
    packs.sort(
      (a, b) => TARGET_SLUGS.indexOf(a.slug as never) - TARGET_SLUGS.indexOf(b.slug as never),
    );

    const repos = await prisma.repo.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    });

    const repoIds = repos.map((r) => r.id);
    const repoPolicies =
      repoIds.length === 0
        ? []
        : await prisma.repoPolicy.findMany({
            where: { userId: user.id, repoId: { in: repoIds } },
            select: { repoId: true, packSlug: true },
          });
    const policyByRepo = new Map(repoPolicies.map((p) => [p.repoId, p.packSlug]));

    // Pack-titles cache for any already-active pack (which may be one of the
    // task packs OR a legacy slug still in the global catalog).
    const activeSlugs = Array.from(new Set(repoPolicies.map((p) => p.packSlug)));
    const titles =
      activeSlugs.length === 0
        ? []
        : await prisma.policyPack.findMany({
            where: { slug: { in: activeSlugs } },
            select: { slug: true, title: true },
          });
    const titleBySlug = new Map(titles.map((p) => [p.slug, p.title]));

    const targeting = packs.map((pack) => {
      const items = repos.map((r) => {
        const currentSlug = policyByRepo.get(r.id) ?? null;
        return {
          repoId: r.id,
          repoName: r.name,
          ownerHandle: r.ownerHandle,
          currentPackSlug: currentSlug,
          currentPackTitle: currentSlug ? (titleBySlug.get(currentSlug) ?? null) : null,
          divergent: currentSlug !== pack.slug,
        };
      });
      const divergentCount = items.filter((i) => i.divergent).length;
      return PackTargeting.parse({
        slug: pack.slug,
        variant: VARIANT_BY_SLUG[pack.slug] ?? 'monorepo',
        title: pack.title,
        description: pack.description,
        scopeToggles: ScopeToggles.parse(pack.scopeTogglesJson),
        autoMergeThreshold: pack.autoMergeThreshold,
        pageHumanWhen: PageHumanRule.array().parse(pack.pageHumanWhenJson),
        items,
        divergentCount,
      });
    });

    return NextResponse.json(PackTargetingList.parse({ packs: targeting }), { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
