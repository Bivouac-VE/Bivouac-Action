// @polsia:user-owned — /api/policy. GET returns (and auto-seeds) the caller's
// per-user auto-merge policy; PATCH upserts the caller's row, scoped by
// session userId (NEVER a userId from the body — IDOR guard).
//
// Modeled on src/app/api/example-secure/route.ts — owner-scoped reads/writes,
// server-only imports, `dynamic = 'force-dynamic'` to opt out of caching.

import 'server-only';
import { NextResponse } from 'next/server';
import {
  AUTO_MERGE_DEFAULTS,
  type AutoMergePolicyInput,
  AutoMergePolicyInput as AutoMergePolicyInputSchema,
  parseAutoMergePolicyRow,
} from '@/lib/contracts/auto-merge-policy';
import { prisma } from '@/lib/db';
import { requireAuth, type SessionUser } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

// Strip guardrail rows whose pattern is required but blank. Server-side
// check so the read shape never carries a half-filled rule even if the
// client forgets (defence in depth on top of the form-level filter).
function sanitizeGuardrails(rows: AutoMergePolicyInput['autoMergeGuardrails']) {
  return rows.filter((row) => {
    if (row.kind === 'touches-path' || row.kind === 'has-label') {
      return row.pattern.trim().length > 0;
    }
    return true;
  });
}

// Map the contract-shaped input (e.g. `packageAllowlist`) onto the SQL-shaped
// Prisma columns (e.g. `packageAllowlistJson`). Used both when seeding a
// brand-new row on first GET and when upserting from a PATCH.
function inputToRowData(input: AutoMergePolicyInput | typeof AUTO_MERGE_DEFAULTS) {
  return {
    scopeMode: input.scopeMode,
    minSeverity: input.minSeverity,
    pageOnLicenseFlip: input.pageOnLicenseFlip,
    pageOnTransitiveCve: input.pageOnTransitiveCve,
    pageOnContestedApi: input.pageOnContestedApi,
    defaultAction: input.defaultAction,
    autoMergeGuardrailsJson: sanitizeGuardrails(input.autoMergeGuardrails),
    packageAllowlistJson: input.packageAllowlist,
    packageDenylistJson: input.packageDenylist,
    maxDependencyDepth: input.maxDependencyDepth,
  };
}

export async function GET(_req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(_req);
  } catch (res) {
    return res as Response;
  }

  const existing = await prisma.autoMergePolicy.findUnique({
    where: { userId: user.id },
  });

  const row =
    existing ??
    (await prisma.autoMergePolicy.create({
      data: {
        userId: user.id,
        ...inputToRowData(AUTO_MERGE_DEFAULTS),
      },
    }));

  return NextResponse.json(parseAutoMergePolicyRow(row), { status: 200 });
}

export async function PATCH(req: Request) {
  let user: SessionUser;
  try {
    user = await requireAuth(req);
  } catch (res) {
    return res as Response;
  }

  let input: AutoMergePolicyInput;
  try {
    const json = (await req.json().catch(() => null)) ?? {};
    input = AutoMergePolicyInputSchema.parse(json);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'invalid_request' },
      { status: 400 },
    );
  }

  const row = await prisma.autoMergePolicy.upsert({
    where: { userId: user.id },
    create: {
      userId: user.id,
      ...inputToRowData(input),
    },
    update: inputToRowData(input),
  });

  return NextResponse.json(parseAutoMergePolicyRow(row), { status: 200 });
}
