// @polsia:user-owned — GET /api/status. Public, unauthenticated snapshot of
// the daily triage cron: banner state, 90-day uptime bars, recent
// incidents, 30-day summary. Backs the /status landing demonstration;
// deliberately has no requireAuth() so anonymous visitors can confirm the
// "agent that never sleeps" claim before signing up. Data lives here and
// only here — page and island read it through apiFetch.

import 'server-only';
import { NextResponse } from 'next/server';
import { loadStatusSnapshot } from '@/lib/business/status';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const snapshot = await loadStatusSnapshot();
    return NextResponse.json(snapshot, { status: 200 });
  } catch {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
