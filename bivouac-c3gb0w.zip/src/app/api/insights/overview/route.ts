// @polsia:user-owned — GET /api/insights/overview. Auth-gated read of the four
// KPI tiles, scoped to the signed-in user's connected repos via prUrl-contains
// matching the same algorithm used by /api/audit-log.

import 'server-only';
import { NextResponse } from 'next/server';
import { loadInsightsOverview } from '@/lib/business/insights';
import { InsightsRangeDaysEnum } from '@/lib/contracts/insights';
import { requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

function parseRange(value: string | null): 7 | 30 | 90 {
  const trimmed = (value ?? '').trim().toLowerCase();
  const candidate = trimmed.endsWith('d') ? trimmed.slice(0, -1) : trimmed;
  const parsed = InsightsRangeDaysEnum.safeParse(Number.parseInt(candidate, 10));
  return parsed.success ? parsed.data : 30;
}

export async function GET(req: Request) {
  try {
    const user = await requireAuth(req);
    const url = new URL(req.url);
    const rangeDays = parseRange(url.searchParams.get('range'));
    const payload = await loadInsightsOverview(user.id, rangeDays);
    return NextResponse.json(payload, { status: 200 });
  } catch (res) {
    if (res instanceof Response) {
      return res;
    }
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
