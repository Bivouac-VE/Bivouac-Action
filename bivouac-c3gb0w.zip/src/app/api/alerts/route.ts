// @polsia:user-owned — GET /api/alerts. Team-role gated: visible only to
// admins and on-call members; viewers (and anyone without a Membership row)
// are 403'd out.
//
// The data source is the SAME CveTriageLog table that backs /api/audit-log;
// we filter a strict on-call-duty subset: severity high or critical, AND an
// action that genuinely requires human judgment (red builds, contested
// decisions, merge-blocked). We re-derive severity the same way audit-log
// does (via @/lib/business/patches) so the badges line up. Alerts are scoped
// to the signed-in user's own audit rows (matches audit-log's per-user-and-
// null contract) so a fresh signup with no real events yet sees an honest
// empty list instead of a leaked cross-tenant stream.

import 'server-only';
import { NextResponse } from 'next/server';
import { deriveSeverity } from '@/lib/business/patches';
import { AlertEntry, AlertList, type AlertList as AlertListT } from '@/lib/contracts/alerts';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/server/session';

export const dynamic = 'force-dynamic';

const ALERT_LIMIT = 50;
const SCAN_LIMIT = 100;

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Team-tier gate. The route does NOT enforce billing-plan tier — a
  // starter-tier viewer can HAVE a Membership row; the role check is what
  // filters the surface. No Membership row at all also blocks here.
  const membership = await prisma.membership.findUnique({
    where: { userId: session.userId },
    select: { role: true },
  });
  const role = membership?.role;
  if (role !== 'admin' && role !== 'on_call') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const rows = await prisma.cveTriageLog.findMany({
    where: {
      OR: [{ userId: session.userId }, { userId: null }],
    },
    orderBy: { createdAt: 'desc' },
    take: SCAN_LIMIT,
  });

  const alerts = rows
    .map((row) => toAlertEntry(row))
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null)
    .slice(0, ALERT_LIMIT);

  const payload: AlertListT = { alerts };
  return NextResponse.json(AlertList.parse(payload));
}

function toAlertEntry(row: {
  id: string;
  cveId: string | null;
  packageName: string;
  fromVersion: string;
  toVersion: string;
  prUrl: string;
  testOutcome: string;
  mergeDecision: string;
  createdAt: Date;
}): AlertEntry | null {
  const sev = deriveAlertSeverity(row.cveId, deriveSeverity);
  if (sev !== 'high' && sev !== 'critical') return null;

  const decision = row.mergeDecision as 'AUTO_MERGE' | 'MANUAL_REVIEW' | 'BLOCKED';
  const alertAction =
    decision === 'BLOCKED'
      ? 'merge_blocked'
      : decision === 'MANUAL_REVIEW'
        ? 'contested_decision'
        : 'red_build';

  const testOutcome = row.testOutcome as 'PASSED' | 'FAILED' | 'ERRORED' | 'PENDING';
  // Auto-merge rows only count as alerts when the test failed or errored —
  // a clean auto-merge doesn't page on-call.
  if (alertAction === 'red_build' && testOutcome !== 'FAILED' && testOutcome !== 'ERRORED') {
    return null;
  }

  const repoSlug = repoSlugFromRow(row.prUrl);
  const summary =
    row.cveId === null
      ? `${row.packageName} ${row.fromVersion} → ${row.toVersion} requires attention`
      : `${row.cveId} on ${row.packageName} ${row.fromVersion} → ${row.toVersion}`;

  return AlertEntry.parse({
    id: row.id,
    at: row.createdAt.toISOString(),
    repo: repoSlug,
    severity: sev,
    action: alertAction,
    summary,
    deepLinkHref: buildDeepLinkHref(repoSlug, row.cveId, sev),
  });
}

function deriveAlertSeverity(
  cveId: string | null,
  deriveSeverityFn: (cveId: string) => 'low' | 'medium' | 'high' | 'critical',
): 'low' | 'medium' | 'high' | 'critical' {
  if (cveId === null) {
    // BREAKING rows don't carry a CVE id. BREAKING is moderate priority at
    // most — drop them so they don't page on-call.
    return 'low';
  }
  return deriveSeverityFn(cveId);
}

function repoSlugFromRow(prUrl: string): string {
  try {
    const u = new URL(prUrl);
    const parts = u.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0]}/${parts[1]}`;
    }
    return '';
  } catch {
    return '';
  }
}

function buildDeepLinkHref(repoSlug: string, cveId: string | null, severity: string): string {
  const params = new URLSearchParams();
  if (repoSlug) params.set('repo', repoSlug);
  if (cveId) params.set('cveId', cveId);
  if (severity) params.set('severity', severity);
  params.set('action', 'paged');
  const qs = params.toString();
  return qs.length > 0 ? `/dashboard/audit?${qs}` : '/dashboard/audit';
}
