// @polsia:user-owned — Public /status route. Server Component that only
// exports per-page metadata + composes the client island; the actual
// data fetch is done by apiFetch from the <StatusBoard/> island against
// the matching /api/status route handler.

import type { Metadata } from 'next';
import { StatusBoard } from '@/components/custom/status/status-board';

export const metadata: Metadata = {
  title: 'Agent status',
  description:
    'Real-time operational health, 90-day uptime, and recent CVE→PR incidents for the Bivouac triage agent.',
  alternates: { canonical: '/status' },
  openGraph: {
    title: 'Agent status — Bivouac',
    description:
      'Real-time operational health, 90-day uptime, and recent CVE→PR incidents for the Bivouac triage agent.',
    url: '/status',
  },
};

export default function StatusPage() {
  return (
    <main className="container-page flex flex-col gap-8 py-section">
      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Operational telemetry</p>
        <h1 className="font-display text-h1 text-balance text-foreground">Agent status</h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          The Bivouac agent runs a daily triage cron against the connected repository fleet. This
          page is a public view of how that cron is doing right now — banner state, 90-day uptime,
          recent detections, and detection-to-PR latency — sourced from the same audit log the
          dashboard reads. No sign-in required.
        </p>
      </header>

      <StatusBoard />
    </main>
  );
}
