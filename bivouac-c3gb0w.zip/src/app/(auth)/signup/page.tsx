// @polsia:user-owned — /signup Server Component exports metadata, reads the
// `?returnTo` query param defensively (must be a same-origin `/path` not `//`)
// and mounts the <SignUpForm/> client island. No Server Actions — the form
// posts to better-auth's catch-all `/api/auth/sign-up/email` via the client.

import type { Metadata } from 'next';
import { SignUpForm } from '@/components/custom/sign-up-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { firstReturnTo, readReturnTo } from '@/lib/business/auth-returnto';

export const metadata: Metadata = {
  title: 'Sign up',
  description: 'Create a Bivouac account.',
  alternates: { canonical: '/signup' },
  robots: { index: false, follow: false },
};

export default async function SignupPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const returnTo = readReturnTo(firstReturnTo(params.returnTo));

  return (
    <main className="min-h-dvh flex items-center justify-center px-gutter py-section bg-[var(--background)]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[var(--brand-100)] opacity-40 blur-3xl" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-[var(--brand-200)] opacity-30 blur-3xl" />
      </div>

      <Card className="relative w-full max-w-md shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-h4">Create an account</CardTitle>
          <CardDescription>Get started — it&apos;s free</CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <SignUpForm returnTo={returnTo} />
        </CardContent>
      </Card>
    </main>
  );
}
