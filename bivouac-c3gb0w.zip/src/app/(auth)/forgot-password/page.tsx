// @polsia:user-owned — /forgot-password Server Component. Exports noindex
// metadata (private flow, never indexed) + composes the Card around the
// <ForgotPasswordForm/> client island. The form posts directly to the
// better-auth catch-all via authClient — no Server Action, no /api handler.

import type { Metadata } from 'next';
import { ForgotPasswordForm } from '@/components/custom/forgot-password-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export const metadata: Metadata = {
  title: 'Reset your password',
  description: 'Get a reset link emailed to you.',
  alternates: { canonical: '/forgot-password' },
  robots: { index: false, follow: false },
};

export default function ForgotPasswordPage() {
  return (
    <main className="min-h-dvh flex items-center justify-center px-gutter py-section bg-[var(--background)]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[var(--brand-100)] opacity-40 blur-3xl" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] rounded-full bg-[var(--brand-200)] opacity-30 blur-3xl" />
      </div>

      <Card className="relative w-full max-w-md shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-h4">Forgot your password?</CardTitle>
          <CardDescription>Enter your email and we&apos;ll send a reset link</CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <ForgotPasswordForm />
        </CardContent>
      </Card>
    </main>
  );
}
