// @polsia:user-owned — /reset-password Server Component. Reads the validation
// token from `?token=…`, exports noindex metadata, and renders the
// <ResetPasswordForm/> client island with the token. The form posts to the
// better-auth catch-all via authClient — no Server Action, no /api handler.

import type { Metadata } from 'next';
import { ResetPasswordForm } from '@/components/custom/reset-password-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export const metadata: Metadata = {
  title: 'Set a new password',
  description: 'Choose a new password to finish resetting your account.',
  alternates: { canonical: '/reset-password' },
  robots: { index: false, follow: false },
};

function firstValue(v: string | string[] | undefined): string | undefined {
  if (Array.isArray(v)) return v[0];
  return v;
}

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const token = firstValue(params.token) ?? null;

  return (
    <main className="min-h-dvh flex items-center justify-center px-gutter py-section bg-[var(--background)]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[var(--brand-100)] opacity-40 blur-3xl" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-[var(--brand-200)] opacity-30 blur-3xl" />
      </div>

      <Card className="relative w-full max-w-md shadow-brand border border-border/60 bg-card/95 backdrop-blur-sm">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-h4">Set a new password</CardTitle>
          <CardDescription>You&apos;re almost back in</CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <ResetPasswordForm token={token} />
        </CardContent>
      </Card>
    </main>
  );
}
