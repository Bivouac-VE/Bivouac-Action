// @polsia:user-owned — 'How Bivouac compares — and where to read more' capability
// matrix on the homepage. 6 capability rows × 4 competitors (Bivouac + 3
// alternatives). Cells are short yes/no/partial strings + per-competitor
// outbound link to the corresponding /blog/<slug> published comparison post.
// Same `Table`/`Card` primitives as the sibling LandingComparisonTable.

import Link from 'next/link';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

type CapabilityRow = {
  capability: string;
  bivouac: string;
  dependabot: string;
  renovate: string;
  snykOpenSource: string;
};

const CAPABILITY_ROWS: CapabilityRow[] = [
  {
    capability: 'Autonomous patch PR',
    bivouac: 'opens a draft PR against the right pin, fork, or downgrade',
    dependabot: 'opens a forward-fix PR',
    renovate: 'opens a forward-fix or pin PR',
    snykOpenSource: 'no PR — surfaces an advisory',
  },
  {
    capability: 'Breaking-change detection on dep bumps',
    bivouac: 'lockfile drift and SemVer-major upstream moves are a trigger',
    dependabot: 'not a trigger — advisory-driven',
    renovate: 'tracks SemVer-major upstream moves',
    snykOpenSource: 'not a trigger — advisory-driven',
  },
  {
    capability: 'Fallback downgrade',
    bivouac: 'picks downgrade-as-fix when the forward upgrade is incompatible',
    dependabot: 'forward-only — fails open otherwise',
    renovate: 'forward-only by default',
    snykOpenSource: 'not a remediation tool',
  },
  {
    capability: 'Human-page-on-judgment calls',
    bivouac:
      'pages the on-call only on contested decisions — license, public API, security surface',
    dependabot: 'not in scope',
    renovate: 'not in scope',
    snykOpenSource: 'not in scope',
  },
  {
    capability: 'Audit log / attestation',
    bivouac: 'every merged patch carries a signed audit row (feed, decision, test outcome)',
    dependabot: 'not in scope',
    renovate: 'not in scope',
    snykOpenSource: 'not in scope',
  },
  {
    capability: 'Transitive CVE coverage',
    bivouac: 'NVD + GHSA, scoped to direct and transitive per repo policy',
    dependabot: 'public advisory feeds, direct-dependency scope',
    renovate: 'public advisory feeds, transitive scope',
    snykOpenSource: 'NVD + vendor-curated DB, direct + transitive scope',
  },
];

export function LandingCapabilityMatrix() {
  return (
    <section className="section bg-muted/40">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">How Bivouac compares</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Capability by capability &mdash; and where to read more.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Six properties that decide whether a dependency-watch tool actually closes the loop.
            Each competitor&rsquo;s column links to the published comparison post so you can read
            the full argument behind every cell.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="border-border bg-muted/50">
                <TableHead className="w-[34%] font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Capability
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-brand-700 dark:text-brand-300">
                  Bivouac
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  <Link
                    href="/blog/bivouac-vs-dependabot"
                    className="underline-offset-4 hover:underline"
                  >
                    Dependabot
                  </Link>
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  <Link
                    href="/blog/bivouac-vs-renovate"
                    className="underline-offset-4 hover:underline"
                  >
                    Renovate
                  </Link>
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  <Link
                    href="/blog/bivouac-vs-snyk-open-source"
                    className="underline-offset-4 hover:underline"
                  >
                    Snyk Open Source
                  </Link>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {CAPABILITY_ROWS.map((row) => (
                <TableRow key={row.capability}>
                  <TableCell className="align-top text-small font-medium text-foreground">
                    {row.capability}
                  </TableCell>
                  <TableCell className="align-top text-small text-brand-700 dark:text-brand-300">
                    {row.bivouac}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.dependabot}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.renovate}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.snykOpenSource}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <p className="max-w-3xl border-t border-border pt-6 text-small text-muted-foreground">
          Each competitor column links to the in-depth comparison post &mdash;{' '}
          <Link href="/blog/bivouac-vs-dependabot" className="underline-offset-4 hover:underline">
            Bivouac vs Dependabot
          </Link>
          ,{' '}
          <Link href="/blog/bivouac-vs-renovate" className="underline-offset-4 hover:underline">
            Bivouac vs Renovate
          </Link>
          , and{' '}
          <Link
            href="/blog/bivouac-vs-snyk-open-source"
            className="underline-offset-4 hover:underline"
          >
            Bivouac vs Snyk Open Source
          </Link>
          .
        </p>
      </div>
    </section>
  );
}
