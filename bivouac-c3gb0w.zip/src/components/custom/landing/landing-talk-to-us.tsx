// @polsia:user-owned — 'Talk to us' panel on the landing page. Server shell
// renders the contact-form module's <ContactForm /> client island — the form
// owns its own submit path via /api/contact; this section owns the framing.
// Visually demoted: the page's primary CTA is "<PrimaryCtaButton/>" elsewhere,
// so this panel sits in muted-secondary treatment instead of competing for
// the fold.

import { ContactForm } from '@/components/custom/contact-form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export function LandingTalkToUs() {
  return (
    <section className="section bg-muted/20">
      <div className="container-page grid gap-10 md:grid-cols-[1.2fr_1fr] md:items-start">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Talk to us</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            Got a fleet, a regulated environment, or a tricky policy?
          </h2>
          <p className="max-w-xl text-body text-muted-foreground">
            Drop a few lines and someone from the Bivouac team will respond within one business day
            — no SDR sequence, no demo gauntlet. We&apos;ll help you size the rollout and pick the
            right policy pack for the repos you actually watch.
          </p>
          <p className="text-small text-muted-foreground">
            Already running Dependabot, Renovate, or Snyk? Tell us what you&apos;re paying for them
            — we&apos;ll show you the overlap with what Bivouac earns.
          </p>
        </div>

        <Card className="flex flex-col border-border bg-card">
          <CardHeader className="gap-2">
            <CardTitle className="font-display text-h4 text-foreground">Send us a note</CardTitle>
            <CardDescription className="text-small text-muted-foreground">
              We read every message. Expect a real reply from a person on the team, not a sequence.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ContactForm />
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
