// @polsia:user-owned — "What does one vulnerability cost your team?" section
// on the landing page. Side-by-side manual vs. automated step lists, with a
// time/effort delta band on top so the savings read before the eye reaches the
// lists. Static copy; no data fetch, no auth, no DB read.

import { CheckCircle2, Clock, X } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const MANUAL_STEPS: string[] = [
  'CVE detected',
  'engineer receives alert',
  'investigates',
  'finds compatible version',
  'creates PR',
  'CI runs',
  'tests fail',
  'engineer investigates',
  'fixes dependency conflict',
  'PR reviewed → merged',
];

const AUTOMATED_STEPS: string[] = [
  'CVE detected',
  'Bivouac investigates',
  'creates fix',
  'runs tests',
  'merges if green',
];

export function LandingCostComparison() {
  return (
    <section id="vuln-cost" className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Cost of one vulnerability</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            What does one vulnerability actually cost your team?
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Same CVE. Same fix. Same end state. The gap between these two timelines is why teams buy
            Bivouac — not because the alert is unique, but because the path from alert to merge is.
          </p>
        </div>

        {/* Delta band — editorial anchor that lands the savings number before
            the reader scans the lists. Mirrors the brand-tinted callout in
            <LandingEscalationGuardrails/> so the two depth sections rhyme. */}
        <div className="grid items-stretch gap-px overflow-hidden rounded-xl border border-border bg-border shadow-sm md:grid-cols-[1fr_auto_1fr]">
          <div className="flex flex-col gap-2 bg-card px-6 py-6 md:px-8 md:py-8">
            <p className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
              Without Bivouac
            </p>
            <p className="font-display text-h2 text-balance text-foreground">4–6 hours</p>
            <p className="flex items-center gap-1.5 text-caption text-muted-foreground">
              <Clock className="size-3.5" aria-hidden /> 10 manual steps · engineer on the loop
            </p>
          </div>
          <div
            aria-hidden
            className="flex items-center justify-center bg-brand-500 px-4 py-3 font-display text-caption font-semibold uppercase tracking-[0.18em] text-primary-foreground md:px-6"
          >
            vs
          </div>
          <div className="flex flex-col gap-2 bg-brand-500/10 px-6 py-6 md:px-8 md:py-8">
            <p className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
              With Bivouac
            </p>
            <p className="font-display text-h2 text-balance text-foreground">5–15 minutes</p>
            <p className="flex items-center gap-1.5 text-caption text-brand-700 dark:text-brand-300">
              <Clock className="size-3.5" aria-hidden /> 5 automated steps · engineer asleep
            </p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <FlowCard
            eyebrow="Without Bivouac"
            tone="manual"
            steps={MANUAL_STEPS}
            stat="4–6 hours"
            statLabel="10 manual steps"
          />
          <FlowCard
            eyebrow="With Bivouac"
            tone="automated"
            steps={AUTOMATED_STEPS}
            stat="5–15 minutes"
            statLabel="5 automated steps"
          />
        </div>

        <p className="max-w-2xl text-caption text-muted-foreground">
          Median across the Bivouac benchmark suite, 2026-Q2 — same CVE, same test suite, real
          engineer time measured end-to-end.
        </p>
      </div>
    </section>
  );
}

type FlowCardProps = {
  eyebrow: string;
  tone: 'manual' | 'automated';
  steps: string[];
  stat: string;
  statLabel: string;
};

function FlowCard({ eyebrow, tone, steps, stat, statLabel }: FlowCardProps) {
  const isAutomated = tone === 'automated';
  // The right card borrows the terminal-row treatment from the live
  // walkthrough above so the "resolved" stack reads as the same good outcome.
  return (
    <Card
      className={cn(
        'lift h-full',
        isAutomated ? 'border-brand-500/60 bg-brand-500/10 shadow-brand' : 'border-border bg-card',
      )}
    >
      <CardHeader className="gap-3">
        <p
          className={cn(
            'font-display text-caption font-semibold uppercase tracking-[0.08em]',
            isAutomated ? 'text-brand-700 dark:text-brand-300' : 'text-muted-foreground',
          )}
        >
          {eyebrow}
        </p>
        <p className="font-display text-h3 text-balance text-foreground">{stat}</p>
        <p
          className={cn(
            'text-caption',
            isAutomated ? 'text-brand-700 dark:text-brand-300' : 'text-muted-foreground',
          )}
        >
          {statLabel}
        </p>
      </CardHeader>
      <CardContent className="pt-0">
        <ol className="flex flex-col">
          {steps.map((label, idx) => (
            <li
              key={`${tone}-${idx}-${label}`}
              className="flex items-start gap-3 border-t border-border/60 py-3 first:border-t-0 first:pt-1 last:pb-1"
            >
              <span
                className={cn(
                  'flex size-7 shrink-0 items-center justify-center rounded-full font-mono text-small font-semibold',
                  isAutomated
                    ? 'bg-brand-500 text-primary-foreground'
                    : 'border border-border bg-muted text-muted-foreground',
                )}
                aria-hidden
              >
                {idx + 1}
              </span>
              <span
                className={cn(
                  'mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full',
                  isAutomated
                    ? 'bg-brand-500/20 text-brand-700 dark:text-brand-300'
                    : 'bg-muted text-muted-foreground',
                )}
                aria-hidden
              >
                {isAutomated ? (
                  <CheckCircle2 className="size-3.5" aria-hidden />
                ) : (
                  <X className="size-3.5" aria-hidden />
                )}
              </span>
              <span className="flex-1 pt-0.5 text-body text-foreground">{label}</span>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  );
}
