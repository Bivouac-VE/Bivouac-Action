// @polsia:user-owned — landing-page primary CTA. The auth check has to be a
// client island because the session cookie is read by better-auth's react
// client; a server component can't see it. Mirrors the pattern in site-nav.tsx.

'use client';

import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import type { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { useSession } from '@/lib/auth-client';
import { cn } from '@/lib/utils';

export function PrimaryCtaButton({
  signedInLabel = 'Open dashboard',
  signedOutLabel = 'Start free',
  signedOutMicrocopy,
  size = 'lg',
  buttonClassName,
}: {
  signedInLabel?: string;
  signedOutLabel?: string;
  signedOutMicrocopy?: ReactNode;
  size?: 'lg' | 'default' | 'sm';
  buttonClassName?: string;
}) {
  const { data } = useSession();
  const isAuthenticated = Boolean(data?.user);
  const href = isAuthenticated ? '/dashboard' : '/signup';
  const label = isAuthenticated ? signedInLabel : signedOutLabel;

  return (
    <div className="flex flex-col items-start gap-1">
      <Button asChild size={size} className={cn('gap-2 shadow-brand', buttonClassName)}>
        <Link href={href}>
          {label}
          <ArrowRight className="size-4" aria-hidden />
        </Link>
      </Button>
      {!isAuthenticated && signedOutMicrocopy ? (
        <span className="text-caption text-muted-foreground">{signedOutMicrocopy}</span>
      ) : null}
    </div>
  );
}
