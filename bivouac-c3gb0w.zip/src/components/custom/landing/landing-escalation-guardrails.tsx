// @polsia:user-owned — Human-escalation guardrails section on the landing
// page. Buyer-reassurance depth section: pairs the live CVE walkthrough's
// 'no engineer woken up' arc with the explicit escalation rules so the
// autonomous-merging claim doesn't read as unbounded. Static copy + a static
// trigger array; no data fetch.

import { AlertTriangle, GitMerge, ScrollText, ShieldCheck } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader } from '@/components/ui/card';

const TRIGGERS: {
  label: string;
  body: string;
  Icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    label: 'Contested decisions',
    body: "When the right remediation isn't unambiguous — forward-fix vs. downgrade vs. pin — the agent opens the PR as a draft and pages a maintainer to pick.",
    Icon: GitMerge,
  },
  {
    label: 'Security-sensitive surfaces',
    body: 'Auth, crypto, signing, and supply-chain entry points. The agent stops and waits for human review before any patch lands in those files.',
    Icon: ShieldCheck,
  },
  {
    label: 'License concerns',
    body: 'License churn (new copyleft dependency, attribution drift, GPL contamination). The agent refuses to merge and surfaces the licensing diff to a maintainer.',
    Icon: ScrollText,
  },
  {
    label: 'Failing builds',
    body: 'If the test suite goes red on the patch, the agent blocks the merge, opens the PR as a draft, and writes the failure to the audit log.',
    Icon: AlertTriangle,
  },
];

export function LandingEscalationGuardrails() {
  return (
    <section id="human-in-the-loop" className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Human in the loop</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            AI handles the routine. Engineers handle the exceptions.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Bivouac doesn&apos;t replace your engineers — it removes the repetitive dependency work
            that doesn&apos;t require engineering judgment. The same loop runs on every signal:
            investigate, fix, test, merge. Engineers stay responsible for the calls that need
            humans.
          </p>
        </div>

        {/* Rule band — editorial anchor. Reinforces the 'routine vs. exception'
            split in one line so the four trigger cards below it read as the
            explicit list, not as marketing decoration. Sits in a brand-tinted
            callout that mirrors the cve-walkthrough's done-row treatment so
            the section ties back to the autonomous-merge demo above it. */}
        <div className="relative overflow-hidden rounded-xl border border-brand-500/40 bg-brand-500/10 px-6 py-8 shadow-sm md:px-10 md:py-10">
          <span
            aria-hidden
            className="absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-brand-500 via-brand-500/80 to-brand-500/40"
          />
          <p className="font-display text-h3 text-balance text-foreground md:text-h2">
            If it doesn&apos;t require engineering judgment, Bivouac closes it.{' '}
            <span className="text-brand-700 dark:text-brand-300">
              If it does, Bivouac pages you.
            </span>
          </p>
          <p className="mt-4 max-w-2xl text-body text-foreground">
            The four triggers below are the only conditions that wake the on-call. This is an opt-in
            rule per repo and lives inside the policy pack, so it&apos;s reviewable in the same diff
            as the patch.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {TRIGGERS.map((trigger) => (
            <Card key={trigger.label} className="lift h-full border-border bg-card">
              <CardHeader className="gap-3">
                <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                  <trigger.Icon className="size-4" aria-hidden />
                </span>
                <span className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                  {trigger.label}
                </span>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-body text-foreground">
                  {trigger.body}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
