// @polsia:user-owned — 3-step 'how it works' flow. Server component; literal
// copy only. The brief explicitly asks for an exactly 3-step version.

import { CheckCircle2, GitMerge, Radar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const STEPS: {
  step: string;
  title: string;
  body: string;
  detail: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    step: '01',
    title: 'Watches',
    body: 'Continuous watch on your GitHub repositories and dependency trees.',
    detail:
      'Public and private advisory feeds, package-registry disclosures, and upstream breaking changes — scanned every five minutes.',
    icon: Radar,
  },
  {
    step: '02',
    title: 'Investigates',
    body: 'Reads the signal. Picks forward fix, downgrade, or pin against your policy pack.',
    detail:
      'SemVer, peer usage, license posture, and security-sensitive surfaces — chosen locally before any code is touched.',
    icon: CheckCircle2,
  },
  {
    step: '03',
    title: 'Patch, test, merge',
    body: 'Opens a draft PR, runs the project test suite, and auto-merges on green.',
    detail:
      'The build is the gate. Red blocks the merge. License churn, public-API breakage, and security-sensitive surfaces stop at a human — every widening is opt-in per repo.',
    icon: GitMerge,
  },
];

export function LandingHowItWorks() {
  return (
    <section className="section-lg">
      <div className="container-page flex flex-col gap-12">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">How it works</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            From disclosure to merged fix — on its own shift.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Every signal runs the same three-step track. The test suite is the gate. The on-call
            only gets paged for contested decisions, security-sensitive surfaces, license concerns,
            or failing builds.
          </p>
        </div>

        <ol className="grid gap-4 md:grid-cols-3">
          {STEPS.map((s) => (
            <li key={s.step} className="flex flex-col">
              <Card className="lift flex h-full flex-col">
                <CardHeader className="gap-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-caption font-bold text-brand-700 dark:text-brand-300">
                      {s.step}
                    </span>
                    <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                      <s.icon className="size-4" aria-hidden />
                    </span>
                  </div>
                  <CardTitle className="font-display text-h3 text-foreground">{s.title}</CardTitle>
                  <CardDescription className="text-body text-foreground">{s.body}</CardDescription>
                </CardHeader>
                <CardContent className="mt-auto">
                  <p className="text-small text-muted-foreground">{s.detail}</p>
                </CardContent>
              </Card>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
