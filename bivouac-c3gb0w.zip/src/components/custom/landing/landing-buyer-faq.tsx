// @polsia:user-owned — homepage buyer-objections FAQ. Client island; literal
// copy, no apiFetch, no state beyond the Radix-backed <Accordion/> open/closed
// UI. Sits above <LandingFinalCta/> so the conversion card follows it.

'use client';

import Link from 'next/link';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ: { q: string; a: string }[] = [
  {
    q: 'How does pricing scale with repo count?',
    a: 'Per active repo per month, the same on every plan tier — Starter ($19), Team ($39), Enterprise ($99) — so a 3-repo org and a 60-repo org pay for what they actually watch, not a tier that bakes in headroom. Volume kicks in past the Enterprise thresholds and is negotiated per fleet. The first repo stays free, no card required.',
  },
  {
    q: 'What happens if Bivouac’s patch PR fails tests?',
    a: 'Bivouac opens the PR as a draft and blocks the merge — the test suite, run on a clean checkout, is the merge gate, not a courtesy. The failure is written to the audit log with the failing check name attached to the merge row, so the regulator and your VP Eng can see what failed, not just that it failed. If the failure traces back to a contested decision (license, public-API impact, or a security-sensitive surface), the on-call rotation is paged — otherwise the signal just stays open and we wait for you or for a follow-up run.',
  },
  {
    q: 'What data does Bivouac read from the connected repo, and what doesn’t it read?',
    a: 'We read the lockfile, package manifests, the GitHub Actions / CI config, and the merge history — that’s the dependency graph, the test gate, and the provenance of every merge. We do not read source code, secrets, env files, or any files outside the dependency surface — and we do not train on any content in your repo. Every merge row carries a hash of what was read so the audit trail is replayable, which is what makes the evidence hand-off to your auditor a real handoff instead of a screenshot.',
  },
  {
    q: 'Which upstream registries are covered today?',
    a: 'npm, PyPI, Maven Central, RubyGems, crates.io, and Go sumdb — the public advisory feeds that cover the package ecosystems most teams ship on. Private and enterprise-only registry mirrors are supported on the Team and Enterprise tiers but are not the default. Coverage of breaking-change signals in your graph (not just CVEs) is on the same upstream set; if a registry we don’t watch yet is on your roadmap, ping us — we read every message.',
  },
  {
    q: 'How does a ‘page the human’ rule get defined and tuned?',
    a: 'The rule is a per-repo config knob inside the policy pack — written in the same diff as the patch, so reviewers see it when they review the patch. The defaults cover the four triggers every reader has already seen above the fold: forward-fix vs. downgrade ambiguity, license churn, security-sensitive surface, and a red build. You can widen or narrow the surface on a per-repo basis, and the audit row records which rule fired on which merge, so when you want to tune it you can read what’s actually been paging you.',
  },
];

export function LandingBuyerFaq() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Buyer objections, answered</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Five questions a buyer should be able to answer.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Pricing, test gates, what we read, the upstream registry set, and how the on-call page
            actually fires — the answers in plain language, the way we wish someone had given them
            to us.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Accordion type="single" collapsible className="px-2">
            {FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`landing-buyer-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  <p>{item.a}</p>
                  <p className="mt-3 text-small text-muted-foreground">
                    Free for the first repo.{' '}
                    <Link
                      href="/signup"
                      className="text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
                    >
                      Start free →
                    </Link>
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
