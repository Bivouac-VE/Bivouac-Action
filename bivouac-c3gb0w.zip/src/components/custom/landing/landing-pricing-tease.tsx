// @polsia:user-owned — pricing-tier tease on the landing page. Pulls plan name
// + one-line body from PLANS (typed catalog, safe to import from a server
// component). Tiles deep-link to /pricing#<slug> so the corresponding tier
// card scrolls into view.

import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { PLANS } from '@/lib/business/plans';
import { PrimaryCtaButton } from './landing-primary-cta-button';

const TAGLINE: Record<string, string> = {
  starter: 'Up to 5 repos — public feeds, forward-fix patch PRs, test-gated auto-merge.',
  team: 'Up to 25 repos — private feeds, downgrade-as-fix, multi-repo policy packs.',
  enterprise: 'Unlimited repos — dedicated on-call routing, SBOM provenance, custom SLAs.',
};

export function LandingPricingTease() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Pricing</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Per active repository. No tier zoo.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Three plans, billed monthly per active repo. All tiers ship the same audit trail and the
            same test-gated merge guardrails — higher plans widen what the agent handles
            autonomously and how fast.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {PLANS.map((plan) => (
            <Card key={plan.slug} className="lift flex flex-col">
              <CardHeader className="gap-2">
                <p className="text-eyebrow">{plan.name}</p>
                <div className="flex items-end gap-2">
                  <CardTitle className="font-display text-h2 text-foreground">
                    ${plan.monthlyPerRepoUsd}
                  </CardTitle>
                  <span className="pb-1 text-small text-muted-foreground">
                    / active repo / month
                  </span>
                </div>
                <CardDescription className="text-small text-foreground">
                  {TAGLINE[plan.slug] ?? plan.eyebrow}
                </CardDescription>
              </CardHeader>
              <CardContent className="mt-auto flex flex-col gap-4">
                <Separator />
                <Button asChild variant="outline" size="sm" className="w-full gap-2">
                  <Link href={`/pricing#${plan.slug}`}>
                    See {plan.name} on the pricing page
                    <ArrowRight className="size-4" aria-hidden />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-col items-center gap-3 rounded-xl border border-brand-500/40 bg-brand-500/5 p-6 md:p-8">
          <PrimaryCtaButton
            signedOutMicrocopy="Free for the first repo. No card. No call."
            buttonClassName="px-8 text-base font-semibold"
          />
          <p className="text-small text-muted-foreground">
            Volume pricing for fleets and SOC 2 / NIS2 / CRA evidence-ready audit export on every
            tier.{' '}
            <Link
              href="/pricing"
              className="text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
            >
              See full pricing →
            </Link>
          </p>
        </div>
      </div>
    </section>
  );
}
