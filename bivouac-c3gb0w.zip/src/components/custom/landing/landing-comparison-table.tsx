// @polsia:user-owned — 'How Bivouac compares' symbol-matrix on the landing page.
// A 4-row, 4-column matrix that pairs each product against four contested
// dimensions (detection surface, remediation speed, test-suite enforcement,
// human escalation rules). Each cell is one of three typed symbols so 16
// cells render with consistent rhythm. The truth table is grounded in
// /pricing plans and the bivouac-vs-snyk-open-source blog post.

import { Check } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

type ComparisonCell = 'yes' | 'partial' | 'no';

type ComparisonRow = {
  dimension: string;
  bivouac: ComparisonCell;
  dependabot: ComparisonCell;
  renovate: ComparisonCell;
  snykOpenSource: ComparisonCell;
};

const COMPARISON_ROWS: ComparisonRow[] = [
  {
    dimension: 'Detection surface',
    bivouac: 'yes',
    dependabot: 'partial',
    renovate: 'yes',
    snykOpenSource: 'yes',
  },
  {
    dimension: 'Remediation speed',
    bivouac: 'yes',
    dependabot: 'partial',
    renovate: 'partial',
    snykOpenSource: 'no',
  },
  {
    dimension: 'Test-suite enforcement',
    bivouac: 'yes',
    dependabot: 'no',
    renovate: 'partial',
    snykOpenSource: 'no',
  },
  {
    dimension: 'Human escalation rules',
    bivouac: 'yes',
    dependabot: 'no',
    renovate: 'no',
    snykOpenSource: 'no',
  },
];

function CellSymbol({ value }: { value: ComparisonCell }) {
  if (value === 'yes') {
    return (
      <span
        role="img"
        aria-label="yes"
        className="inline-flex size-7 items-center justify-center rounded-full border border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
      >
        <Check className="size-4" aria-hidden />
      </span>
    );
  }
  if (value === 'partial') {
    return (
      <span
        role="img"
        aria-label="partial"
        className="inline-flex items-center rounded-full border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-caption font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-300"
      >
        Partial
      </span>
    );
  }
  return <span className="text-small font-medium text-muted-foreground">No</span>;
}

export function LandingComparisonTable() {
  return (
    <section className="section bg-muted/40">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Dimension by dimension</p>
          <h2 className="font-display text-h2 text-balance text-foreground">
            How Bivouac compares.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Four dimensions where the bots disagree on what counts as a fix. Bivouac&rsquo;s column
            reflects only what runs in your repo today — anything we can&rsquo;t ship on a green
            build, we won&rsquo;t claim here.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="border-border bg-muted/50">
                <TableHead className="w-[34%] font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Dimension
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-brand-700 dark:text-brand-300">
                  Bivouac
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Dependabot
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Renovate
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Snyk Open Source
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {COMPARISON_ROWS.map((row) => (
                <TableRow key={row.dimension}>
                  <TableCell className="align-middle text-small font-medium text-foreground">
                    {row.dimension}
                  </TableCell>
                  <TableCell className="align-middle">
                    <CellSymbol value={row.bivouac} />
                  </TableCell>
                  <TableCell className="align-middle">
                    <CellSymbol value={row.dependabot} />
                  </TableCell>
                  <TableCell className="align-middle">
                    <CellSymbol value={row.renovate} />
                  </TableCell>
                  <TableCell className="align-middle">
                    <CellSymbol value={row.snykOpenSource} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
          <p className="max-w-xl text-small text-muted-foreground">
            Each cell is grounded in{' '}
            <Link href="/pricing" className="underline-offset-4 hover:underline">
              what each plan runs
            </Link>{' '}
            and the comparison blog series.
          </p>
          <Button asChild size="sm" variant="outline" className="gap-2">
            <Link href="/vs">See the deep comparisons &rarr;</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
