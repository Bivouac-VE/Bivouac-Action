// @polsia:user-owned — NIS2 / EU Cyber Resilience Act / SOC 2 / dependency-graph
// alignment shelf on the landing page. CTO-secondary depth section; sits
// below the comparison table. Static copy, no data fetch.

import { ShieldCheck } from 'lucide-react';

const PILLARS: { title: string; body: string }[] = [
  {
    title: 'NIS2 · Article 21',
    body: '24/7 incident handling and supply-chain security recorded per merge — no end-of-quarter scramble.',
  },
  {
    title: 'EU CRA',
    body: 'Vulnerability handling, supported-product disclosure, and signed SBOMs / software-bill-of-materials per build — exportable from the merge log.',
  },
  {
    title: 'SOC 2 evidence-ready',
    body: 'Append-only audit trail: which signal fired, which policy pack applied, which test gate cleared the merge.',
  },
  {
    title: 'Dependency graph awareness',
    body: 'Reads the full transitive dependency graph before picking forward-fix, downgrade, or pin — so the chosen remediation is the one your graph actually supports.',
  },
];

export function LandingCompliance() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">For the CTO and the auditor</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            NIS2, CRA, SOC 2, and the dependency graph — generated as a side effect of the merge.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Every autonomous decision leaves a signed, exportable record — the same record your
            auditor wants to see. Compliance turns from a quarterly scramble into a query against
            the merge log, and the agent reasons over your full dependency graph before it picks a
            remediation. Bivouac produces the evidence your team hands to the auditor — it
            isn&apos;t itself SOC 2 / NIS2 or EU CRA certified.
          </p>
        </div>

        <div className="grid gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((pillar) => (
            <div key={pillar.title} className="flex flex-col gap-3 bg-card p-6 md:p-8">
              <div className="flex items-center gap-3">
                <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                  <ShieldCheck className="size-4" aria-hidden />
                </span>
                <span className="font-display text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
                  {pillar.title}
                </span>
              </div>
              <p className="text-body text-foreground">{pillar.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
