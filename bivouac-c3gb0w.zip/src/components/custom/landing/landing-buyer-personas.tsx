// @polsia:user-owned — "Who Bivouac is for" persona section. Static 2×2 grid
// of economic-buyer cards. No data fetch, no auth, no DB read. The trailing
// <PrimaryCtaButton/> reuses the auth-aware client island that drives the
// hero / pricing / final CTA so the signup path stays the dominant next step.

import { ClipboardCheck, Code2, Layers, type LucideIcon, ShieldAlert } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { PrimaryCtaButton } from './landing-primary-cta-button';

type Persona = {
  icon: LucideIcon;
  role: string;
  justification: string;
};

const PERSONAS: Persona[] = [
  {
    icon: Code2,
    role: 'CTO',
    justification:
      'Stop paying engineer-hours to maintain dependencies. Bivouac absorbs the maintenance tax so your roadmap keeps moving.',
  },
  {
    icon: ClipboardCheck,
    role: 'Engineering Manager',
    justification:
      'No more manually triaging Dependabot PRs at 8am. Bivouac sorts, tests, and opens the patch PR your team can merge.',
  },
  {
    icon: Layers,
    role: 'Platform Team',
    justification:
      'Standardize dependency remediation across every repo. One policy, one agent, every service — without the bespoke plumbing per team.',
  },
  {
    icon: ShieldAlert,
    role: 'Security Team',
    justification:
      'Turn every CVE alert into a tested, gated patch PR. Remediation lands before the alert ages out of the dashboard.',
  },
];

export function LandingBuyerPersonas() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Built for teams that maintain their own stack</p>
          <h2 className="font-display text-h1 text-balance text-foreground">Who Bivouac is for</h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            One product, four reasons to buy — pick the one that matches the room you&apos;re in.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {PERSONAS.map(({ icon: Icon, role, justification }) => (
            <Card key={role} className="lift h-full border-brand-500/40 bg-brand-500/5">
              <CardHeader className="gap-3">
                <div className="flex items-center gap-3">
                  <span
                    aria-hidden
                    className="flex size-10 shrink-0 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
                  >
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <p className="text-eyebrow text-brand-700 dark:text-brand-300">{role}</p>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-body-lg text-balance text-foreground">{justification}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <PrimaryCtaButton
          signedOutMicrocopy="All four start free on the same first repo. No sales call required."
          buttonClassName="px-8 text-base font-semibold"
        />
      </div>
    </section>
  );
}
