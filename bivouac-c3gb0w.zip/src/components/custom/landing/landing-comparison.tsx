// @polsia:user-owned — 'How Bivouac compares' framing on the landing page.
// Four-column outcome-language table. Static copy; the deep comparison lives
// on /pricing and the docs.

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

type ComparisonRow = {
  capability: string;
  bivouac: string;
  dependabot: string;
  renovate: string;
  snykOpenSource: string;
};

const ROWS: ComparisonRow[] = [
  {
    capability: 'Monitors CVEs and breaking changes',
    bivouac: 'watches CVEs and SemVer-major signals across public and private feeds',
    dependabot: 'tracks public advisory feeds only',
    renovate: 'tracks public advisory feeds and SemVer drift',
    snykOpenSource: 'tracks public vulnerability feeds',
  },
  {
    capability: 'Opens a patch PR',
    bivouac: 'opens a draft PR against the right pin, fork, or downgrade',
    dependabot: 'opens a forward-fix PR',
    renovate: 'opens a forward-fix or pin PR',
    snykOpenSource: 'no PR — surfaces an advisory',
  },
  {
    capability: 'Runs your test suite',
    bivouac: 'runs the project test suite before the PR is reviewable',
    dependabot: 'not in scope',
    renovate: 'opt-in — automerge requires explicit maintainer config',
    snykOpenSource: 'not in scope',
  },
  {
    capability: 'Merges when green',
    bivouac: 'auto-merges on green with a signed audit row',
    dependabot: 'no merge authority',
    renovate: 'merges only when CI passes AND maintainer config allows',
    snykOpenSource: 'not in scope',
  },
  {
    capability: 'Pages a human on judgment calls',
    bivouac:
      'pages the on-call only on contested decisions — license, public API, security surface',
    dependabot: 'not in scope',
    renovate: 'not in scope',
    snykOpenSource: 'not in scope',
  },
  {
    capability: 'Handles downgrades when a forward fix is not viable',
    bivouac: 'picks downgrade-as-fix when the forward upgrade is incompatible',
    dependabot: 'forward-only — fails open otherwise',
    renovate: 'forward-only by default',
    snykOpenSource: 'not a remediation tool',
  },
];

export function LandingComparison() {
  return (
    <section className="section bg-muted/40">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">How Bivouac compares</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            More than alerts — Bivouac closes the loop.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Dependabot and Renovate keep raising PRs. Snyk keeps flagging advisories. Bivouac is the
            layer that decides what to do, proves it on your tests, and ships it — only paging a
            human when the call is genuinely contested.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="border-border bg-muted/50">
                <TableHead className="w-[34%] font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Capability
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-brand-700 dark:text-brand-300">
                  Bivouac
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Dependabot
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Renovate
                </TableHead>
                <TableHead className="font-display text-caption uppercase tracking-wider text-muted-foreground">
                  Snyk Open Source
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ROWS.map((row) => (
                <TableRow key={row.capability}>
                  <TableCell className="align-top text-small font-medium text-foreground">
                    {row.capability}
                  </TableCell>
                  <TableCell className="align-top text-small text-brand-700 dark:text-brand-300">
                    {row.bivouac}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.dependabot}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.renovate}
                  </TableCell>
                  <TableCell className="align-top text-small text-muted-foreground">
                    {row.snykOpenSource}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
          <p className="max-w-xl text-small text-muted-foreground">
            Outcome-language summary — see pricing for what each plan actually runs in your repo.
          </p>
          <Button asChild size="sm" variant="outline" className="gap-2">
            <Link href="/pricing">See pricing →</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
