// @polsia:user-owned — homepage buyer FAQ. Client island wraps the Radix
// Accordion primitive; literal copy, no apiFetch, no state beyond the
// accordion open/closed UI.

'use client';

import Link from 'next/link';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const FAQ: { q: string; a: string }[] = [
  {
    q: 'What is Bivouac?',
    a: 'A 24/7 on-call agent that watches your GitHub repos for CVEs and breaking changes in your dependencies, opens patch PRs, runs your test suite, and merges the fix — only paging a human when the call is genuinely contested.',
  },
  {
    q: 'Who is it for?',
    a: 'Engineering teams running on GitHub who already pay someone — internal or external — to triage Dependabot and Renovate PRs, and who need an audit trail a regulated buyer will accept. Solo maintainers and 50-engineer orgs both fit; the difference is fleet features, not the core loop.',
  },
  {
    q: 'What does Bivouac automate?',
    a: 'The whole dependency-update loop — investigate the signal, pick forward fix / pin / downgrade, open the PR, run tests, merge on green, and write the audit row. You pick the policy pack; Bivouac runs it.',
  },
  {
    q: 'Why is it better than Dependabot, Renovate, or Snyk Open Source?',
    a: 'Those tools raise alerts or PRs and stop there. Bivouac closes the loop: it investigates the signal, picks the right remediation (including downgrade-as-fix when a forward upgrade is incompatible), proves it on your tests, and merges — paging you only on license, public-API, and security-surface judgment calls. Every merge is a signed audit row, so your regulator and your VP Eng get the same record.',
  },
  {
    q: 'How do I try it?',
    a: 'Connect GitHub, pick a policy pack, and push the first patch PR through the test suite — usually inside ten minutes of wiring up. The first repo stays free, no card to start.',
  },
];

export function LandingFaq() {
  return (
    <section className="section">
      <div className="container-page flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Buyer FAQ</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Five questions a buyer should be able to answer in under thirty seconds.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Plain-language answers, the way we wish someone had given them to us. Skim the
            questions; the answer you&rsquo;re looking for is almost certainly in there. If
            something&rsquo;s missing, ping us — we read every message.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Accordion type="single" collapsible className="px-2">
            {FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`landing-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  <p>{item.a}</p>
                  <p className="mt-3 text-small text-muted-foreground">
                    Free for the first repo.{' '}
                    <Link
                      href="/signup"
                      className="text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
                    >
                      Start free →
                    </Link>
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
