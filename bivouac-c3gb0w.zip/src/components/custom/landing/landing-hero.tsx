// @polsia:user-owned — landing hero. Server component: literal copy, no
// server data. The auth-aware primary CTA is a client-island child.

import { ArrowRight, Radar } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { PrimaryCtaButton } from './landing-primary-cta-button';

const FLOW_STEPS: { step: string; label: string }[] = [
  { step: '01', label: 'Connect GitHub' },
  { step: '02', label: 'Choose your policy' },
  { step: '03', label: 'Bivouac finds an issue' },
  { step: '04', label: 'Patch PR' },
  { step: '05', label: 'Tests' },
  { step: '06', label: 'Merge' },
];

export function LandingHero() {
  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 hidden md:block" aria-hidden>
        <svg
          viewBox="0 0 800 600"
          className="absolute -right-32 -top-24 h-[820px] w-[820px] text-brand-500/15"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative radar rings</title>
          <circle cx="400" cy="300" r="280" strokeWidth="1" />
          <circle cx="400" cy="300" r="220" strokeWidth="1" />
          <circle cx="400" cy="300" r="160" strokeWidth="1" />
          <circle cx="400" cy="300" r="100" strokeWidth="1.5" />
          <circle cx="400" cy="300" r="44" strokeWidth="1.5" />
          <circle cx="400" cy="300" r="6" fill="currentColor" />
          <path
            d="M 400 300 L 400 20 A 280 280 0 0 1 642 192 Z"
            fill="currentColor"
            opacity="0.08"
          />
          <path d="M 400 20 L 400 580" strokeWidth="0.5" />
          <path d="M 120 300 L 680 300" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="container-page relative flex flex-col gap-10 pt-section-lg pb-section md:pt-section-xl">
        <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
          <Radar className="size-3 text-brand-700 dark:text-brand-300" aria-hidden />
          <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
            On-call in 10 minutes
          </span>
        </Badge>

        <h1 className="max-w-4xl font-display text-display text-balance text-foreground">
          Your first patch PR in 10 minutes.
        </h1>

        <p className="max-w-3xl text-body-lg text-muted-foreground">
          An on-call agent for dependency updates. It opens, tests, and merges dependency security
          PRs in your GitHub repos — connect GitHub, choose your policy, and your first patch PR is
          usually live in 10 minutes.
        </p>

        <ol className="flex flex-wrap items-center gap-x-2 gap-y-3 text-body-lg">
          {FLOW_STEPS.map(({ step, label }, i) => (
            <li key={step} className="flex items-center gap-2">
              <span className="inline-flex items-center gap-2 rounded-md border border-brand-500/40 bg-brand-500/10 px-3 py-1.5 text-brand-700 dark:text-brand-300">
                <span className="font-mono text-caption font-bold">{step}</span>
                <span className="font-semibold">{label}</span>
              </span>
              {i < FLOW_STEPS.length - 1 ? (
                <ArrowRight className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
              ) : null}
            </li>
          ))}
        </ol>

        <div className="flex max-w-2xl flex-col gap-4 rounded-lg border border-brand-500/40 bg-brand-500/10 p-6 shadow-brand md:p-8">
          <Badge
            variant="outline"
            className="w-fit gap-1.5 border-brand-500/60 bg-background/80 text-foreground"
          >
            <span className="text-caption font-semibold uppercase tracking-[0.08em]">
              On-call in 10 minutes.
            </span>
          </Badge>

          <PrimaryCtaButton
            signedOutMicrocopy="No credit card. No sales call. No commitment."
            buttonClassName="px-10 text-base font-semibold"
          />
        </div>
      </div>
    </section>
  );
}
