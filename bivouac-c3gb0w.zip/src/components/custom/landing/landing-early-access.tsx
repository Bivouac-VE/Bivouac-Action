// @polsia:user-owned — landing-page social-proof section. Server Component:
// literal copy + typed catalog only, no apiFetch, no Prisma, no await.
// Real team logos swap in via EARLY_ACCESS_TEAMS in @/lib/business/early-access
// (currently empty by design — Bivouac is in private beta).

import { Github } from 'lucide-react';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BODY,
  CUSTOMER_EMPTY_COPY,
  CUSTOMER_HEADING,
  EARLY_ACCESS_TEAMS,
  ECOSYSTEM_HEADING,
  ECOSYSTEM_SUB,
  HEADER,
  LANGUAGES,
  type LanguageId,
  SUBHEAD,
} from '@/lib/business/early-access';

// Inline-SVG badge for language runtimes. Monochrome, sized via `className`,
// no network call, no npm install. Mirrors the instrument-panel brand hue
// by taking the parent `text-brand-700/300` color via currentColor.
function LanguageBadge({
  initials,
  ariaLabel,
  corner = 6,
  className,
}: {
  initials: string;
  ariaLabel: string;
  corner?: number;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 32 32"
      role="img"
      aria-label={ariaLabel}
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        x="1.5"
        y="1.5"
        width="29"
        height="29"
        rx={corner}
        stroke="currentColor"
        strokeWidth="2"
      />
      <text
        x="16"
        y="16"
        dominantBaseline="central"
        textAnchor="middle"
        fontFamily="ui-sans-serif, system-ui, -apple-system, sans-serif"
        fontWeight="700"
        fontSize="11"
        letterSpacing="0.02em"
        fill="currentColor"
      >
        {initials}
      </text>
    </svg>
  );
}

// `corner` is tuned per-language so the badges vary subtly rather than all
// looking identical — small repeating variation that breaks the "row of
// identical cards" anti-pattern that defaults fall into.
const MARK_BY_ID: Record<
  LanguageId,
  { initials: string; corner: number; Icon?: React.ComponentType<{ className?: string }> }
> = {
  github: { initials: '', corner: 7, Icon: Github },
  node: { initials: 'js', corner: 7 },
  python: { initials: 'py', corner: 8 },
  java: { initials: 'ja', corner: 4 },
  go: { initials: 'go', corner: 9 },
  ruby: { initials: 'rb', corner: 6 },
  rust: { initials: 'rs', corner: 3 },
  php: { initials: 'php', corner: 7 },
  dotnet: { initials: '.n', corner: 4 },
};

function LanguageMark({ id, className }: { id: LanguageId; className?: string }) {
  const entry = MARK_BY_ID[id];
  if (entry.Icon) {
    return <entry.Icon className={className} aria-hidden />;
  }
  return (
    <LanguageBadge
      initials={entry.initials}
      ariaLabel={LANGUAGES.find((l) => l.id === id)?.name ?? id}
      corner={entry.corner}
      className={className}
    />
  );
}

export function LandingEarlyAccess() {
  return (
    <section id="early-access" className="section bg-muted/40">
      <div className="container-page flex flex-col gap-12">
        <div className="flex flex-col gap-4">
          <p className="text-eyebrow">Early access</p>
          <h2 className="font-display text-h1 text-balance text-foreground">{HEADER}</h2>
          <p className="max-w-3xl text-h4 text-balance text-brand-700 dark:text-brand-300">
            {SUBHEAD}
          </p>
          <p className="max-w-3xl text-body text-muted-foreground">{BODY}</p>
        </div>

        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h3 className="font-display text-h2 text-foreground">{ECOSYSTEM_HEADING}</h3>
            <p className="max-w-3xl text-body-lg text-muted-foreground">{ECOSYSTEM_SUB}</p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
            {LANGUAGES.map((lang) => (
              <Card key={lang.id} className="lift">
                <CardHeader className="gap-3">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                      <LanguageMark id={lang.id} className="size-7" />
                    </span>
                    <CardTitle className="font-display text-h4 text-foreground">
                      {lang.name}
                    </CardTitle>
                  </div>
                  <p className="mt-1 text-small text-muted-foreground">{lang.tagline}</p>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <h3 className="font-display text-h2 text-foreground">{CUSTOMER_HEADING}</h3>

          {EARLY_ACCESS_TEAMS.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {EARLY_ACCESS_TEAMS.map((team) => (
                <Card key={team.name} className="lift">
                  <div className="flex items-center gap-3 p-6">
                    <span className="inline-flex size-10 items-center justify-center rounded-md border border-border bg-muted-foreground/10 font-display text-h4 font-semibold text-foreground">
                      {team.mark ?? team.name.slice(0, 1).toUpperCase()}
                    </span>
                    <span className="font-display text-h4 text-foreground">{team.name}</span>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <output
              aria-live="polite"
              className="block rounded-lg border border-border bg-card p-6"
            >
              <p className="max-w-3xl text-body text-muted-foreground">{CUSTOMER_EMPTY_COPY}</p>
            </output>
          )}
        </div>
      </div>
    </section>
  );
}
