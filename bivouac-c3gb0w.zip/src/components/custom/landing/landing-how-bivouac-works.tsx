// @polsia:user-owned — 4-step operational walkthrough for the homepage. A
// separate component from the existing 3-step LandingHowItWorks section: this
// one spells out every step, including the downgrade path and the human-page
// conditions, and ends with the auth-aware primary CTA to /signup.

import { BellRing, GitMerge, GitPullRequestArrow, Search } from 'lucide-react';
import { PrimaryCtaButton } from '@/components/custom/landing/landing-primary-cta-button';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const STEPS: {
  step: string;
  title: string;
  body: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    step: '01',
    title: 'Detect',
    body: 'A CVE drops or an upstream ships a breaking change — we read it from your repo’s dependency tree, not a public feed.',
    icon: BellRing,
  },
  {
    step: '02',
    title: 'Investigate',
    body: 'Trace the impact in your lockfile, your test suite, and your call sites. Pick the smallest viable fix path before any code is touched.',
    icon: Search,
  },
  {
    step: '03',
    title: 'Patch and test',
    body: 'Open a draft PR, run the project’s test suite, and pick a downgrade when a forward fix isn’t viable. The build is the gate.',
    icon: GitPullRequestArrow,
  },
  {
    step: '04',
    title: 'Merge or page',
    body: 'Merge on green. Page a human on contested license churn, security-sensitive surfaces, public-API breakage, or red builds.',
    icon: GitMerge,
  },
];

export function LandingHowBivouacWorks() {
  return (
    <section className="section bg-muted/40">
      <div className="container-page flex flex-col gap-12">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">How Bivouac works</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            From disclosure to merged fix &mdash; on its own shift.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            What happens between signal and shipped fix: four ordered steps the agent runs against
            every connected repo, no shortcuts, no skipped gates.
          </p>
        </div>

        <ol className="grid gap-4 md:grid-cols-4">
          {STEPS.map((s) => (
            <li key={s.step} className="flex flex-col">
              <Card className="lift flex h-full flex-col">
                <CardHeader className="gap-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-caption font-bold text-brand-700 dark:text-brand-300">
                      {s.step}
                    </span>
                    <span className="inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                      <s.icon className="size-4" aria-hidden />
                    </span>
                  </div>
                  <CardTitle className="font-display text-h3 text-foreground">{s.title}</CardTitle>
                  <CardDescription className="text-body text-foreground">{s.body}</CardDescription>
                </CardHeader>
              </Card>
            </li>
          ))}
        </ol>

        <PrimaryCtaButton
          signedOutLabel="Start free on the first repo"
          buttonClassName="px-8 text-base font-semibold"
          signedOutMicrocopy="No credit card. No sales call. No commitment."
        />
      </div>
    </section>
  );
}
