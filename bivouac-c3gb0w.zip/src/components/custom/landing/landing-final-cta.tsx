// @polsia:user-owned — final panel on the landing page. Uses the same auth-aware
// primary CTA island as the hero so the conversion route is consistent.

import { PrimaryCtaButton } from './landing-primary-cta-button';

export function LandingFinalCta() {
  return (
    <section className="section-lg">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-lg border border-brand-500/30 bg-gradient-to-br from-brand-500/10 via-background to-background p-10 md:p-14">
          <div
            aria-hidden
            className="absolute -right-20 -top-20 size-72 rounded-full bg-brand-500/15 blur-3xl"
          />
          <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between md:gap-10">
            <div className="flex flex-col gap-3">
              <p className="text-eyebrow">Light the watch</p>
              <h2 className="font-display text-h1 text-balance text-foreground">
                Your first patch PR in 10 minutes.
              </h2>
              <p className="max-w-xl text-body-lg text-muted-foreground">
                Connect GitHub → choose your policy → Bivouac finds an issue → opens the patch PR →
                runs your tests → merges on green. The test suite is the gate; humans stay on the
                bench.
              </p>
            </div>

            <div className="flex flex-col gap-3 md:items-end">
              <PrimaryCtaButton />
              <p className="text-small text-muted-foreground md:text-right">
                No credit card. No sales call. No commitment.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
