// @polsia:user-owned — Email + password sign-in with GitHub OAuth. Composes
// the template's base shadcn primitives (Button/Input/Label) styled through
// the theme tokens. Restyle freely — this file is user-owned.
//
// On email sign-in: better-auth's authClient.signIn.email validates
// credentials via the catch-all handler, sets the session cookie on success,
// and we then navigate to `returnTo` (default /dashboard) so the visitor
// lands in their original destination. On OAuth: continues through GitHub
// and lands at `returnTo` with the same cookie set.

'use client';

import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { OAuthButton } from '@/components/custom/auth/oauth-button';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { signIn } from '@/lib/auth-client';

export interface SignInFormProps {
  /** Where to land after a successful sign-in. Must be a same-origin path;
   * defaults to /dashboard. */
  returnTo?: string;
}

export function SignInForm({ returnTo = '/dashboard' }: SignInFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError(undefined);

    const { error: signInError } = await signIn.email({ email, password });
    setPending(false);

    if (signInError) {
      setError(signInError.message ?? 'Could not sign in. Check your details.');
      return;
    }

    window.location.assign(returnTo);
  }

  return (
    <div className="flex flex-col gap-5">
      <OAuthButton callbackURL={returnTo} />

      <div className="relative">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">Or with email</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3" noValidate>
        <Label htmlFor="sign-in-email">Email address</Label>
        <Input
          id="sign-in-email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          aria-invalid={error ? true : undefined}
        />
        <div className="flex items-center justify-between">
          <Label htmlFor="sign-in-password">Password</Label>
          <Link
            href="/forgot-password"
            className="text-small text-muted-foreground hover:text-brand-600 hover:underline underline-offset-2 transition-colors"
          >
            Forgot your password?
          </Link>
        </div>
        <Input
          id="sign-in-password"
          name="password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          aria-invalid={error ? true : undefined}
        />
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        <Button type="submit" disabled={pending} className="w-full">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden />
              <span>Signing in…</span>
            </>
          ) : (
            'Sign in'
          )}
        </Button>
        <p className="text-center text-small text-muted-foreground">
          Don&apos;t have an account?{' '}
          <Link
            href={`/signup${returnTo !== '/dashboard' ? `?returnTo=${encodeURIComponent(returnTo)}` : ''}`}
            className="text-brand-600 font-medium hover:text-brand-700 hover:underline underline-offset-2 transition-colors"
          >
            Create one
          </Link>
        </p>
      </form>
    </div>
  );
}
