// @polsia:user-owned — /activity client island. Fetches the public
// activity feed via apiFetch against /api/activity, parses through the
// shared ActivityFeed contract, and renders:
//   - a "Live now" status strip at the top (last triage row + 24h count
//     + health dot — read together with the feed so the strip never
//     disagrees with the most-recent row),
//   - a reverse-chronological timeline of recent patches below.
//
// Owns loading / empty / error branches so the page itself stays a
// Server Component that only exports metadata.

'use client';

import { AlertTriangle, RefreshCw } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  type ActivityDotState,
  ActivityFeed as ActivityFeedSchema,
  type ActivityFeed as ActivityFeedT,
} from '@/lib/contracts/activity';
import { cn } from '@/lib/utils';
import { ActivityFeedItemRow, LiveDot } from './activity-feed-item';

const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c', 'sk-d', 'sk-e', 'sk-f'] as const;

const DOT_LABEL: Record<ActivityDotState, string> = {
  green: 'Live now',
  amber: 'Delayed',
  red: 'Outage',
};

function relativeFromIso(iso: string, now: Date): string {
  const elapsedMs = Math.max(0, now.getTime() - new Date(iso).getTime());
  const minutes = Math.floor(elapsedMs / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

type State =
  | { kind: 'loading' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; data: ActivityFeedT; now: Date };

// Outer shell — owns the refresh counter and exposes a `<Button>` that
// bumps it. The fetch lives in <ActivityFeedBody/> keyed on the counter
// so a click remounts the body (and re-runs the effect) without an extra
// `useEffect` dependency on the counter inside the body.
export function ActivityFeed() {
  const [reloadKey, setReloadKey] = useState(0);
  return (
    <div className="flex flex-col gap-8">
      <ActivityFeedBody key={reloadKey} />
      <Button
        variant="outline"
        size="sm"
        onClick={() => setReloadKey((k) => k + 1)}
        className="self-start gap-2"
      >
        <RefreshCw className="size-4" aria-hidden /> Refresh feed
      </Button>
    </div>
  );
}

function ActivityFeedBody() {
  const [state, setState] = useState<State>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    setState({ kind: 'loading' });
    apiFetch('/api/activity', { schema: ActivityFeedSchema })
      .then((data) => {
        if (active) setState({ kind: 'ready', data, now: new Date() });
      })
      .catch((err: unknown) => {
        if (!active) return;
        const message = err instanceof Error ? err.message : 'Could not load the activity feed.';
        setState({ kind: 'error', message });
      });
    return () => {
      active = false;
    };
  }, []);

  if (state.kind === 'loading') return <ActivityFeedLoading />;
  if (state.kind === 'error') return <ActivityFeedError message={state.message} />;

  const { data, now } = state;
  if (data.items.length === 0) return <ActivityFeedEmpty />;

  return (
    <>
      <LiveStrip data={data} now={now} />
      <Timeline items={data.items} now={now} />
    </>
  );
}

function ActivityFeedLoading() {
  return (
    <div aria-busy="true" className="flex flex-col gap-8">
      <Skeleton className="h-20 w-full rounded-md" />
      <ul className="flex flex-col gap-3">
        {SKELETON_IDS.map((id) => (
          <li key={id}>
            <Skeleton className="h-24 w-full rounded-md" />
          </li>
        ))}
      </ul>
    </div>
  );
}

function ActivityFeedError({ message }: { message: string }) {
  return (
    <Alert variant="destructive" className="border-destructive/40">
      <AlertTriangle className="size-4" aria-hidden />
      <AlertTitle>Activity feed unavailable</AlertTitle>
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  );
}

function ActivityFeedEmpty() {
  return (
    <div className="flex flex-col gap-3 rounded-md border border-border bg-card/40 p-6">
      <p className="font-display text-h4 text-foreground">No activity yet</p>
      <p className="text-body text-muted-foreground">
        The daily triage cron hasn&apos;t opened a patch PR yet. Once it does, every one shows up
        here in reverse-chronological order — no sign-in required.
      </p>
    </div>
  );
}

// "Live now" status strip — paints in lock-step with the feed rows below.
// Three narrow chips summarise the cron's state from the same response,
// so a refresh of one paints the chips too.
function LiveStrip({ data, now }: { data: ActivityFeedT; now: Date }) {
  const { live } = data;
  const dotClass = {
    green: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    amber: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    red: 'border-destructive/40 bg-destructive/10 text-destructive',
  }[live.dotState];

  return (
    <section
      aria-label="Agent live status"
      className="flex flex-wrap items-stretch gap-2 rounded-md border border-border bg-card/40 p-2.5"
    >
      <div className={cn('flex flex-1 items-center gap-3 rounded-sm border px-4 py-3', dotClass)}>
        <LiveDot state={live.dotState} />
        <div className="flex flex-col">
          <span className="text-caption font-semibold uppercase tracking-[0.08em]">
            {DOT_LABEL[live.dotState]}
          </span>
          <span className="font-mono text-small">
            {live.lastTriageAt
              ? `Last triage ${relativeFromIso(live.lastTriageAt, now)}`
              : 'No triage row observed yet'}
          </span>
        </div>
      </div>
      <div className="flex flex-1 flex-col justify-center rounded-sm border border-border bg-background/40 px-4 py-3">
        <span className="text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          Last 24 hours
        </span>
        <span className="font-display text-h4 text-foreground">
          {live.patchesLast24h} patch{live.patchesLast24h === 1 ? '' : 'es'}
        </span>
      </div>
      <div className="flex flex-1 flex-col justify-center rounded-sm border border-border bg-background/40 px-4 py-3">
        <span className="text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          Showing
        </span>
        <span className="font-display text-h4 text-foreground">
          {data.items.length} most recent
        </span>
      </div>
    </section>
  );
}

// Vertical timeline with a left rail (the connecting line) and a content
// column. Each row clicks through to /patches/[id] for the evidence page.
// Not a card grid: the brief explicitly calls out a timeline with a left
// rail as the alternative to "a row of identical three-column feature
// cards".
function Timeline({ items, now }: { items: ActivityFeedT['items']; now: Date }) {
  return (
    <ol className="relative flex flex-col gap-3 pl-6 sm:pl-8" aria-label="Recent activity">
      {/* Connecting rail — stops short of the last row so the timeline
          doesn't dangle a line below the last entry. */}
      <span aria-hidden className="absolute bottom-3 left-2 top-3 w-px bg-border sm:left-3" />
      {items.map((item, index) => (
        <li key={item.id} className="relative">
          {/* Tick — sits on the rail. The most recent row uses a vibrant
              brand-tinted halo so a reader's eye lands on the freshest
              patch first. */}
          <span
            aria-hidden
            className={cn(
              'absolute -left-6 top-5 size-2 rounded-full border border-background',
              index === 0 ? 'bg-brand-500' : 'bg-muted-foreground',
            )}
            style={
              index === 0
                ? {
                    boxShadow: '0 0 0 4px color-mix(in oklch, var(--brand-500) 22%, transparent)',
                  }
                : undefined
            }
          />
          <ActivityFeedItemRow item={item} now={now} />
        </li>
      ))}
    </ol>
  );
}
