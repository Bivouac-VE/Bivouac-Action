// @polsia:user-owned — single row in the /activity timeline. Pure
// presentation; lives in the same client tree as <ActivityFeed/> so it
// can share the row badge vocabulary imports without crossing the
// server-only fence. Each row links to /patches/[id] for the full
// evidence page (the existing drilldown route — no /api/activity/[id]).

'use client';

import { ArrowUpRight } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import type {
  ActivityDotState,
  ActivityFeedItem as ActivityFeedItemT,
  ActivityMergeState,
  ActivitySeverity,
} from '@/lib/contracts/activity';
import { cn } from '@/lib/utils';

type Tones = { tone: string; label: string };

const SEVERITY_LABEL: Record<ActivitySeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const MERGE_LABEL: Record<ActivityMergeState, string> = {
  'auto-merged': 'Auto-merged',
  open: 'PR open',
  declined: 'Declined',
  'paged-human': 'Paged human',
};

function severityTone(s: ActivitySeverity): Tones {
  switch (s) {
    case 'critical':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive',
        label: SEVERITY_LABEL[s],
      };
    case 'high':
      return {
        tone: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
        label: SEVERITY_LABEL[s],
      };
    case 'medium':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: SEVERITY_LABEL[s],
      };
    case 'low':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: SEVERITY_LABEL[s],
      };
  }
}

function mergeTone(m: ActivityMergeState): Tones {
  switch (m) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: MERGE_LABEL[m],
      };
    case 'paged-human':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: MERGE_LABEL[m],
      };
    case 'declined':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive',
        label: MERGE_LABEL[m],
      };
    case 'open':
      return {
        tone: 'border-border bg-muted text-muted-foreground',
        label: MERGE_LABEL[m],
      };
  }
}

// Compact time-to-patch formatter. Mirrors /api/audit-log's bucket scheme
// so the same feed row reads identically across surfaces; sub-hour rows
// round to minutes so the cell breathes on long feeds.
export function formatTimeToPatch(hours: number): string {
  if (!Number.isFinite(hours) || hours < 0) return '—';
  if (hours < 1) {
    const mins = Math.max(0, Math.round(hours * 60));
    return `${mins}m`;
  }
  if (hours < 24) {
    return `${hours.toFixed(1)}h`;
  }
  if (hours < 24 * 14) {
    return `${Math.round(hours / 24)}d`;
  }
  return `${Math.round(hours / (24 * 7))}w`;
}

function relativeFromIso(iso: string, now: Date): string {
  const elapsedMs = Math.max(0, now.getTime() - new Date(iso).getTime());
  const minutes = Math.floor(elapsedMs / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 14) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 8) return `${weeks}w ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

const DOT_TONE: Record<ActivityDotState, string> = {
  green: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-destructive',
};

export function LiveDot({ state }: { state: ActivityDotState }) {
  return (
    <span className="relative inline-flex size-3 items-center justify-center" aria-hidden>
      {/* Subtle ping only when green — keeps the strip legible in
          quiet red/amber states (which is when the operator wants to read
          the chip, not watch it throb). */}
      <span
        className={cn(
          'absolute inset-0 rounded-full opacity-30',
          state === 'green' && 'animate-ping',
          DOT_TONE[state],
        )}
      />
      <span className={cn('relative inline-block size-3 rounded-full', DOT_TONE[state])} />
    </span>
  );
}

export interface ActivityFeedItemProps {
  item: ActivityFeedItemT;
  now: Date;
}

export function ActivityFeedItemRow({ item, now }: ActivityFeedItemProps) {
  const sev = severityTone(item.severity);
  const merge = mergeTone(item.mergeState);
  return (
    <Link
      href={`/patches/${encodeURIComponent(item.id)}`}
      className={cn(
        'group relative flex flex-col gap-3 rounded-md border border-border bg-card px-5 py-4 transition-colors',
        'hover:border-brand-500/40 hover:bg-card/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-col gap-1">
          <span className="font-mono text-caption tracking-wide text-muted-foreground">
            {item.cveId ?? 'Upstream breaking change'}
          </span>
          <span className="font-mono text-body text-foreground">
            <span className="text-foreground">{item.packageName}</span>
            <span className="text-muted-foreground">@{item.fromVersion}</span>
            <span aria-hidden> → </span>
            <span className="font-semibold text-foreground">@{item.toVersion}</span>
          </span>
        </div>
        <ArrowUpRight
          className="mt-0.5 size-4 shrink-0 text-muted-foreground group-hover:text-brand-700 dark:group-hover:text-brand-300"
          aria-hidden
        />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="outline" className={sev.tone}>
          {sev.label} severity
        </Badge>
        <Badge variant="outline" className={merge.tone}>
          {merge.label}
        </Badge>
        {item.repoLabel ? (
          <Badge
            variant="outline"
            className="border-border bg-background/40 font-mono text-caption text-muted-foreground"
          >
            {item.repoLabel}
          </Badge>
        ) : null}
        <span className="ml-auto flex items-center gap-1.5 font-mono text-caption text-muted-foreground">
          <span className="text-foreground">{formatTimeToPatch(item.timeToPatchHours)}</span>
          <span aria-hidden>·</span>
          <span>{relativeFromIso(item.createdAt, now)}</span>
        </span>
      </div>
    </Link>
  );
}
