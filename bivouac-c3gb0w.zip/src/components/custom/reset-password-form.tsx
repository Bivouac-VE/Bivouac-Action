// @polsia:user-owned — /reset-password client island. Posts to the better-auth
// catch-all via authClient.resetPassword; better-auth validates the token and,
// on success, redirects the user to /login so they can sign in with the new
// password. min password length 8 matches auth-config.ts.

'use client';

import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { authClient } from '@/lib/auth-client';

export interface ResetPasswordFormProps {
  /** Verification token from `/reset-password?token=…`; null = invalid/missing. */
  token: string | null;
}

export function ResetPasswordForm({ token }: ResetPasswordFormProps) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);

  if (!token) {
    return (
      <div className="flex flex-col gap-3 text-center">
        <p className="text-body text-foreground">This password reset link is missing or invalid.</p>
        <p className="text-small text-muted-foreground">
          Restart the process and we'll email you a fresh link.
        </p>
        <Button asChild className="mt-2">
          <Link href="/forgot-password">Request a new link</Link>
        </Button>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(undefined);
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setPending(true);
    const t = token ?? '';
    const { error: resetError } = await authClient.resetPassword({
      newPassword: password,
      token: t,
    });
    setPending(false);
    if (resetError) {
      setError(resetError.message ?? 'Could not reset your password. Try again.');
      return;
    }
    window.location.assign('/login');
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3" noValidate>
      <Label htmlFor="reset-password">New password</Label>
      <Input
        id="reset-password"
        name="password"
        type="password"
        autoComplete="new-password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        minLength={8}
        aria-invalid={error ? true : undefined}
      />
      <Label htmlFor="reset-confirm">Confirm password</Label>
      <Input
        id="reset-confirm"
        name="confirm"
        type="password"
        autoComplete="new-password"
        value={confirm}
        onChange={(e) => setConfirm(e.target.value)}
        required
        minLength={8}
        aria-invalid={error ? true : undefined}
      />
      {error ? <p className="text-small text-destructive">{error}</p> : null}
      <Button type="submit" disabled={pending} className="w-full">
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden />
            <span>Updating…</span>
          </>
        ) : (
          'Update password'
        )}
      </Button>
    </form>
  );
}
