// @polsia:user-owned — /forgot-password client island. Posts to the better-auth
// catch-all via authClient.requestPasswordReset, which writes a Verification
// token and fires the sendResetPassword callback wired in auth-config.ts.

'use client';

import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { authClient } from '@/lib/auth-client';

export function ForgotPasswordForm() {
  const [email, setEmail] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError(undefined);

    // better-auth appends `?token=…` to redirectTo on the email link. We send
    // the user to /reset-password?token=… from their inbox.
    const { error: requestError } = await authClient.requestPasswordReset({
      email,
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setPending(false);

    if (requestError) {
      // Don't reveal whether an address is registered; better-auth already
      // returns generic success even for unknown emails when no user matches,
      // so this branch is mostly a network error.
      setError(requestError.message ?? 'Could not send reset email. Try again.');
      return;
    }

    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="flex flex-col gap-3 text-center">
        <p className="text-body text-foreground">
          If an account exists for <span className="font-medium">{email}</span>, we just sent reset
          instructions.
        </p>
        <p className="text-small text-muted-foreground">
          Check your inbox (and spam folder). The link expires after a short time.
        </p>
        <Button asChild variant="ghost" className="mt-2">
          <Link href="/login">Back to sign in</Link>
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3" noValidate>
      <Label htmlFor="forgot-email">Email address</Label>
      <Input
        id="forgot-email"
        name="email"
        type="email"
        autoComplete="email"
        placeholder="you@example.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        aria-invalid={error ? true : undefined}
      />
      {error ? <p className="text-small text-destructive">{error}</p> : null}
      <Button type="submit" disabled={pending} className="w-full">
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden />
            <span>Sending…</span>
          </>
        ) : (
          'Email me a reset link'
        )}
      </Button>
      <p className="text-center text-small text-muted-foreground">
        Remembered it?{' '}
        <Link
          href="/login"
          className="text-brand-600 font-medium hover:text-brand-700 hover:underline underline-offset-2 transition-colors"
        >
          Back to sign in
        </Link>
      </p>
    </form>
  );
}
