// @polsia:user-owned — client island for /dashboard/alerts.
//
// The page (src/app/(dashboard)/dashboard/alerts/page.tsx) is a Server
// Component exporting metadata. This island owns the fetch to /api/alerts,
// which is team-role-gated server-side (admin or on_call). The viewer-tier
// empty card below is rendered when the API rejects — the page body itself
// never imports server-only modules.

'use client';

import { AlertTriangle, BellRing, Inbox, RefreshCcw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  type AlertAction,
  AlertList,
  type AlertList as AlertListT,
  type AlertSeverity,
} from '@/lib/contracts/alerts';
import { ROLE_TONE } from '@/lib/contracts/team';

type FetchState =
  | { status: 'loading' }
  | { status: 'forbidden' }
  | { status: 'error'; message: string }
  | { status: 'ready'; data: AlertListT };

const ACTION_LABEL: Record<AlertAction, string> = {
  red_build: 'Red build',
  contested_decision: 'Contested decision',
  merge_blocked: 'Merge blocked',
};

const SEVERITY_LABEL: Record<AlertSeverity, string> = {
  high: 'High',
  critical: 'Critical',
};

function severityTone(s: AlertSeverity): string {
  switch (s) {
    case 'critical':
      return 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground';
    case 'high':
      return 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300';
  }
}

function actionTone(action: AlertAction): string {
  switch (action) {
    case 'red_build':
      return 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300';
    case 'contested_decision':
      return ROLE_TONE.on_call.toneClass;
    case 'merge_blocked':
      return 'border-destructive/30 bg-destructive/10 text-destructive';
  }
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const diffMs = Date.now() - d.getTime();
  const diffSec = Math.round(diffMs / 1000);
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.round(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHour = Math.round(diffMin / 60);
  if (diffHour < 24) return `${diffHour}h ago`;
  const diffDay = Math.round(diffHour / 24);
  return `${diffDay}d ago`;
}

export function AlertFeedView() {
  const [state, setState] = useState<FetchState>({ status: 'loading' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/alerts', { schema: AlertList });
      setState({ status: 'ready', data });
    } catch (err: unknown) {
      const cause = (err as { cause?: unknown } | null)?.cause;
      const nested =
        cause && typeof cause === 'object' && 'error' in cause
          ? (cause as { error?: unknown }).error
          : undefined;
      const code = typeof nested === 'string' ? nested : undefined;
      if (code === 'Forbidden' || code === 'Unauthorized') {
        setState({ status: 'forbidden' });
        return;
      }
      const message = err instanceof Error ? err.message : 'request_failed';
      setState({ status: 'error', message });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.status === 'loading') {
    return <FeedSkeleton />;
  }
  if (state.status === 'forbidden') {
    return <ForbiddenCard />;
  }
  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load alerts.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach the alerts endpoint. Retry in a moment.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void load()}
            className="w-fit gap-1.5"
          >
            <RefreshCcw className="size-3.5" aria-hidden />
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  if (state.data.alerts.length === 0) {
    return <EmptyCard />;
  }
  return <ReadyList data={state.data} onRefresh={load} />;
}

function FeedSkeleton() {
  return (
    <Card aria-busy="true">
      <CardHeader>
        <CardTitle className="font-display text-h4">Recent alerts</CardTitle>
        <CardDescription className="text-small text-muted-foreground">Loading…</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        <Skeleton className="h-12 w-full rounded-md" />
        <Skeleton className="h-12 w-full rounded-md" />
        <Skeleton className="h-12 w-full rounded-md" />
      </CardContent>
    </Card>
  );
}

function EmptyCard() {
  return (
    <Card className="border-border bg-card/60">
      <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
        <Inbox className="size-6 text-muted-foreground" aria-hidden />
        <p className="font-display text-h4 text-foreground">No live alerts</p>
        <p className="max-w-md text-small text-muted-foreground">
          Nothing on the triage audit log requires on-call attention right now. New red builds,
          contested decisions, and merge blocks will appear here as soon as they land.
        </p>
      </CardContent>
    </Card>
  );
}

function ForbiddenCard() {
  return (
    <Card className="border-border bg-card/60">
      <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
        <BellRing className="size-6 text-muted-foreground" aria-hidden />
        <p className="font-display text-h4 text-foreground">On-call only</p>
        <p className="max-w-md text-small text-muted-foreground">
          The alerts feed is restricted to team admins and on-call members. Ask an admin to change
          your role if you need to see live alerts.
        </p>
      </CardContent>
    </Card>
  );
}

function ReadyList({ data, onRefresh }: { data: AlertListT; onRefresh: () => Promise<void> }) {
  return (
    <Card className="lift border-border bg-card/80 p-0">
      <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0 p-5 pb-3">
        <div className="grid gap-1">
          <CardTitle className="font-display text-h4 text-foreground">
            {data.alerts.length} {data.alerts.length === 1 ? 'live alert' : 'live alerts'}
          </CardTitle>
          <CardDescription className="text-small text-muted-foreground">
            Events from the audit log that require a human reviewer.
          </CardDescription>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => void onRefresh()}
          className="gap-1.5"
        >
          <RefreshCcw className="size-3.5" aria-hidden />
          Refresh
        </Button>
      </CardHeader>
      <Separator />
      <CardContent className="flex flex-col gap-2 px-5 pb-5">
        {data.alerts.map((alert) => {
          const actionLabel = ACTION_LABEL[alert.action];
          const severityLabel = SEVERITY_LABEL[alert.severity];
          return (
            <a
              key={alert.id}
              href={alert.deepLinkHref}
              className="group flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-4 transition-colors hover:border-brand-500/60 hover:bg-card"
            >
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className={severityTone(alert.severity)}>
                  {severityLabel}
                </Badge>
                <Badge variant="outline" className={actionTone(alert.action)}>
                  {actionLabel}
                </Badge>
                <span className="font-mono text-caption text-muted-foreground">{alert.repo}</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {formatRelative(alert.at)}
                </span>
              </div>
              <p className="text-body text-foreground">{alert.summary}</p>
              <p className="text-xs text-muted-foreground group-hover:text-foreground">
                Open in audit log →
              </p>
            </a>
          );
        })}
      </CardContent>
    </Card>
  );
}
