// @polsia:user-owned — /status client island. Fetches the public status
// snapshot via apiFetch against /api/status, renders a banner +
// 90-day uptime strip + recent incidents + 30-day summary. Shares the
// zod contract with the route handler so a shape change surfaces as a
// ZodError, not a silent cast.

'use client';

import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  type LucideIcon,
} from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import {
  type IncidentRow,
  type StatusAction,
  type StatusOverall,
  type StatusSeverity,
  type StatusSnapshot,
  StatusSnapshot as StatusSnapshotSchema,
  type UptimeDay,
  type UptimeDayStatus,
} from '@/lib/contracts/status';
import { cn } from '@/lib/utils';

type BannerVisual = {
  icon: LucideIcon;
  containerClass: string;
  indicatorClass: string;
  accentClass: string;
  bannerRole?: 'status' | 'alert';
};

function bannerVisual(overall: StatusOverall): BannerVisual {
  switch (overall) {
    case 'healthy':
      return {
        icon: CheckCircle2,
        containerClass:
          'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        indicatorClass: 'bg-emerald-500',
        accentClass: 'text-emerald-700 dark:text-emerald-300',
      };
    case 'delayed':
      return {
        icon: AlertTriangle,
        containerClass: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        indicatorClass: 'bg-amber-500',
        accentClass: 'text-amber-700 dark:text-amber-300',
      };
    case 'down':
      return {
        icon: AlertOctagon,
        containerClass: 'border-destructive/40 bg-destructive/10 text-destructive',
        indicatorClass: 'bg-destructive',
        accentClass: 'text-destructive',
        bannerRole: 'alert',
      };
    default:
      return {
        icon: Activity,
        containerClass: 'border-border bg-muted text-muted-foreground',
        indicatorClass: 'bg-muted-foreground',
        accentClass: 'text-muted-foreground',
      };
  }
}

function severityTone(severity: StatusSeverity): string {
  switch (severity) {
    case 'critical':
      return 'border-destructive/40 bg-destructive/10 text-destructive';
    case 'high':
      return 'border-destructive/30 bg-destructive/10 text-destructive';
    case 'medium':
      return 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300';
    case 'low':
      return 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300';
  }
}

function actionTone(action: StatusAction): string {
  switch (action) {
    case 'auto-merged':
      return 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300';
    case 'paged':
      return 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300';
    case 'declined':
      return 'border-destructive/30 bg-destructive/10 text-destructive';
  }
}

function cellTone(status: UptimeDayStatus): string {
  switch (status) {
    case 'up':
      return 'bg-emerald-500';
    case 'stale':
      return 'bg-amber-500/70';
    case 'down':
      return 'bg-destructive/80';
  }
}

function formatLatencyHours(value: number | null): string {
  if (value === null) return '—';
  if (value < 1) {
    const mins = Math.max(0, Math.round(value * 60));
    return `${mins} min`;
  }
  if (value < 48) {
    return `${value.toFixed(1)} h`;
  }
  return `${Math.round(value / 24)} d`;
}

function relativeFromIso(iso: string, now: Date): string {
  const elapsedMs = Math.max(0, now.getTime() - new Date(iso).getTime());
  const minutes = Math.floor(elapsedMs / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 14) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 8) return `${weeks}w ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

function formatSnapshotTimestamp(iso: string): string {
  return `${iso.replace('T', ' ').slice(0, 16)} UTC`;
}

type State =
  | { kind: 'loading' }
  | { kind: 'error'; message: string }
  | { kind: 'ready'; snapshot: StatusSnapshot; now: Date };

export function StatusBoard() {
  const [state, setState] = useState<State>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch('/api/status', { schema: StatusSnapshotSchema })
      .then((snapshot) => {
        if (active) {
          setState({ kind: 'ready', snapshot, now: new Date() });
        }
      })
      .catch((err: unknown) => {
        if (active) {
          const message =
            err instanceof Error ? err.message : 'Could not load the status snapshot.';
          setState({ kind: 'error', message });
        }
      });
    return () => {
      active = false;
    };
  }, []);

  if (state.kind === 'loading') {
    return <StatusLoadingSkeleton />;
  }
  if (state.kind === 'error') {
    return (
      <Card role="alert" className="border-destructive/30">
        <CardHeader>
          <CardTitle className="font-display text-h4 text-destructive">
            Status unavailable
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">{state.message}</p>
        </CardContent>
      </Card>
    );
  }

  const { snapshot, now } = state;
  const isNoData = snapshot.recentIncidents.items.length === 0 && snapshot.summary30d.patches === 0;

  // The loader already returns overall='no-data' for an empty dataset, but a
  // banner can still be "healthy" while the inner tiles are empty — promote
  // the visible state to no-data when the dataset is empty.
  const displayedOverall: StatusOverall = isNoData ? 'no-data' : snapshot.headline.overall;

  return (
    <div className="flex flex-col gap-section">
      <StatusBanner
        overall={displayedOverall}
        label={snapshot.headline.label}
        detail={snapshot.headline.detail}
        lastSeenAt={snapshot.headline.lastSeenAt}
        generatedAt={snapshot.generatedAt}
      />

      <UptimeStrip uptime={snapshot.uptime} />

      <Summary30d summary={snapshot.summary30d} />

      <RecentIncidentsCard items={snapshot.recentIncidents.items} now={now} />
    </div>
  );
}

function StatusLoadingSkeleton() {
  return (
    <div className="flex flex-col gap-section" aria-busy="true">
      <Card>
        <CardContent className="flex items-center gap-4 py-8">
          <div className="size-5 animate-pulse rounded-full bg-muted" aria-hidden />
          <div className="flex-1 space-y-2">
            <div className="h-4 w-40 animate-pulse rounded-md bg-muted" aria-hidden />
            <div className="h-3 w-64 animate-pulse rounded-md bg-muted" aria-hidden />
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">90-day uptime</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-10 animate-pulse rounded-md bg-muted" aria-hidden />
          <div className="mt-4 h-3 w-32 animate-pulse rounded-md bg-muted" aria-hidden />
        </CardContent>
      </Card>
    </div>
  );
}

function StatusBanner({
  overall,
  label,
  detail,
  lastSeenAt,
  generatedAt,
}: {
  overall: StatusOverall;
  label: string;
  detail: string;
  lastSeenAt: string | null;
  generatedAt: string;
}) {
  const visual = bannerVisual(overall);
  const Icon = visual.icon;
  return (
    <Card
      role={visual.bannerRole ?? 'status'}
      aria-live={visual.bannerRole === 'alert' ? 'assertive' : 'polite'}
      className={cn('border-2', visual.containerClass)}
    >
      <CardContent className="flex flex-col gap-4 py-6 sm:flex-row sm:items-center">
        <div className="flex items-center gap-4">
          <div className="relative flex size-10 shrink-0 items-center justify-center">
            <span
              className={cn(
                'absolute inset-0 animate-ping rounded-full opacity-30',
                visual.indicatorClass,
              )}
              aria-hidden
            />
            <span
              className={cn(
                'relative flex size-10 items-center justify-center rounded-full text-background',
                visual.indicatorClass,
              )}
              aria-hidden
            >
              <Icon className="size-5" />
            </span>
          </div>
          <div className="flex flex-col gap-1">
            <span
              className={cn(
                'text-small font-semibold uppercase tracking-[0.08em]',
                visual.accentClass,
              )}
            >
              Agent status
            </span>
            <p className={cn('font-display text-h3', visual.accentClass)}>{label}</p>
          </div>
        </div>
        <div className="flex-1 border-t border-border pt-4 sm:border-l sm:border-t-0 sm:pt-0 sm:pl-4">
          <p className="text-small text-muted-foreground">{detail}</p>
          <p className="mt-1 text-caption text-muted-foreground">
            Snapshot generated at{' '}
            <time dateTime={generatedAt}>{formatSnapshotTimestamp(generatedAt)}</time>
            {lastSeenAt && (
              <>
                {' · '}
                last seen <time dateTime={lastSeenAt}>{formatSnapshotTimestamp(lastSeenAt)}</time>
              </>
            )}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function UptimeStrip({ uptime }: { uptime: StatusSnapshot['uptime'] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-h4">90-day uptime</CardTitle>
        <p className="text-small text-muted-foreground">
          Each cell is one UTC day. Green means a triage row landed; amber means today hasn&apos;t
          observed a row yet; red means a full day passed without telemetry.
        </p>
      </CardHeader>
      <CardContent>
        <ul
          className="flex flex-row gap-[2px] overflow-x-auto"
          aria-label={`Uptime from ${uptime.fromDay} to ${uptime.toDay}`}
        >
          {uptime.days.map((day) => (
            <UptimeCell key={day.day} day={day} />
          ))}
        </ul>
        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-caption text-muted-foreground">
          <LegendDot tone="bg-emerald-500" label="Triage row landed" />
          <LegendDot tone="bg-amber-500/70" label="Today, awaiting cron" />
          <LegendDot tone="bg-destructive/80" label="Day with no telemetry" />
          <span className="ml-auto font-mono">
            {uptime.fromDay} → {uptime.toDay}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

function UptimeCell({ day }: { day: UptimeDay }) {
  const tooltip =
    day.status === 'up'
      ? `${day.day} — ${day.patchesCount} triage row${day.patchesCount === 1 ? '' : 's'}`
      : day.status === 'stale'
        ? `${day.day} — today, awaiting the next cron run`
        : `${day.day} — no triage row`;
  return (
    <li
      title={tooltip}
      aria-label={tooltip}
      className={cn('h-9 w-[8px] shrink-0 rounded-sm', cellTone(day.status))}
    >
      <span className="sr-only">{tooltip}</span>
    </li>
  );
}

function LegendDot({ tone, label }: { tone: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn('inline-block size-2.5 rounded-sm', tone)} aria-hidden />
      <span>{label}</span>
    </span>
  );
}

function Summary30d({ summary }: { summary: StatusSnapshot['summary30d'] }) {
  const tiles: Array<{ label: string; value: string; hint: string }> = [
    {
      label: 'Patches landed (30d)',
      value: String(summary.patches),
      hint:
        summary.patches === 0
          ? 'No triage rows in the last 30 days'
          : 'Total triage rows in the trailing 30 days',
    },
    {
      label: 'Auto-merged (30d)',
      value: String(summary.autoMerged),
      hint:
        summary.patches === 0
          ? 'No triage rows yet'
          : `${summary.autoMerged} of ${summary.patches} merged without review`,
    },
    {
      label: 'Paged (30d)',
      value: String(summary.paged),
      hint:
        summary.patches === 0
          ? 'No triage rows yet'
          : `${summary.paged} of ${summary.patches} escalated to a human reviewer`,
    },
    {
      label: 'Median detection→PR',
      value: formatLatencyHours(summary.medianLatencyHours),
      hint:
        summary.medianLatencyHours === null
          ? 'No triage rows yet'
          : 'Median age of triage rows in the last 30 days',
    },
  ];
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-h4">Trailing 30 days</CardTitle>
      </CardHeader>
      <CardContent>
        <dl className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {tiles.map((tile) => (
            <div
              key={tile.label}
              className="flex flex-col gap-1 rounded-md border border-border bg-card p-4"
            >
              <dt className="text-caption font-semibold uppercase tracking-[0.06em] text-muted-foreground">
                {tile.label}
              </dt>
              <dd className="font-display text-h3 text-foreground">{tile.value}</dd>
              <p className="text-caption text-muted-foreground">{tile.hint}</p>
            </div>
          ))}
        </dl>
      </CardContent>
    </Card>
  );
}

function RecentIncidentsCard({ items, now }: { items: IncidentRow[]; now: Date }) {
  if (items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">Recent incidents</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">
            No detection→PR rows yet. Once the daily cron matches a CVE or breaking change against
            the manifest, the most recent triage actions land in this list.
          </p>
        </CardContent>
      </Card>
    );
  }
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-h4">Recent incidents</CardTitle>
        <p className="text-small text-muted-foreground">
          The {items.length} most recent triage rows — package, version pin, severity, decision, and
          the elapsed time between detection and PR open.
        </p>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>When</TableHead>
              <TableHead>CVE</TableHead>
              <TableHead>Package</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead>Action</TableHead>
              <TableHead className="text-right">Detection→PR</TableHead>
              <TableHead className="text-right">PR</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((row) => (
              <TableRow key={row.id}>
                <TableCell>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-small text-foreground">
                      {relativeFromIso(row.createdAt, now)}
                    </span>
                    <time
                      dateTime={row.createdAt}
                      className="font-mono text-caption text-muted-foreground"
                    >
                      {row.createdAt.slice(0, 10)}
                    </time>
                  </div>
                </TableCell>
                <TableCell>
                  {row.cveId ? (
                    <span className="font-mono text-small text-foreground">{row.cveId}</span>
                  ) : (
                    <Badge
                      variant="outline"
                      className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                    >
                      Breaking
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-0.5">
                    <span className="font-mono text-small text-foreground">{row.packageName}</span>
                    <span className="font-mono text-caption text-muted-foreground">
                      {row.fromVersion} → {row.toVersion}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={severityTone(row.severity)}>
                    {row.severity[0]?.toUpperCase() + row.severity.slice(1)}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={actionTone(row.action)}>
                    {row.action}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-mono text-small text-foreground">
                  {formatLatencyHours(row.detectionToPrLatencyHours)}
                </TableCell>
                <TableCell className="text-right">
                  <Link
                    href={row.prUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-small text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
                  >
                    Open
                    <ExternalLink className="size-3.5" aria-hidden />
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
