// @polsia:user-owned — extra <head> rendered by the framework layout (null by default).
// Add <meta>/<link> here (verification, preconnect) — React hoists them. For scripts use
// next/script with the passed `nonce` (CSP-safe). Edit freely.

import { siteDescription, siteName, siteUrl } from '@/lib/site';

export function HeadContent({ nonce }: { nonce?: string }) {
  void nonce;
  const orgLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: siteName,
    url: siteUrl,
    description: siteDescription,
    logo: `${siteUrl}/icon.svg`,
    sameAs: [] as string[],
  };
  return (
    <script
      type="application/ld+json"
      id="organization-ldjson"
      // biome-ignore lint/security/noDangerouslySetInnerHtml: JSON-LD schema.org payload; payload is server-derived and run through JSON.stringify (safe-encoded).
      dangerouslySetInnerHTML={{ __html: JSON.stringify(orgLd) }}
    />
  );
}
