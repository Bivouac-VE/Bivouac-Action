// @polsia:user-owned — horizontal-bar SVG chart of patch counts grouped by
// severity. Reuses the same severity tone map as the audit log table so a
// "high" row in the audit log and the "high" bar on the dashboard read as the
// same risk tier at a glance. Inline SVG (CSP-safe, no chart deps).

import { useMemo } from 'react';
import type { SeverityBreakdownPoint, SeverityBucket } from '@/lib/contracts/insights';

export interface SeverityBreakdownChartProps {
  points: SeverityBreakdownPoint[];
}

const ORDER: SeverityBucket[] = ['low', 'medium', 'high', 'critical'];
const LABEL: Record<SeverityBucket, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const BAR_FILL: Record<SeverityBucket, string> = {
  low: 'fill-emerald-500',
  medium: 'fill-amber-500',
  high: 'fill-rose-500',
  critical: 'fill-destructive',
};

const BAR_TINT: Record<SeverityBucket, string> = {
  low: 'fill-emerald-500/30',
  medium: 'fill-amber-500/30',
  high: 'fill-rose-500/30',
  critical: 'fill-destructive/30',
};

interface Resolved extends SeverityBreakdownPoint {
  fill: string;
  tint: string;
}

export function SeverityBreakdownChart({ points }: SeverityBreakdownChartProps) {
  const rows = useMemo<Resolved[]>(() => {
    const byKey = new Map<SeverityBucket, number>();
    for (const p of points) byKey.set(p.severity, p.count);
    return ORDER.map((severity) => ({
      severity,
      count: byKey.get(severity) ?? 0,
      fill: BAR_FILL[severity],
      tint: BAR_TINT[severity],
    }));
  }, [points]);

  const maxCount = rows.reduce((acc, r) => Math.max(acc, r.count), 0);
  const total = rows.reduce((acc, r) => acc + r.count, 0);

  if (total === 0) {
    return (
      <div className="grid h-[220px] w-full place-items-center rounded-md border border-dashed border-border/60 bg-muted/30 text-sm text-muted-foreground">
        No patches in this window.
      </div>
    );
  }

  const ROW_HEIGHT = 36;
  const LABEL_WIDTH = 80;
  const VALUE_WIDTH = 48;
  const CHART_WIDTH = 640;
  const CHART_HEIGHT = ROW_HEIGHT * rows.length + 16;
  const trackX = LABEL_WIDTH;
  const trackWidth = CHART_WIDTH - LABEL_WIDTH - VALUE_WIDTH - 16;

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}
        role="img"
        aria-label="Patches by severity"
        className="block w-full"
      >
        <title>Patches opened by severity</title>
        {rows.map((row, i) => {
          const y = i * ROW_HEIGHT + 8;
          const ratio = maxCount === 0 ? 0 : row.count / maxCount;
          const width = Math.max(row.count > 0 ? 6 : 0, ratio * trackWidth);
          return (
            <g key={row.severity}>
              <text
                x={0}
                y={y + ROW_HEIGHT / 2 + 4}
                fontSize={12}
                className="fill-foreground"
                fontWeight={500}
              >
                {LABEL[row.severity]}
              </text>
              <rect
                x={trackX}
                y={y + 8}
                width={trackWidth}
                height={ROW_HEIGHT - 16}
                rx={6}
                className="fill-muted/40"
              />
              <rect
                x={trackX}
                y={y + 8}
                width={width}
                height={ROW_HEIGHT - 16}
                rx={6}
                className={row.count === 0 ? row.tint : row.fill}
              >
                <title>{`${LABEL[row.severity]}: ${row.count}`}</title>
              </rect>
              <text
                x={trackX + trackWidth + 8}
                y={y + ROW_HEIGHT / 2 + 4}
                fontSize={12}
                className="fill-muted-foreground"
                fontWeight={600}
              >
                {row.count}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
