// @polsia:user-owned — client island for /insights. Owns:
//  - URL sync for the date-range filter (?range=7d|30d|90d)
//  - three parallel /api/insights/* fetches (overview, patches-by-week, severity)
//  - the rendered view (range picker, KPI grid, two inline-SVG charts, empty/error states)
//
// The page itself stays a Server Component that exports metadata only.

'use client';

import { AlertTriangle, BarChart3, RefreshCcw, ShieldCheck, Workflow } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import type { ZodType } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { apiFetch } from '@/lib/api-client';
import type { InsightsRangeDays } from '@/lib/contracts/insights';
import {
  InsightsOverview,
  InsightsRangeDaysEnum,
  PatchesByWeekSeries,
  SeverityBreakdownSeries,
} from '@/lib/contracts/insights';
import { PatchesByWeekChart } from './patches-by-week-chart';
import { SeverityBreakdownChart } from './severity-breakdown-chart';

const DEFAULT_RANGE: InsightsRangeDays = 30;
const RANGES: InsightsRangeDays[] = [7, 30, 90];

type Overview = InsightsOverview;
type Patches = PatchesByWeekSeries;
type Breakdown = SeverityBreakdownSeries;

function parseRange(raw: string | null): InsightsRangeDays {
  const candidate = (raw ?? '').trim().toLowerCase();
  const numeric = candidate.endsWith('d') ? candidate.slice(0, -1) : candidate;
  const parsed = InsightsRangeDaysEnum.safeParse(Number.parseInt(numeric, 10));
  return parsed.success ? parsed.data : DEFAULT_RANGE;
}

interface KpiCardProps {
  label: string;
  value: string;
  hint: string | null;
  icon: typeof RefreshCcw;
  emphasis?: 'brand' | 'neutral' | 'warm';
}

const EMPHASIS_RING: Record<NonNullable<KpiCardProps['emphasis']>, string> = {
  brand: 'ring-1 ring-inset ring-brand-500/30 dark:ring-brand-500/20',
  neutral: 'ring-1 ring-inset ring-border/60',
  warm: 'ring-1 ring-inset ring-amber-500/30 dark:ring-amber-500/20',
};

const EMPHASIS_ICON: Record<NonNullable<KpiCardProps['emphasis']>, string> = {
  brand: 'text-brand-600 dark:text-brand-400',
  neutral: 'text-muted-foreground',
  warm: 'text-amber-600 dark:text-amber-400',
};

function KpiCard({ label, value, hint, icon: Icon, emphasis = 'neutral' }: KpiCardProps) {
  return (
    <Card className={`flex h-full flex-col gap-3 bg-card/80 ${EMPHASIS_RING[emphasis]}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        <span
          className={`flex size-8 items-center justify-center rounded-md border border-border/60 bg-background ${EMPHASIS_ICON[emphasis]}`}
        >
          <Icon aria-hidden="true" className="size-4" />
        </span>
      </CardHeader>
      <CardContent className="flex flex-col gap-1 p-5 pt-0">
        <p className="font-display text-h2 leading-none text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{hint ?? ' '}</p>
      </CardContent>
    </Card>
  );
}

function KpiSkeleton({
  emphasis = 'neutral',
}: {
  emphasis?: NonNullable<KpiCardProps['emphasis']>;
}) {
  return (
    <Card className={`flex h-full flex-col gap-3 bg-card/80 ${EMPHASIS_RING[emphasis]}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-2">
        <Skeleton className="h-4 w-32" />
        <Skeleton className="size-8 rounded-md" />
      </CardHeader>
      <CardContent className="flex flex-col gap-1 p-5 pt-0">
        <Skeleton className="h-8 w-28" />
        <Skeleton className="h-3 w-24" />
      </CardContent>
    </Card>
  );
}

function ChartSkeleton({ label }: { label: string }) {
  return (
    <div className="grid h-[220px] w-full place-items-center rounded-md border border-border/60 bg-muted/20">
      <span className="sr-only">Loading {label}</span>
      <Skeleton className="h-4 w-48" />
    </div>
  );
}

function ErrorBanner({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm">
      <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 text-destructive" />
      <div className="grid flex-1 gap-1">
        <p className="font-medium text-foreground">Couldn’t load compliance insights.</p>
        <p className="text-muted-foreground">{message}</p>
      </div>
      <button
        type="button"
        onClick={onRetry}
        className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border/70 bg-background px-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
      >
        <RefreshCcw aria-hidden="true" className="size-3.5" />
        Retry
      </button>
    </div>
  );
}

function ConnectedRepoEmptyHint({ count }: { count: number }) {
  if (count > 0) return null;
  return (
    <p className="rounded-md border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
      Connect a repo to see compliance metrics. Insights here will populate once Bivouac opens its
      first patch PR for your account.
    </p>
  );
}

interface FetchState<T> {
  data: T | null;
  error: string | null;
  loaded: boolean;
}

async function loadOne<T>(
  schema: ZodType<T>,
  url: string,
  signal: AbortSignal,
): Promise<{ kind: 'ok'; data: T } | { kind: 'err'; error: string }> {
  try {
    const data = await apiFetch<T>(url, { schema, signal });
    return { kind: 'ok', data };
  } catch (err) {
    if (signal.aborted) return { kind: 'err', error: 'aborted' };
    return { kind: 'err', error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

export function InsightsBoard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const range = useMemo<InsightsRangeDays>(
    () => parseRange(searchParams.get('range')),
    [searchParams],
  );

  const [overview, setOverview] = useState<FetchState<Overview>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [patches, setPatches] = useState<FetchState<Patches>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [breakdown, setBreakdown] = useState<FetchState<Breakdown>>({
    data: null,
    error: null,
    loaded: false,
  });
  const [reloadKey, setReloadKey] = useState(0);
  const [pendingRange, setPendingRange] = useState<InsightsRangeDays | null>(null);

  // Mirror the range to ?range=Nd in the URL (audit-log pattern). Skip the
  // initial render so we don't replace the URL on first mount with the
  // default value parsed from a missing query string.
  useEffect(() => {
    if (pendingRange === null) return;
    const next = new URLSearchParams(searchParams.toString());
    if (pendingRange === DEFAULT_RANGE) {
      next.delete('range');
    } else {
      next.set('range', `${pendingRange}d`);
    }
    const qs = next.toString();
    router.replace(qs.length > 0 ? `?${qs}` : '?', { scroll: false });
    setPendingRange(null);
  }, [pendingRange, router, searchParams]);

  useEffect(() => {
    const controller = new AbortController();
    setOverview({ data: null, error: null, loaded: false });
    setPatches({ data: null, error: null, loaded: false });
    setBreakdown({ data: null, error: null, loaded: false });

    const qs = `?range=${range}d&_=${reloadKey}`;
    void (async () => {
      const res = await loadOne(InsightsOverview, `/api/insights/overview${qs}`, controller.signal);
      if (!controller.signal.aborted) {
        if (res.kind === 'ok') {
          setOverview({ data: res.data, error: null, loaded: true });
        } else {
          setOverview({ data: null, error: res.error, loaded: true });
        }
      }
    })();
    void (async () => {
      const res = await loadOne(
        PatchesByWeekSeries,
        `/api/insights/patches-by-week${qs}`,
        controller.signal,
      );
      if (!controller.signal.aborted) {
        if (res.kind === 'ok') {
          setPatches({ data: res.data, error: null, loaded: true });
        } else {
          setPatches({ data: null, error: res.error, loaded: true });
        }
      }
    })();
    void (async () => {
      const res = await loadOne(
        SeverityBreakdownSeries,
        `/api/insights/severity-breakdown${qs}`,
        controller.signal,
      );
      if (!controller.signal.aborted) {
        if (res.kind === 'ok') {
          setBreakdown({ data: res.data, error: null, loaded: true });
        } else {
          setBreakdown({ data: null, error: res.error, loaded: true });
        }
      }
    })();

    return () => {
      controller.abort();
    };
  }, [range, reloadKey]);

  function handleRangeChange(next: InsightsRangeDays) {
    setPendingRange(next);
    setReloadKey((k) => k + 1);
  }

  function handleRetry() {
    setReloadKey((k) => k + 1);
  }

  const anyPending = !overview.loaded || !patches.loaded || !breakdown.loaded;
  const anyError = overview.error !== null || patches.error !== null || breakdown.error !== null;
  const errorMessage = overview.error ?? patches.error ?? breakdown.error ?? 'Unknown error';

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <p className="text-eyebrow">Compliance insights</p>
          <p className="max-w-xl text-sm text-muted-foreground">
            Patch velocity, automation coverage, and human overrides scoped to your connected
            repositories.
          </p>
        </div>
        <Tabs
          value={String(range)}
          onValueChange={(value) => {
            const parsed = InsightsRangeDaysEnum.safeParse(Number.parseInt(value, 10));
            if (parsed.success) handleRangeChange(parsed.data);
          }}
          aria-label="Date range"
        >
          <TabsList className="bg-muted/60">
            {RANGES.map((d) => (
              <TabsTrigger key={d} value={String(d)} type="button">
                Last {d} days
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {anyError && !anyPending ? (
        <ErrorBanner message={errorMessage} onRetry={handleRetry} />
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {overview.loaded ? (
          <>
            <KpiCard
              label="Mean time to patch"
              value={overview.data?.tiles.mttp.value ?? '—'}
              hint={overview.data?.tiles.mttp.hint ?? null}
              icon={ShieldCheck}
              emphasis="brand"
            />
            <KpiCard
              label="Patches opened"
              value={overview.data?.tiles.patchesOpened.value ?? '0'}
              hint={overview.data?.tiles.patchesOpened.hint ?? null}
              icon={BarChart3}
              emphasis="neutral"
            />
            <KpiCard
              label="Auto-merge rate"
              value={overview.data?.tiles.autoMergeRate.value ?? '—'}
              hint={overview.data?.tiles.autoMergeRate.hint ?? null}
              icon={Workflow}
              emphasis="neutral"
            />
            <KpiCard
              label="Human-override rate"
              value={overview.data?.tiles.humanOverrideRate.value ?? '—'}
              hint={overview.data?.tiles.humanOverrideRate.hint ?? null}
              icon={AlertTriangle}
              emphasis="warm"
            />
          </>
        ) : (
          <>
            <KpiSkeleton emphasis="brand" />
            <KpiSkeleton />
            <KpiSkeleton />
            <KpiSkeleton emphasis="warm" />
          </>
        )}
      </div>

      <ConnectedRepoEmptyHint count={overview.data?.connectedRepoCount ?? 0} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="flex flex-col gap-0 border-border/70 bg-card/80">
          <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-3">
            <div className="grid gap-1">
              <CardTitle className="font-display text-h4 tracking-tight">
                Patches opened per week
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Counts of new CVE-triage PRs the agent opened, bucketed by ISO week.
              </p>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5 pt-0">
            {patches.loaded ? (
              <PatchesByWeekChart points={patches.data?.points ?? []} />
            ) : (
              <ChartSkeleton label="patches per week" />
            )}
          </CardContent>
        </Card>

        <Card className="flex flex-col gap-0 border-border/70 bg-card/80">
          <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-3">
            <div className="grid gap-1">
              <CardTitle className="font-display text-h4 tracking-tight">
                Patches by severity
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Distribution of opened patches across the four severity tiers.
              </p>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5 pt-0">
            {breakdown.loaded ? (
              <SeverityBreakdownChart points={breakdown.data?.points ?? []} />
            ) : (
              <ChartSkeleton label="severity breakdown" />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
