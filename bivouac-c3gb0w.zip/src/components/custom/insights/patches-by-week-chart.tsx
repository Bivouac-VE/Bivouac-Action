// @polsia:user-owned — vertical-bar SVG chart of patches opened per ISO week,
// zero-padded so a quiet week reads as a zero-height bar with the same
// baseline as a busy week. Inline SVG (CSP-safe, no chart deps).

import { useMemo } from 'react';
import type { PatchesByWeekPoint } from '@/lib/contracts/insights';

export interface PatchesByWeekChartProps {
  points: PatchesByWeekPoint[];
}

const CHART_WIDTH = 640;
const CHART_HEIGHT = 220;
const PADDING = { top: 16, right: 16, bottom: 28, left: 32 };

function fmtWeek(iso: string): string {
  const date = new Date(`${iso}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function niceCeiling(value: number): number {
  if (value <= 1) return 4;
  if (value <= 4) return value;
  if (value <= 6) return 6;
  if (value <= 10) return 10;
  return Math.ceil(value / 5) * 5;
}

export function PatchesByWeekChart({ points }: PatchesByWeekChartProps) {
  const data = useMemo(
    () => points.slice().sort((a, b) => a.weekStart.localeCompare(b.weekStart)),
    [points],
  );
  const maxCount = data.reduce((acc, p) => Math.max(acc, p.count), 0);
  const yMax = niceCeiling(maxCount);

  const innerWidth = CHART_WIDTH - PADDING.left - PADDING.right;
  const innerHeight = CHART_HEIGHT - PADDING.top - PADDING.bottom;

  if (data.length === 0) {
    return (
      <div className="grid h-[220px] w-full place-items-center rounded-md border border-dashed border-border/60 bg-muted/30 text-sm text-muted-foreground">
        No patches in this window.
      </div>
    );
  }

  const barCount = data.length;
  const gap = Math.max(2, Math.floor(innerWidth / (barCount * 6)));
  const barWidth = Math.max(4, Math.floor((innerWidth - gap * (barCount - 1)) / barCount));

  const yTicks = [0, yMax / 2, yMax];

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}
        role="img"
        aria-label="Patches opened per week"
        className="block w-full"
      >
        <title>Patches opened per week</title>
        {/* Y-axis grid + labels */}
        {yTicks.map((tick) => {
          const y = PADDING.top + innerHeight - (tick / yMax) * innerHeight;
          return (
            <g key={`yt-${tick}`}>
              <line
                x1={PADDING.left}
                x2={CHART_WIDTH - PADDING.right}
                y1={y}
                y2={y}
                stroke="currentColor"
                strokeWidth={0.5}
                className="text-border"
              />
              <text
                x={PADDING.left - 6}
                y={y + 4}
                textAnchor="end"
                fontSize={11}
                className="fill-muted-foreground"
              >
                {Math.round(tick)}
              </text>
            </g>
          );
        })}
        {/* Bars */}
        {data.map((point, i) => {
          const x = PADDING.left + i * (barWidth + gap);
          const heightRatio = yMax === 0 ? 0 : point.count / yMax;
          const height = Math.max(2, heightRatio * innerHeight);
          const y = PADDING.top + innerHeight - height;
          const zero = point.count === 0;
          return (
            <g key={`bar-${point.weekStart}`}>
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={height}
                rx={3}
                className={zero ? 'fill-brand-200 dark:fill-brand-700/40' : 'fill-brand-500'}
              >
                {point.count > 0 ? (
                  <title>{`${fmtWeek(point.weekStart)}: ${point.count}`}</title>
                ) : null}
              </rect>
            </g>
          );
        })}
        {/* X-axis labels (first / mid / last) */}
        {[0, Math.floor(barCount / 2), barCount - 1].map((idx) => {
          if (idx < 0 || idx >= data.length) return null;
          const point = data[idx];
          if (!point) return null;
          const x = PADDING.left + idx * (barWidth + gap) + barWidth / 2;
          const y = CHART_HEIGHT - 8;
          return (
            <text
              key={`xt-${point.weekStart}`}
              x={x}
              y={y}
              textAnchor="middle"
              fontSize={11}
              className="fill-muted-foreground"
            >
              {fmtWeek(point.weekStart)}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
