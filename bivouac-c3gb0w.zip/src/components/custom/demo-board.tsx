// @polsia:user-owned — public demo board. Client island that loads the
// canonical ledger state via apiFetch and renders the before/after split-pane.
// No data fetch lives in the page or layout; loading/error/empty are handled
// inline. Every visible number comes from /api/demo (single source of truth).

'use client';

import { CheckCircle2, Clock, GitPullRequest, ShieldAlert, XCircle } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import { type AfterEntry, type BeforeEntry, type Decision, DemoState } from '@/lib/contracts/demo';

type DecisionTone = { tone: string; label: string; Icon: typeof CheckCircle2 };

function decisionTone(decision: Decision): DecisionTone {
  switch (decision) {
    case 'AUTO_MERGE':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: 'Auto-merge',
        Icon: CheckCircle2,
      };
    case 'FLAGGED':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: 'Flagged',
        Icon: Clock,
      };
    case 'REJECTED':
      return {
        tone: 'border-destructive/30 bg-destructive/10 text-destructive',
        label: 'Rejected',
        Icon: XCircle,
      };
  }
}

function typeBadge(type: BeforeEntry['type']): { tone: string; label: string } {
  switch (type) {
    case 'SECURITY':
      return {
        tone: 'border-destructive/30 bg-destructive/10 text-destructive',
        label: 'Security',
      };
    case 'MAJOR':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: 'Major',
      };
    case 'PATCH':
      return { tone: 'border-border bg-muted text-muted-foreground', label: 'Patch' };
    case 'MINOR':
      return { tone: 'border-border bg-muted text-muted-foreground', label: 'Minor' };
  }
}

function outcomeBadge(outcome: AfterEntry['testOutcome']): { tone: string; label: string } {
  switch (outcome) {
    case 'PASSED':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: 'Passed',
      };
    case 'PENDING':
      return { tone: 'border-border bg-muted text-muted-foreground', label: 'Pending' };
    case 'FAILED':
      return {
        tone: 'border-destructive/30 bg-destructive/10 text-destructive',
        label: 'Failed (rejected by analyzer)',
      };
  }
}

function MetricTile({
  Icon,
  value,
  label,
  tone,
}: {
  Icon: typeof CheckCircle2;
  value: string | number;
  label: string;
  tone: 'destructive' | 'brand' | 'amber' | 'muted';
}) {
  const toneClass = {
    destructive: 'text-destructive',
    brand: 'text-brand-700 dark:text-brand-300',
    amber: 'text-amber-700 dark:text-amber-300',
    muted: 'text-muted-foreground',
  }[tone];
  return (
    <div className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
      <Icon className={`mt-0.5 size-5 ${toneClass}`} aria-hidden />
      <div className="flex flex-col">
        <p className="font-display text-h3 text-foreground">{value}</p>
        <p className="text-small text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

export function DemoBoard() {
  const [state, setState] = useState<DemoState | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    apiFetch('/api/demo', { schema: DemoState })
      .then((data) => {
        if (active) {
          setState(data);
        }
      })
      .catch((err: unknown) => {
        if (active) {
          setError(err instanceof Error ? err.message : 'Could not load the demo ledger.');
        }
      });
    return () => {
      active = false;
    };
  }, []);

  if (error) {
    return (
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="font-display text-h4 text-destructive">
            Demo ledger unavailable
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <p className="text-small text-muted-foreground">{error}</p>
          <p className="text-small text-muted-foreground">
            Expected at <code>demo-bivouac/ledger.json</code> from the repo root.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (state === null) {
    return (
      <Card>
        <CardContent className="py-10">
          <p className="text-small text-muted-foreground">Loading the canonical demo ledger…</p>
        </CardContent>
      </Card>
    );
  }

  const { before, after, beforeEntries, afterEntries } = state;
  if (beforeEntries.length === 0 || afterEntries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">Empty demo ledger</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">
            The <code>demo-bivouac/ledger.json</code> file exists but contains no entries. Commit at
            least one before/after pair to render the demo board.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <section aria-labelledby="metrics-heading" className="flex flex-col gap-4">
        <h2 id="metrics-heading" className="font-display text-h3 text-foreground">
          The numbers, side by side
        </h2>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricTile
            Icon={GitPullRequest}
            value={before.openDependabotPRs}
            label="Open Dependabot PRs"
            tone="destructive"
          />
          <MetricTile
            Icon={ShieldAlert}
            value={before.securityAdvisories}
            label="Open CVEs"
            tone="destructive"
          />
          <MetricTile
            Icon={CheckCircle2}
            value={after.autoMerged}
            label="Auto-merged by Bivouac"
            tone="brand"
          />
          <MetricTile
            Icon={CheckCircle2}
            value={`${after.testsPass}/${after.testsRun}`}
            label="Tests passing (node --test)"
            tone="brand"
          />
        </div>
      </section>

      <Separator />

      <section aria-labelledby="story-heading" className="flex flex-col gap-4">
        <h2 id="story-heading" className="font-display text-h3 text-foreground">
          What Bivouac actually decided
        </h2>
        <p className="max-w-3xl text-body text-muted-foreground">
          Each row is one Dependabot PR from the fixture repo. The first column shows what arrived
          in the queue; the right side shows Bivouac&apos;s analysis and the test outcome the
          analyzer observed before deciding.
        </p>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>PR</TableHead>
                  <TableHead>Package</TableHead>
                  <TableHead>From → To</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Reasoning</TableHead>
                  <TableHead>Decision</TableHead>
                  <TableHead>Test</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {afterEntries.map((after) => {
                  const beforeEntry = beforeEntries.find((b) => b.id === after.id);
                  if (!beforeEntry) {
                    return null;
                  }
                  const decision = decisionTone(after.decision);
                  const Icon = decision.Icon;
                  const type = typeBadge(beforeEntry.type);
                  const outcome = outcomeBadge(after.testOutcome);
                  return (
                    <TableRow key={after.id} className="align-top">
                      <TableCell className="font-mono text-caption text-foreground">
                        {after.id}
                      </TableCell>
                      <TableCell className="font-mono text-small">{beforeEntry.package}</TableCell>
                      <TableCell className="font-mono text-small text-muted-foreground">
                        {after.fromVersion} → {after.toVersion}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={type.tone}>
                          {type.label}
                        </Badge>
                        {beforeEntry.cveId ? (
                          <p className="mt-1 font-mono text-caption text-muted-foreground">
                            {beforeEntry.cveId}
                          </p>
                        ) : null}
                      </TableCell>
                      <TableCell className="max-w-md text-small text-muted-foreground">
                        {after.reasoning}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={decision.tone}>
                          <Icon className="mr-1 size-3.5" aria-hidden />
                          {decision.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={outcome.tone}>
                          {outcome.label}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </section>

      <Separator />

      <section aria-labelledby="after-heading" className="flex flex-col gap-4">
        <h2 id="after-heading" className="font-display text-h3 text-foreground">
          After Bivouac has run
        </h2>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <MetricTile
            Icon={CheckCircle2}
            value={after.autoMerged}
            label="Auto-merged"
            tone="brand"
          />
          <MetricTile
            Icon={Clock}
            value={after.flaggedForReview}
            label="Flagged for review"
            tone="amber"
          />
          <MetricTile
            Icon={XCircle}
            value={after.rejected}
            label="Rejected by analyzer"
            tone="destructive"
          />
          <MetricTile
            Icon={ShieldAlert}
            value={after.vulnerabilitiesRemaining}
            label="CVEs remaining"
            tone={after.vulnerabilitiesRemaining > 0 ? 'destructive' : 'brand'}
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="font-display text-h4">Where the numbers come from</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <p className="text-small text-muted-foreground">{after.summary}</p>
            <p className="text-small text-muted-foreground">
              Every number on this page is the corresponding count in{' '}
              <code>demo-bivouac/ledger.json</code>. The fixture repo at{' '}
              <code>demo-bivouac/sample-app/</code> is what generated the queue; its
              <code> package.json</code>, <code>package-lock.json</code>, and
              <code> node --test</code> run are the verifiable source of truth.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" size="sm">
                <a
                  href="https://github.com/bivouac/demo-sample-app"
                  target="_blank"
                  rel="noreferrer"
                >
                  Open the fixture repo
                </a>
              </Button>
              <Button asChild variant="outline" size="sm">
                <Link href="/blog">Read the deep dive</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
