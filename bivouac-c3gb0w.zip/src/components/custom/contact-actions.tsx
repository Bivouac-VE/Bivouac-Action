// @polsia:user-owned — copy-to-clipboard affordance for the contact email in the
// final CTA. Sonner toast confirms the copy.

'use client';

import { Check, Copy } from 'lucide-react';
import * as React from 'react';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const EMAIL = 'bivouac-c3gb0w@polsia.app';

export function CopyEmailButton({ className }: { className?: string }) {
  const [copied, setCopied] = React.useState(false);

  const onCopy = React.useCallback(async () => {
    try {
      await navigator.clipboard.writeText(EMAIL);
      setCopied(true);
      toast.success('Email copied', { description: EMAIL });
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error('Copy failed — please select and copy the address manually.');
    }
  }, []);

  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      onClick={onCopy}
      className={cn('gap-2', className)}
      aria-label={`Copy ${EMAIL} to clipboard`}
    >
      {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
      {copied ? 'Copied' : EMAIL}
    </Button>
  );
}
