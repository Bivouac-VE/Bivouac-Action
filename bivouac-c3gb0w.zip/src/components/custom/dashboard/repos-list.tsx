// @polsia:user-owned — client island for /dashboard/repos. Owns the three
// render states the data-plane rule demands (loading/error/empty/data) and
// is the only thing in the page that calls `apiFetch`. The page itself
// stays a Server Component that exports `metadata`.

'use client';

import { AlertTriangle, Plus } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import { DashboardReposList, type RepoRow as RepoRowT } from '@/lib/contracts/dashboard-repos';
import { ReposEmptyState } from './repos-empty-state';
import { ReposRow } from './repos-row';

type ListState =
  | { status: 'loading' }
  | { status: 'ready'; items: RepoRowT[] }
  | { status: 'error'; message: string };

const SKELETON_IDS = ['a', 'b', 'c', 'd', 'e', 'f'] as const;

export function ReposList() {
  const [state, setState] = useState<ListState>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    const refetch = () => {
      apiFetch('/api/dashboard/repos', { schema: DashboardReposList })
        .then((data) => {
          if (active) {
            setState({ status: 'ready', items: data.items });
          }
        })
        .catch((err: unknown) => {
          if (!active) return;
          const reason =
            err instanceof Error ? err.message : 'Unknown error fetching repositories.';
          setState({ status: 'error', message: reason });
        });
    };
    refetch();
    const handler = () => refetch();
    window.addEventListener('bivouac:repo-policy-changed', handler);
    return () => {
      active = false;
      window.removeEventListener('bivouac:repo-policy-changed', handler);
    };
  }, []);

  if (state.status === 'loading') {
    return (
      <section aria-label="Loading repositories" className="flex flex-col gap-3">
        {SKELETON_IDS.map((id) => (
          <Skeleton key={id} className="h-28 w-full rounded-lg" />
        ))}
      </section>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load repositories.</AlertTitle>
        <AlertDescription>
          We could not reach the repo list right now. Retry in a moment, or contact us if this keeps
          failing. <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.items.length === 0) {
    return <ReposEmptyState />;
  }

  const needsReinstallCount = state.items.filter(
    (item) => item.installStatus === 'needs_reinstall',
  ).length;

  return (
    <section aria-label="Connected repositories" className="flex flex-col gap-6">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Repositories</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Connected repositories
        </h1>
        <p className="text-body-lg text-muted-foreground">
          {state.items.length} {state.items.length === 1 ? 'repo' : 'repos'} on watch — live triage
          status, install health, and most-recent agent activity.
          {needsReinstallCount > 0 ? (
            <>
              {' '}
              <span className="font-medium text-rose-700 dark:text-rose-300">
                {needsReinstallCount} {needsReinstallCount === 1 ? 'needs' : 'need'} reinstall.
              </span>
            </>
          ) : null}
        </p>
      </header>

      <ul className="flex flex-col gap-3">
        {state.items.map((row) => (
          <li key={row.id}>
            <ReposRow row={row} />
          </li>
        ))}
      </ul>

      <Separator className="my-2" />

      <div className="flex flex-wrap items-center justify-between gap-3 text-small text-muted-foreground">
        <span>
          Watching <span className="text-foreground">{state.items.length}</span>{' '}
          {state.items.length === 1 ? 'repository' : 'repositories'}
        </span>
        <Button asChild variant="outline" size="sm" className="gap-1.5">
          <Link href="/connect">
            <Plus className="size-4" aria-hidden /> Connect another repo
          </Link>
        </Button>
      </div>
    </section>
  );
}
