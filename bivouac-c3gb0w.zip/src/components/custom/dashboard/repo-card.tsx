// @polsia:user-owned — presentational card for a single connected repo. All
// styling discipline comes from theme tokens + cva variants; the only
// per-status element is <StatusBadge/>, which keeps the palette decision in
// one place.

import { CircleDot } from 'lucide-react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Repo as RepoType } from '@/lib/contracts/repos';
import { StatusBadge } from './status-badge';

function formatScanned(value: string | null): string {
  if (!value) return 'Not yet scanned';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Not yet scanned';
  return date.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export interface RepoCardProps {
  repo: RepoType;
}

export function RepoCard({ repo }: RepoCardProps) {
  return (
    <Card className="lift flex h-full flex-col gap-0 border-border bg-card/80 p-0 backdrop-blur">
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-3">
        <div className="grid min-w-0 gap-1">
          <CardTitle className="font-display text-h4 tracking-tight text-foreground">
            <span className="font-mono text-muted-foreground">@{repo.ownerHandle}</span>
            <span aria-hidden> / </span>
            <span>{repo.name}</span>
          </CardTitle>
        </div>
        <StatusBadge status={repo.status} />
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-3 px-5 pb-5 pt-0 text-small text-muted-foreground">
        <p className="flex items-start gap-2">
          <CircleDot className="mt-0.5 size-3.5 shrink-0 text-foreground/70" aria-hidden />
          <span>
            Last scan:{' '}
            <time dateTime={repo.lastScannedAt ?? undefined} className="text-foreground">
              {formatScanned(repo.lastScannedAt)}
            </time>
          </span>
        </p>
        <p>
          Triage queue:{' '}
          <span className="text-foreground">{repo.activePack?.packTitle ?? 'default'}</span>
        </p>
        <p>
          <Link
            href={`https://github.com/${repo.ownerHandle}/${repo.name}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-600"
          >
            Open on GitHub
            <span aria-hidden>↗</span>
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}
