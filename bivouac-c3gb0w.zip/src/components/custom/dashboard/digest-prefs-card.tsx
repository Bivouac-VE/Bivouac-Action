// @polsia:user-owned — client island for /dashboard/settings. Owns:
//  - the `/api/digest-prefs` fetch (loading / error / ready branches)
//  - the daily-digest opt-in toggle bound to `@/components/ui/switch`
//  - the `lastDigestSentAt` watermark display ("Last digest: …" pill)
//  - optimistic updates so the switch flips immediately and rolls back on
//    a failed PATCH
//  - a short toast on success/failure (transient feedback) via sonner.
//
// The page itself stays a Server Component that only exports `metadata`.

'use client';

import { BellRing, Loader2, Mail, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { apiFetch } from '@/lib/api-client';
import {
  DigestPrefs,
  DigestPrefsInput,
  type DigestPrefs as DigestPrefsT,
} from '@/lib/contracts/digest-prefs';
import { cn } from '@/lib/utils';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | {
      status: 'ready';
      values: DigestPrefsT;
      saving: boolean;
    };

function formatTimestamp(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function DigestPrefsCard() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch('/api/digest-prefs', { schema: DigestPrefs })
      .then((data) => {
        if (!active) return;
        setState({ status: 'ready', values: data, saving: false });
      })
      .catch((err: unknown) => {
        if (!active) return;
        const message = err instanceof Error ? err.message : 'Could not load digest preferences.';
        setState({ status: 'error', message });
      });
    return () => {
      active = false;
    };
  }, []);

  async function toggle(nextOptIn: boolean) {
    if (state.status !== 'ready') return;

    // Optimistic flip — show the new value immediately, mark saving, then
    // PATCH. If the PATCH fails, roll back to the previous value and toast.
    const previous = state.values.digestOptIn;
    setState({
      status: 'ready',
      values: { ...state.values, digestOptIn: nextOptIn },
      saving: true,
    });

    try {
      const updated = await apiFetch('/api/digest-prefs', {
        method: 'PATCH',
        body: JSON.stringify(DigestPrefsInput.parse({ digestOptIn: nextOptIn })),
        schema: DigestPrefs,
      });
      setState({ status: 'ready', values: updated, saving: false });
      toast.success(
        nextOptIn
          ? 'Daily digest enabled — you’ll get an 08:00 UTC summary.'
          : 'Daily digest paused — you can turn it back on whenever.',
      );
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not save your preference.';
      setState({
        status: 'ready',
        values: { ...state.values, digestOptIn: previous },
        saving: false,
      });
      toast.error(message);
    }
  }

  if (state.status === 'loading') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail aria-hidden="true" className="size-4" />
            <span>Daily digest</span>
          </CardTitle>
          <CardDescription>Loading your digest preferences…</CardDescription>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-5 w-9 rounded-full" />
          <Skeleton className="mt-3 h-4 w-full max-w-md" />
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'error') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail aria-hidden="true" className="size-4" />
            <span>Daily digest</span>
          </CardTitle>
          <CardDescription>We couldn’t load your digest preferences.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>{state.message}</AlertDescription>
          </Alert>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => {
              setState({ status: 'loading' });
              apiFetch('/api/digest-prefs', { schema: DigestPrefs })
                .then((data) => setState({ status: 'ready', values: data, saving: false }))
                .catch((err: unknown) => {
                  const message =
                    err instanceof Error ? err.message : 'Could not load digest preferences.';
                  setState({ status: 'error', message });
                });
            }}
          >
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { values, saving } = state;
  const lastSent = values.lastDigestSentAt
    ? formatTimestamp(values.lastDigestSentAt)
    : 'No digest has shipped yet';

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BellRing aria-hidden="true" className="size-4" />
          <span>Daily digest</span>
        </CardTitle>
        <CardDescription>
          A short morning summary of yesterday’s patch activity — per-repo tallies of patches
          auto-merged, CVE responses opened, and human pages or overrides, with a deep link into the
          day’s attestation records. Sent at 08:00&nbsp;UTC each morning.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div
          className={cn(
            'flex items-center justify-between gap-4 rounded-lg border border-border/70 bg-muted/30 px-4 py-3',
            saving && 'opacity-80',
          )}
        >
          <div className="flex flex-col gap-1">
            <span className="text-sm font-medium text-foreground">Email me the daily digest</span>
            <span className="text-xs text-muted-foreground">
              We’ll only send it on days when something happened on the repos you’ve connected.
            </span>
          </div>
          <div className="flex items-center gap-2">
            {saving ? (
              <Loader2 aria-hidden="true" className="size-4 animate-spin text-muted-foreground" />
            ) : null}
            <Switch
              checked={values.digestOptIn}
              onCheckedChange={toggle}
              disabled={saving}
              aria-label="Email me the daily digest"
            />
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 rounded-lg border border-dashed border-border/70 px-4 py-3 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <ShieldCheck aria-hidden="true" className="size-4" />
            <span>Last digest sent</span>
          </div>
          <span className="font-medium text-foreground">{lastSent}</span>
        </div>

        <p className="text-xs text-muted-foreground">
          You can change this any time — flipping the toggle saves instantly. Each digest is a
          single email to your account inbox and never includes credentials.
        </p>
      </CardContent>
    </Card>
  );
}
