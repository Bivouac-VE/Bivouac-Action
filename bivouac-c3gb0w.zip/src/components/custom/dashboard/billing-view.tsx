// @polsia:user-owned — client island for /dashboard/billing.
//
// Renders the same billing-state contract as /settings/billing but lives
// inside the workspace dashboard (admin-gated via DashboardShell). The data
// plane is the existing /api/billing/{state,invoices,portal,portal-session,
// checkout} routes; this island does no server-only imports and never reads
// Prisma. All contract drift surfaces as ZodError rather than silent wrong UI.
//
// Render states:
//   - loading    : skeleton matching /settings/billing
//   - unauthed   : 401 → router.replace('/login?next=/dashboard/billing')
//   - error      : any other /api/billing/* error — friendly retry CTA
//   - empty      : no plan yet → <TierPicker/> drives the upgrade action
//   - ready      : with-plan body split into five sections:
//       1. Current plan card (PlanSummary) — SLUG + monthlyPerRepoUsd +
//          renewal date + cancelAtPeriodEnd flag.
//       2. Manage in Stripe button — GETs /api/billing/portal-session and
//          redirects to the returned URL (or surfaces the in-app fallback
//          copy when the platform hasn't yet wired Stripe's hosted portal).
//       3. Cancel at period end action — POSTs /api/billing/portal (existing)
//          and refetches /api/billing/state to flip cancelAtPeriodEnd.
//       4. <TierPicker/> — in-page 4-card upgrade / downgrade / subscribe
//          surface, per-card action derived from the user's current slug.
//          Enterprise pivots to a `mailto:` contact (mirrors /pricing's
//          sales CTA). Click → POST /api/billing/checkout → redirect.
//       5. Last 6 invoices rendered via <InvoiceTable/> — date, description,
//          status badge, amount, optional hosted-invoice URL link.

'use client';

import { Check, CircleDot, CreditCard, ExternalLink, Loader2, Mail, Receipt } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import { PLANS } from '@/lib/business/plans';
import {
  BillingCheckoutResponse,
  type BillingCheckoutResponse as BillingCheckoutResponseT,
  BillingInvoicesResponse,
  type BillingInvoicesResponse as BillingInvoicesResponseT,
  BillingState,
  type BillingState as BillingStateT,
  PortalSessionResponse,
  type PortalSessionResponse as PortalSessionResponseT,
  PortalSyncResponse,
  type PortalSyncResponse as PortalSyncResponseT,
} from '@/lib/contracts/billing';
import type { PricingPlan, PricingPlanSlug } from '@/lib/contracts/pricing';
import { cn } from '@/lib/utils';

const ENTERPRISE_CONTACT_EMAIL = 'bivouac-c3gb0w@polsia.app';

// Per-tier rank — used to derive the upgrade vs downgrade action label.
const TIER_RANK: Record<PricingPlanSlug, number> = {
  free: 0,
  starter: 1,
  team: 2,
  enterprise: 3,
};

type TierAction =
  | { kind: 'current' }
  | { kind: 'subscribe' }
  | { kind: 'upgrade' }
  | { kind: 'downgrade' }
  | { kind: 'downgrade_free' }
  | { kind: 'contact' };

function deriveTierAction(currentSlug: PricingPlanSlug | null, plan: PricingPlan): TierAction {
  // Free from a paid plan is a cancel-at-period-end action handled via
  // /api/billing/portal — Stripe ends the subscription automatically when
  // the cycle closes, so we don't open a fresh Checkout session.
  if (plan.slug === 'free' && currentSlug !== null && currentSlug !== 'free') {
    return { kind: 'downgrade_free' };
  }
  // Otherwise Free is universally "current" — there's no Stripe subscription
  // for it and clicking it would just bounce off `/api/billing/checkout`'s
  // `invalid_plan` guard.
  if (plan.slug === 'free') return { kind: 'current' };
  if (plan.slug === 'enterprise' && currentSlug !== 'enterprise') {
    return { kind: 'contact' };
  }
  if (currentSlug === plan.slug) return { kind: 'current' };
  if (currentSlug === null || currentSlug === 'free') return { kind: 'subscribe' };
  if (TIER_RANK[plan.slug] > TIER_RANK[currentSlug]) return { kind: 'upgrade' };
  return { kind: 'downgrade' };
}

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'unauthed' }
  | { status: 'empty'; repoCount: number }
  | { status: 'ready'; state: BillingStateT };

const STRIPE_ERROR_COPY: Record<string, string> = {
  stripe_billing_not_configured:
    'Stripe billing is not configured for this app yet. Set up billing from the Polsia dashboard.',
  email_required_for_subscription_status:
    'Your account is missing an email on file — required to query Stripe.',
  Unauthorized: 'Session expired — sign in again to switch plans.',
  STRIPE_NOT_ENABLED:
    'Stripe isn’t enabled for this workspace yet. Write to bivouac-c3gb0w@polsia.app to enable it.',
  ONBOARDING_REQUIRED:
    'Stripe needs to finish onboarding before subscriptions can start. Email bivouac-c3gb0w@polsia.app to complete setup.',
  STRIPE_NOT_CONFIGURED:
    'Stripe is misconfigured for this workspace. Email bivouac-c3gb0w@polsia.app.',
  invalid_plan: 'That tier isn’t available — pick another plan or refresh the page.',
  no_active_repos:
    'Connect at least one repository to Bivouac before subscribing to a paid tier. The Free tier covers your first repo.',
  checkout_failed:
    'Could not start the Stripe checkout for that tier. Try again, or email bivouac-c3gb0w@polsia.app.',
  forbidden: 'You don’t have permission to change this workspace’s plan.',
};

function formatUsd(value: number): string {
  return `$${value}`;
}

function errorCode(err: unknown): string | null {
  if (err && typeof err === 'object' && 'cause' in err) {
    const cause = (err as { cause: unknown }).cause;
    if (cause && typeof cause === 'object' && 'error' in cause) {
      const inside = (cause as { error?: unknown }).error;
      if (typeof inside === 'string') return inside;
    }
  }
  return null;
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function BillingView() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });
  const router = useRouter();

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/billing/state', { schema: BillingState });
      setState(
        data.plan
          ? { status: 'ready', state: data }
          : { status: 'empty', repoCount: data.repoCount },
      );
    } catch (err: unknown) {
      const code = errorCode(err);
      if (code === 'Unauthorized') {
        setState({ status: 'unauthed' });
        return;
      }
      const reason = err instanceof Error ? err.message : 'Could not load billing state.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (state.status === 'unauthed') {
      router.replace('/login?next=/dashboard/billing');
    }
  }, [router, state.status]);

  if (state.status === 'loading') return <BillingSkeleton />;

  if (state.status === 'unauthed') {
    return (
      <Card className="border-border bg-card/60">
        <CardContent className="py-10 text-center">
          <p className="text-small text-muted-foreground">Redirecting to sign in…</p>
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTitle>Could not load your billing state.</AlertTitle>
        <AlertDescription>
          We could not reach the billing endpoint right now. Retry in a moment.{' '}
          <span className="text-xs text-muted-foreground">({state.message})</span>{' '}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void load()}
            className="mt-2"
          >
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <div className="flex flex-col gap-section">
        <NoPlanCallout />
        <TierPicker currentSlug={null} repoCount={state.repoCount} />
      </div>
    );
  }

  return <WithPlanPanel state={state.state} onRefresh={load} />;
}

// ----------------------------------------------------------------------------

function TierPicker({
  currentSlug,
  repoCount,
  title,
  subtitle,
  onRefresh,
}: {
  currentSlug: PricingPlanSlug | null;
  repoCount: number;
  title?: string;
  subtitle?: string;
  onRefresh?: () => Promise<void>;
}) {
  // TierPicker renders 4 PLANS cards with action buttons derived from the
  // user's current slug. Click → POST /api/billing/checkout (authed) →
  // {ok:'checkout', url} redirect via window.location.href. Enterprise from a
  // non-Enterprise tier pivots to a `mailto:` sales CTA (the public /pricing
  // CTA stays the same). Free while on a paid tier is a cancel-at-period-end
  // shortcut — POST /api/billing/portal, refetch state, toast.
  const [busySlug, setBusySlug] = useState<PricingPlanSlug | null>(null);

  const startCheckout = useCallback(
    async (slug: PricingPlanSlug) => {
      if (busySlug) return;
      setBusySlug(slug);
      try {
        const res = await apiFetch<BillingCheckoutResponseT>('/api/billing/checkout', {
          method: 'POST',
          body: JSON.stringify({ planId: slug }),
          schema: BillingCheckoutResponse,
        });
        if (res.ok === 'checkout') {
          window.location.href = res.url;
          return;
        }
        toast.error(STRIPE_ERROR_COPY[res.error] ?? `Could not start checkout for ${slug}.`);
      } catch (err: unknown) {
        const code = errorCode(err);
        toast.error(STRIPE_ERROR_COPY[code ?? ''] ?? 'Could not reach /api/billing/checkout.');
      } finally {
        setBusySlug(null);
      }
    },
    [busySlug],
  );

  const cancelToFree = useCallback(async () => {
    if (busySlug) return;
    setBusySlug('free');
    try {
      const res = await apiFetch<PortalSyncResponseT>('/api/billing/portal', {
        method: 'POST',
        schema: PortalSyncResponse,
      });
      toast.message(
        res.cancelAtPeriodEnd
          ? 'Cancellation scheduled — your plan ends at the current period close, then drops to Free.'
          : 'Stripe reports your subscription is active. Reloading…',
      );
      if (onRefresh) await onRefresh();
    } catch (err: unknown) {
      const code = errorCode(err);
      const copy = STRIPE_ERROR_COPY[code ?? ''];
      if (code === 'stripe_billing_not_configured') {
        toast.error(copy ?? STRIPE_ERROR_COPY.stripe_billing_not_configured);
      } else if (code === 'email_required_for_subscription_status') {
        toast.error('Your account is missing an email on file — required to query Stripe.');
      } else if (code === 'Unauthorized') {
        toast.error('Session expired — sign in again to manage your subscription.');
      } else {
        toast.error('Could not reach /api/billing/portal.');
      }
    } finally {
      setBusySlug(null);
    }
  }, [busySlug, onRefresh]);

  return (
    <section aria-label="Tier picker" className="flex flex-col gap-6" data-testid="tier-picker">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Pick a tier</p>
        <h2 className="font-display text-h3 text-balance text-foreground">
          {title ?? 'Switch, upgrade, or downgrade your Bivouac plan'}
        </h2>
        <p className="text-body text-muted-foreground">
          {subtitle ??
            'Pricing is computed by Stripe, never the browser — your current tier is highlighted, and each tier opens a hosted Stripe checkout to switch.'}{' '}
          {repoCount > 0 ? (
            <span className="text-small">
              You currently have {repoCount} active {repoCount === 1 ? 'repo' : 'repos'} connected.
            </span>
          ) : null}
        </p>
      </header>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 md:items-stretch">
        {PLANS.map((plan) => {
          const action = deriveTierAction(currentSlug, plan);
          const isContact = action.kind === 'contact';
          const isBusy = busySlug === plan.slug;
          const isCurrentCurrent = plan.slug === currentSlug;

          const buttonProps = (() => {
            if (action.kind === 'current') {
              return {
                label: isCurrentCurrent ? 'Current plan' : 'Free tier',
                variant: 'outline' as const,
                disabled: true,
              };
            }
            if (action.kind === 'contact') {
              return {
                label: 'Talk to sales',
                variant: 'outline' as const,
                disabled: false,
              };
            }
            if (action.kind === 'subscribe') {
              return {
                label: `Subscribe to ${plan.name}`,
                variant: 'default' as const,
                disabled: false,
              };
            }
            if (action.kind === 'upgrade') {
              return {
                label: `Upgrade to ${plan.name}`,
                variant: 'default' as const,
                disabled: false,
              };
            }
            if (action.kind === 'downgrade_free') {
              return {
                label: `Switch to ${plan.name} (cancel-at-period-end)`,
                variant: 'outline' as const,
                disabled: false,
              };
            }
            return {
              label: `Downgrade to ${plan.name}`,
              variant: 'outline' as const,
              disabled: false,
            };
          })();

          const buttonBody =
            isBusy && action.kind === 'downgrade_free' ? (
              <>
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Scheduling cancellation…
              </>
            ) : isBusy ? (
              <>
                <Loader2 className="size-4 animate-spin" aria-hidden />
                Starting checkout…
              </>
            ) : isContact ? (
              <>
                <Mail className="size-4" aria-hidden />
                {buttonProps.label}
              </>
            ) : (
              buttonProps.label
            );

          const isHighlight = isCurrentCurrent;
          const cardClasses = cn(
            'relative flex h-full flex-col gap-3 border-border bg-card/80 p-5 lift',
            isHighlight && 'border-brand-500/60 ring-1 ring-brand-500/40',
          );

          return (
            <Card key={plan.slug} className={cardClasses}>
              <div aria-hidden className="absolute inset-x-0 top-0 h-1 overflow-hidden">
                <div
                  className={cn('h-full w-full', isHighlight ? 'bg-brand-500/80' : 'bg-border')}
                />
              </div>
              <CardHeader className="gap-2 p-0">
                <p className="text-eyebrow text-muted-foreground">{plan.eyebrow}</p>
                <CardTitle
                  className={cn(
                    'font-display text-h3',
                    isHighlight ? 'text-brand-700 dark:text-brand-300' : 'text-foreground',
                  )}
                >
                  {plan.name}
                </CardTitle>
                <CardDescription className="text-small text-muted-foreground">
                  {plan.monthlyPerRepoUsd === 0
                    ? `${plan.includedActiveRepos} active repo · no card required`
                    : `${formatUsd(plan.monthlyPerRepoUsd)} / active repo / month`}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col gap-3 p-0">
                <ul className="flex flex-1 flex-col gap-2">
                  {plan.features.slice(0, 3).map((f) => (
                    <li key={f.label} className="flex items-start gap-2 text-small text-foreground">
                      <Check
                        className="mt-0.5 size-3.5 shrink-0 text-brand-700 dark:text-brand-300"
                        aria-hidden
                      />
                      <span>{f.label}</span>
                    </li>
                  ))}
                </ul>
                {action.kind === 'contact' ? (
                  <Button
                    type="button"
                    variant={buttonProps.variant}
                    className="w-full gap-2"
                    disabled={buttonProps.disabled}
                    onClick={() => {
                      window.location.href = `mailto:${ENTERPRISE_CONTACT_EMAIL}?subject=${encodeURIComponent(
                        'Enterprise Bivouac tier request',
                      )}`;
                    }}
                  >
                    {buttonBody}
                  </Button>
                ) : action.kind === 'current' ? (
                  <Button
                    type="button"
                    variant={buttonProps.variant}
                    className="w-full gap-2"
                    disabled
                  >
                    <Check className="size-4" aria-hidden />
                    {buttonProps.label}
                  </Button>
                ) : action.kind === 'downgrade_free' ? (
                  <Button
                    type="button"
                    variant={buttonProps.variant}
                    className="w-full gap-2"
                    disabled={buttonProps.disabled || isBusy}
                    onClick={() => void cancelToFree()}
                  >
                    {buttonBody}
                  </Button>
                ) : (
                  <Button
                    type="button"
                    variant={buttonProps.variant}
                    className="w-full gap-2"
                    disabled={buttonProps.disabled || isBusy}
                    onClick={() => void startCheckout(plan.slug)}
                  >
                    {buttonBody}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------

function BillingSkeleton() {
  return (
    <section aria-label="Loading billing state" className="flex flex-col gap-4">
      <Skeleton className="h-10 w-60" />
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-24 w-full rounded-xl" />
    </section>
  );
}

function NoPlanCallout() {
  return (
    <section
      aria-label="Pick a plan"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-card via-muted/40 to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[360px] text-brand-500/15 md:-right-32"
      >
        <svg
          viewBox="0 0 360 360"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative plan card</title>
          <circle cx="180" cy="180" r="160" strokeWidth="1" />
          <circle cx="180" cy="180" r="110" strokeWidth="1" />
          <circle cx="180" cy="180" r="60" strokeWidth="1.5" />
          <path d="M 180 20 L 180 340" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="relative flex flex-col items-start gap-6 p-8 md:p-12">
        <p className="text-eyebrow">No plan yet</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          Pick a Bivouac tier to put the workspace on duty.
        </h2>
        <p className="max-w-xl text-body text-muted-foreground">
          Plans are billed monthly per active repository. Once a plan is in place this surface shows
          the renewal date, the cancel-at-period-end action, and the last invoices pulled from
          Stripe. Free covers your first repo without a card.
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <Button asChild variant="ghost" size="sm" className="gap-2">
            <Link href="/pricing">Open full plan page →</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------

function WithPlanPanel({
  state,
  onRefresh,
}: {
  state: BillingStateT;
  onRefresh: () => Promise<void>;
}) {
  // Hooks at the top — the early-return guard below MUST stay AFTER the last
  // hook call so React doesn't trip "hooks called conditionally".
  const [portalBusy, setPortalBusy] = useState(false);
  const [cancelBusy, setCancelBusy] = useState(false);
  const [invoices, setInvoices] = useState<
    | { status: 'loading' }
    | { status: 'ready'; invoices: BillingInvoicesResponseT['invoices'] }
    | { status: 'unavailable' }
  >({ status: 'loading' });

  const plan = state.plan;
  const planRecord = useMemo(
    () => (plan ? PLANS.find((p) => p.slug === plan.slug) : undefined),
    [plan],
  );

  const loadInvoices = useCallback(async () => {
    setInvoices({ status: 'loading' });
    try {
      const res = await apiFetch<BillingInvoicesResponseT>('/api/billing/invoices', {
        schema: BillingInvoicesResponse,
      });
      setInvoices({ status: 'ready', invoices: res.invoices });
    } catch {
      setInvoices({ status: 'unavailable' });
    }
  }, []);

  useEffect(() => {
    void loadInvoices();
  }, [loadInvoices]);

  const openPortal = useCallback(async () => {
    if (portalBusy) return;
    setPortalBusy(true);
    try {
      const res = await apiFetch<PortalSessionResponseT>('/api/billing/portal-session', {
        schema: PortalSessionResponse,
      });
      if (res.available) {
        window.location.href = res.url;
        return;
      }
      toast.message(
        'Stripe customer portal is not wired yet. Use the cancel-at-period-end action below, or pick the Starter tier on /settings/billing to step down via Checkout.',
      );
    } catch (err: unknown) {
      const code = errorCode(err);
      toast.error(STRIPE_ERROR_COPY[code ?? ''] ?? 'Could not reach /api/billing/portal-session.');
    } finally {
      setPortalBusy(false);
    }
  }, [portalBusy]);

  const cancelAtPeriodEnd = useCallback(async () => {
    if (cancelBusy) return;
    setCancelBusy(true);
    try {
      const res = await apiFetch<PortalSyncResponseT>('/api/billing/portal', {
        method: 'POST',
        schema: PortalSyncResponse,
      });
      toast.message(
        res.cancelAtPeriodEnd
          ? 'Cancellation scheduled — your plan ends at the current period close.'
          : 'Stripe reports your subscription is active. Reloading…',
      );
      await onRefresh();
      void loadInvoices();
    } catch (err: unknown) {
      const code = errorCode(err);
      if (code === 'stripe_billing_not_configured') {
        toast.error(STRIPE_ERROR_COPY[code]);
      } else if (code === 'email_required_for_subscription_status') {
        toast.error(STRIPE_ERROR_COPY[code]);
      } else if (code === 'Unauthorized') {
        toast.error('Session expired — sign in again to manage your subscription.');
      } else {
        toast.error('Could not reach /api/billing/portal.');
      }
    } finally {
      setCancelBusy(false);
    }
  }, [cancelBusy, onRefresh, loadInvoices]);

  if (!plan) return <NoPlanCallout />;

  const repoLimit = plan.repoLimit;
  const limitLabel = repoLimit === null ? 'Unlimited' : `${repoLimit}`;
  const overLimit = repoLimit !== null && state.repoCount > repoLimit;
  const monthlyTotal = plan.monthlyPerRepoUsd + state.addons.reduce((s, a) => s + a.monthlyUsd, 0);

  return (
    <section aria-label="Billing" className="flex flex-col gap-section">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Subscription</p>
        <h1 className="font-display text-h2 text-balance text-foreground">Your Bivouac plan</h1>
        <p className="text-body-lg text-muted-foreground">
          Renews at the current period close. Open cancellation and the Stripe customer portal live
          below.
        </p>
      </header>

      {/* ---------- Current plan card ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-3">
          <div className="grid min-w-0 gap-1">
            <p className="text-eyebrow">Current tier</p>
            <CardTitle className="font-display text-h3 text-foreground">
              {planRecord?.name ?? plan.slug}
            </CardTitle>
            <CardDescription className="text-small text-muted-foreground">
              {planRecord?.eyebrow ??
                `${formatUsd(plan.monthlyPerRepoUsd)} per active repo, monthly`}
            </CardDescription>
          </div>
          <PlanStatusBadge status={plan.status} />
        </CardHeader>
        <CardContent className="flex flex-col gap-6 px-5 pb-5 pt-0 text-small text-muted-foreground">
          <dl className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Stat
              label="Active repos"
              value={String(state.repoCount)}
              right={repoLimit === null ? 'unlimited' : `of ${limitLabel}`}
              tone={overLimit ? 'warn' : undefined}
            />
            <Stat
              label="Per-repo price"
              value={formatUsd(plan.monthlyPerRepoUsd)}
              right="/ active repo / month"
            />
            <Stat
              label="Total monthly"
              value={formatUsd(monthlyTotal)}
              right={state.addons.length > 0 ? `+ ${state.addons.length} add-on(s)` : 'base plan'}
            />
          </dl>

          {state.addons.length > 0 ? (
            <div className="flex flex-col gap-2">
              <p className="text-eyebrow">SLA add-ons</p>
              <div className="flex flex-wrap gap-2">
                {state.addons.map((addon) => (
                  <Badge
                    key={addon.id}
                    variant="outline"
                    className="border-brand-500/40 bg-card text-foreground"
                  >
                    {addon.label} · {formatUsd(addon.monthlyUsd)}/mo
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}

          <div className="flex flex-col gap-2 border-t border-border pt-4 text-small text-muted-foreground">
            {plan.currentPeriodEnd ? (
              <p className="flex items-center gap-2">
                <CircleDot className="size-3.5 shrink-0 text-foreground/70" aria-hidden />
                Current period renews{' '}
                <time dateTime={plan.currentPeriodEnd} className="font-medium text-foreground">
                  {formatDate(plan.currentPeriodEnd)}
                </time>
              </p>
            ) : (
              <p>Awaiting confirmation from Stripe.</p>
            )}
            {plan.paidRepoCount !== null && plan.paidRepoCount !== undefined ? (
              <p>
                Billed for {plan.paidRepoCount} active {plan.paidRepoCount === 1 ? 'repo' : 'repos'}{' '}
                at last checkout. New repos joined after that bill on the next renewal.
              </p>
            ) : null}
            {plan.cancelAtPeriodEnd ? (
              <p className="text-amber-600 dark:text-amber-400">
                Cancellation scheduled — your plan ends at the current period close.
              </p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* ---------- Stripe customer portal + cancel ---------- */}
      <section aria-label="Subscription management" className="flex flex-col gap-3">
        <p className="text-eyebrow">Manage subscription</p>
        <div className="flex flex-wrap items-center gap-3">
          <Button
            type="button"
            variant="default"
            onClick={() => void openPortal()}
            disabled={portalBusy || cancelBusy}
            className="gap-1.5 shadow-brand"
          >
            {portalBusy ? (
              <span className="inline-flex items-center gap-2">
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
                Opening…
              </span>
            ) : (
              <>
                <CreditCard className="size-4" aria-hidden />
                Manage subscription
              </>
            )}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => void cancelAtPeriodEnd()}
            disabled={plan.cancelAtPeriodEnd || cancelBusy || portalBusy}
            className="gap-1.5"
          >
            <Receipt className="size-4" aria-hidden />
            {plan.cancelAtPeriodEnd
              ? 'Cancellation pending'
              : cancelBusy
                ? 'Working…'
                : 'Cancel at period end'}
          </Button>
          <span className="text-small text-muted-foreground">
            The Stripe customer portal lets you swap payment method, change the renewal cycle, or
            download purchase history. Cancellations land at the next period close.
          </span>
        </div>
      </section>

      {/* ---------- Tier picker — in-page upgrade/downgrade ---------- */}
      <TierPicker
        currentSlug={plan.slug}
        repoCount={state.repoCount}
        title="Switch to a different tier"
        subtitle="Each tier opens Stripe Checkout — your current tier is highlighted. Downgrades take effect at the next period close."
        onRefresh={onRefresh}
      />

      {/* ---------- Invoice history ---------- */}
      <InvoiceTable invoices={invoices} onRetry={loadInvoices} />
    </section>
  );
}

// ----------------------------------------------------------------------------

function Stat({
  label,
  value,
  right,
  tone,
}: {
  label: string;
  value: string;
  right?: string;
  tone?: 'warn';
}) {
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border/70 bg-background/60 p-3">
      <p className="text-eyebrow">{label}</p>
      <p
        className={cn(
          'font-display text-h3 text-foreground',
          tone === 'warn' && 'text-amber-700 dark:text-amber-400',
        )}
      >
        {value}
      </p>
      {right ? <p className="text-small text-muted-foreground">{right}</p> : null}
    </div>
  );
}

function PlanStatusBadge({ status }: { status: 'ACTIVE' | 'CANCELLED' | 'PAST_DUE' }) {
  const tone = (() => {
    if (status === 'ACTIVE')
      return 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300';
    if (status === 'CANCELLED') return 'border-border bg-muted text-muted-foreground';
    return 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground';
  })();
  const label =
    status === 'PAST_DUE' ? 'Past due' : status === 'CANCELLED' ? 'Cancelled' : 'Active';
  return (
    <Badge variant="outline" className={tone}>
      {label}
    </Badge>
  );
}

// ----------------------------------------------------------------------------

function InvoiceTable({
  invoices,
  onRetry,
}: {
  invoices:
    | { status: 'loading' }
    | { status: 'ready'; invoices: BillingInvoicesResponseT['invoices'] }
    | { status: 'unavailable' };
  onRetry: () => Promise<void>;
}) {
  return (
    <section aria-label="Invoice history" className="flex flex-col gap-3">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-eyebrow">Invoice history</p>
          <p className="text-small text-muted-foreground">
            The last 6 receipts Stripe recorded for this workspace.
          </p>
        </div>
        {invoices.status === 'ready' && invoices.invoices.length > 0 ? (
          <span className="text-small text-muted-foreground">
            Last {invoices.invoices.length} payment
            {invoices.invoices.length === 1 ? '' : 's'}
          </span>
        ) : null}
      </div>

      <Card className="border-border bg-card/80 p-0">
        <CardContent className="p-0">
          {invoices.status === 'loading' ? (
            <div className="flex flex-col gap-2 p-4">
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-5 w-64" />
              <Skeleton className="h-5 w-56" />
            </div>
          ) : invoices.status === 'unavailable' ? (
            <div className="flex flex-col gap-3 p-4 text-small text-muted-foreground">
              <p>
                The invoice feed could not be reached. Retry, or write to bivouac-c3gb0w@polsia.app.
              </p>
              <div>
                <Button type="button" variant="outline" onClick={() => void onRetry()}>
                  Retry
                </Button>
              </div>
            </div>
          ) : invoices.invoices.length === 0 ? (
            <div className="p-4 text-small text-muted-foreground">
              No invoices yet — your first one lands after the first renewal.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-eyebrow text-muted-foreground">Date</TableHead>
                  <TableHead className="text-eyebrow text-muted-foreground">Description</TableHead>
                  <TableHead className="text-eyebrow text-muted-foreground">Status</TableHead>
                  <TableHead className="text-right text-eyebrow text-muted-foreground">
                    Amount
                  </TableHead>
                  <TableHead className="text-right text-eyebrow text-muted-foreground">
                    Receipt
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.invoices.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell className="text-small text-foreground">
                      {formatDate(row.occurredAt)}
                    </TableCell>
                    <TableCell className="text-small text-muted-foreground">
                      {row.description ?? (
                        <span className="text-muted-foreground/70">Subscription renewal</span>
                      )}
                    </TableCell>
                    <TableCell className="text-small text-muted-foreground">
                      <Badge
                        variant="outline"
                        className="border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
                      >
                        Paid
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right text-small font-medium text-foreground">
                      {row.amountUsd === null ? '—' : formatUsd(row.amountUsd)}
                    </TableCell>
                    <TableCell className="text-right text-small text-muted-foreground">
                      {row.hostedInvoiceUrl ? (
                        <a
                          href={row.hostedInvoiceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
                        >
                          View
                          <ExternalLink className="size-3" aria-hidden />
                        </a>
                      ) : (
                        <span
                          className="text-muted-foreground/70"
                          title={
                            row.stripeCheckoutSessionId
                              ? `Stripe session: ${row.stripeCheckoutSessionId}`
                              : 'Hosted invoice URL not yet exposed by the platform feed.'
                          }
                        >
                          —
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
