// @polsia:user-owned — client island for /dashboard/policy. Owns the form
// (scope radio + severity cutoff radio + default-action radio + auto-merge
// guardrail list editor + page-human rule builder with severity / package
// allow/deny lists / dependency depth / quick toggles + Save/Reset) and the
// /api/policy fetch / patch lifecycle. Listens for the
// `bivouac:policy-changed` window event so a save on a sibling tab refreshes
// this form too, and dispatches the same event after a successful save so the
// header <PolicyBadge/> refetches immediately.

'use client';

import {
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Loader2,
  Package,
  Plus,
  ShieldAlert,
  ShieldCheck,
  X,
} from 'lucide-react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import type { z } from 'zod';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { apiFetch } from '@/lib/api-client';
import {
  AutoMergePolicy as AutoMergePolicySchema,
  type AutoMergeScope,
  DEFAULT_ACTION_LABEL,
  type DefaultAction,
  GUARDRAIL_KIND_DESCRIPTION,
  GUARDRAIL_KIND_LABEL,
  type GuardrailKind,
  type GuardrailRule,
  SCOPE_SHORT_LABEL,
  SEVERITY_CVSS_FLOOR,
  SEVERITY_SHORT_LABEL,
  type SeverityCutoff,
} from '@/lib/contracts/auto-merge-policy';
import { RepoList } from '@/lib/contracts/repos';

type InferredPolicy = z.infer<typeof AutoMergePolicySchema>;
type InferredPolicyInput = {
  scopeMode: InferredPolicy['scopeMode'];
  minSeverity: InferredPolicy['minSeverity'];
  pageOnLicenseFlip: boolean;
  pageOnTransitiveCve: boolean;
  pageOnContestedApi: boolean;
  defaultAction: InferredPolicy['defaultAction'];
  autoMergeGuardrails: GuardrailRule[];
  packageAllowlist: string[];
  packageDenylist: string[];
  maxDependencyDepth: number;
};

type FormState =
  | {
      status: 'ready';
      current: InferredPolicy;
      draft: InferredPolicyInput;
      saving: boolean;
    }
  | { status: 'error'; message: string }
  | { status: 'loading' };

const SCOPE_OPTIONS: ReadonlyArray<{
  value: AutoMergeScope;
  description: string;
}> = [
  {
    value: 'cve-only',
    description: 'Auto-merge only when a published CVE or upstream advisory calls for it.',
  },
  {
    value: 'breaking-change-only',
    description: 'Auto-merge only when an upstream release carries a breaking semver bump.',
  },
  {
    value: 'both',
    description: 'Auto-merge on either signal — broadest autonomous coverage.',
  },
];

const SEVERITY_OPTIONS: ReadonlyArray<{ value: SeverityCutoff; description: string }> = [
  { value: 'low', description: SEVERITY_CVSS_FLOOR.low },
  { value: 'medium', description: SEVERITY_CVSS_FLOOR.medium },
  { value: 'high', description: SEVERITY_CVSS_FLOOR.high },
  { value: 'critical', description: SEVERITY_CVSS_FLOOR.critical },
];

const DEFAULT_ACTION_OPTIONS: ReadonlyArray<{
  value: DefaultAction;
  description: string;
}> = [
  {
    value: 'auto-merge',
    description: 'Merge the PR immediately once all in-scope signals pass — fastest, no human.',
  },
  {
    value: 'open-pr-wait',
    description: 'Open a draft PR and wait for approval before merging — safe middle ground.',
  },
  {
    value: 'page-human',
    description: 'Page a human on every qualifying change — minimum autonomy.',
  },
];

const GUARDRAIL_KIND_ORDER: ReadonlyArray<GuardrailKind> = [
  'tests-fail',
  'touches-path',
  'has-label',
  'free-text',
];

const PAGE_HUMAN_RULES = [
  {
    field: 'pageOnLicenseFlip' as const,
    title: 'License flips',
    description:
      'A direct or transitive upgrade changes the dep’s license. Page on-call so legal can review before merge.',
  },
  {
    field: 'pageOnTransitiveCve' as const,
    title: 'Transitive CVEs',
    description:
      'Patch the CVE even though the vulnerability sits in an indirect dependency — keep a human in the loop to spot blast-radius.',
  },
  {
    field: 'pageOnContestedApi' as const,
    title: 'Contested API surfaces',
    description:
      'The PR changes a public API used by other writing repos in your org. Coordinate before merging.',
  },
] satisfies ReadonlyArray<{
  field: keyof InferredPolicyInput;
  title: string;
  description: string;
}>;

function extractInput(policy: InferredPolicy): InferredPolicyInput {
  return {
    scopeMode: policy.scopeMode,
    minSeverity: policy.minSeverity,
    pageOnLicenseFlip: policy.pageOnLicenseFlip,
    pageOnTransitiveCve: policy.pageOnTransitiveCve,
    pageOnContestedApi: policy.pageOnContestedApi,
    defaultAction: policy.defaultAction,
    autoMergeGuardrails: policy.autoMergeGuardrails.map((row) => ({ ...row })),
    packageAllowlist: [...policy.packageAllowlist],
    packageDenylist: [...policy.packageDenylist],
    maxDependencyDepth: policy.maxDependencyDepth,
  };
}

function guardrailsEqual(a: GuardrailRule[], b: GuardrailRule[]): boolean {
  if (a.length !== b.length) return false;
  const sortedA = [...a].sort((x, y) => x.id.localeCompare(y.id));
  const sortedB = [...b].sort((x, y) => x.id.localeCompare(y.id));
  return sortedA.every((row, idx) => {
    const other = sortedB[idx];
    return (
      other !== undefined &&
      row.id === other.id &&
      row.kind === other.kind &&
      row.pattern === other.pattern
    );
  });
}

function stringListEqual(a: readonly string[], b: readonly string[]): boolean {
  if (a.length !== b.length) return false;
  const sa = [...a].sort();
  const sb = [...b].sort();
  return sa.every((v, idx) => v === sb[idx]);
}

function isDirty(current: InferredPolicy, draft: InferredPolicyInput): boolean {
  return (
    current.scopeMode !== draft.scopeMode ||
    current.minSeverity !== draft.minSeverity ||
    current.pageOnLicenseFlip !== draft.pageOnLicenseFlip ||
    current.pageOnTransitiveCve !== draft.pageOnTransitiveCve ||
    current.pageOnContestedApi !== draft.pageOnContestedApi ||
    current.defaultAction !== draft.defaultAction ||
    current.maxDependencyDepth !== draft.maxDependencyDepth ||
    !stringListEqual(current.packageAllowlist, draft.packageAllowlist) ||
    !stringListEqual(current.packageDenylist, draft.packageDenylist) ||
    !guardrailsEqual(current.autoMergeGuardrails, draft.autoMergeGuardrails)
  );
}

function makeGuardrailId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `gr-${Math.random().toString(36).slice(2, 10)}-${Date.now().toString(36)}`;
}

export function AutoMergePolicyForm() {
  const [state, setState] = useState<FormState>({ status: 'loading' });
  const [deepLinkRepo, setDeepLinkRepo] = useState<
    | { status: 'loading' }
    | { status: 'idle' }
    | { status: 'resolved'; id: string; ownerHandle: string; name: string }
    | { status: 'unknown-id'; id: string }
  >({ status: 'idle' });

  const searchParams = useSearchParams();
  const repoQueryId = searchParams.get('repo');

  // When the URL carries `?repo=<id>`, look up that repo so the banner can
  // name it (@owner/name) and so we can show a fallback link if the id
  // doesn't resolve to one of the caller's connected repos.
  useEffect(() => {
    if (!repoQueryId) {
      setDeepLinkRepo({ status: 'idle' });
      return;
    }
    let active = true;
    setDeepLinkRepo({ status: 'loading' });
    apiFetch('/api/repos', { schema: RepoList })
      .then((data) => {
        if (!active) return;
        const match = data.items.find((item) => item.id === repoQueryId);
        if (match) {
          setDeepLinkRepo({
            status: 'resolved',
            id: match.id,
            ownerHandle: match.ownerHandle,
            name: match.name,
          });
        } else {
          setDeepLinkRepo({ status: 'unknown-id', id: repoQueryId });
        }
      })
      .catch(() => {
        if (!active) return;
        setDeepLinkRepo({ status: 'unknown-id', id: repoQueryId });
      });
    return () => {
      active = false;
    };
  }, [repoQueryId]);

  const load = useCallback(async () => {
    try {
      const policy = await apiFetch('/api/policy', { schema: AutoMergePolicySchema });
      setState({
        status: 'ready',
        current: policy,
        draft: extractInput(policy),
        saving: false,
      });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not load auto-merge policy.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
    const handler = () => {
      void load();
    };
    window.addEventListener('bivouac:policy-changed', handler);
    return () => {
      window.removeEventListener('bivouac:policy-changed', handler);
    };
  }, [load]);

  if (state.status === 'loading') {
    return <AutoMergePolicyFormSkeleton />;
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load auto-merge policy.</AlertTitle>
        <AlertDescription>
          We could not reach your saved preference right now. Retry in a moment, or contact us if
          this keeps failing.{' '}
          <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
      </Alert>
    );
  }

  const { current, draft, saving } = state;

  function updateDraft<K extends keyof InferredPolicyInput>(
    key: K,
    value: InferredPolicyInput[K],
  ): void {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return { ...prev, draft: { ...prev.draft, [key]: value } };
    });
  }

  function addGuardrail(): void {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      const row: GuardrailRule = { id: makeGuardrailId(), kind: 'tests-fail', pattern: '' };
      return {
        ...prev,
        draft: {
          ...prev.draft,
          autoMergeGuardrails: [...prev.draft.autoMergeGuardrails, row],
        },
      };
    });
  }

  function removeGuardrail(id: string): void {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return {
        ...prev,
        draft: {
          ...prev.draft,
          autoMergeGuardrails: prev.draft.autoMergeGuardrails.filter((row) => row.id !== id),
        },
      };
    });
  }

  function updateGuardrail(id: string, partial: Partial<GuardrailRule>): void {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return {
        ...prev,
        draft: {
          ...prev.draft,
          autoMergeGuardrails: prev.draft.autoMergeGuardrails.map((row) =>
            row.id === id ? { ...row, ...partial } : row,
          ),
        },
      };
    });
  }

  function setPackageList(field: 'packageAllowlist' | 'packageDenylist', next: string[]): void {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return { ...prev, draft: { ...prev.draft, [field]: next } };
    });
  }

  async function handleSave(): Promise<void> {
    setState((prev) => (prev.status === 'ready' ? { ...prev, saving: true } : prev));
    try {
      const updated = await apiFetch('/api/policy', {
        method: 'PATCH',
        schema: AutoMergePolicySchema,
        body: JSON.stringify(draft),
      });
      setState({
        status: 'ready',
        current: updated,
        draft: extractInput(updated),
        saving: false,
      });
      window.dispatchEvent(new CustomEvent('bivouac:policy-changed'));
      toast.success('Auto-merge policy saved.', {
        description: `${SCOPE_SHORT_LABEL[updated.scopeMode]} · ${SEVERITY_SHORT_LABEL[updated.minSeverity]}+ · ${DEFAULT_ACTION_LABEL[updated.defaultAction]}`,
      });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not save policy.';
      setState((prev) => (prev.status === 'ready' ? { ...prev, saving: false } : prev));
      toast.error('Could not save auto-merge policy.', { description: reason });
    }
  }

  function handleReset(): void {
    setState((prev) =>
      prev.status === 'ready' ? { ...prev, draft: extractInput(prev.current) } : prev,
    );
  }

  const dirty = isDirty(current, draft);

  return (
    <div className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Auto-merge policy</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Tune how aggressively Bivouac merges on your behalf.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Bivouac opens draft pull requests for two kinds of upstream signal: published CVEs and
          breaking semver bumps. Pick which signals drive autonomous merges, set the severity floor
          for CVE-driven merges, and choose which edge cases always page a human.
        </p>
        <div className="mt-2 flex flex-wrap items-center gap-3 text-small text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <CheckPipIcon dirty={dirty} />
            {dirty ? 'Unsaved changes' : 'Up to date'}
          </span>
          <span aria-hidden className="h-3 w-px bg-border" />
          <span>
            Last saved{' '}
            <time dateTime={current.updatedAt} className="text-foreground">
              {formatUpdated(current.updatedAt)}
            </time>
          </span>
        </div>
      </header>

      <DeepLinkBanner state={deepLinkRepo} />

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-1.5">
          <CardTitle className="text-h4">Trigger scope</CardTitle>
          <CardDescription>
            Which upstream signals should an autonomous merge ride on?
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={draft.scopeMode}
            onValueChange={(value) => updateDraft('scopeMode', value as AutoMergeScope)}
            className="grid gap-2"
            aria-label="Trigger scope"
          >
            {SCOPE_OPTIONS.map((opt) => (
              <Label
                key={opt.value}
                htmlFor={`scope-${opt.value}`}
                className="flex cursor-pointer items-start gap-3 rounded-md border border-border/70 p-3 transition-colors hover:border-brand-500/60 hover:bg-secondary/40 has-[[data-state=checked]]:border-brand-500 has-[[data-state=checked]]:bg-brand-50/60 has-[[data-state=checked]]:ring-1 has-[[data-state=checked]]:ring-brand-500/40 dark:has-[[data-state=checked]]:bg-brand-900/20"
              >
                <RadioGroupItem id={`scope-${opt.value}`} value={opt.value} className="mt-0.5" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm font-medium text-foreground">
                    {SCOPE_SHORT_LABEL[opt.value]}
                  </span>
                  <span className="text-small text-muted-foreground">{opt.description}</span>
                </div>
              </Label>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-1.5">
          <CardTitle className="text-h4">Default action</CardTitle>
          <CardDescription>
            What Bivouac does once a change passes scope and clear of every guardrail below.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={draft.defaultAction}
            onValueChange={(value) => updateDraft('defaultAction', value as DefaultAction)}
            className="grid gap-2"
            aria-label="Default action"
          >
            {DEFAULT_ACTION_OPTIONS.map((opt) => (
              <Label
                key={opt.value}
                htmlFor={`action-${opt.value}`}
                className="flex cursor-pointer items-start gap-3 rounded-md border border-border/70 p-3 transition-colors hover:border-brand-500/60 hover:bg-secondary/40 has-[[data-state=checked]]:border-brand-500 has-[[data-state=checked]]:bg-brand-50/60 has-[[data-state=checked]]:ring-1 has-[[data-state=checked]]:ring-brand-500/40 dark:has-[[data-state=checked]]:bg-brand-900/20"
              >
                <RadioGroupItem id={`action-${opt.value}`} value={opt.value} className="mt-0.5" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm font-medium text-foreground">
                    {DEFAULT_ACTION_LABEL[opt.value]}
                  </span>
                  <span className="text-small text-muted-foreground">{opt.description}</span>
                </div>
              </Label>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-1.5">
          <CardTitle className="text-h4">Auto-merge guardrails</CardTitle>
          <CardDescription>
            Hard rules that block auto-merge and force a human review even when scope and severity
            both clear. Add as many as you need.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="flex flex-col gap-3">
            {draft.autoMergeGuardrails.length === 0 ? (
              <li className="rounded-md border border-dashed border-border/70 bg-secondary/20 px-3 py-4 text-small text-muted-foreground">
                No guardrails yet. Add one below to start enforcing limits on autonomous merges.
              </li>
            ) : (
              draft.autoMergeGuardrails.map((row) => (
                <li key={row.id}>
                  <GuardrailRow
                    row={row}
                    onChange={(partial) => updateGuardrail(row.id, partial)}
                    onRemove={() => removeGuardrail(row.id)}
                    idPrefix={`gr-${row.id}`}
                  />
                </li>
              ))
            )}
          </ul>
          <div className="mt-4 flex justify-end">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addGuardrail}
              className="gap-1.5"
            >
              <Plus className="size-3.5" aria-hidden /> Add guardrail
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-1.5">
          <CardTitle className="text-h4">Page a human when&hellip;</CardTitle>
          <CardDescription>
            Edge cases Bivouac should escalate instead of merging silently — extends the default
            action with a richer rule builder.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-6">
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1">
              <Label className="text-sm font-medium text-foreground">Severity floor</Label>
              <p className="text-small text-muted-foreground">
                For CVE-driven merges only, treat findings below this CVSS as informational.
              </p>
            </div>
            <RadioGroup
              value={draft.minSeverity}
              onValueChange={(value) => updateDraft('minSeverity', value as SeverityCutoff)}
              className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4"
              aria-label="Minimum severity"
            >
              {SEVERITY_OPTIONS.map((opt) => (
                <Label
                  key={opt.value}
                  htmlFor={`severity-${opt.value}`}
                  className="flex cursor-pointer items-start gap-3 rounded-md border border-border/70 p-3 transition-colors hover:border-brand-500/60 hover:bg-secondary/40 has-[[data-state=checked]]:border-brand-500 has-[[data-state=checked]]:bg-brand-50/60 has-[[data-state=checked]]:ring-1 has-[[data-state=checked]]:ring-brand-500/40 dark:has-[[data-state=checked]]:bg-brand-900/20"
                >
                  <RadioGroupItem
                    id={`severity-${opt.value}`}
                    value={opt.value}
                    className="mt-0.5"
                  />
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-medium text-foreground">
                      {SEVERITY_SHORT_LABEL[opt.value]}
                    </span>
                    <span className="font-mono text-caption text-muted-foreground">
                      {opt.description}
                    </span>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </div>

          <Separator />

          <PackageChipField
            id="package-allow"
            label="Package allowlist"
            help="Only changes touching these packages are eligible for auto-merge. Leave empty to allow all."
            fieldKey="packageAllowlist"
            value={draft.packageAllowlist}
            onChange={(next) => setPackageList('packageAllowlist', next)}
          />

          <PackageChipField
            id="package-deny"
            label="Package denylist"
            help="Changes touching any of these packages always page a human, regardless of severity or scope."
            fieldKey="packageDenylist"
            value={draft.packageDenylist}
            onChange={(next) => setPackageList('packageDenylist', next)}
          />

          <Separator />

          <div className="flex flex-col gap-2">
            <Label htmlFor="max-dep-depth" className="text-sm font-medium text-foreground">
              Max dependency depth
            </Label>
            <p className="text-small text-muted-foreground">
              Auto-merge only when the changed package is within this many hops from your direct
              dependencies. Use 0 for no limit.
            </p>
            <div className="flex items-center gap-3">
              <Input
                id="max-dep-depth"
                type="number"
                inputMode="numeric"
                min={0}
                max={20}
                step={1}
                value={draft.maxDependencyDepth}
                onChange={(event) => {
                  const parsed = Number.parseInt(event.currentTarget.value, 10);
                  const safe = Number.isFinite(parsed) ? Math.max(0, Math.min(20, parsed)) : 0;
                  updateDraft('maxDependencyDepth', safe);
                }}
                className="max-w-[7rem]"
                aria-describedby="max-dep-depth-help"
              />
              <span id="max-dep-depth-help" className="text-small text-muted-foreground">
                {draft.maxDependencyDepth === 0
                  ? '0 = unlimited'
                  : `within ${draft.maxDependencyDepth} hop${draft.maxDependencyDepth === 1 ? '' : 's'}`}
              </span>
            </div>
          </div>

          <Separator />

          <div className="flex flex-col gap-1">
            <Label className="text-sm font-medium text-foreground">Quick toggles</Label>
            <p className="text-small text-muted-foreground">
              One-click shorthands for the most common page-a-human cases. They stay on even when
              the rest of your policy is permissive.
            </p>
          </div>
          <ul className="flex flex-col">
            {PAGE_HUMAN_RULES.map((rule, idx) => {
              const id = `page-${rule.field}`;
              const checked = draft[rule.field];
              return (
                <li key={rule.field}>
                  <div className="flex items-start gap-4 py-4">
                    <div className="flex flex-1 flex-col gap-1">
                      <Label htmlFor={id} className="cursor-pointer text-sm font-medium">
                        {rule.title}
                      </Label>
                      <p className="text-small text-muted-foreground">{rule.description}</p>
                    </div>
                    <Switch
                      id={id}
                      checked={checked}
                      onCheckedChange={(value) => updateDraft(rule.field, value)}
                      aria-label={`Page a human on ${rule.title.toLowerCase()}`}
                    />
                  </div>
                  {idx < PAGE_HUMAN_RULES.length - 1 ? <Separator /> : null}
                </li>
              );
            })}
          </ul>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center justify-end gap-3 border-t border-border pt-6">
        <Button type="button" variant="outline" onClick={handleReset} disabled={!dirty || saving}>
          Reset
        </Button>
        <Button
          type="button"
          onClick={handleSave}
          disabled={!dirty || saving}
          className="gap-2 shadow-brand"
        >
          {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : null}
          {saving ? 'Saving…' : 'Save policy'}
        </Button>
      </div>

      <div className="rounded-lg border border-border/70 bg-secondary/30 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 flex-col gap-1">
            <p className="text-sm font-medium text-foreground">Start from a policy pack instead</p>
            <p className="text-small text-muted-foreground">
              Apply a multi-repo starter template — Monorepo or Microservices fleet — in one click.
            </p>
          </div>
          <Button asChild variant="outline" size="sm" className="gap-1.5">
            <Link href="/dashboard/policy/packs">
              Open starter packs
              <ArrowUpRight aria-hidden className="size-3.5" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}

function GuardrailRow({
  row,
  idPrefix,
  onChange,
  onRemove,
}: {
  row: GuardrailRule;
  idPrefix: string;
  onChange: (partial: Partial<GuardrailRule>) => void;
  onRemove: () => void;
}) {
  const patternRequired = row.kind === 'touches-path' || row.kind === 'has-label';
  const placeholder =
    row.kind === 'touches-path'
      ? '/auth/**, **/payments.ts'
      : row.kind === 'has-label'
        ? 'needs-review, security'
        : row.kind === 'free-text'
          ? 'Skip on Fridays'
          : 'No pattern required';

  return (
    <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-card/40 p-3">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-[12rem_1fr_auto] md:items-start">
        <div className="flex flex-col gap-1">
          <Label
            htmlFor={`${idPrefix}-kind`}
            className="text-xs uppercase tracking-wide text-muted-foreground"
          >
            Kind
          </Label>
          <Select
            value={row.kind}
            onValueChange={(value) => onChange({ kind: value as GuardrailKind, pattern: '' })}
          >
            <SelectTrigger id={`${idPrefix}-kind`} className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {GUARDRAIL_KIND_ORDER.map((kind) => (
                <SelectItem key={kind} value={kind}>
                  {GUARDRAIL_KIND_LABEL[kind]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-1">
          <Label
            htmlFor={`${idPrefix}-pattern`}
            className="text-xs uppercase tracking-wide text-muted-foreground"
          >
            {patternRequired ? 'Pattern' : 'Pattern (optional)'}
          </Label>
          <Input
            id={`${idPrefix}-pattern`}
            value={row.pattern ?? ''}
            placeholder={placeholder}
            onChange={(event) => onChange({ pattern: event.currentTarget.value })}
            disabled={row.kind === 'tests-fail'}
            aria-invalid={patternRequired && row.pattern.trim().length === 0}
          />
        </div>
        <div className="flex items-end md:justify-end">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onRemove}
            aria-label="Remove guardrail"
            className="text-muted-foreground hover:text-destructive"
          >
            <X className="size-4" aria-hidden />
          </Button>
        </div>
      </div>
      <p className="text-caption text-muted-foreground">{GUARDRAIL_KIND_DESCRIPTION[row.kind]}</p>
    </div>
  );
}

function PackageChipField({
  id,
  label,
  help,
  fieldKey,
  value,
  onChange,
}: {
  id: string;
  label: string;
  help: string;
  fieldKey: 'packageAllowlist' | 'packageDenylist';
  value: string[];
  onChange: (next: string[]) => void;
}) {
  const [draft, setDraft] = useState('');

  const sortedValue = useMemo(() => [...value].sort((a, b) => a.localeCompare(b)), [value]);

  function addChip() {
    const candidate = draft.trim().toLowerCase();
    if (!candidate) return;
    if (sortedValue.includes(candidate)) {
      setDraft('');
      return;
    }
    onChange([...value, candidate]);
    setDraft('');
  }

  function removeChip(name: string) {
    onChange(value.filter((entry) => entry !== name));
  }

  return (
    <div className="flex flex-col gap-2">
      <Label htmlFor={`${id}-input`} className="text-sm font-medium text-foreground">
        {label}
      </Label>
      <p className="text-small text-muted-foreground">{help}</p>
      <div className="flex flex-wrap items-center gap-2 rounded-md border border-border/70 bg-card/40 p-2">
        {sortedValue.map((name) => (
          <span
            key={`${fieldKey}-${name}`}
            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-2.5 py-1 text-caption font-medium text-foreground"
          >
            <Package className="size-3 text-brand-600 dark:text-brand-400" aria-hidden />
            {name}
            <button
              type="button"
              onClick={() => removeChip(name)}
              aria-label={`Remove ${name}`}
              className="ml-0.5 rounded-full p-0.5 text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
            >
              <X className="size-3" aria-hidden />
            </button>
          </span>
        ))}
        <Input
          id={`${id}-input`}
          value={draft}
          onChange={(event) => setDraft(event.currentTarget.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' || event.key === ',') {
              event.preventDefault();
              addChip();
            }
          }}
          onBlur={() => {
            if (draft.trim().length > 0) addChip();
          }}
          placeholder={sortedValue.length === 0 ? 'e.g. lodash' : 'Add another…'}
          className="h-7 min-w-[10rem] flex-1 border-0 bg-transparent px-2 shadow-none focus-visible:ring-0"
        />
      </div>
    </div>
  );
}

function CheckPipIcon({ dirty }: { dirty: boolean }) {
  const Icon = dirty ? ShieldAlert : ShieldCheck;
  return (
    <Icon
      aria-hidden
      className={dirty ? 'size-4 text-amber-600 dark:text-amber-400' : 'size-4 text-brand-500'}
    />
  );
}

function formatUpdated(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return 'recently';
  return date.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function DeepLinkBanner({
  state,
}: {
  state:
    | { status: 'loading' }
    | { status: 'idle' }
    | { status: 'resolved'; id: string; ownerHandle: string; name: string }
    | { status: 'unknown-id'; id: string };
}) {
  if (state.status === 'idle') return null;
  if (state.status === 'loading') return null;
  if (state.status === 'resolved') {
    const slug = `@${state.ownerHandle}/${state.name}`;
    return (
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-brand-500/40 bg-brand-50/60 px-4 py-3 text-small text-foreground dark:bg-brand-900/20">
        <div className="flex min-w-0 flex-col gap-0.5">
          <p className="font-medium">
            Editing detection settings for <span className="font-mono text-foreground">{slug}</span>
          </p>
          <p className="text-muted-foreground">
            Settings apply to all your connected repositories — this banner highlights the repo you
            arrived from.
          </p>
        </div>
        <Button asChild variant="outline" size="sm" className="gap-1.5">
          <Link href={`/dashboard/repos/${encodeURIComponent(state.id)}`}>
            Back to repo detail
            <ArrowRight className="size-3.5" aria-hidden />
          </Link>
        </Button>
      </div>
    );
  }
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-amber-500/40 bg-amber-50/60 px-4 py-3 text-small text-foreground dark:bg-amber-900/20">
      <p className="text-muted-foreground">
        The repository id in the URL doesn&apos;t match any of your connected repos. The form below
        still applies — settings are global — but you came from a stale link.
      </p>
      <Button asChild variant="outline" size="sm" className="gap-1.5">
        <Link href="/dashboard/repos">
          Resolve from repos list
          <ArrowRight className="size-3.5" aria-hidden />
        </Link>
      </Button>
    </div>
  );
}

function AutoMergePolicyFormSkeleton() {
  return (
    <output aria-busy="true" className="flex flex-col gap-section">
      <span className="sr-only">Loading auto-merge policy</span>
      <div className="flex flex-col gap-2">
        <Skeleton className="h-3 w-28" />
        <Skeleton className="h-10 w-3/4" />
        <Skeleton className="h-4 w-full max-w-2xl" />
        <Skeleton className="h-4 w-5/6 max-w-2xl" />
      </div>
      <Skeleton className="h-64 w-full rounded-xl" />
      <Skeleton className="h-56 w-full rounded-xl" />
      <Skeleton className="h-56 w-full rounded-xl" />
      <Skeleton className="h-96 w-full rounded-xl" />
    </output>
  );
}
