// @polsia:user-owned — client island for /dashboard/settings/webhooks. Owns:
//   - the /api/digest-webhook fetch (URL + enabled state, loading/error/ready)
//   - the URL <Input> + enabled <Switch> with optimistic flip + save
//   - the canary <Button> (POST /api/digest-webhook/test, toasts the result)
//   - the recent deliveries <Table> backed by /api/digest-webhook/deliveries
//   - empty / loading / error branches for both the config panel and the
//     delivery log so a slow first paint doesn't 500 the page
//
// The page itself stays a Server Component that exports `metadata`.

'use client';

import { CheckCircle2, Loader2, Send, ShieldAlert, Webhook, XCircle } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import {
  DigestDeliveryList,
  type DigestDeliveryList as DigestDeliveryListT,
  DigestWebhookConfig,
  type DigestWebhookConfig as DigestWebhookConfigT,
  DigestWebhookInput,
  DigestWebhookTestResult,
} from '@/lib/contracts/digest-webhook';
import { cn } from '@/lib/utils';

type ConfigState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | {
      status: 'ready';
      values: DigestWebhookConfigT;
      draftUrl: string;
      draftEnabled: boolean;
      saving: boolean;
      dirty: boolean;
    };

type TestState =
  | { status: 'idle' }
  | { status: 'sending' }
  | {
      status: 'sent';
      result: {
        status: 'delivered' | 'failed';
        statusCode: number | null;
        error: string | null;
        runDay: string;
      };
    };

type DeliveriesState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; items: DigestDeliveryListT['items'] };

function formatTimestamp(iso: string | null): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function isCanary(runDay: string): boolean {
  return runDay.startsWith('canary-');
}

function statusTone(status: 'delivered' | 'failed' | 'pending'): { tone: string; label: string } {
  switch (status) {
    case 'delivered':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: 'Delivered',
      };
    case 'failed':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: 'Failed',
      };
    case 'pending':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: 'Pending',
      };
  }
}

export function DigestWebhookSettings() {
  const [state, setState] = useState<ConfigState>({ status: 'loading' });
  const [test, setTest] = useState<TestState>({ status: 'idle' });
  const [deliveries, setDeliveries] = useState<DeliveriesState>({ status: 'loading' });

  const refreshDeliveries = useCallback(() => {
    setDeliveries({ status: 'loading' });
    apiFetch('/api/digest-webhook/deliveries', { schema: DigestDeliveryList })
      .then((data) => setDeliveries({ status: 'ready', items: data.items }))
      .catch((err: unknown) =>
        setDeliveries({
          status: 'error',
          message: err instanceof Error ? err.message : 'Could not load deliveries.',
        }),
      );
  }, []);

  // First-paint: fetch config + delivery log in parallel.
  useEffect(() => {
    let active = true;
    apiFetch('/api/digest-webhook', { schema: DigestWebhookConfig })
      .then((data) => {
        if (!active) return;
        setState({
          status: 'ready',
          values: data,
          draftUrl: data.url ?? '',
          draftEnabled: data.enabled,
          saving: false,
          dirty: false,
        });
      })
      .catch((err: unknown) =>
        setState({
          status: 'error',
          message: err instanceof Error ? err.message : 'Could not load webhook settings.',
        }),
      );
    apiFetch('/api/digest-webhook/deliveries', { schema: DigestDeliveryList })
      .then((data) => {
        if (!active) return;
        setDeliveries({ status: 'ready', items: data.items });
      })
      .catch((err: unknown) => {
        if (!active) return;
        setDeliveries({
          status: 'error',
          message: err instanceof Error ? err.message : 'Could not load deliveries.',
        });
      });
    return () => {
      active = false;
    };
  }, []);

  function patchDraft(next: Partial<{ url: string; enabled: boolean }>) {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      const merged = {
        draftUrl: next.url ?? prev.draftUrl,
        draftEnabled: next.enabled ?? prev.draftEnabled,
      };
      return {
        ...prev,
        draftUrl: merged.draftUrl,
        draftEnabled: merged.draftEnabled,
        dirty:
          merged.draftUrl !== (prev.values.url ?? '') ||
          merged.draftEnabled !== prev.values.enabled,
      };
    });
  }

  async function save() {
    if (state.status !== 'ready') return;
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return { ...prev, saving: true };
    });
    try {
      const updated = await apiFetch('/api/digest-webhook', {
        method: 'PUT',
        body: JSON.stringify(
          DigestWebhookInput.parse({ url: state.draftUrl, enabled: state.draftEnabled }),
        ),
        schema: DigestWebhookConfig,
      });
      setState((prev) =>
        prev.status === 'ready'
          ? {
              ...prev,
              values: updated,
              saving: false,
              dirty: false,
            }
          : prev,
      );
      toast.success('Webhook saved.');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not save your webhook.';
      setState((prev) => (prev.status === 'ready' ? { ...prev, saving: false } : prev));
      toast.error(message);
    }
  }

  async function sendTestPing() {
    if (state.status !== 'ready') return;
    setTest({ status: 'sending' });
    try {
      const result = await apiFetch('/api/digest-webhook/test', {
        method: 'POST',
        schema: DigestWebhookTestResult,
      });
      setTest({ status: 'sent', result: { ...result } });
      if (result.status === 'delivered') {
        toast.success(
          `Test ping delivered (${result.statusCode ?? '2xx'}). See the delivery log below.`,
        );
      } else {
        toast.error(`Test ping failed: ${result.error ?? 'no response'}`);
      }
      refreshDeliveries();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Test ping failed.';
      setTest({
        status: 'sent',
        result: { status: 'failed', statusCode: null, error: message, runDay: '—' },
      });
      toast.error(message);
    }
  }

  // --- LOADING BRANCH ---------------------------------------------------
  if (state.status === 'loading') {
    return (
      <div className="flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Webhook aria-hidden="true" className="size-4" />
              <span>Outbound webhook</span>
            </CardTitle>
            <CardDescription>Loading your webhook configuration…</CardDescription>
          </CardHeader>
          <CardContent>
            <Skeleton className="h-9 w-full" />
            <Skeleton className="mt-3 h-5 w-24" />
          </CardContent>
        </Card>
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  // --- ERROR BRANCH -----------------------------------------------------
  if (state.status === 'error') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Webhook aria-hidden="true" className="size-4" />
            <span>Outbound webhook</span>
          </CardTitle>
          <CardDescription>We couldn’t load your webhook configuration.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>{state.message}</AlertDescription>
          </Alert>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => {
              setState({ status: 'loading' });
              apiFetch('/api/digest-webhook', { schema: DigestWebhookConfig })
                .then((data) =>
                  setState({
                    status: 'ready',
                    values: data,
                    draftUrl: data.url ?? '',
                    draftEnabled: data.enabled,
                    saving: false,
                    dirty: false,
                  }),
                )
                .catch((err: unknown) =>
                  setState({
                    status: 'error',
                    message:
                      err instanceof Error ? err.message : 'Could not load webhook settings.',
                  }),
                );
            }}
          >
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { values, draftUrl, draftEnabled, saving, dirty } = state;
  const urlDirty = draftUrl !== (values.url ?? '');

  return (
    <div className="flex flex-col gap-section">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Webhook aria-hidden="true" className="size-4" />
            <span>Outbound webhook</span>
          </CardTitle>
          <CardDescription>
            POST the daily digest JSON to a Slack-compatible (or any HTTPS JSON) endpoint at
            08:00&nbsp;UTC. The payload mirrors the email summary — auto-merged patches, CVE
            responses opened, human overrides — with a deep link into today’s attestation records.
            Each request is signed with a per-webhook HMAC-SHA256; receivers verify the{' '}
            <code className="rounded bg-muted px-1 py-0.5 text-xs">X-Bivouac-Digest-Signature</code>{' '}
            header against your stored secret.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="digest-webhook-url">Destination URL</Label>
            <Input
              id="digest-webhook-url"
              type="url"
              inputMode="url"
              placeholder="https://hooks.example.com/services/X/Y/Z"
              value={draftUrl}
              onChange={(e) => patchDraft({ url: e.target.value })}
              aria-describedby={urlDirty ? 'digest-webhook-url-help' : undefined}
            />
            {urlDirty ? (
              <p id="digest-webhook-url-help" className="text-xs text-muted-foreground">
                Must be HTTPS, 165 chars or less, and must not resolve to a private network address
                (we re-check at fetch time too).
              </p>
            ) : null}
          </div>

          <div
            className={cn(
              'flex items-center justify-between gap-4 rounded-lg border border-border/70 bg-muted/30 px-4 py-3',
              saving && 'opacity-80',
            )}
          >
            <div className="flex flex-col gap-1">
              <span className="text-sm font-medium text-foreground">Send to webhook</span>
              <span className="text-xs text-muted-foreground">
                When enabled, the daily digest payload goes out alongside the email. Disabling stops
                deliveries without dropping your URL.
              </span>
            </div>
            <div className="flex items-center gap-2">
              {saving ? (
                <Loader2 aria-hidden="true" className="size-4 animate-spin text-muted-foreground" />
              ) : null}
              <Switch
                checked={draftEnabled}
                onCheckedChange={(checked) => patchDraft({ enabled: checked })}
                disabled={saving}
                aria-label="Send to webhook"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              size="sm"
              onClick={save}
              disabled={!dirty || saving || draftUrl.trim().length === 0}
            >
              {saving ? 'Saving…' : 'Save webhook'}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={sendTestPing}
              disabled={test.status === 'sending' || !values.url}
              title={!values.url ? 'Save a URL first' : 'Send a canary POST to your endpoint'}
            >
              {test.status === 'sending' ? (
                <>
                  <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                  <span>Sending test…</span>
                </>
              ) : (
                <>
                  <Send aria-hidden="true" className="size-4" />
                  <span>Send test ping</span>
                </>
              )}
            </Button>
            <span className="text-xs text-muted-foreground">
              Last saved {formatTimestamp(values.updatedAt)}.
            </span>
          </div>

          {test.status === 'sent' && test.result.status === 'failed' ? (
            <Alert>
              <XCircle aria-hidden="true" className="size-4" />
              <AlertTitle>Test ping failed</AlertTitle>
              <AlertDescription>
                {test.result.error ?? 'No response'} (run{' '}
                <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>)
              </AlertDescription>
            </Alert>
          ) : null}
          {test.status === 'sent' && test.result.status === 'delivered' ? (
            <Alert>
              <CheckCircle2 aria-hidden="true" className="size-4" />
              <AlertTitle>Test ping delivered</AlertTitle>
              <AlertDescription>
                Endpoint returned {test.result.statusCode ?? '2xx'}. Recorded as{' '}
                <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>.
              </AlertDescription>
            </Alert>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert aria-hidden="true" className="size-4" />
            <span>Recent deliveries</span>
          </CardTitle>
          <CardDescription>
            The most recent 20 webhook deliveries — including manual canaries. Failure rows mean the
            dispatcher retried and still didn’t get a 2xx; tomorrow’s cron starts a fresh delivery
            slot.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DeliveriesTable state={deliveries} onRefresh={refreshDeliveries} />
        </CardContent>
      </Card>
    </div>
  );
}

interface DeliveriesTableProps {
  state: DeliveriesState;
  onRefresh: () => void;
}

function DeliveriesTable({ state, onRefresh }: DeliveriesTableProps) {
  if (state.status === 'loading') {
    return (
      <div className="flex flex-col gap-2">
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-9 w-full" />
      </div>
    );
  }
  if (state.status === 'error') {
    return (
      <div className="flex flex-col gap-3">
        <Alert>
          <AlertTitle>Couldn’t load deliveries</AlertTitle>
          <AlertDescription>{state.message}</AlertDescription>
        </Alert>
        <Button type="button" variant="outline" size="sm" onClick={onRefresh}>
          Retry
        </Button>
      </div>
    );
  }
  if (state.items.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border/70 px-4 py-6 text-sm text-muted-foreground">
        No deliveries yet. Tomorrow’s 08:00&nbsp;UTC cron will write the first row here once
        enabled, or hit <em>Send test ping</em> for an immediate canary.
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Run</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="hidden text-right md:table-cell">Attempts</TableHead>
          <TableHead className="hidden md:table-cell">Endpoint</TableHead>
          <TableHead className="text-right">When</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {state.items.map((row) => {
          const tone = statusTone(row.status);
          const canary = isCanary(row.runDay);
          return (
            <TableRow key={row.id}>
              <TableCell>
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-xs text-foreground">{row.runDay}</span>
                  {row.lastError ? (
                    <span className="text-xs text-muted-foreground" title={row.lastError}>
                      {truncateForTable(row.lastError, 80)}
                    </span>
                  ) : row.lastStatusCode ? (
                    <span className="text-xs text-muted-foreground">HTTP {row.lastStatusCode}</span>
                  ) : null}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className={tone.tone} variant="outline">
                    {tone.label}
                  </Badge>
                  {canary ? (
                    <Badge variant="secondary" className="text-[10px] uppercase tracking-wide">
                      canary
                    </Badge>
                  ) : null}
                </div>
              </TableCell>
              <TableCell className="hidden text-right md:table-cell">{row.attempts}</TableCell>
              <TableCell className="hidden md:table-cell">
                <span className="font-mono text-xs text-muted-foreground">{row.urlPreview}</span>
              </TableCell>
              <TableCell className="text-right text-xs text-muted-foreground">
                {formatTimestamp(row.sentAt ?? row.createdAt)}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

function truncateForTable(value: string, max: number): string {
  if (value.length <= max) return value;
  return `${value.slice(0, max - 1)}…`;
}
