// @polsia:user-owned — dashboard first-run onboarding panel. Renders on
// /dashboard ONLY when the team has zero connected repos. A single primary
// CTA "Connect GitHub" pointing at /connect plus the reassurance line
// "Pick a repo, choose a policy, get your first patch PR." The panel hides
// the moment REPO_CONNECTED flips true (so the existing <RepoCardsGrid/>
// becomes the page focus). State mirrors the data-plane pattern from
// <RepoCardsGrid/> and <PolicyBadge/>: loading shows a low-key skeleton so
// the shell doesn't pop in late, error is fail-soft (render null — never
// block the rest of the dashboard). Listens for `bivouac:repo-policy-
// changed` so cross-tab / post-connect updates without a hard nav.
//
// Reads its single signal through apiFetch('/api/onboarding/status', {
// schema: OnboardingStatus }) — reuses the existing zod contract shared
// with the route handler, so client/server shape drift is a ZodError not
// silent JSON drift. Importing from @/lib/db here would be a biome
// noRestrictedImports failure; the panel must NOT touch the DB directly.

'use client';

import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import type { OnboardingStatus } from '@/lib/contracts/onboarding-status';
import { OnboardingStatus as OnboardingStatusSchema } from '@/lib/contracts/onboarding-status';
import { DashboardCard } from './dashboard-card';

type PanelState =
  | { kind: 'loading' }
  | { kind: 'ready'; status: OnboardingStatus }
  | { kind: 'error' };

export function ConnectFirstRepoPanel() {
  const [state, setState] = useState<PanelState>({ kind: 'loading' });

  useEffect(() => {
    let active = true;
    const refetch = () => {
      apiFetch('/api/onboarding/status', { schema: OnboardingStatusSchema })
        .then((status) => {
          if (active) setState({ kind: 'ready', status });
        })
        .catch(() => {
          if (active) setState({ kind: 'error' });
        });
    };
    refetch();
    const handler = () => refetch();
    window.addEventListener('bivouac:repo-policy-changed', handler);
    return () => {
      active = false;
      window.removeEventListener('bivouac:repo-policy-changed', handler);
    };
  }, []);

  if (state.kind === 'error') {
    return null;
  }

  if (state.kind === 'ready' && state.status.steps.REPO_CONNECTED) {
    return null;
  }

  if (state.kind === 'loading') {
    return (
      <section aria-label="Connect GitHub onboarding" className="flex flex-col gap-2">
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-80" />
      </section>
    );
  }

  return (
    <DashboardCard
      aria-label="Connect GitHub onboarding"
      title="Connect your first repository"
      description="Pick a repo, choose a policy, get your first patch PR."
      action={
        <Button asChild size="lg" className="gap-2 shadow-brand">
          <Link href="/connect">
            Connect GitHub
            <ArrowRight className="size-4" aria-hidden />
          </Link>
        </Button>
      }
    >
      <p className="text-small text-muted-foreground">The first repo is free. No card to start.</p>
    </DashboardCard>
  );
}
