// @polsia:user-owned
'use client';

import {
  BarChart3,
  BellRing,
  CreditCard,
  GitBranch,
  LayoutDashboard,
  LineChart,
  Plug,
  ScrollText,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Users,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { TeamRoleEnum } from '@/lib/contracts/team';
import { cn } from '@/lib/utils';

export interface DashboardNavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  /**
   * Visibility rule. The shell resolves `isTeamAdmin` + `teamRole` and passes
   * them through the props below; this string is matched against that pair.
   *
   *   - 'always'             : render for any signed-in user.
   *   - 'seated-any'         : render when the caller has any Membership role
   *                            (i.e. on a team-tier workspace). Falls back to
   *                            'always'-show during the initial team-state
   *                            load (the shell renders before /api/team/state
   *                            returns — exact filtering applies on the second
   *                            paint).
   *   - 'admin-only'         : render only when `isTeamAdmin === true` OR
   *                            `teamRole === 'admin'`. Owners who have NO team
   *                            role yet still see admin surfaces until they
   *                            upgrade or downgrade.
   *   - 'on-call-or-admin'   : render when teamRole is 'admin' OR 'on_call',
   *                            or `isTeamAdmin === true`. The alert feed is a
   *                            on-call-duty surface — viewers drop off.
   */
  showWhen: 'always' | 'seated-any' | 'admin-only' | 'on-call-or-admin';
}

interface NavProps {
  /** Caller's team role from /api/team/state. `null` until the first fetch. */
  teamRole: TeamRoleEnum | null;
  /** True when the caller holds the team-admin Membership role. */
  isTeamAdmin: boolean;
}

const navItems: DashboardNavItem[] = [
  {
    href: '/dashboard',
    label: 'Overview',
    icon: LayoutDashboard,
    showWhen: 'always',
  },
  {
    href: '/dashboard/repos',
    label: 'Repos',
    icon: GitBranch,
    showWhen: 'always',
  },
  {
    href: '/dashboard/policy',
    label: 'Policy',
    icon: SlidersHorizontal,
    showWhen: 'always',
  },
  {
    href: '/dashboard/audit',
    label: 'Audit',
    icon: ScrollText,
    showWhen: 'always',
  },
  {
    href: '/dashboard/attest',
    label: 'Attestation',
    icon: ShieldCheck,
    showWhen: 'always',
  },
  {
    href: '/dashboard/settings',
    label: 'Settings',
    icon: Settings,
    showWhen: 'always',
  },
  {
    href: '/dashboard/metrics',
    label: 'Metrics',
    icon: LineChart,
    showWhen: 'always',
  },
  {
    href: '/insights',
    label: 'Insights',
    icon: BarChart3,
    showWhen: 'always',
  },
  {
    href: '/dashboard/alerts',
    label: 'Alerts',
    icon: BellRing,
    // On-call surface — visible to admins and on_call members; viewers (and
    // unaffiliated callers) drop off.
    showWhen: 'on-call-or-admin',
  },
  {
    href: '/dashboard/billing',
    label: 'Billing',
    icon: CreditCard,
    showWhen: 'admin-only',
  },
  {
    href: '/settings/policy-packs',
    label: 'Policy packs',
    icon: ShieldCheck,
    showWhen: 'admin-only',
  },
  {
    href: '/dashboard/settings/integrations',
    label: 'Integrations',
    icon: Plug,
    // Admin-only — Slack/PagerDuty credentials are team-admin surfaces. Non-
    // admins hit 403 on the backing API and the island renders a
    // "Team admins only" banner rather than throwing.
    showWhen: 'admin-only',
  },
  {
    href: '/dashboard/team',
    label: 'Team',
    icon: Users,
    // Gated to admins — non-admin viewers hit /dashboard/team and see a
    // read-only banner + ask-an-admin card, but the nav itself should not
    // point them at a surface they cannot act on.
    showWhen: 'admin-only',
  },
];

function isVisible(item: DashboardNavItem, props: NavProps): boolean {
  switch (item.showWhen) {
    case 'always':
      return true;
    case 'seated-any':
      // While teamRole is still loading (null) we render — the second paint,
      // post-/api/team/state, tightens the visibility correctly.
      return props.teamRole !== null || props.isTeamAdmin;
    case 'admin-only':
      // Treat "no teamRole yet" as admin-visible for one paint so the OWNER
      // with no Membership row on first render still sees their surfaces and
      // can self-seat by visiting the team page. After the team-state fetch
      // returns, a viewer with role === 'viewer' is filtered out.
      return props.isTeamAdmin || props.teamRole === 'admin';
    case 'on-call-or-admin':
      return props.isTeamAdmin || props.teamRole === 'admin' || props.teamRole === 'on_call';
  }
}

export function DashboardNav({ teamRole, isTeamAdmin }: NavProps) {
  const pathname = usePathname();

  return (
    <nav
      aria-label="Dashboard"
      className="flex gap-2 overflow-x-auto pb-1 lg:grid lg:overflow-visible lg:pb-0"
    >
      {navItems.map((item) => {
        if (!isVisible(item, { teamRole, isTeamAdmin })) return null;
        const Icon = item.icon;
        const active =
          item.href === '/dashboard'
            ? pathname === item.href
            : pathname === item.href || pathname.startsWith(`${item.href}/`);

        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'flex h-10 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors',
              active
                ? 'bg-secondary text-secondary-foreground'
                : 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground',
            )}
          >
            <Icon aria-hidden="true" className="size-4" />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
