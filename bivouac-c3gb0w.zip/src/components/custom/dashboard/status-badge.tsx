// @polsia:user-owned — status badge for connected-repo cards. Owns the
// color/icon decision so cards never hand-color their own status indicator.

import { cva, type VariantProps } from 'class-variance-authority';
import { AlertTriangle, BellRing, GitPullRequest, ShieldCheck } from 'lucide-react';
import type { RepoStatus } from '@/lib/contracts/repos';

const statusVariants = cva(
  'inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-caption font-semibold ring-1 ring-inset',
  {
    variants: {
      status: {
        HEALTHY: 'bg-emerald-500/10 text-emerald-700 ring-emerald-500/30 dark:text-emerald-300',
        VULN_DETECTED: 'bg-amber-500/10 text-amber-700 ring-amber-500/30 dark:text-amber-300',
        PR_OPEN: 'bg-sky-500/10 text-sky-700 ring-sky-500/30 dark:text-sky-300',
        PAGED_HUMAN: 'bg-rose-500/10 text-rose-700 ring-rose-500/30 dark:text-rose-300',
      },
    },
    defaultVariants: {
      status: 'HEALTHY',
    },
  },
);

const STATUS_META: Record<
  RepoStatus,
  { label: string; Icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }> }
> = {
  HEALTHY: { label: 'Healthy', Icon: ShieldCheck },
  VULN_DETECTED: { label: 'Vuln detected', Icon: AlertTriangle },
  PR_OPEN: { label: 'PR open', Icon: GitPullRequest },
  PAGED_HUMAN: { label: 'Paged human', Icon: BellRing },
};

export interface StatusBadgeProps
  extends Omit<React.HTMLAttributes<HTMLOutputElement>, 'children'>,
    VariantProps<typeof statusVariants> {
  status: RepoStatus;
}

export function StatusBadge({ status, className, ...props }: StatusBadgeProps) {
  const { label, Icon } = STATUS_META[status];
  return (
    <output aria-label={label} className={statusVariants({ status, className })} {...props}>
      <Icon className="size-3.5" aria-hidden />
      {label}
    </output>
  );
}
