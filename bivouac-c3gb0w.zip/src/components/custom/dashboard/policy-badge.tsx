// @polsia:user-owned — small header badge mounted next to the brand link that
// reflects the caller's current auto-merge policy. Renders nothing on the
// first paint (no spinner) and on fetch error — the shell never throws.
//
// Listens for `bivouac:policy-changed` so the badge refetches immediately
// after a successful save from anywhere in the dashboard (the form island
// dispatches it).

'use client';

import { SlidersHorizontal } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { z } from 'zod';
import { Badge } from '@/components/ui/badge';
import { apiFetch } from '@/lib/api-client';
import {
  AutoMergePolicy as AutoMergePolicySchema,
  SEVERITY_SHORT_LABEL,
  type SeverityCutoff,
} from '@/lib/contracts/auto-merge-policy';

type AutoMergePolicy = z.infer<typeof AutoMergePolicySchema>;

const SEVERITY_GLYPH: Record<SeverityCutoff, string> = {
  low: '· Low+',
  medium: '· Medium+',
  high: '· High+',
  critical: '· Critical+',
};

export function PolicyBadge() {
  const [policy, setPolicy] = useState<AutoMergePolicy | null>(null);

  useEffect(() => {
    let active = true;
    const load = () => {
      apiFetch('/api/policy', { schema: AutoMergePolicySchema })
        .then((data) => {
          if (active) setPolicy(data);
        })
        .catch(() => {
          if (active) setPolicy(null);
        });
    };
    load();
    const handler = () => load();
    window.addEventListener('bivouac:policy-changed', handler);
    return () => {
      active = false;
      window.removeEventListener('bivouac:policy-changed', handler);
    };
  }, []);

  if (!policy) {
    return null;
  }

  const scopeLabel = scopeShortLabel(policy);
  const severitySuffix = SEVERITY_GLYPH[policy.minSeverity];

  return (
    <Badge
      variant="outline"
      className="hidden items-center gap-1.5 border-border/70 bg-card/60 font-medium text-foreground/80 sm:inline-flex"
      title={`Auto-merge policy: ${scopeLabel} ${SEVERITY_SHORT_LABEL[policy.minSeverity]} floor`}
    >
      <SlidersHorizontal className="size-3.5 text-brand-600 dark:text-brand-400" aria-hidden />
      <span className="font-mono text-caption tracking-normal">
        Auto-merge: {scopeLabel}
        <span className="text-muted-foreground">{severitySuffix}</span>
      </span>
    </Badge>
  );
}

function scopeShortLabel(policy: AutoMergePolicy): string {
  switch (policy.scopeMode) {
    case 'cve-only':
      return 'CVE-only';
    case 'breaking-change-only':
      return 'Breaking-change-only';
    case 'both':
      return 'CVE + breaking';
  }
}
