// @polsia:user-owned — presentational row for the /dashboard/repos listing.
// Renders one <RepoRow> as a horizontal data row that wraps on narrow
// viewports. Decorative only — all the data arrives already-derived from
// /api/dashboard/repos (installStatus, activityLabel, activityKind, patchBadge).

import { cva, type VariantProps } from 'class-variance-authority';
import {
  BellRing,
  CircleCheck,
  CircleDashed,
  CircleSlash,
  ExternalLink,
  Eye,
  GitMerge,
  GitPullRequest,
  ShieldAlert,
} from 'lucide-react';
import Link from 'next/link';
import type { PatchBadgeKind, RepoRow as RepoRowT } from '@/lib/contracts/dashboard-repos';
import { cn } from '@/lib/utils';
import { StatusBadge } from './status-badge';

const installChipVariants = cva(
  'inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-caption font-semibold ring-1 ring-inset',
  {
    variants: {
      installStatus: {
        connected: 'bg-emerald-500/10 text-emerald-700 ring-emerald-500/30 dark:text-emerald-300',
        needs_reinstall: 'bg-rose-500/10 text-rose-700 ring-rose-500/30 dark:text-rose-300',
        pending: 'bg-sky-500/10 text-sky-700 ring-sky-500/30 dark:text-sky-300',
      },
    },
    defaultVariants: { installStatus: 'connected' },
  },
);

const patchBadgeVariants = cva(
  'inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-caption font-semibold ring-1 ring-inset',
  {
    variants: {
      kind: {
        monitored: 'bg-emerald-500/10 text-emerald-700 ring-emerald-500/30 dark:text-emerald-300',
        vuln_detected: 'bg-amber-500/10 text-amber-700 ring-amber-500/30 dark:text-amber-300',
        patch_open: 'bg-sky-500/10 text-sky-700 ring-sky-500/30 dark:text-sky-300',
        patch_merged: 'bg-indigo-500/10 text-indigo-700 ring-indigo-500/30 dark:text-indigo-300',
        paged_human: 'bg-rose-500/10 text-rose-700 ring-rose-500/30 dark:text-rose-300',
      },
    },
    defaultVariants: { kind: 'monitored' },
  },
);

const INSTALL_META: Record<
  RepoRowT['installStatus'],
  {
    label: string;
    Icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }>;
  }
> = {
  connected: { label: 'Connected', Icon: CircleCheck },
  needs_reinstall: { label: 'Needs reinstall', Icon: CircleSlash },
  pending: { label: 'Pending', Icon: CircleDashed },
};

const ACT_KIND_META: Record<RepoRowT['activityKind'], string> = {
  watching: 'Watching',
  last_scan: 'Last scan',
  last_patch: 'Last patch',
  paged: 'Paged',
};

const PATCH_META: Record<
  PatchBadgeKind,
  {
    label: string;
    Icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }>;
  }
> = {
  monitored: { label: 'Monitoring', Icon: Eye },
  vuln_detected: { label: 'Vulnerability detected', Icon: ShieldAlert },
  patch_open: { label: 'Patch open', Icon: GitPullRequest },
  patch_merged: { label: 'Patch merged', Icon: GitMerge },
  paged_human: { label: 'Paged human', Icon: BellRing },
};

export interface ReposRowProps {
  row: RepoRowT;
}

function ReposRowInstallChip({
  installStatus,
  className,
}: {
  installStatus: RepoRowT['installStatus'];
  className?: string;
}) {
  const { label, Icon } = INSTALL_META[installStatus];
  return (
    <output aria-label={label} className={cn(installChipVariants({ installStatus }), className)}>
      <Icon className="size-3.5" aria-hidden />
      {label}
    </output>
  );
}

function PatchBadge({
  kind,
  label,
  at,
}: {
  kind: PatchBadgeKind;
  label: string;
  at: string | null;
}) {
  const meta = PATCH_META[kind];
  return (
    <output aria-label={meta.label} className={patchBadgeVariants({ kind })}>
      <meta.Icon className="size-3.5" aria-hidden />
      <span>{label}</span>
      {at ? (
        <time dateTime={at} className="sr-only">
          {at}
        </time>
      ) : null}
    </output>
  );
}

export function ReposRow({ row }: ReposRowProps) {
  const repoUrl = `https://github.com/${row.ownerHandle}/${row.name}`;
  const detailHref = `/dashboard/repos/${encodeURIComponent(row.id)}`;
  return (
    <article
      className={cn(
        'group relative flex flex-col gap-4 rounded-lg border border-border/70 bg-card/80 p-4 lift backdrop-blur',
        'sm:grid sm:grid-cols-[1.5fr_1fr_auto] sm:items-center sm:gap-6 sm:p-5',
      )}
      aria-label={`${row.ownerHandle}/${row.name}`}
    >
      {/* Identity column. The whole card is the affordance to open
          /dashboard/repos/[id], so the GitHub link is rendered as a sibling
          action in the badges column (right) and the @owner/name text is
          plain — no nested anchors. */}
      <div className="min-w-0">
        <p className="text-eyebrow">{row.ownerHandle}</p>
        <Link
          href={detailHref}
          className="mt-1 block truncate font-mono text-body-lg font-semibold text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <span className="sr-only">Open </span>
          {row.name}
          <span className="sr-only"> repository detail</span>
        </Link>
        <p className="mt-1 text-small text-muted-foreground">
          default branch: <span className="text-foreground">{row.defaultBranch}</span>
        </p>
      </div>

      {/* Activity column */}
      <div className="min-w-0 text-small text-muted-foreground">
        <p className="text-eyebrow text-muted-foreground/80">{ACT_KIND_META[row.activityKind]}</p>
        <p className="mt-1 text-foreground">{row.activityLabel}</p>
      </div>

      {/* Status + install chips + explicit "Open on GitHub" sibling anchor so
          the row stays reachable inside the detail page too. No nested <a>. */}
      <div className="flex flex-wrap items-center gap-2 sm:justify-end">
        <a
          href={repoUrl}
          target="_blank"
          rel="noopener noreferrer"
          title={`Open ${row.ownerHandle}/${row.name} on GitHub`}
          className="relative z-10 inline-flex items-center gap-1 text-caption font-medium text-muted-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
        >
          GitHub
          <ExternalLink className="size-3.5" aria-hidden />
        </a>
        <PatchBadge
          kind={row.patchBadge.kind}
          label={row.patchBadge.label}
          at={row.patchBadge.at}
        />
        <ReposRowInstallChip installStatus={row.installStatus} />
        <StatusBadge status={row.status} />
      </div>

      {/* The whole card is clickable through this absolutely-positioned
          overlay link; the GitHub anchor above stacks above it (z-10) so
          a click on GitHub goes to GitHub, and anywhere else opens the
          drilldown. Per the rule: no nested <a>, so we don't wrap the
          GitHub anchor inside this Link — it's a sibling. */}
      <Link
        href={detailHref}
        aria-label={`Open ${row.ownerHandle}/${row.name} detail page`}
        className="absolute inset-0 z-0 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <span className="sr-only">
          Open {row.ownerHandle}/{row.name} detail page
        </span>
      </Link>
    </article>
  );
}

export { ReposRowInstallChip };
export type ReposRowVariantProps = VariantProps<typeof installChipVariants>;
