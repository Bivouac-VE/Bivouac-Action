// @polsia:user-owned — client island for /dashboard/policy/packs. Presents two
// reusable starter templates — Monorepo (single-repo CI-matrix-strict) and
// Microservices fleet (uniform severity + paging rules) — each as a card
// listing every connected repo, flagging divergent repos before confirmation,
// and mirroring the pack's scope toggles + auto-merge guardrails + page-human
// rules to every targeted repo in one Apply click. The write goes through
// /api/repo-policies/apply; success dispatches `bivouac:repo-policy-changed`
// so dashboard cards + repos grid + the existing /settings/policy-packs page
// refetch without a manual reload.

'use client';

import {
  AlertTriangle,
  Box,
  Check,
  CircleAlert,
  CircleDot,
  GitBranch,
  Loader2,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  ApplyPolicyInput,
  ApplyPolicyResult,
  type PageHumanRule,
  type PolicyPack as PolicyPackT,
  ScopeToggles,
} from '@/lib/contracts/policy-packs';
import {
  type PackTargeting,
  type PackTargetingItem,
  PackTargetingList,
} from '@/lib/contracts/policy-packs-multi';
import { cn } from '@/lib/utils';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; packs: PackTargeting[] };

type ApplyDialogState =
  | { status: 'closed' }
  | {
      status: 'open';
      pack: PackTargeting;
      repoIds: string[];
      pending: boolean;
      error: string | null;
    };

const REPO_POLICY_EVENT = 'bivouac:repo-policy-changed';

const LOCKFILE_LABEL: Record<PolicyPackT['scopeToggles']['lockfileUpdates'], string> = {
  strict: 'Strict lockfile updates',
  'cve-only': 'CVE-only lockfile changes',
  asis: 'Lockfile as-is',
};

const DEP_SCOPE_LABEL: Record<PolicyPackT['scopeToggles']['dependencyScope'], string> = {
  all: 'All dependencies',
  direct: 'Direct only',
  'direct+transitive': 'Direct + transitive',
};

const ADVISORY_LABEL: Record<PolicyPackT['scopeToggles']['advisoryScope'], string> = {
  nvd: 'NVD',
  ghsa: 'GHSA',
  'nvd+ghsa': 'NVD + GHSA',
};

function humanRuleLabel(rule: PageHumanRule): string {
  const map: Record<PageHumanRule, string> = {
    'high-severity-cve': 'High-severity CVE',
    'license-change': 'License change',
    'public-api-break': 'Public API break',
    'security-sensitive': 'Security-sensitive',
    'red-build': 'Red build',
    'major-bump': 'Major version bump',
    'minor-bump': 'Minor version bump',
  };
  return map[rule];
}

export function PolicyPacksMultiIsland() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });
  const [apply, setApply] = useState<ApplyDialogState>({ status: 'closed' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const res = await apiFetch('/api/policy-packs/targeting', { schema: PackTargetingList });
      setState({ status: 'ready', packs: res.packs });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not load starter packs.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
    const handler = () => {
      void load();
    };
    window.addEventListener(REPO_POLICY_EVENT, handler);
    return () => {
      window.removeEventListener(REPO_POLICY_EVENT, handler);
    };
  }, [load]);

  const confirmApply = useCallback(
    async (pack: PackTargeting, repoIds: string[]) => {
      const parsed = ApplyPolicyInput.safeParse({ packSlug: pack.slug, repoIds });
      if (!parsed.success) {
        toast.error('Pick at least one repo to apply this pack.');
        return;
      }
      setApply({ status: 'open', pack, repoIds, pending: false, error: null });
      try {
        const res = await apiFetch('/api/repo-policies/apply', {
          method: 'POST',
          schema: ApplyPolicyResult,
          body: JSON.stringify(parsed.data),
        });
        const count = res.applied.length;
        toast.success(
          count === 1
            ? `${pack.title} applied to 1 repo.`
            : `${pack.title} applied to ${count} repos.`,
          {
            description:
              count === 1
                ? 'The active pack on that card has been updated.'
                : 'The active pack on every selected card has been updated.',
          },
        );
        window.dispatchEvent(new CustomEvent(REPO_POLICY_EVENT));
        setApply({ status: 'closed' });
        // Pull fresh catalog + targeting rows so divergent badges refresh.
        void load();
      } catch (err: unknown) {
        const cause = (err as { cause?: unknown } | null)?.cause;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? ((cause as { error?: unknown }).error as string | undefined)
            : undefined;
        setApply({
          status: 'open',
          pack,
          repoIds,
          pending: false,
          error: code ?? (err instanceof Error ? err.message : 'Could not apply that pack.'),
        });
      }
    },
    [load],
  );

  if (state.status === 'loading') {
    return <PolicyPacksMultiSkeleton />;
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load starter packs.</AlertTitle>
        <AlertDescription>
          We could not reach the catalog right now. Retry in a moment.{' '}
          <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
        <Button type="button" variant="outline" size="sm" onClick={load} className="mt-3 w-fit">
          Retry
        </Button>
      </Alert>
    );
  }

  return (
    <section aria-label="Multi-repo policy packs" className="flex flex-col gap-section">
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Multi-repo starter templates</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Apply a starter pack across your repos in one click.
        </h1>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Two reusable policy templates you can mirror across every connected repo at once. Pick a
          template, target the repos it should govern, and Bivouac will write the same scope,
          severity, and human-page rules onto each one.
        </p>
      </header>

      <div className="grid gap-section lg:grid-cols-2">
        {state.packs.map((pack) => (
          <PackCard
            key={pack.slug}
            pack={pack}
            onConfirm={(repoIds) => {
              // Decide confirmation UX by divergence — divergent rows show the
              // confirmation dialog; otherwise fire inline.
              if (pack.divergentCount > 0) {
                setApply({ status: 'open', pack, repoIds, pending: false, error: null });
              } else {
                void confirmApply(pack, repoIds);
              }
            }}
          />
        ))}
      </div>

      <ApplyDialog
        state={apply}
        onCancel={() => {
          if (apply.status === 'open' && apply.pending) return;
          setApply({ status: 'closed' });
        }}
        onSubmit={() => {
          if (apply.status !== 'open' || apply.pending) return;
          const { pack, repoIds } = apply;
          setApply({ status: 'open', pack, repoIds, pending: true, error: null });
          void confirmApply(pack, repoIds);
        }}
      />
    </section>
  );
}

// ----------------------------------------------------------------------------

function PolicyPacksMultiSkeleton() {
  return (
    <section aria-label="Loading starter packs" className="flex flex-col gap-section">
      <Skeleton className="h-9 w-72" />
      <Skeleton className="h-5 w-2xl max-w-2xl" />
      <div className="grid gap-section lg:grid-cols-2">
        <Skeleton className="h-96 w-full rounded-xl" />
        <Skeleton className="h-96 w-full rounded-xl" />
      </div>
    </section>
  );
}

function PackCard({
  pack,
  onConfirm,
}: {
  pack: PackTargeting;
  onConfirm: (repoIds: string[]) => void;
}) {
  const isMonorepo = pack.variant === 'monorepo';
  const variantLabel = isMonorepo ? 'Single target' : 'Fleet-wide';
  const variantAccent = isMonorepo ? 'border-brand-500/40' : 'border-violet-500/40';
  const variantIconBg = isMonorepo
    ? 'bg-brand-500/10 text-brand-700 dark:text-brand-300'
    : 'bg-violet-500/10 text-violet-700 dark:text-violet-300';

  return (
    <Card className="lift flex h-full flex-col gap-0 border-border bg-card/80 p-0">
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 p-5 pb-3">
        <div className="grid min-w-0 gap-2">
          <div className="flex items-center gap-2">
            <Box className={cn('size-4 shrink-0 rounded-md p-0.5', variantIconBg)} aria-hidden />
            <CardTitle className="font-display text-h3 tracking-tight text-foreground">
              {pack.title}
            </CardTitle>
          </div>
          <Badge variant="outline" className={cn('w-fit text-xs', variantAccent)}>
            {variantLabel}
          </Badge>
          <CardDescription className="text-small text-muted-foreground">
            {pack.description}
          </CardDescription>
        </div>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-5 px-5 pb-5 text-small text-muted-foreground">
        <PackPreview pack={pack} />

        {pack.items.length === 0 ? (
          <div className="rounded-md border border-dashed border-border/70 bg-background/60 p-4 text-small text-muted-foreground">
            No connected repos yet — connect a GitHub repo first and this card will populate.
          </div>
        ) : isMonorepo ? (
          <MonorepoPicker pack={pack} onConfirm={onConfirm} />
        ) : (
          <MicroservicesFleetPicker pack={pack} onConfirm={onConfirm} />
        )}
      </CardContent>
    </Card>
  );
}

function PackPreview({ pack }: { pack: PackTargeting }) {
  // Validate the catalog rows on the UI side too so a malformed JSON payload
  // lands as a graceful empty state instead of blowing up the page.
  const scope = ScopeToggles.safeParse(pack.scopeToggles);
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-3 gap-3">
        <PreviewItem
          label="Lockfile"
          value={scope.success ? LOCKFILE_LABEL[scope.data.lockfileUpdates] : '—'}
        />
        <PreviewItem
          label="Deps"
          value={scope.success ? DEP_SCOPE_LABEL[scope.data.dependencyScope] : '—'}
        />
        <PreviewItem
          label="Advisories"
          value={scope.success ? ADVISORY_LABEL[scope.data.advisoryScope] : '—'}
        />
      </div>
      <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-3">
        <div className="flex items-center justify-between gap-3">
          <p className="text-eyebrow">Auto-merge threshold</p>
          <Badge
            variant="outline"
            className="border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
          >
            <ShieldCheck aria-hidden className="mr-1 size-3" />
            {pack.autoMergeThreshold}
          </Badge>
        </div>
        <div className="flex flex-col gap-1">
          <p className="text-eyebrow">Page a human when</p>
          {pack.pageHumanWhen.length > 0 ? (
            <ul className="flex flex-wrap gap-1.5">
              {pack.pageHumanWhen.map((rule) => (
                <li key={rule}>
                  <Badge variant="outline" className="border-border bg-muted/40 text-foreground">
                    {humanRuleLabel(rule)}
                  </Badge>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-small text-muted-foreground">No human-paging rules configured.</p>
          )}
        </div>
      </div>
    </div>
  );
}

function PreviewItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border/70 bg-background/60 p-3">
      <p className="text-eyebrow">{label}</p>
      <p className="text-small text-foreground">{value}</p>
    </div>
  );
}

function CardWideRow({
  item,
  owner,
  label,
}: {
  item: PackTargetingItem;
  owner: 'left' | 'right';
  label: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        'flex w-full min-w-0 items-center gap-3 rounded-md border px-3 py-2 text-small',
        item.divergent
          ? 'border-amber-500/50 bg-amber-500/5 text-foreground'
          : 'border-border bg-background/60 text-foreground',
      )}
    >
      {owner === 'left' ? (
        <>
          <span className="flex min-w-0 flex-1 flex-col">
            <span className="truncate">
              <span className="font-mono text-muted-foreground">@{item.ownerHandle}</span>
              <span aria-hidden> / </span>
              <span className="font-medium">{item.repoName}</span>
            </span>
            <span className="truncate text-xs text-muted-foreground">{label}</span>
          </span>
          {item.divergent ? (
            <Badge
              variant="outline"
              className="shrink-0 border-amber-500/50 bg-amber-500/10 text-amber-700 dark:text-amber-300"
            >
              <CircleAlert aria-hidden className="mr-1 size-3" />
              Will change
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="shrink-0 border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
            >
              <Check aria-hidden className="mr-1 size-3" />
              On template
            </Badge>
          )}
        </>
      ) : (
        <>
          {item.divergent ? (
            <Badge
              variant="outline"
              className="shrink-0 border-amber-500/50 bg-amber-500/10 text-amber-700 dark:text-amber-300"
            >
              <CircleAlert aria-hidden className="mr-1 size-3" />
              Will change
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="shrink-0 border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
            >
              <Check aria-hidden className="mr-1 size-3" />
              On template
            </Badge>
          )}
          <span className="flex min-w-0 flex-1 flex-col text-right">
            <span className="truncate">
              <span className="font-mono text-muted-foreground">@{item.ownerHandle}</span>
              <span aria-hidden> / </span>
              <span className="font-medium">{item.repoName}</span>
            </span>
            <span className="truncate text-xs text-muted-foreground">{label}</span>
          </span>
        </>
      )}
    </div>
  );
}

function MonorepoPicker({
  pack,
  onConfirm,
}: {
  pack: PackTargeting;
  onConfirm: (repoIds: string[]) => void;
}) {
  const monorepoDefaultId = pack.items[0]?.repoId ?? null;
  const [selected, setSelected] = useState<string | null>(monorepoDefaultId);

  // Keep valid in the face of fresh data.
  useEffect(() => {
    if (!pack.items.some((i) => i.repoId === selected)) {
      setSelected(monorepoDefaultId);
    }
  }, [pack.items, selected, monorepoDefaultId]);

  const selectedItem = useMemo(
    () => pack.items.find((i) => i.repoId === selected) ?? null,
    [pack.items, selected],
  );

  return (
    <div className="flex flex-col gap-3 rounded-md border border-border/70 bg-background/60 p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-eyebrow">Pick the monorepo</p>
        {pack.items.length > 0 ? (
          <Badge variant="outline" className="border-border bg-muted/40 text-foreground">
            <Sparkles aria-hidden className="mr-1 size-3" />1 of {pack.items.length}
          </Badge>
        ) : null}
      </div>
      <Select value={selected ?? ''} onValueChange={setSelected}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Pick a connected repo" />
        </SelectTrigger>
        <SelectContent>
          {pack.items.map((item) => (
            <SelectItem key={item.repoId} value={item.repoId}>
              <span className="font-mono text-muted-foreground">@{item.ownerHandle}</span>
              <span aria-hidden> / </span>
              <span className="font-medium">{item.repoName}</span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Separator />
      <div className="flex flex-col gap-2">
        <p className="text-eyebrow">Current state</p>
        {selectedItem ? <CurrentStateRow item={selectedItem} /> : null}
      </div>
      <Button
        type="button"
        size="sm"
        onClick={() => {
          if (selected) onConfirm([selected]);
        }}
        disabled={!selected}
        className="mt-1 gap-1.5 shadow-brand"
      >
        <Check aria-hidden className="size-3.5" />
        Apply to this monorepo
      </Button>
    </div>
  );
}

function MicroservicesFleetPicker({
  pack,
  onConfirm,
}: {
  pack: PackTargeting;
  onConfirm: (repoIds: string[]) => void;
}) {
  const allIds = useMemo(() => pack.items.map((i) => i.repoId), [pack.items]);
  const divergeIds = useMemo(
    () => pack.items.filter((i) => i.divergent).map((i) => i.repoId),
    [pack.items],
  );
  const [excluded, setExcluded] = useState<Set<string>>(new Set());

  const visibleIds = useMemo(() => allIds.filter((id) => !excluded.has(id)), [allIds, excluded]);

  return (
    <div className="flex flex-col gap-3 rounded-md border border-border/70 bg-background/60 p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-eyebrow">
          Target fleet ({visibleIds.length} of {allIds.length})
        </p>
        <Badge
          variant="outline"
          className="border-violet-500/40 bg-violet-500/10 text-violet-700 dark:text-violet-300"
        >
          <GitBranch aria-hidden className="mr-1 size-3" />
          {pack.items.length} services
        </Badge>
      </div>
      <ul className="flex max-h-48 flex-col gap-1 overflow-y-auto">
        {pack.items.map((item) => {
          const checked = !excluded.has(item.repoId);
          const id = `fleet-${pack.slug}-${item.repoId}`;
          return (
            <li key={item.repoId}>
              <label
                htmlFor={id}
                className={cn(
                  'flex cursor-pointer items-center gap-3 rounded-md border px-3 py-2 text-small transition-colors',
                  item.divergent
                    ? 'border-amber-500/40 bg-amber-500/5'
                    : checked
                      ? 'border-brand-500/40 bg-brand-500/5'
                      : 'border-border hover:bg-muted/40',
                )}
              >
                <Checkbox
                  id={id}
                  checked={checked}
                  onCheckedChange={(value) => {
                    setExcluded((prev) => {
                      const next = new Set(prev);
                      if (value === true) {
                        next.delete(item.repoId);
                      } else {
                        next.add(item.repoId);
                      }
                      return next;
                    });
                  }}
                />
                <span className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate">
                    <span className="font-mono text-muted-foreground">@{item.ownerHandle}</span>
                    <span aria-hidden> / </span>
                    <span className="font-medium">{item.repoName}</span>
                  </span>
                  <span className="truncate text-xs text-muted-foreground">
                    Currently on: {item.currentPackTitle ?? 'default'}
                  </span>
                </span>
                {item.divergent ? (
                  <Badge
                    variant="outline"
                    className="shrink-0 border-amber-500/50 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                  >
                    <CircleAlert aria-hidden className="mr-1 size-3" />
                    Will change
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="shrink-0 border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
                  >
                    <Check aria-hidden className="mr-1 size-3" />
                    On template
                  </Badge>
                )}
              </label>
            </li>
          );
        })}
      </ul>
      <Separator />
      <div className="flex flex-col gap-1">
        <p className="text-small text-muted-foreground">
          {pack.divergentCount} of {pack.items.length} will diverge on apply. Picked 'will change'
          services inherit the template's uniform severity threshold (
          <span className="font-mono text-foreground">{pack.autoMergeThreshold}</span>) and paging
          rules.
        </p>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => setExcluded(new Set())}
          disabled={excluded.size === 0}
        >
          Select all services
        </Button>
        <Button
          type="button"
          size="sm"
          onClick={() => {
            // If any divergent rows are still in scope, force a second
            // confirmation click via the dialog; otherwise apply inline.
            const includesDivergent = divergeIds.some((id) => !excluded.has(id));
            if (includesDivergent) {
              onConfirm(visibleIds);
            } else {
              void applyWithToast(pack.slug, visibleIds);
            }
          }}
          disabled={visibleIds.length === 0}
          className="gap-1.5 shadow-brand"
        >
          <Check aria-hidden className="size-3.5" />
          Apply to {visibleIds.length} {visibleIds.length === 1 ? 'service' : 'services'}
        </Button>
      </div>
    </div>
  );

  async function applyWithToast(slug: string, repoIds: string[]) {
    const parsed = ApplyPolicyInput.safeParse({ packSlug: slug, repoIds });
    if (!parsed.success) {
      toast.error('Pick at least one service to apply this template.');
      return;
    }
    try {
      const res = await apiFetch('/api/repo-policies/apply', {
        method: 'POST',
        schema: ApplyPolicyResult,
        body: JSON.stringify(parsed.data),
      });
      toast.success(
        res.applied.length === 1
          ? `${pack.title} applied to 1 service.`
          : `${pack.title} applied to ${res.applied.length} services.`,
      );
      window.dispatchEvent(new CustomEvent(REPO_POLICY_EVENT));
      // A refetch in-place would re-mount and clobber UI state; the parent
      // island already refetches via the same event listener. We just reset
      // our local excluded set.
      setExcluded(new Set());
    } catch (err: unknown) {
      const cause = (err as { cause?: unknown } | null)?.cause;
      const code =
        cause && typeof cause === 'object' && 'error' in cause
          ? ((cause as { error?: unknown }).error as string | undefined)
          : undefined;
      toast.error('Could not apply starter pack.', {
        description: code ?? (err instanceof Error ? err.message : undefined),
      });
    }
  }
}

function CurrentStateRow({ item }: { item: PackTargetingItem }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-border bg-card/40 px-3 py-2 text-small">
      <div className="flex items-center gap-2">
        <CircleDot aria-hidden className="size-3.5 text-foreground/70" />
        <span className="truncate">
          <span className="font-mono text-muted-foreground">@{item.ownerHandle}</span>
          <span aria-hidden> / </span>
          <span className="font-medium text-foreground">{item.repoName}</span>
        </span>
      </div>
      {item.divergent ? (
        <Badge
          variant="outline"
          className="border-amber-500/50 bg-amber-500/10 text-amber-700 dark:text-amber-300"
        >
          <CircleAlert aria-hidden className="mr-1 size-3" />
          Currently: {item.currentPackTitle ?? 'default'} — will change
        </Badge>
      ) : (
        <Badge
          variant="outline"
          className="border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
        >
          <Check aria-hidden className="mr-1 size-3" />
          Already on template
        </Badge>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Confirmation Dialog (used by both variants when any targeted row diverges).

function ApplyDialog({
  state,
  onCancel,
  onSubmit,
}: {
  state: ApplyDialogState;
  onCancel: () => void;
  onSubmit: () => void;
}) {
  const open = state.status === 'open';
  const pack = state.status === 'open' ? state.pack : null;
  const repoIds = state.status === 'open' ? state.repoIds : [];
  const pending = state.status === 'open' ? state.pending : false;
  const error = state.status === 'open' ? state.error : null;
  const items = useMemo(
    () => (pack ? pack.items.filter((i) => repoIds.includes(i.repoId)) : []),
    [pack, repoIds],
  );
  const divergent = items.filter((i) => i.divergent);

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) onCancel();
      }}
    >
      <DialogContent className="max-w-xl">
        {pack ? (
          <>
            <DialogHeader>
              <DialogTitle className="font-display text-h3 text-foreground">
                Apply {pack.title}?
              </DialogTitle>
              <DialogDescription className="text-small text-muted-foreground">
                This will overwrite the active pack on{' '}
                <span className="text-foreground">{repoIds.length}</span>{' '}
                {repoIds.length === 1 ? 'repo' : 'repos'}.
                {divergent.length > 0
                  ? ` ${divergent.length} will diverge from their current pack.`
                  : ' Every selected repo is already on this pack.'}
              </DialogDescription>
            </DialogHeader>

            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-3">
                <p className="text-eyebrow">What's getting mirrored</p>
                <ul className="flex flex-col gap-1 text-small text-foreground">
                  <li>
                    Lockfile:{' '}
                    <span className="text-muted-foreground">
                      {LOCKFILE_LABEL[pack.scopeToggles.lockfileUpdates]}
                    </span>
                  </li>
                  <li>
                    Dependency scope:{' '}
                    <span className="text-muted-foreground">
                      {DEP_SCOPE_LABEL[pack.scopeToggles.dependencyScope]}
                    </span>
                  </li>
                  <li>
                    Auto-merge threshold:{' '}
                    <span className="font-mono text-muted-foreground">
                      {pack.autoMergeThreshold}
                    </span>
                  </li>
                  <li>
                    Page-a-human:{' '}
                    <span className="text-muted-foreground">
                      {pack.pageHumanWhen.length > 0
                        ? pack.pageHumanWhen.map(humanRuleLabel).join(', ')
                        : 'no rules'}
                    </span>
                  </li>
                </ul>
              </div>

              <CardWideRowLegend items={items} />
            </div>

            {error ? (
              <Alert variant="destructive" className="border-destructive/40">
                <X aria-hidden className="size-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : null}

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={onCancel}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={onSubmit}
                disabled={pending}
                className="gap-1.5 shadow-brand"
              >
                {pending ? (
                  <>
                    <Loader2 aria-hidden className="size-3.5 animate-spin" />
                    Applying…
                  </>
                ) : (
                  <>
                    <Check aria-hidden className="size-3.5" />
                    Confirm apply to {repoIds.length} {repoIds.length === 1 ? 'repo' : 'repos'}
                  </>
                )}
              </Button>
            </DialogFooter>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function CardWideRowLegend({ items }: { items: PackTargetingItem[] }) {
  return (
    <ul className="flex flex-col gap-2">
      {items.map((item) => (
        <li key={item.repoId}>
          <CardWideRow
            item={item}
            owner="right"
            label={
              item.currentPackTitle ? `currently: ${item.currentPackTitle}` : 'currently: default'
            }
          />
        </li>
      ))}
    </ul>
  );
}
