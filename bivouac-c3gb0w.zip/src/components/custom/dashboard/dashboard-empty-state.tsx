// @polsia:user-owned — empty state for the dashboard. Renders ONLY when
// /api/repos returns zero rows. Onboarding panel for a fresh workspace:
// mirrors the three-step track the landing page hero lands on (Connect
// GitHub → Pick your policy → Watch it work), with the "Free for the first
// repo. No card to start." reassurance under the primary CTA. Decorative
// radar artwork + a primary CTA pointing at /connect (same install-URL
// flow the landing Final CTA uses).

import { ArrowRight, BookOpenText } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

const STEPS: { step: string; title: string; body: string }[] = [
  {
    step: '01',
    title: 'Connect GitHub',
    body: 'Install the Bivouac GitHub App on the org or user that owns your repos.',
  },
  {
    step: '02',
    title: 'Pick your policy',
    body: 'Choose forward-fix, downgrade, or pin per repo — and the guardrails that have to trip before a human gets paged.',
  },
  {
    step: '03',
    title: 'Watch it work',
    body: 'New CVEs and upstream breaking changes land as draft PRs within minutes, tested and merged on green.',
  },
];

export function DashboardEmptyState() {
  return (
    <section
      aria-label="Connect your first repository"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-muted/60 via-background to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[420px] text-brand-500/15 md:-right-32"
      >
        <svg
          viewBox="0 0 420 420"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative watchtower radar</title>
          <circle cx="210" cy="210" r="190" strokeWidth="1" />
          <circle cx="210" cy="210" r="150" strokeWidth="1" />
          <circle cx="210" cy="210" r="110" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="70" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="32" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="5" fill="currentColor" />
          <path
            d="M 210 210 L 210 20 A 190 190 0 0 1 378 110 Z"
            fill="currentColor"
            opacity="0.08"
          />
          <path d="M 210 20 L 210 400" strokeWidth="0.5" />
          <path d="M 20 210 L 400 210" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="relative flex flex-col items-start gap-8 p-8 md:p-12">
        <p className="text-eyebrow">Connect your first repository</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          No repositories on watch yet.
        </h2>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          Three steps and a draft PR. The first repo is free — no card to start.
        </p>

        <ol className="grid w-full max-w-3xl gap-4 md:grid-cols-3">
          {STEPS.map((s) => (
            <li
              key={s.step}
              className="flex flex-col gap-2 rounded-md border border-border/70 bg-card/60 p-4"
            >
              <span className="font-mono text-caption font-bold text-brand-700 dark:text-brand-300">
                {s.step}
              </span>
              <h3 className="font-display text-h4 text-foreground">{s.title}</h3>
              <p className="text-small text-muted-foreground">{s.body}</p>
            </li>
          ))}
        </ol>

        <div className="flex flex-col items-start gap-1">
          <div className="flex flex-wrap items-center gap-3">
            <Button asChild size="lg" className="gap-2 shadow-brand">
              <Link href="/connect">
                Connect a repo
                <ArrowRight className="size-4" aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="ghost" className="gap-2">
              <Link href="/#triage-loop">
                <BookOpenText className="size-4" aria-hidden />
                See the triage loop
              </Link>
            </Button>
          </div>
          <p className="text-small text-muted-foreground">
            Free for the first repo. No card to start.
          </p>
        </div>
      </div>
    </section>
  );
}
