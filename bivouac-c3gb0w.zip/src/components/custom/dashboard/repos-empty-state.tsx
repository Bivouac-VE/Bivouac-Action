// @polsia:user-owned — empty state for the /dashboard/repos listing. Renders
// ONLY when /api/dashboard/repos returns zero rows. Decorative radar artwork
// + a primary CTA that points at /connect where the existing GitHub App
// install flow lives.

import { ArrowRight, GitBranch } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export function ReposEmptyState() {
  return (
    <section
      aria-label="No repositories connected"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-muted/60 via-background to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[420px] text-brand-500/15 md:-right-32"
      >
        <svg
          viewBox="0 0 420 420"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative watchtower radar</title>
          <circle cx="210" cy="210" r="190" strokeWidth="1" />
          <circle cx="210" cy="210" r="150" strokeWidth="1" />
          <circle cx="210" cy="210" r="110" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="70" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="32" strokeWidth="1.5" />
          <circle cx="210" cy="210" r="5" fill="currentColor" />
          <path
            d="M 210 210 L 210 20 A 190 190 0 0 1 378 110 Z"
            fill="currentColor"
            opacity="0.08"
          />
          <path d="M 210 20 L 210 400" strokeWidth="0.5" />
          <path d="M 20 210 L 400 210" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="relative flex flex-col items-start gap-6 p-8 md:p-12">
        <p className="text-eyebrow">No repos on watch</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          No repositories connected yet.
        </h2>
        <p className="max-w-xl text-body text-muted-foreground">
          Connect a GitHub repository to put Bivouac on duty. The GitHub App installs in one click —
          read-only repo metadata, contents read &amp; write, and pull-request write are the only
          scopes requested.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <Button asChild size="lg" className="gap-2 shadow-brand">
            <Link href="/connect">
              <GitBranch className="size-4" aria-hidden />
              Connect a repo
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
