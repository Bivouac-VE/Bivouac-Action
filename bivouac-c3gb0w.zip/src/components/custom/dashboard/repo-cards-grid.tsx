// @polsia:user-owned — client island for /dashboard. Owns the three render
// states the data-plane rule demands (loading/error/empty/data) and is the
// only thing in the page that calls `apiFetch`. The page itself stays a
// Server Component that exports `metadata`.

'use client';

import { AlertTriangle, Plus } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import { type Repo, RepoList } from '@/lib/contracts/repos';
import { DashboardEmptyState } from './dashboard-empty-state';
import { RepoCard } from './repo-card';

type GridState =
  | { status: 'loading' }
  | { status: 'ready'; items: Repo[] }
  | { status: 'error'; message: string };

const SKELETON_IDS = ['a', 'b', 'c', 'd', 'e', 'f'] as const;

export function RepoCardsGrid() {
  const [state, setState] = useState<GridState>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    const refetch = () => {
      apiFetch('/api/repos', { schema: RepoList })
        .then((data) => {
          if (active) {
            setState({ status: 'ready', items: data.items });
          }
        })
        .catch((err: unknown) => {
          if (!active) return;
          const reason =
            err instanceof Error ? err.message : 'Unknown error fetching repositories.';
          setState({ status: 'error', message: reason });
        });
    };
    refetch();
    const handler = () => refetch();
    window.addEventListener('bivouac:repo-policy-changed', handler);
    return () => {
      active = false;
      window.removeEventListener('bivouac:repo-policy-changed', handler);
    };
  }, []);

  if (state.status === 'loading') {
    return (
      <section
        aria-label="Loading repositories"
        className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
      >
        {SKELETON_IDS.map((id) => (
          <Skeleton key={id} className="h-40 w-full rounded-xl" />
        ))}
      </section>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load repositories.</AlertTitle>
        <AlertDescription>
          We could not reach the repo list right now. Retry in a moment, or contact us if this keeps
          failing. <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.items.length === 0) {
    return <DashboardEmptyState />;
  }

  return (
    <section aria-label="Connected repositories" className="flex flex-col gap-6">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">On watch</p>
        <h1 className="font-display text-h2 text-balance text-foreground">
          Connected repositories
        </h1>
        <p className="text-body-lg text-muted-foreground">
          Live triage status for every repo on watch.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {state.items.map((repo) => (
          <RepoCard key={repo.id} repo={repo} />
        ))}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6 text-small text-muted-foreground">
        <span>
          Watching <span className="text-foreground">{state.items.length}</span>{' '}
          {state.items.length === 1 ? 'repository' : 'repositories'}
        </span>
        <Button asChild variant="outline" size="sm" className="gap-1.5">
          <Link href="/connect">
            <Plus className="size-4" aria-hidden /> Connect another repo
          </Link>
        </Button>
      </div>
    </section>
  );
}
