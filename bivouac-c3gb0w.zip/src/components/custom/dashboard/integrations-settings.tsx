// @polsia:user-owned — client island for /dashboard/settings/integrations.
// Owns:
//   - parallel /api/integrations + /api/dashboard/repos fetches on first
//     paint, plus a per-provider/per-scope draft state when the user types.
//   - Slack + PagerDuty <Card>s with an <Input/> for the value, Save
//     <Button/> (PUT /api/integrations) and "Send test notification"
//     <Button/> (POST /api/integrations/test), saved-state <Badge/> and an
//     inline Alert for the canary result.
//   - a per-repo overrides section that exhibits the same Form for a chosen
//     (provider, repo:<repoId>) scope, plus a small picker sourced from
//     /api/dashboard/repos.
//   - "Admin only" fallback banner when /api/integrations returns 403 (the
//     non-admin case still loads /api/dashboard/repos so the page doesn't
//     500).
//
// All state, fetch, success/error UI lives here; the page stays a Server
// Component that only exports `metadata`.

'use client';

import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  Loader2,
  Plug,
  Send,
  Trash2,
  XCircle,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  DashboardReposList,
  type DashboardReposList as DashboardReposListT,
} from '@/lib/contracts/dashboard-repos';
import {
  type IntegrationItem,
  IntegrationItem as IntegrationItemSchema,
  IntegrationList,
  IntegrationTestResult,
  type IntegrationTestResult as IntegrationTestResultT,
  IntegrationUpsertInput,
  type RuleTriggerInput as RuleTriggerInputT,
  RuleTriggerResult,
  type RuleTriggerResult as RuleTriggerResultT,
} from '@/lib/contracts/integrations';

type Provider = 'slack' | 'pagerduty';
type ScopeKey = 'team' | `repo:${string}`;
type TestState =
  | { status: 'idle' | 'sending' }
  | {
      status: 'sent';
      result: {
        status: 'delivered' | 'failed';
        statusCode: number | null;
        error: string | null;
        runDay: string;
      };
    };

interface DraftState {
  value: string;
  dirty: boolean;
  saving: boolean;
}

type FetchState =
  | { status: 'loading' }
  | { status: 'forbidden' }
  | { status: 'error'; message: string }
  | { status: 'ready'; items: IntegrationItem[] };

type ReposState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; repos: DashboardReposListT['items'] };

interface ProviderCardProps {
  provider: Provider;
  scope: ScopeKey;
  /** The matching item from the fetched list, if any. */
  item: IntegrationItem | null;
  draft: DraftState;
  test: TestState;
  disabled?: boolean;
  onDraft: (value: string) => void;
  onSave: () => void;
  onTest: () => void;
  onClear: () => void;
}

const SLACK_PLACEHOLDER =
  'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX';
const PAGERDUTY_PLACEHOLDER = '0123456789abcdef0123456789abcdef';

function formatTimestamp(iso: string | null | undefined): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function providerLabel(provider: Provider): string {
  return provider === 'slack' ? 'Slack' : 'PagerDuty';
}

function providerHelpLine(provider: Provider): string {
  return provider === 'slack'
    ? 'Incoming-webhook URL only — Slack encodes the channel + secret right in the URL, so we never see them as separate fields. URL must look like https://hooks.slack.com/services/T…/B…/…'
    : 'PagerDuty Events API v2 routing key — the 32-character hex string from your PagerDuty service. Authentication is the routing_key field in the JSON body (PagerDuty does not sign the request).';
}

export function IntegrationsSettings() {
  const [fetched, setFetched] = useState<FetchState>({ status: 'loading' });
  const [reposState, setReposState] = useState<ReposState>({ status: 'loading' });
  const [teamDrafts, setTeamDrafts] = useState<Record<Provider, DraftState>>({
    slack: { value: '', dirty: false, saving: false },
    pagerduty: { value: '', dirty: false, saving: false },
  });
  const [teamTests, setTeamTests] = useState<Record<Provider, TestState>>({
    slack: { status: 'idle' },
    pagerduty: { status: 'idle' },
  });
  const [override, setOverride] = useState<{
    provider: Provider;
    repoId: string;
    draft: DraftState;
    test: TestState;
  } | null>(null);

  const refresh = useCallback(() => {
    setFetched({ status: 'loading' });
    apiFetch('/api/integrations', { schema: IntegrationList })
      .then((data) => setFetched({ status: 'ready', items: data.items }))
      .catch((err: unknown) => {
        const status = (err as { cause?: { status?: number } })?.cause?.status;
        if (status === 403) {
          setFetched({ status: 'forbidden' });
        } else {
          setFetched({
            status: 'error',
            message: err instanceof Error ? err.message : 'Could not load integrations.',
          });
        }
      });
  }, []);

  useEffect(() => {
    let active = true;
    apiFetch('/api/integrations', { schema: IntegrationList })
      .then((data) => {
        if (!active) return;
        setFetched({ status: 'ready', items: data.items });
      })
      .catch((err: unknown) => {
        if (!active) return;
        const status = (err as { cause?: { status?: number } })?.cause?.status;
        if (status === 403) {
          setFetched({ status: 'forbidden' });
        } else {
          setFetched({
            status: 'error',
            message: err instanceof Error ? err.message : 'Could not load integrations.',
          });
        }
      });
    setReposState({ status: 'loading' });
    apiFetch('/api/dashboard/repos', { schema: DashboardReposList })
      .then((data) => {
        if (!active) return;
        setReposState({ status: 'ready', repos: data.items });
      })
      .catch((err: unknown) => {
        if (!active) return;
        setReposState({
          status: 'error',
          message: err instanceof Error ? err.message : 'Could not load repos.',
        });
      });
    return () => {
      active = false;
    };
  }, []);

  const itemsByScopeAndProvider = useMemo(() => {
    const lookup = new Map<string, IntegrationItem>();
    if (fetched.status === 'ready') {
      for (const item of fetched.items) {
        lookup.set(`${item.provider}|${item.scope}`, item);
      }
    }
    return lookup;
  }, [fetched]);

  // ---- TEAM-SCOPE DRAFTS ---------------------------------------------
  function patchTeamDraft(provider: Provider, value: string) {
    setTeamDrafts((prev) => ({
      ...prev,
      [provider]: { ...prev[provider], value, dirty: true },
    }));
  }

  async function saveTeam(provider: Provider) {
    setTeamDrafts((prev) => ({ ...prev, [provider]: { ...prev[provider], saving: true } }));
    try {
      const updated = await apiFetch('/api/integrations', {
        method: 'PUT',
        body: JSON.stringify(
          IntegrationUpsertInput.parse({
            provider,
            scope: 'team',
            value: teamDrafts[provider].value,
          }),
        ),
        schema: IntegrationItemSchema,
      });
      setFetched((prev) => {
        if (prev.status !== 'ready') return prev;
        const next = [...prev.items];
        const idx = next.findIndex((i) => i.provider === provider && i.scope === 'team');
        if (idx === -1) {
          next.push(updated);
        } else {
          next[idx] = updated;
        }
        return { ...prev, items: next };
      });
      setTeamDrafts((prev) => ({
        ...prev,
        [provider]: { value: '', dirty: false, saving: false },
      }));
      setTeamTests((prev) => ({ ...prev, [provider]: { status: 'idle' } }));
      toast.success(`${providerLabel(provider)} integration saved.`);
    } catch (err: unknown) {
      const message =
        err instanceof Error
          ? err.message
          : `Could not save your ${providerLabel(provider)} integration.`;
      setTeamDrafts((prev) => ({
        ...prev,
        [provider]: { ...prev[provider], saving: false },
      }));
      toast.error(message);
    }
  }

  async function testTeam(provider: Provider) {
    setTeamTests((prev) => ({ ...prev, [provider]: { status: 'sending' } }));
    try {
      const result: IntegrationTestResultT = await apiFetch('/api/integrations/test', {
        method: 'POST',
        body: JSON.stringify({ provider, scope: 'team' }),
        schema: IntegrationTestResult,
      });
      setTeamTests((prev) => ({
        ...prev,
        [provider]: { status: 'sent', result: { ...result } },
      }));
      if (result.status === 'delivered') {
        toast.success(`${providerLabel(provider)} test delivered (${result.statusCode ?? '2xx'}).`);
      } else {
        toast.error(`${providerLabel(provider)} test failed: ${result.error ?? 'no response'}`);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Test notification failed.';
      setTeamTests((prev) => ({
        ...prev,
        [provider]: {
          status: 'sent',
          result: { status: 'failed', statusCode: null, error: message, runDay: '—' },
        },
      }));
      toast.error(message);
    }
  }

  async function clearTeam(provider: Provider) {
    try {
      await apiFetch('/api/integrations', {
        method: 'DELETE',
        body: JSON.stringify({ provider, scope: 'team' }),
      });
      setFetched((prev) => {
        if (prev.status !== 'ready') return prev;
        return {
          ...prev,
          items: prev.items.filter((i) => !(i.provider === provider && i.scope === 'team')),
        };
      });
      setTeamDrafts((prev) => ({
        ...prev,
        [provider]: { value: '', dirty: false, saving: false },
      }));
      setTeamTests((prev) => ({ ...prev, [provider]: { status: 'idle' } }));
      toast.success(`${providerLabel(provider)} integration removed.`);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not remove integration.';
      toast.error(message);
    }
  }

  // ---- OVERRIDE DRAFTS ------------------------------------------------
  function openOverride(provider: Provider, repoId: string) {
    setOverride({
      provider,
      repoId,
      draft: { value: '', dirty: false, saving: false },
      test: { status: 'idle' },
    });
  }
  function patchOverrideDraft(value: string) {
    setOverride((prev) =>
      prev ? { ...prev, draft: { ...prev.draft, value, dirty: true } } : prev,
    );
  }
  async function saveOverride() {
    if (!override) return;
    setOverride((prev) => (prev ? { ...prev, draft: { ...prev.draft, saving: true } } : prev));
    const scope: ScopeKey = `repo:${override.repoId}`;
    try {
      const updated = await apiFetch<IntegrationItem>('/api/integrations', {
        method: 'PUT',
        body: JSON.stringify(
          IntegrationUpsertInput.parse({
            provider: override.provider,
            scope,
            value: override.draft.value,
          }),
        ),
        schema: IntegrationItemSchema,
      });
      setFetched((prev) => {
        if (prev.status !== 'ready') return prev;
        const next = [...prev.items];
        const idx = next.findIndex((i) => i.provider === override.provider && i.scope === scope);
        if (idx === -1) next.push(updated);
        else next[idx] = updated;
        return { ...prev, items: next };
      });
      setOverride((prev) =>
        prev
          ? { ...prev, draft: { value: '', dirty: false, saving: false }, test: { status: 'idle' } }
          : prev,
      );
      toast.success(`${providerLabel(override.provider)} override saved.`);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not save override.';
      setOverride((prev) => (prev ? { ...prev, draft: { ...prev.draft, saving: false } } : prev));
      toast.error(message);
    }
  }
  async function testOverride() {
    if (!override) return;
    setOverride((prev) => (prev ? { ...prev, test: { status: 'sending' } } : prev));
    try {
      const result = await apiFetch('/api/integrations/test', {
        method: 'POST',
        body: JSON.stringify({ provider: override.provider, scope: `repo:${override.repoId}` }),
        schema: IntegrationTestResult,
      });
      setOverride((prev) =>
        prev ? { ...prev, test: { status: 'sent', result: { ...result } } } : prev,
      );
      if (result.status === 'delivered') {
        toast.success(`${providerLabel(override.provider)} override test delivered.`);
      } else {
        toast.error(
          `${providerLabel(override.provider)} override test failed: ${result.error ?? 'no response'}`,
        );
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Test notification failed.';
      setOverride((prev) =>
        prev
          ? {
              ...prev,
              test: {
                status: 'sent',
                result: { status: 'failed', statusCode: null, error: message, runDay: '—' },
              },
            }
          : prev,
      );
      toast.error(message);
    }
  }
  async function clearOverride() {
    if (!override) return;
    try {
      await apiFetch('/api/integrations', {
        method: 'DELETE',
        body: JSON.stringify({ provider: override.provider, scope: `repo:${override.repoId}` }),
      });
      setFetched((prev) => {
        if (prev.status !== 'ready') return prev;
        return {
          ...prev,
          items: prev.items.filter(
            (i) => !(i.provider === override.provider && i.scope === `repo:${override.repoId}`),
          ),
        };
      });
      setOverride(null);
      toast.success('Override removed.');
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not remove override.';
      toast.error(message);
    }
  }

  // ---- RENDER BRANCHES ------------------------------------------------
  if (fetched.status === 'loading') {
    return (
      <div className="flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plug aria-hidden="true" className="size-4" />
              <span>Loading integrations…</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Skeleton className="h-9 w-full" />
            <Skeleton className="mt-3 h-5 w-24" />
          </CardContent>
        </Card>
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (fetched.status === 'forbidden') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plug aria-hidden="true" className="size-4" />
            <span>Integrations</span>
          </CardTitle>
          <CardDescription>
            Slack + PagerDuty team alerting, with optional per-repo overrides.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTriangle aria-hidden="true" className="size-4" />
            <AlertTitle>Team admins only</AlertTitle>
            <AlertDescription>
              Configuring integrations requires the team-admin role. Ask an admin on your team to
              set the team-wide defaults, then revisit any per-repo overrides. You can still browse
              the rest of the dashboard.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  if (fetched.status === 'error') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plug aria-hidden="true" className="size-4" />
            <span>Integrations</span>
          </CardTitle>
          <CardDescription>We couldn’t load your integrations.</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>{fetched.message}</AlertDescription>
          </Alert>
          <Button type="button" variant="outline" size="sm" className="mt-3" onClick={refresh}>
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  const slackItem = itemsByScopeAndProvider.get('slack|team') ?? null;
  const pdItem = itemsByScopeAndProvider.get('pagerduty|team') ?? null;

  return (
    <div className="flex flex-col gap-section">
      <ProviderCard
        provider="slack"
        scope="team"
        item={slackItem}
        draft={teamDrafts.slack}
        test={teamTests.slack}
        onDraft={(v) => patchTeamDraft('slack', v)}
        onSave={() => saveTeam('slack')}
        onTest={() => testTeam('slack')}
        onClear={() => clearTeam('slack')}
      />
      <ProviderCard
        provider="pagerduty"
        scope="team"
        item={pdItem}
        draft={teamDrafts.pagerduty}
        test={teamTests.pagerduty}
        onDraft={(v) => patchTeamDraft('pagerduty', v)}
        onSave={() => saveTeam('pagerduty')}
        onTest={() => testTeam('pagerduty')}
        onClear={() => clearTeam('pagerduty')}
      />

      <PerRepoOverrides
        reposState={reposState}
        rows={fetched.items.filter((i) => i.scope.startsWith('repo:'))}
        itemsByScope={itemsByScopeAndProvider}
        onOpenOverride={openOverride}
      />

      <RuleTriggerCard reposState={reposState} itemsByScope={itemsByScopeAndProvider} />

      {override ? (
        <OverrideCard
          provider={override.provider}
          repoId={override.repoId}
          reposState={reposState}
          draft={override.draft}
          test={override.test}
          item={itemsByScopeAndProvider.get(`${override.provider}|repo:${override.repoId}`) ?? null}
          onDraft={patchOverrideDraft}
          onSave={saveOverride}
          onTest={testOverride}
          onClear={clearOverride}
          onClose={() => setOverride(null)}
        />
      ) : null}
    </div>
  );
}

function ProviderCard(props: ProviderCardProps) {
  const { provider, item, draft, test, onDraft, onSave, onTest, onClear } = props;
  const placeholder = provider === 'slack' ? SLACK_PLACEHOLDER : PAGERDUTY_PLACEHOLDER;
  const helpId = `integrations-${provider}-help`;
  const dirty = draft.dirty || draft.value.length > 0;
  const valueDirty = draft.value.length > 0;
  const isSaved = !!item;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plug aria-hidden="true" className="size-4" />
          <span>{providerLabel(provider)}</span>
          {isSaved ? (
            <Badge
              variant="outline"
              className="ml-2 border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
            >
              Connected
            </Badge>
          ) : (
            <Badge variant="outline" className="ml-2 border-border/60 text-muted-foreground">
              Not configured
            </Badge>
          )}
        </CardTitle>
        <CardDescription>{providerHelpLine(provider)}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor={`integrations-${provider}-value`}>
            {provider === 'slack' ? 'Slack incoming-webhook URL' : 'PagerDuty routing key'}
          </Label>
          <Input
            id={`integrations-${provider}-value`}
            type={provider === 'slack' ? 'url' : 'text'}
            autoComplete="off"
            inputMode={provider === 'slack' ? 'url' : 'text'}
            placeholder={placeholder}
            value={draft.value}
            onChange={(e) => onDraft(e.target.value)}
            aria-describedby={valueDirty ? helpId : undefined}
            disabled={draft.saving}
          />
          {valueDirty ? (
            <p id={helpId} className="text-xs text-muted-foreground">
              {provider === 'slack'
                ? 'Must be HTTPS on hooks.slack.com with path /services/T…/B…/…'
                : 'Must be exactly 32 hexadecimal characters; case-insensitive.'}
            </p>
          ) : null}
          {item ? (
            <p className="text-xs text-muted-foreground">
              Saved {item.valuePreview ? `· ${item.valuePreview} · ` : ''}
              Last updated {formatTimestamp(item.updatedAt)}.
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            size="sm"
            onClick={onSave}
            disabled={!dirty || draft.saving || draft.value.trim().length === 0}
          >
            {draft.saving ? (
              <>
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                <span>Saving…</span>
              </>
            ) : isSaved ? (
              'Save changes'
            ) : (
              'Save'
            )}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onTest}
            disabled={!isSaved || test.status === 'sending'}
            title={!isSaved ? 'Save first' : 'Send a canary notification'}
          >
            {test.status === 'sending' ? (
              <>
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                <span>Sending test…</span>
              </>
            ) : (
              <>
                <Send aria-hidden="true" className="size-4" />
                <span>Send test notification</span>
              </>
            )}
          </Button>
          {isSaved ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onClear}
              disabled={draft.saving || test.status === 'sending'}
            >
              <Trash2 aria-hidden="true" className="size-4" />
              <span>Remove</span>
            </Button>
          ) : null}
        </div>

        {test.status === 'sent' && test.result.status === 'failed' ? (
          <Alert>
            <XCircle aria-hidden="true" className="size-4" />
            <AlertTitle>Test failed</AlertTitle>
            <AlertDescription>
              {test.result.error ?? 'No response'} (run{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>)
            </AlertDescription>
          </Alert>
        ) : null}
        {test.status === 'sent' && test.result.status === 'delivered' ? (
          <Alert>
            <CheckCircle2 aria-hidden="true" className="size-4" />
            <AlertTitle>Test delivered</AlertTitle>
            <AlertDescription>
              Endpoint returned {test.result.statusCode ?? '2xx'}. Recorded as{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>.
            </AlertDescription>
          </Alert>
        ) : null}
      </CardContent>
    </Card>
  );
}

interface PerRepoOverridesProps {
  reposState: ReposState;
  rows: IntegrationItem[];
  itemsByScope: Map<string, IntegrationItem>;
  onOpenOverride: (provider: Provider, repoId: string) => void;
}

function PerRepoOverrides({
  reposState,
  rows,
  itemsByScope,
  onOpenOverride,
}: PerRepoOverridesProps) {
  const [provider, setProvider] = useState<Provider>('slack');
  const [repoId, setRepoId] = useState<string>('');

  // After repos load, default the picker to the first repo if the user
  // hasn't picked one yet. Re-sync only when the available list changes
  // AND the current selection no longer exists.
  useEffect(() => {
    if (reposState.status !== 'ready') return;
    if (reposState.repos.length === 0) {
      if (repoId !== '') setRepoId('');
      return;
    }
    const stillExists = reposState.repos.find((r) => r.id === repoId);
    if (!stillExists) setRepoId(reposState.repos[0]?.id ?? '');
  }, [reposState, repoId]);

  function startOverride() {
    if (!repoId) return;
    onOpenOverride(provider, repoId);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plug aria-hidden="true" className="size-4" />
          <span>Per-repo overrides</span>
        </CardTitle>
        <CardDescription>
          Override the team-wide <em>{providerLabel(provider)}</em> integration for a single
          repository. The team default still applies to every other repo.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {reposState.status === 'loading' ? (
          <Skeleton className="h-9 w-full" />
        ) : reposState.status === 'error' ? (
          <Alert>
            <AlertTitle>Could not load repos</AlertTitle>
            <AlertDescription>{reposState.message}</AlertDescription>
          </Alert>
        ) : reposState.repos.length === 0 ? (
          <Alert>
            <AlertTitle>No repos connected</AlertTitle>
            <AlertDescription>
              Connect at least one repository before adding per-repo overrides. Head to{' '}
              <a className="underline" href="/dashboard/connect">
                Connect a repo
              </a>{' '}
              to start.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
            <div className="flex flex-col gap-1">
              <Label htmlFor="override-provider">Provider</Label>
              <Select
                value={provider}
                onValueChange={(v) => setProvider(v === 'pagerduty' ? 'pagerduty' : 'slack')}
              >
                <SelectTrigger id="override-provider" className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="slack">Slack</SelectItem>
                  <SelectItem value="pagerduty">PagerDuty</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-1 flex-col gap-1">
              <Label htmlFor="override-repo">Repository</Label>
              <Select value={repoId} onValueChange={(v) => setRepoId(v)}>
                <SelectTrigger id="override-repo" className="w-full sm:w-[280px]">
                  <SelectValue placeholder="Pick a repository" />
                </SelectTrigger>
                <SelectContent>
                  {reposState.repos.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.ownerHandle}/{r.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button type="button" size="sm" onClick={startOverride} disabled={!repoId}>
              Override for repo
            </Button>
          </div>
        )}

        <ExistingOverrides rows={rows} itemsByScope={itemsByScope} />
      </CardContent>
    </Card>
  );
}

function ExistingOverrides({
  rows,
  itemsByScope,
}: {
  rows: IntegrationItem[];
  itemsByScope: Map<string, IntegrationItem>;
}) {
  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border/70 px-4 py-3 text-sm text-muted-foreground">
        No per-repo overrides yet. Use the picker above to add one.
      </div>
    );
  }
  return (
    <ul className="flex flex-col gap-2 text-sm">
      {rows.map((row) => {
        const fresh = itemsByScope.get(`${row.provider}|${row.scope}`);
        const valuePreview = fresh?.valuePreview ?? row.valuePreview;
        const repoLabel = row.repoSlug ?? row.scope.replace(/^repo:/, '');
        return (
          <li
            key={row.id}
            className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border/70 bg-muted/30 px-3 py-2"
          >
            <span className="flex min-w-0 items-center gap-2">
              <Badge variant="secondary" className="text-[10px] uppercase tracking-wide">
                {providerLabel(row.provider)}
              </Badge>
              <span className="truncate font-medium text-foreground">{repoLabel}</span>
              <span className="truncate font-mono text-xs text-muted-foreground">
                {valuePreview}
              </span>
            </span>
            <span className="text-xs text-muted-foreground">
              Updated {formatTimestamp(fresh?.updatedAt ?? row.updatedAt)}
            </span>
          </li>
        );
      })}
    </ul>
  );
}

interface OverrideCardProps {
  provider: Provider;
  repoId: string;
  reposState: ReposState;
  item: IntegrationItem | null;
  draft: DraftState;
  test: TestState;
  onDraft: (value: string) => void;
  onSave: () => void;
  onTest: () => void;
  onClear: () => void;
  onClose: () => void;
}

function OverrideCard({
  provider,
  repoId,
  reposState,
  item,
  draft,
  test,
  onDraft,
  onSave,
  onTest,
  onClear,
  onClose,
}: OverrideCardProps) {
  const placeholder = provider === 'slack' ? SLACK_PLACEHOLDER : PAGERDUTY_PLACEHOLDER;
  const inputId = `override-${provider}-${repoId}-value`;
  const helpId = `${inputId}-help`;
  const isSaved = !!item;
  const valueDirty = draft.value.length > 0;

  let repoLabel = repoId;
  if (reposState.status === 'ready') {
    const repo = reposState.repos.find((r) => r.id === repoId);
    if (repo) repoLabel = `${repo.ownerHandle}/${repo.name}`;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plug aria-hidden="true" className="size-4" />
          <span>
            {providerLabel(provider)} override · {repoLabel}
          </span>
          {isSaved ? (
            <Badge
              variant="outline"
              className="ml-2 border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
            >
              Connected
            </Badge>
          ) : (
            <Badge variant="outline" className="ml-2 border-border/60 text-muted-foreground">
              Not configured
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          This override beats the team-wide default for {repoLabel} only. Other repos still use the
          team-wide configuration.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor={inputId}>
            {provider === 'slack' ? 'Slack incoming-webhook URL' : 'PagerDuty routing key'}
          </Label>
          <Input
            id={inputId}
            type={provider === 'slack' ? 'url' : 'text'}
            autoComplete="off"
            inputMode={provider === 'slack' ? 'url' : 'text'}
            placeholder={placeholder}
            value={draft.value}
            onChange={(e) => onDraft(e.target.value)}
            aria-describedby={valueDirty ? helpId : undefined}
            disabled={draft.saving}
          />
          {valueDirty ? (
            <p id={helpId} className="text-xs text-muted-foreground">
              {provider === 'slack'
                ? 'Must be HTTPS on hooks.slack.com with path /services/T…/B…/…'
                : 'Must be exactly 32 hexadecimal characters; case-insensitive.'}
            </p>
          ) : null}
          {item ? (
            <p className="text-xs text-muted-foreground">
              Saved {item.valuePreview ? `· ${item.valuePreview} · ` : ''}
              Last updated {formatTimestamp(item.updatedAt)}.
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            size="sm"
            onClick={onSave}
            disabled={!draft.dirty || draft.saving || draft.value.trim().length === 0}
          >
            {draft.saving ? (
              <>
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                <span>Saving…</span>
              </>
            ) : (
              'Save override'
            )}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onTest}
            disabled={!isSaved || test.status === 'sending'}
          >
            {test.status === 'sending' ? (
              <>
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                <span>Sending test…</span>
              </>
            ) : (
              <>
                <Send aria-hidden="true" className="size-4" />
                <span>Send test notification</span>
              </>
            )}
          </Button>
          {isSaved ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onClear}
              disabled={draft.saving || test.status === 'sending'}
            >
              <Trash2 aria-hidden="true" className="size-4" />
              <span>Remove override</span>
            </Button>
          ) : null}
          <Button type="button" variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>

        {test.status === 'sent' && test.result.status === 'failed' ? (
          <Alert>
            <XCircle aria-hidden="true" className="size-4" />
            <AlertTitle>Override test failed</AlertTitle>
            <AlertDescription>
              {test.result.error ?? 'No response'} (run{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>)
            </AlertDescription>
          </Alert>
        ) : null}
        {test.status === 'sent' && test.result.status === 'delivered' ? (
          <Alert>
            <CheckCircle2 aria-hidden="true" className="size-4" />
            <AlertTitle>Override test delivered</AlertTitle>
            <AlertDescription>
              Endpoint returned {test.result.statusCode ?? '2xx'}. Recorded as{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{test.result.runDay}</code>.
            </AlertDescription>
          </Alert>
        ) : null}
      </CardContent>
    </Card>
  );
}

/** Human-readable label for a "page a human" rule enum value. Mirrors
 *  `humanRuleLabel` in policy-packs-island.tsx so the labels stay consistent
 *  across the admin surfaces. The list ordering follows the canonical
 *  PageHumanRule enum (policy-packs.ts) so the picker reverses-fine in the
 *  same order users see in the policy-pack surface. */
const PAGE_HUMAN_RULES: Array<{
  value: RuleTriggerInputT['reason'];
  label: string;
}> = [
  { value: 'high-severity-cve', label: 'High-severity CVE' },
  { value: 'license-change', label: 'License change' },
  { value: 'public-api-break', label: 'Public API break' },
  { value: 'security-sensitive', label: 'Security-sensitive' },
  { value: 'red-build', label: 'Red build' },
  { value: 'major-bump', label: 'Major version bump' },
  { value: 'minor-bump', label: 'Minor version bump' },
];

interface RuleTriggerCardProps {
  reposState: ReposState;
  itemsByScope: Map<string, IntegrationItem>;
}

type RuleTriggerState =
  | { status: 'idle' }
  | { status: 'sending' }
  | { status: 'sent'; result: RuleTriggerResultT };

/** Manual "page a human" probe: pick a provider, a repo, a rule reason, and
 *  a PR URL, then POST to /api/integrations/rule-trigger. The route handler
 *  applies the per-repo → team-wide lookup precedence; on no config it
 *  returns a no-op result, on a missing delivery it surfaces the error inline
 *  so the user can see whether the webhook is reachable end-to-end. */
function RuleTriggerCard({ reposState, itemsByScope }: RuleTriggerCardProps) {
  const [provider, setProvider] = useState<Provider>('slack');
  const [repoId, setRepoId] = useState<string>('');
  const [reason, setReason] = useState<RuleTriggerInputT['reason']>('high-severity-cve');
  const [prUrl, setPrUrl] = useState<string>('');
  const [result, setResult] = useState<RuleTriggerState>({ status: 'idle' });

  // Default the repo picker to the first connected repo (matches the
  // override picker behaviour) and the provider to whichever team-scoped
  // item we already have saved so the user can fire without further input.
  useEffect(() => {
    if (reposState.status !== 'ready') return;
    if (reposState.repos.length === 0) {
      if (repoId !== '') setRepoId('');
      return;
    }
    if (!repoId) setRepoId(reposState.repos[0]?.id ?? '');
  }, [reposState, repoId]);

  useEffect(() => {
    const teamSlack = itemsByScope.get('slack|team');
    const teamPd = itemsByScope.get('pagerduty|team');
    if (teamSlack && !teamPd) setProvider('slack');
    else if (teamPd && !teamSlack) setProvider('pagerduty');
  }, [itemsByScope]);

  const canSubmit =
    provider !== undefined &&
    !!repoId &&
    !!prUrl.trim() &&
    prUrl.startsWith('http') &&
    result.status !== 'sending';

  // The team-default row may be missing if the team only configured per-repo
  // overrides for one provider — count either source as a "ready" state.
  let overrideCount = 0;
  for (const key of itemsByScope.keys()) {
    if (key.includes('|repo:')) overrideCount++;
  }
  const hasSlack =
    itemsByScope.get('slack|team') !== undefined ||
    Array.from(itemsByScope.keys()).some((k) => k.startsWith('slack|repo:'));
  const hasPagerDuty =
    itemsByScope.get('pagerduty|team') !== undefined ||
    Array.from(itemsByScope.keys()).some((k) => k.startsWith('pagerduty|repo:'));

  async function fire() {
    setResult({ status: 'sending' });
    try {
      const sent: RuleTriggerResultT = await apiFetch('/api/integrations/rule-trigger', {
        method: 'POST',
        body: JSON.stringify({
          provider,
          scope: 'team',
          repoId,
          reason,
          prUrl,
        }),
        schema: RuleTriggerResult,
      });
      setResult({ status: 'sent', result: sent });
      if (sent.noOp) {
        toast.message(`${providerLabel(provider)} not configured — page skipped.`);
      } else if (sent.delivered) {
        toast.success(
          `${providerLabel(provider)} rule webhook delivered (${sent.statusCode ?? '2xx'}).`,
        );
      } else {
        toast.error(
          `${providerLabel(provider)} rule webhook failed: ${sent.error ?? 'no response'}`,
        );
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Could not fire rule webhook.';
      setResult({
        status: 'sent',
        result: {
          delivered: false,
          noOp: false,
          noOpReason: null,
          provider,
          resolvedScope: 'team',
          runDay: '—',
          statusCode: null,
          error: message,
        },
      });
      toast.error(message);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell aria-hidden="true" className="size-4" />
          <span>Page-a-human probe</span>
        </CardTitle>
        <CardDescription>
          Fire the configured <em>{providerLabel(provider)}</em> webhook with a synthetic rule-trip
          payload (repo, reason, PR link). Use this to confirm your on-call surface is wired end-to-
          end before the real CveTriageLog-driven fires arrive.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex flex-col gap-1">
            <Label htmlFor="rule-trigger-provider">Provider</Label>
            <Select
              value={provider}
              onValueChange={(v) => setProvider(v === 'pagerduty' ? 'pagerduty' : 'slack')}
            >
              <SelectTrigger id="rule-trigger-provider" className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="slack" disabled={!hasSlack}>
                  Slack
                </SelectItem>
                <SelectItem value="pagerduty" disabled={!hasPagerDuty}>
                  PagerDuty
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-1 flex-col gap-1">
            <Label htmlFor="rule-trigger-repo">Repository</Label>
            <Select value={repoId} onValueChange={(v) => setRepoId(v)}>
              <SelectTrigger id="rule-trigger-repo" className="w-full sm:w-[280px]">
                <SelectValue placeholder="Pick a repository" />
              </SelectTrigger>
              <SelectContent>
                {reposState.status === 'ready'
                  ? reposState.repos.map((r) => (
                      <SelectItem key={r.id} value={r.id}>
                        {r.ownerHandle}/{r.name}
                      </SelectItem>
                    ))
                  : null}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-1 flex-col gap-1">
            <Label htmlFor="rule-trigger-reason">Reason</Label>
            <Select
              value={reason}
              onValueChange={(v) => {
                const next = PAGE_HUMAN_RULES.find((r) => r.value === v);
                setReason(next ? next.value : 'high-severity-cve');
              }}
            >
              <SelectTrigger id="rule-trigger-reason" className="w-full sm:w-[220px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAGE_HUMAN_RULES.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <Label htmlFor="rule-trigger-pr">PR URL</Label>
          <Input
            id="rule-trigger-pr"
            type="url"
            autoComplete="off"
            inputMode="url"
            placeholder="https://github.com/owner/name/pull/123"
            value={prUrl}
            onChange={(e) => setPrUrl(e.target.value)}
          />
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            size="sm"
            onClick={fire}
            disabled={!canSubmit}
            title={
              !hasSlack && !hasPagerDuty
                ? 'Save at least one Slack or PagerDuty endpoint first'
                : 'Send a synthetic rule webhook against the configured endpoint'
            }
          >
            {result.status === 'sending' ? (
              <>
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
                <span>Sending…</span>
              </>
            ) : (
              <>
                <Send aria-hidden="true" className="size-4" />
                <span>Send rule webhook</span>
              </>
            )}
          </Button>
        </div>

        {result.status === 'sent' && result.result.noOp ? (
          <Alert>
            <AlertTriangle aria-hidden="true" className="size-4" />
            <AlertTitle>No webhook configured</AlertTitle>
            <AlertDescription>
              Neither a per-repo override nor the team-wide default has been saved for{' '}
              <strong>{providerLabel(result.result.provider)}</strong>. The rule trip would have
              been a no-op — save an endpoint first, then re-run.
            </AlertDescription>
          </Alert>
        ) : null}
        {result.status === 'sent' && !result.result.noOp && !result.result.delivered ? (
          <Alert>
            <XCircle aria-hidden="true" className="size-4" />
            <AlertTitle>Rule webhook failed</AlertTitle>
            <AlertDescription>
              {result.result.error ?? 'No response'} (run{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{result.result.runDay}</code>)
            </AlertDescription>
          </Alert>
        ) : null}
        {result.status === 'sent' && result.result.delivered ? (
          <Alert>
            <CheckCircle2 aria-hidden="true" className="size-4" />
            <AlertTitle>Rule webhook delivered</AlertTitle>
            <AlertDescription>
              Endpoint returned {result.result.statusCode ?? '2xx'} via scope{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">
                {result.result.resolvedScope}
              </code>{' '}
              — recorded as{' '}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">{result.result.runDay}</code>.
            </AlertDescription>
          </Alert>
        ) : null}

        {/* `items` is referenced indirectly via `itemsByScope` in the parent;
            keeping the prop preserves the future ability to surface a per-repo
            override hint inside the card without forcing a re-render. */}
        {overrideCount === 0 ? null : (
          <p className="text-xs text-muted-foreground">
            {overrideCount} per-repo override
            {overrideCount === 1 ? '' : 's'} configured — team default still applies for other
            repos.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
