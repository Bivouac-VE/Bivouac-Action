// @polsia:user-owned — client island for /dashboard/repos/connect. Reads the
// `installation_id` from the URL (the second leg of the connect-a-repo flow
// after GitHubApp install completes), lists the repos that install granted
// access to, and on submit persists the enabled set via POST /api/repos.
// On success, redirects to /dashboard/repos so the new entries show up
// with their status badges.

'use client';

import { AlertTriangle, ArrowRight, GitBranch, Github, RefreshCw } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { apiFetch } from '@/lib/api-client';
import {
  type GithubInstallationRepo,
  GithubInstallationRepoList,
  RepoSelectInput,
  RepoSelectResult,
} from '@/lib/contracts/repos';

type PickerState =
  | { status: 'loading' }
  | {
      status: 'ready';
      installationId: string;
      repos: GithubInstallationRepo[];
      // Per-row toggle; initial value seeded to `true` so the user only opts
      // OUT of a repo rather than opts in.
      enabled: Record<string, boolean>;
    }
  | { status: 'error'; message: string }
  | { status: 'empty'; installationId: string }
  | { status: 'invalid-installation' };

function readInstallationIdFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  const params = new URLSearchParams(window.location.search);
  const raw = params.get('installation_id');
  return raw && /^\d+$/.test(raw) ? raw : null;
}

export function RepoSelectCard() {
  const [state, setState] = useState<PickerState>({ status: 'loading' });
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const router = useRouter();

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    setSubmitError(null);
    const installationId = readInstallationIdFromUrl();
    if (!installationId) {
      setState({ status: 'invalid-installation' });
      return;
    }
    try {
      const data = await apiFetch(
        `/api/github/installation/${encodeURIComponent(installationId)}/repos`,
        { schema: GithubInstallationRepoList },
      );
      const enabled: Record<string, boolean> = {};
      for (const r of data.items) enabled[r.githubNodeId] = true;
      if (data.items.length === 0) {
        setState({ status: 'empty', installationId });
        return;
      }
      setState({ status: 'ready', installationId, repos: data.items, enabled });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Unknown error fetching picker.';
      const status =
        err && typeof err === 'object' && 'cause' in err
          ? ((err as { cause?: { status?: number } }).cause?.status ?? null)
          : null;
      if (status === 404) {
        setState({ status: 'invalid-installation' });
        return;
      }
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const grouped = useMemo(() => {
    if (state.status !== 'ready') return null;
    const groups = new Map<string, GithubInstallationRepo[]>();
    for (const r of state.repos) {
      const list = groups.get(r.ownerHandle) ?? [];
      list.push(r);
      groups.set(r.ownerHandle, list);
    }
    return Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [state]);

  const enabledCount =
    state.status === 'ready' ? state.repos.filter((r) => state.enabled[r.githubNodeId]).length : 0;

  async function handleSubmit() {
    if (state.status !== 'ready') return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      const pickedRepos = state.repos.filter((r) => state.enabled[r.githubNodeId]);
      const body = RepoSelectInput.parse({
        installationId: state.installationId,
        repos: pickedRepos.map((r) => ({
          githubNodeId: r.githubNodeId,
          githubRepoId: r.githubRepoId,
          name: r.name,
          ownerHandle: r.ownerHandle,
          defaultBranch: r.defaultBranch,
        })),
      });
      const result = await apiFetch('/api/repos', {
        method: 'POST',
        body: JSON.stringify(body),
        schema: RepoSelectResult,
      });
      void result;
      router.push('/dashboard/repos');
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not save the selected repos.';
      setSubmitError(reason);
      setSubmitting(false);
    }
  }

  if (state.status === 'loading') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-4">
          <Skeleton className="h-5 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <Skeleton className="h-12 w-full rounded-lg" />
          <Skeleton className="h-12 w-full rounded-lg" />
          <Skeleton className="h-12 w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'invalid-installation') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Missing installation id.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            The URL is missing an <code className="font-mono text-xs">installation_id</code>{' '}
            parameter. Run the install flow so we land back here with one.{' '}
            <span className="text-xs text-muted-foreground">(no installation_id on URL)</span>
          </span>
          <Button asChild variant="outline" size="sm">
            <Link href="/connect">
              <Github className="size-4" aria-hidden /> Open the install flow
            </Link>
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load the repo list.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach GitHub to list the repos on this install. Retry in a moment, or
            re-run the install if it keeps failing.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => void load()}>
            <RefreshCw className="size-3.5" aria-hidden /> Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-3">
          <CardTitle className="text-base font-semibold">
            The install returned 0 repositories.
          </CardTitle>
          <CardDescription>
            GitHub confirmed the App install on installation{' '}
            <span className="font-mono text-foreground">#{state.installationId}</span>, but no repos
            were granted access. Re-run the install and tick at least one repo so Bivouac has
            something to watch.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2">
          <Button asChild variant="outline" size="sm">
            <Link href="/connect">
              <Github className="size-4" aria-hidden /> Re-run install
            </Link>
          </Button>
          <Button asChild variant="ghost" size="sm" className="gap-1.5">
            <Link href="/dashboard/repos">
              Go to repos <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  // ready
  const toggle = (githubNodeId: string, value: boolean) => {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return { ...prev, enabled: { ...prev.enabled, [githubNodeId]: value } };
    });
  };

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader className="space-y-2 pb-3">
        <CardTitle className="text-base font-semibold">
          Pick the repositories Bivouac should watch
        </CardTitle>
        <CardDescription>
          All repos are on by default — toggle any off to skip them. Bivouac scopes each one to its{' '}
          <span className="font-medium text-foreground">default branch</span> only; reading{' '}
          <span className="font-mono">code</span>, <span className="font-mono">contents</span>, and{' '}
          <span className="font-mono">pull requests</span> are the only scopes GitHub grants.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {grouped?.map(([owner, repos]) => (
          <section key={owner} className="flex flex-col gap-2">
            <header className="flex items-center justify-between gap-3 px-1">
              <h3 className="font-mono text-small text-foreground">@{owner}</h3>
              <span className="text-caption text-muted-foreground">
                {repos.filter((r) => state.enabled[r.githubNodeId]).length} / {repos.length}
              </span>
            </header>
            <ul className="flex flex-col divide-y divide-border/70 rounded-lg border border-border/70 bg-card/60">
              {repos.map((r) => {
                const checked = state.enabled[r.githubNodeId] ?? true;
                return (
                  <li
                    key={r.githubNodeId}
                    className="flex items-center gap-4 px-4 py-3 transition-colors hover:bg-muted/40"
                  >
                    <Switch
                      id={`repo-${r.githubNodeId}`}
                      checked={checked}
                      onCheckedChange={(value) => toggle(r.githubNodeId, value)}
                      aria-label={`Toggle ${r.ownerHandle}/${r.name}`}
                    />
                    <label
                      htmlFor={`repo-${r.githubNodeId}`}
                      className="grid min-w-0 flex-1 cursor-pointer gap-0.5"
                    >
                      <span className="truncate font-medium text-foreground">
                        {r.ownerHandle} / {r.name}
                      </span>
                      <span className="flex items-center gap-1 text-caption text-muted-foreground">
                        <GitBranch className="size-3.5" aria-hidden />
                        default branch <span className="font-mono">{r.defaultBranch}</span>
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </section>
        ))}

        {submitError ? (
          <Alert variant="destructive" className="border-destructive/40">
            <AlertTriangle className="size-4" aria-hidden />
            <AlertTitle>Could not save the selection.</AlertTitle>
            <AlertDescription>
              <span>{submitError}</span>{' '}
              <span className="text-xs text-muted-foreground">(retry the submit)</span>
            </AlertDescription>
          </Alert>
        ) : null}

        <Separator />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-small text-muted-foreground">
            <span className="text-foreground">{enabledCount}</span> of {state.repos.length}{' '}
            {state.repos.length === 1 ? 'repository' : 'repositories'} on watch.
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <Button asChild variant="ghost" size="sm" disabled={submitting}>
              <Link href="/connect">
                <Github className="size-4" aria-hidden /> Connect another repo
              </Link>
            </Button>
            <Button
              type="button"
              size="sm"
              className="gap-1.5 shadow-brand"
              onClick={() => void handleSubmit()}
              disabled={submitting}
            >
              {submitting ? (
                <>Saving…</>
              ) : (
                <>
                  Add {enabledCount} {enabledCount === 1 ? 'repository' : 'repositories'}
                  <ArrowRight className="size-4" aria-hidden />
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
