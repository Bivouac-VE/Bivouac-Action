// @polsia:user-owned — client island for /dashboard/repos/[id]. Owns:
//   - the header (identity + status badge + per-repo policy chip linked to
//     /dashboard/policy?repo={id} + the "Back to repositories" link)
//   - the three-tab layout ("Recent patches", "Activity feed",
//     "Detection settings") per the brief, all callers authenticated, none
//     of the page or layout owns db work
//   - per-tab fetch + loading/empty/error branches
//   - the 404 branch
//
// The page itself only exports `metadata` and forwards `{ id }` to this
// island. No Server Component awaits Prisma / apiFetch — every datum on the
// page (including the header) is fetched here via apiFetch.

'use client';

import {
  AlertTriangle,
  ArrowLeft,
  ClipboardList,
  Clock,
  ExternalLink,
  GitBranch,
  ShieldCheck,
  SlidersHorizontal,
} from 'lucide-react';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { apiFetch } from '@/lib/api-client';
import { type AuditLogAction, AuditLogList, type AuditLogRow } from '@/lib/contracts/audit-log';
import {
  DEFAULT_ACTION_LABEL,
  SCOPE_SHORT_LABEL,
  SEVERITY_SHORT_LABEL,
} from '@/lib/contracts/auto-merge-policy';
import {
  PatchList,
  type PatchListItem,
  type PatchMergeState,
  type PatchSeverity,
  RepoDetailHeader,
  type RepoDetailHeader as RepoDetailHeaderT,
} from '@/lib/contracts/repo-detail';
import { cn } from '@/lib/utils';
import { StatusBadge } from './status-badge';

type Tones = { tone: string; label: string };

const HEADER_SKELETON_IDS = ['hdr-a', 'hdr-b', 'hdr-c'] as const;
const ROW_SKELETON_IDS = ['row-a', 'row-b', 'row-c', 'row-d', 'row-e'] as const;

const SEVERITY_LABEL: Record<PatchSeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const MERGE_LABEL: Record<PatchMergeState, string> = {
  'auto-merged': 'Auto-merged',
  open: 'Open',
  declined: 'Declined',
  'paged-human': 'Paged human',
};

const ACTION_LABEL: Record<AuditLogAction, string> = {
  'auto-merged': 'Auto-merged',
  downgraded: 'Downgraded',
  paged: 'Paged',
  declined: 'Declined',
  exported: 'Exported',
};

function severityTone(s: PatchSeverity): Tones {
  switch (s) {
    case 'critical':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: SEVERITY_LABEL[s],
      };
    case 'high':
      return {
        tone: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
        label: SEVERITY_LABEL[s],
      };
    case 'medium':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: SEVERITY_LABEL[s],
      };
    case 'low':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: SEVERITY_LABEL[s],
      };
  }
}

function mergeTone(m: PatchMergeState): Tones {
  switch (m) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: MERGE_LABEL[m],
      };
    case 'paged-human':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: MERGE_LABEL[m],
      };
    case 'declined':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: MERGE_LABEL[m],
      };
    case 'open':
      return {
        tone: 'border-border bg-muted text-muted-foreground',
        label: MERGE_LABEL[m],
      };
  }
}

function actionTone(action: AuditLogAction): Tones {
  switch (action) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: ACTION_LABEL[action],
      };
    case 'downgraded':
    case 'paged':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: ACTION_LABEL[action],
      };
    case 'declined':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: ACTION_LABEL[action],
      };
    case 'exported':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: ACTION_LABEL[action],
      };
  }
}

// Positional cron (`[minute, hour, day-of-month, month, day-of-week]`) → a
// human "Daily at HH:MM UTC" label. Falls back to the raw schedule string if
// the format drifts. Source-of-truth for the cadence line on the Detection tab.
function cronScheduleLabel(schedule: string): string {
  const rawParts = schedule.trim().split(/\s+/);
  if (rawParts.length !== 5) return schedule;
  const [minute, hour, day, month, dow] = rawParts;
  if (!minute || !hour || !day || !month || !dow) return schedule;
  if (day !== '*' || month !== '*' || dow !== '*') return schedule;
  if (minute === '*' && hour === '*') return `Every minute`;
  if (hour === '*') return `Hourly at minute ${minute}`;
  if (minute === '*') return `Every minute of ${hour}:00`;
  const hh = hour.padStart(2, '0');
  const mm = minute.padStart(2, '0');
  return `Daily at ${hh}:${mm} UTC`;
}

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function isNotFound(err: unknown): boolean {
  if (!(err instanceof Error)) return false;
  if (err.message.includes('(404)')) return true;
  const cause = (err as { cause?: unknown }).cause;
  if (cause && typeof cause === 'object' && cause !== null) {
    const status = (cause as { status?: unknown }).status;
    if (status === 404) return true;
  }
  return false;
}

export function RepoDetail({ id }: { id: string }) {
  const [headerState, setHeaderState] = useState<
    | { status: 'loading' }
    | { status: 'ready'; header: RepoDetailHeaderT }
    | { status: 'not-found' }
    | { status: 'error'; message: string }
  >({ status: 'loading' });

  useEffect(() => {
    let active = true;
    if (!id) {
      setHeaderState({ status: 'not-found' });
      return () => {
        active = false;
      };
    }
    apiFetch(`/api/dashboard/repos/${encodeURIComponent(id)}`, {
      schema: RepoDetailHeader,
    })
      .then((header) => {
        if (active) setHeaderState({ status: 'ready', header });
      })
      .catch((err: unknown) => {
        if (!active) return;
        if (isNotFound(err)) {
          setHeaderState({ status: 'not-found' });
          return;
        }
        const msg = err instanceof Error ? err.message : 'Could not load this repository.';
        setHeaderState({ status: 'error', message: msg });
      });
    return () => {
      active = false;
    };
  }, [id]);

  if (headerState.status === 'not-found') {
    return <RepoNotFound />;
  }

  if (headerState.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load this repository.</AlertTitle>
        <AlertDescription>
          {headerState.message}{' '}
          <Link
            href="/dashboard/repos"
            className="underline decoration-dotted underline-offset-4 hover:text-foreground"
          >
            Back to repositories
          </Link>
          .
        </AlertDescription>
      </Alert>
    );
  }

  if (headerState.status === 'loading' || headerState.status === 'ready') {
    const header = headerState.status === 'ready' ? headerState.header : null;
    const slug = header ? `${header.ownerHandle}/${header.name}` : '';

    return (
      <div className="flex flex-col gap-section">
        <Button asChild variant="ghost" size="sm" className="self-start gap-1.5">
          <Link href="/dashboard/repos">
            <ArrowLeft className="size-4" aria-hidden /> Back to repositories
          </Link>
        </Button>

        {header ? (
          <RepoDetailHeaderView header={header} repoSlug={slug} />
        ) : (
          <RepoDetailHeaderSkeleton />
        )}

        <Tabs defaultValue="patches" className="flex flex-col gap-4">
          <TabsList
            aria-label="Repository detail tabs"
            className="bg-card/60 border border-border/70 p-1"
          >
            <TabsTrigger value="patches">Recent patches</TabsTrigger>
            <TabsTrigger value="activity">Activity feed</TabsTrigger>
            <TabsTrigger value="detection">Detection settings</TabsTrigger>
          </TabsList>

          <TabsContent value="patches" className="m-0">
            {header ? <RepoDetailPatchesTab repoId={header.id} slug={slug} /> : <RowSkeletonList />}
          </TabsContent>

          <TabsContent value="activity" className="m-0">
            {header ? (
              <RepoDetailAuditTab slug={slug} ownerHandle={header.ownerHandle} name={header.name} />
            ) : (
              <RowSkeletonList />
            )}
          </TabsContent>

          <TabsContent value="detection" className="m-0">
            {header ? <RepoDetailDetectionTab header={header} /> : <DetectionTabSkeleton />}
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  return null;
}

function RepoDetailHeaderView({
  header,
  repoSlug,
}: {
  header: RepoDetailHeaderT;
  repoSlug: string;
}) {
  const repoUrl = `https://github.com/${header.ownerHandle}/${header.name}`;
  const policyHref = `/dashboard/policy?repo=${encodeURIComponent(header.id)}`;

  const policyDescriptor = useMemo(() => {
    const scope = SCOPE_SHORT_LABEL[header.policy.scopeMode];
    const sev = SEVERITY_SHORT_LABEL[header.policy.minSeverity];
    const act = DEFAULT_ACTION_LABEL[header.policy.defaultAction];
    return `${scope} · ${sev}+ · ${act}`;
  }, [header.policy]);

  return (
    <header className="flex flex-col gap-4 rounded-lg border border-border/70 bg-card/80 p-5 shadow-sm backdrop-blur">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex min-w-0 flex-col gap-1.5">
          <p className="text-eyebrow">Repository</p>
          <h1 className="font-display text-h2 break-all text-foreground">
            <span className="font-mono text-muted-foreground">@{header.ownerHandle}</span>
            <span aria-hidden> / </span>
            <span>{header.name}</span>
          </h1>
          <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-small text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <GitBranch className="size-3.5" aria-hidden />
              <span className="text-xs uppercase tracking-wide text-muted-foreground/80">
                default branch
              </span>
              <span className="font-mono text-foreground">{header.defaultBranch}</span>
            </span>
            <span aria-hidden className="h-3 w-px bg-border" />
            <a
              href={repoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
            >
              {repoSlug}
              <ExternalLink className="size-3.5" aria-hidden />
            </a>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={header.status} />
          {header.activePack ? (
            <Badge
              variant="outline"
              className="border-border/70 bg-card/60 font-medium text-foreground/80"
              title={`Active policy pack: ${header.activePack.packTitle}`}
            >
              <ClipboardList className="size-3.5 text-brand-600 dark:text-brand-400" aria-hidden />
              <span className="font-mono text-caption tracking-normal">
                Pack: {header.activePack.packTitle}
              </span>
            </Badge>
          ) : null}
        </div>
      </div>

      <Separator />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button asChild variant="outline" size="sm" className="gap-1.5">
          <Link href={policyHref}>
            <SlidersHorizontal className="size-4 text-brand-600 dark:text-brand-400" aria-hidden />
            <span className="font-mono text-caption">Auto-merge: {policyDescriptor}</span>
            <span aria-hidden className="text-xs text-muted-foreground">
              →
            </span>
          </Link>
        </Button>
        <p className="text-caption text-muted-foreground">
          Opens the global policy page so you can edit scope / severity / action / page-a-human
          rules.
        </p>
      </div>
    </header>
  );
}

function RepoDetailHeaderSkeleton() {
  return (
    <header className="flex flex-col gap-4 rounded-lg border border-border/70 bg-card/80 p-5 shadow-sm backdrop-blur">
      <span className="sr-only">Loading repository header</span>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex min-w-0 flex-col gap-2">
          <Skeleton className="h-3 w-24" />
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-48" />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {HEADER_SKELETON_IDS.map((id) => (
            <Skeleton key={id} className="h-6 w-28 rounded-md" />
          ))}
        </div>
      </div>
      <Skeleton className="h-px w-full" />
      <Skeleton className="h-9 w-72 rounded-md" />
    </header>
  );
}

function RowSkeletonList() {
  return (
    <Card aria-busy="true">
      <CardContent className="flex flex-col gap-2 py-6">
        {ROW_SKELETON_IDS.map((id) => (
          <Skeleton key={id} className="h-12 w-full rounded-md" />
        ))}
      </CardContent>
    </Card>
  );
}

// Recent-patches tab — per-repo `PatchList`. Reuses the rows+chips from the
// existing `patch-list-card` markup, minus the card chrome and the empty-state
// prose (this tab lives inside the drilldown shell, so the empty state has
// its own short copy).
function RepoDetailPatchesTab({ repoId, slug }: { repoId: string; slug: string }) {
  type State =
    | { status: 'loading' }
    | { status: 'ready'; items: PatchListItem[] }
    | { status: 'empty' }
    | { status: 'error'; message: string };
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch(`/api/dashboard/repo-patches?repo=${encodeURIComponent(repoId)}&limit=50`, {
      schema: PatchList,
    })
      .then((data) => {
        if (!active) return;
        if (data.items.length === 0) {
          setState({ status: 'empty' });
        } else {
          setState({ status: 'ready', items: data.items });
        }
      })
      .catch((err: unknown) => {
        if (!active) return;
        const msg =
          err instanceof Error ? err.message : 'Could not load recent patches for this repo.';
        setState({ status: 'error', message: msg });
      });
    return () => {
      active = false;
    };
  }, [repoId]);

  if (state.status === 'loading') {
    return <RowSkeletonList />;
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load recent patches.</AlertTitle>
        <AlertDescription>{state.message}</AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <Card>
        <CardContent className="flex flex-col gap-2 py-8 text-small text-muted-foreground">
          <p>No patch PRs opened for {slug} yet.</p>
          <p>
            Patches show up here once the cve-triage-poll cron finds a CVE or breaking change in
            this repository&apos;s dependency graph.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-h4">
          {state.items.length} {state.items.length === 1 ? 'recent patch' : 'recent patches'}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ul className="flex flex-col divide-y divide-border/70">
          {state.items.map((row) => {
            const sev = severityTone(row.severity);
            const merge = mergeTone(row.mergeState);
            return (
              <li key={row.id}>
                <Link
                  href={`/dashboard/patches/${encodeURIComponent(row.id)}`}
                  className={cn(
                    'group flex flex-col gap-2 px-5 py-4 transition-colors',
                    'hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="font-display text-base font-semibold text-balance text-foreground group-hover:text-brand-700 dark:group-hover:text-brand-300">
                      {row.title}
                    </p>
                    <span className="shrink-0 text-caption text-muted-foreground">
                      <time dateTime={row.createdAt}>{formatTimestamp(row.createdAt)}</time>
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-caption text-muted-foreground">
                    <span className="font-mono text-foreground/80">{row.cveId}</span>
                    <span aria-hidden>·</span>
                    <span className="font-mono">
                      {row.packageName}@
                      <span className="text-muted-foreground">{row.fromVersion}</span> →{' '}
                      <span className="font-semibold text-foreground">{row.toVersion}</span>
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className={sev.tone}>
                      {sev.label} severity
                    </Badge>
                    <Badge variant="outline" className={merge.tone}>
                      {merge.label}
                    </Badge>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

// Activity feed tab — pulls /api/audit-log?repo={slug}&limit=100, mirrors the
// /dashboard/audit row schema but in a compact drilldown variant. The
// footer link "View all in audit log" round-trips through to the full page
// with the same `?repo=` filter so filters survive a click.
function RepoDetailAuditTab({
  slug,
  ownerHandle,
  name,
}: {
  slug: string;
  ownerHandle: string;
  name: string;
}) {
  type State =
    | { status: 'loading' }
    | { status: 'ready'; rows: AuditLogRow[] }
    | { status: 'empty' }
    | { status: 'error'; message: string };
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let active = true;
    const href = `/api/audit-log?repo=${encodeURIComponent(slug)}&limit=100`;
    apiFetch(href, { schema: AuditLogList })
      .then((data) => {
        if (!active) return;
        if (data.items.length === 0) {
          setState({ status: 'empty' });
        } else {
          setState({ status: 'ready', rows: data.items });
        }
      })
      .catch((err: unknown) => {
        if (!active) return;
        const msg =
          err instanceof Error ? err.message : 'Could not load the activity feed for this repo.';
        setState({ status: 'error', message: msg });
      });
    return () => {
      active = false;
    };
  }, [slug]);

  const auditHref = `/dashboard/audit?repo=${encodeURIComponent(slug)}`;

  if (state.status === 'loading') {
    return <RowSkeletonList />;
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load the activity feed.</AlertTitle>
        <AlertDescription>
          {state.message}{' '}
          <Link
            href={auditHref}
            className="underline decoration-dotted underline-offset-4 hover:text-foreground"
          >
            Try the full audit log
          </Link>
          .
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">
            @{ownerHandle}/{name}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-2 py-6 text-small text-muted-foreground">
          <p>No triage events for this repository yet.</p>
          <p>
            Activity shows up here once the cron opens a patch PR on this repo — every detected
            advisory, opened PR, test run, and merge decision lands in this feed.{' '}
            <Link
              href={auditHref}
              className="underline decoration-dotted underline-offset-4 hover:text-foreground"
            >
              Browse the full audit log
            </Link>
            .
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0">
        <CardTitle className="font-display text-h4">
          {state.rows.length} {state.rows.length === 1 ? 'event' : 'events'}
        </CardTitle>
        <Button asChild variant="ghost" size="sm" className="gap-1.5">
          <Link href={auditHref}>
            View all in audit log
            <span aria-hidden>↗</span>
          </Link>
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>When</TableHead>
              <TableHead>CVE / Event</TableHead>
              <TableHead>Package · version</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {state.rows.map((row) => {
              const actionBadge = actionTone(row.action);
              return (
                <TableRow key={row.id}>
                  <TableCell className="text-caption text-muted-foreground">
                    <time dateTime={row.createdAt}>{formatTimestamp(row.createdAt)}</time>
                  </TableCell>
                  <TableCell className="font-mono text-caption text-foreground">
                    {row.cveId ?? (
                      <span className="inline-flex items-center gap-1.5 text-amber-700 dark:text-amber-300">
                        <span className="font-mono">{row.packageName}</span>
                        <Badge
                          variant="outline"
                          className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                        >
                          Breaking
                        </Badge>
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-small text-muted-foreground">
                    {row.fromVersion} → <span className="text-foreground">{row.toVersion}</span>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={actionBadge.tone}>
                      {actionBadge.label}
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

// Detection tab — read-only summary. Today the cron schedule is in fact
// `{{CRON_SCHEDULE}}`; surfaced here as a literal aside from the contract.
// The "CVE / breaking-change subscription" copy is derived from
// `policy.scopeMode`. The CTA points to the editable policy form.
function RepoDetailDetectionTab({ header }: { header: RepoDetailHeaderT }) {
  const cadence = cronScheduleLabel(header.cronSchedule);
  const scope = SCOPE_SHORT_LABEL[header.policy.scopeMode];
  const minSev = SEVERITY_SHORT_LABEL[header.policy.minSeverity];
  const defaultAction = DEFAULT_ACTION_LABEL[header.policy.defaultAction];
  const policyHref = `/dashboard/policy?repo=${encodeURIComponent(header.id)}`;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-h4">
          <ShieldCheck aria-hidden className="size-4 text-brand-700 dark:text-brand-300" />
          Detection settings
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <dl className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5 rounded-md border border-border/70 bg-card/40 p-4">
            <dt className="text-eyebrow">Subscription</dt>
            <dd className="font-mono text-body-lg text-foreground">{scope}</dd>
            <dd className="text-small text-muted-foreground">
              Triggers autonomous merges for {scope.toLowerCase()} on this repo.
            </dd>
          </div>
          <div className="flex flex-col gap-1.5 rounded-md border border-border/70 bg-card/40 p-4">
            <dt className="text-eyebrow">Severity floor</dt>
            <dd className="font-mono text-body-lg text-foreground">{minSev}+</dd>
            <dd className="text-small text-muted-foreground">
              CVEs scored below {minSev.toLowerCase()} stay informational.
            </dd>
          </div>
          <div className="flex flex-col gap-1.5 rounded-md border border-border/70 bg-card/40 p-4">
            <dt className="text-eyebrow">Default action</dt>
            <dd className="font-mono text-body-lg text-foreground">{defaultAction}</dd>
            <dd className="text-small text-muted-foreground">
              What Bivouac does once a change passes scope and clear of every guardrail.
            </dd>
          </div>
          <div className="flex flex-col gap-1.5 rounded-md border border-border/70 bg-card/40 p-4">
            <dt className="flex items-center gap-1.5 text-eyebrow">
              <Clock className="size-3.5 text-brand-600 dark:text-brand-400" aria-hidden />
              Polling cadence
            </dt>
            <dd className="font-mono text-body-lg text-foreground">{cadence}</dd>
            <dd className="text-small text-muted-foreground">
              cve-triage-poll · schedule <span className="font-mono">{header.cronSchedule}</span>
            </dd>
          </div>
        </dl>

        <Separator />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-col gap-1">
            <p className="text-small font-medium text-foreground">
              Policy is global — applies to all your connected repos
            </p>
            <p className="text-small text-muted-foreground">
              Edits go through the same form other tabs read from. No per-repo override today.
            </p>
          </div>
          <Button asChild className="gap-1.5 shadow-brand">
            <Link href={policyHref}>
              <SlidersHorizontal className="size-4" aria-hidden />
              Edit in policy
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function DetectionTabSkeleton() {
  return (
    <Card aria-busy="true">
      <CardContent className="flex flex-col gap-4 py-6">
        <Skeleton className="h-6 w-48" />
        <div className="grid gap-4 sm:grid-cols-2">
          {['det-a', 'det-b', 'det-c', 'det-d'].map((id) => (
            <Skeleton key={id} className="h-24 w-full rounded-md" />
          ))}
        </div>
        <Skeleton className="h-10 w-40 rounded-md" />
      </CardContent>
    </Card>
  );
}

function RepoNotFound() {
  return (
    <div className="flex flex-col gap-section">
      <Button asChild variant="ghost" size="sm" className="self-start gap-1.5">
        <Link href="/dashboard/repos">
          <ArrowLeft className="size-4" aria-hidden /> Back to repositories
        </Link>
      </Button>
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Repository not found</AlertTitle>
        <AlertDescription>
          That repository id either does not exist on this account or has been removed.{' '}
          <Link
            href="/dashboard/repos"
            className="underline decoration-dotted underline-offset-4 hover:text-foreground"
          >
            Back to repositories
          </Link>
          .
        </AlertDescription>
      </Alert>
    </div>
  );
}
