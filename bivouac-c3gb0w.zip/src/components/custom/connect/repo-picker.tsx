// @polsia:user-owned — client island for /dashboard/connect/repo. The
// "pick ONE repo" step in the Connect-a-repo flow. On mount fetches the
// repos the freshly-completed GitHub App install granted access to (via
// the shared /api/github/installation/[installationId]/repos endpoint, so
// it shares the IDOR guard with the multi-toggle sibling surface). The user
// filters the list client-side, picks one card, and on confirm POSTs the
// pick to /api/connected-repos and routes to /dashboard/repos so the new
// entry shows up immediately.
//
// State machine: loading → (invalid-installation | ready | error | empty).

'use client';

import {
  AlertTriangle,
  ArrowRight,
  GitBranch,
  Github,
  Lock,
  RefreshCw,
  Search,
  Unlock,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  ConnectedRepoSelectInput,
  ConnectedRepoSelectResult,
} from '@/lib/contracts/connected-repos';
import { type GithubInstallationRepo, GithubInstallationRepoList } from '@/lib/contracts/repos';

type PickerState =
  | { status: 'loading' }
  | {
      status: 'ready';
      installationId: string;
      repos: GithubInstallationRepo[];
      selectedGitHubNodeId: string | null;
    }
  | { status: 'error'; message: string }
  | { status: 'empty'; installationId: string }
  | { status: 'invalid-installation' };

function readInstallationIdFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  const params = new URLSearchParams(window.location.search);
  const raw = params.get('installation_id');
  return raw && /^\d+$/.test(raw) ? raw : null;
}

const SKELETON_IDS = ['a', 'b', 'c', 'd', 'e', 'f'] as const;

export function RepoPicker() {
  const [state, setState] = useState<PickerState>({ status: 'loading' });
  const [filter, setFilter] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    const installationId = readInstallationIdFromUrl();
    if (!installationId) {
      setState({ status: 'invalid-installation' });
      return;
    }
    try {
      const data = await apiFetch(
        `/api/github/installation/${encodeURIComponent(installationId)}/repos`,
        { schema: GithubInstallationRepoList },
      );
      if (data.items.length === 0) {
        setState({ status: 'empty', installationId });
        return;
      }
      setState({
        status: 'ready',
        installationId,
        repos: data.items,
        selectedGitHubNodeId: null,
      });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Unknown error fetching picker.';
      const status =
        err && typeof err === 'object' && 'cause' in err
          ? ((err as { cause?: { status?: number } }).cause?.status ?? null)
          : null;
      if (status === 404 || status === 403) {
        setState({ status: 'invalid-installation' });
        return;
      }
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const filteredRepos = useMemo(() => {
    if (state.status !== 'ready') return [];
    const needle = filter.trim().toLowerCase();
    if (!needle) return state.repos;
    return state.repos.filter((r) => {
      const owner = r.ownerHandle.toLowerCase();
      const name = r.name.toLowerCase();
      return owner.includes(needle) || name.includes(needle) || `${owner}/${name}`.includes(needle);
    });
  }, [state, filter]);

  const handleSelect = useCallback((githubNodeId: string) => {
    setState((prev) => {
      if (prev.status !== 'ready') return prev;
      return {
        ...prev,
        selectedGitHubNodeId: prev.selectedGitHubNodeId === githubNodeId ? null : githubNodeId,
      };
    });
  }, []);

  async function handleConfirm() {
    if (state.status !== 'ready') return;
    if (!state.selectedGitHubNodeId) return;
    const picked = state.repos.find((r) => r.githubNodeId === state.selectedGitHubNodeId);
    if (!picked) return;
    setSubmitting(true);
    try {
      const body = ConnectedRepoSelectInput.parse({
        installationId: state.installationId,
        githubNodeId: picked.githubNodeId,
        githubRepoId: picked.githubRepoId,
        name: picked.name,
        ownerHandle: picked.ownerHandle,
        defaultBranch: picked.defaultBranch,
      });
      const result = await apiFetch('/api/connected-repos', {
        method: 'POST',
        body: JSON.stringify(body),
        schema: ConnectedRepoSelectResult,
      });
      toast.success(
        `Connected ${result.repo.ownerHandle}/${result.repo.name} — Bivouac starts scanning it shortly.`,
        { description: 'Opening your repositories dashboard…' },
      );
      router.push('/dashboard/repos');
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not save the selected repo.';
      toast.error('Could not connect that repository.', { description: reason });
      setSubmitting(false);
    }
  }

  if (state.status === 'loading') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-4">
          <Skeleton className="h-5 w-56" />
          <Skeleton className="h-4 w-72" />
          <Skeleton className="h-9 w-full rounded-md" />
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          {SKELETON_IDS.map((id) => (
            <Skeleton key={id} className="h-20 w-full rounded-lg" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'invalid-installation') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Missing installation id.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            The URL is missing an <code className="font-mono text-xs">installation_id</code>{' '}
            parameter. Run the install flow so we land back here with one.{' '}
            <span className="text-xs text-muted-foreground">(no installation_id on URL)</span>
          </span>
          <Button asChild variant="outline" size="sm">
            <Link href="/connect">
              <Github className="size-4" aria-hidden /> Open the install flow
            </Link>
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load the repo list.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach GitHub to list the repos on this install. Retry in a moment, or
            re-run the install if it keeps failing.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => void load()}>
            <RefreshCw className="size-3.5" aria-hidden /> Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-3">
          <CardTitle className="text-base font-semibold">
            The install returned 0 repositories.
          </CardTitle>
          <CardDescription>
            GitHub confirmed the App install on installation{' '}
            <span className="font-mono text-foreground">#{state.installationId}</span>, but no repos
            were granted access. Re-run the install and tick at least one repo so Bivouac has
            something to watch on the dashboard.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2">
          <Button asChild variant="outline" size="sm">
            <Link href="/connect">
              <Github className="size-4" aria-hidden /> Re-run install
            </Link>
          </Button>
          <Button asChild variant="ghost" size="sm" className="gap-1.5">
            <Link href="/dashboard/repos">
              Go to repos <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  // ready
  const selectedRepo = state.selectedGitHubNodeId
    ? (state.repos.find((r) => r.githubNodeId === state.selectedGitHubNodeId) ?? null)
    : null;

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader className="space-y-2 pb-3">
        <CardTitle className="text-base font-semibold">
          Pick the repository to put on watch
        </CardTitle>
        <CardDescription>
          Bivouac scopes each one to its{' '}
          <span className="font-medium text-foreground">default branch</span> only; reading{' '}
          <span className="font-mono">code</span>, <span className="font-mono">contents</span>, and{' '}
          <span className="font-mono">pull requests</span> are the only scopes GitHub grants. You
          can connect more later from the dashboard.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            type="search"
            placeholder="Filter by owner or repo name…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-9"
            aria-label="Filter repositories"
          />
        </div>

        {filteredRepos.length === 0 ? (
          <p className="rounded-md border border-dashed border-border bg-muted/40 px-4 py-6 text-center text-small text-muted-foreground">
            No repositories match <span className="font-mono text-foreground">{filter.trim()}</span>
            .
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {filteredRepos.map((r) => (
              <RepoRow
                key={r.githubNodeId}
                repo={r}
                selected={state.selectedGitHubNodeId === r.githubNodeId}
                onSelect={() => handleSelect(r.githubNodeId)}
              />
            ))}
          </ul>
        )}

        <Separator />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-small text-muted-foreground">
            {selectedRepo ? (
              <>
                <span className="text-foreground">Selected:</span>{' '}
                <span className="font-mono text-foreground">
                  {selectedRepo.ownerHandle}/{selectedRepo.name}
                </span>
              </>
            ) : (
              'Select one repository to confirm.'
            )}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <Button asChild variant="ghost" size="sm" disabled={submitting}>
              <Link href="/connect">
                <Github className="size-4" aria-hidden /> Connect another repo
              </Link>
            </Button>
            <Button
              type="button"
              size="sm"
              className="gap-1.5 shadow-brand"
              onClick={() => void handleConfirm()}
              disabled={!selectedRepo || submitting}
              aria-label={
                selectedRepo
                  ? `Confirm ${selectedRepo.ownerHandle}/${selectedRepo.name}`
                  : 'Confirm selected repository'
              }
            >
              {submitting ? (
                'Saving…'
              ) : (
                <>
                  Confirm selection
                  <ArrowRight className="size-4" aria-hidden />
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface RepoRowProps {
  repo: GithubInstallationRepo;
  selected: boolean;
  onSelect: () => void;
}

function RepoRow({ repo, selected, onSelect }: RepoRowProps) {
  const isPrivate = repo.visibility === 'private';
  return (
    <li>
      <button
        type="button"
        onClick={onSelect}
        aria-pressed={selected}
        aria-label={`Select ${repo.ownerHandle}/${repo.name}`}
        className={[
          'flex w-full flex-col gap-2 rounded-lg border bg-card/60 p-4 text-left transition-colors',
          'hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          selected
            ? 'border-brand-500/60 bg-brand-50/40 shadow-brand dark:bg-brand-900/20'
            : 'border-border/70',
        ].join(' ')}
      >
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-small text-muted-foreground">@{repo.ownerHandle}</span>
          <span aria-hidden className="text-small text-border">
            /
          </span>
          <span className="truncate font-medium text-foreground">{repo.name}</span>
          <Badge
            variant={isPrivate ? 'secondary' : 'outline'}
            className="gap-1.5"
            aria-label={isPrivate ? 'Private repository' : 'Public repository'}
          >
            {isPrivate ? (
              <Lock className="size-3" aria-hidden />
            ) : (
              <Unlock className="size-3" aria-hidden />
            )}
            {isPrivate ? 'Private' : 'Public'}
          </Badge>
          <span
            aria-hidden
            className={[
              'ml-auto size-4 shrink-0 rounded-full border-2 transition-colors',
              selected ? 'border-brand-600 bg-brand-600' : 'border-border bg-background',
            ].join(' ')}
          />
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-caption text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <GitBranch className="size-3.5" aria-hidden />
            default branch <span className="font-mono text-foreground">{repo.defaultBranch}</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span aria-hidden className="size-1.5 rounded-full bg-emerald-500" />
            {lastActivityLabel(repo)}
          </span>
        </div>
      </button>
    </li>
  );
}

function lastActivityLabel(repo: GithubInstallationRepo): string {
  if (!repo.pushedAt) return 'Activity unknown';
  const at = new Date(repo.pushedAt);
  if (Number.isNaN(at.getTime())) return 'Activity unknown';
  const deltaMs = Date.now() - at.getTime();
  const formatter = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
  const MINUTE = 60_000;
  const HOUR = 60 * MINUTE;
  const DAY = 24 * HOUR;
  if (Math.abs(deltaMs) < HOUR) {
    return `last activity ${formatter.format(-Math.round(deltaMs / MINUTE), 'minute')}`;
  }
  if (Math.abs(deltaMs) < DAY) {
    return `last activity ${formatter.format(-Math.round(deltaMs / HOUR), 'hour')}`;
  }
  return `last activity ${formatter.format(-Math.round(deltaMs / DAY), 'day')}`;
}
