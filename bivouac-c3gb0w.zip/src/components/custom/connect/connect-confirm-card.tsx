// @polsia:user-owned — client island for /connect/confirm. Re-reads the
// connected installations via /api/connect/installs (the URL may include an
// `installation_id` query string but we always render the full list — the
// caller can scroll back to it later). Loading/error/empty/data states map
// 1:1 to the four render paths the data plane requires.

'use client';

import { AlertTriangle, ArrowRight, GitBranch, Github, Lock, RefreshCw } from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  ConnectInstallationList,
  type ConnectInstallationWithRepos,
} from '@/lib/contracts/connect';

type ConfirmState =
  | { status: 'loading' }
  | { status: 'ready'; items: ConnectInstallationWithRepos[] }
  | { status: 'error'; message: string }
  | { status: 'empty' };

function readInstallationIdFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  const params = new URLSearchParams(window.location.search);
  const raw = params.get('installation_id');
  return raw && /^\d+$/.test(raw) ? raw : null;
}

export function ConnectConfirmCard() {
  const [state, setState] = useState<ConfirmState>({ status: 'loading' });
  const [focusedId, setFocusedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    setFocusedId(readInstallationIdFromUrl());
    try {
      const data = await apiFetch('/api/connect/installs', {
        schema: ConnectInstallationList,
      });
      if (data.items.length === 0) {
        setState({ status: 'empty' });
        return;
      }
      setState({ status: 'ready', items: data.items });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Unknown error fetching installs.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.status === 'loading') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-4">
          <Skeleton className="h-5 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <Skeleton className="h-12 w-full rounded-lg" />
          <Skeleton className="h-12 w-full rounded-lg" />
          <Skeleton className="h-12 w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load your installations.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach the install listing right now. Retry in a moment, or contact us if
            this keeps failing.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => void load()}>
            <RefreshCw className="size-3.5" aria-hidden /> Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return (
      <Alert className="border-border bg-card">
        <AlertTitle>No installations found for this account.</AlertTitle>
        <AlertDescription className="text-muted-foreground">
          The callback fired but no installs are linked to this session.{' '}
          <Link
            href="/connect"
            className="text-brand-600 font-medium hover:underline underline-offset-4"
          >
            Try the install flow again
          </Link>
          .
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {state.items.map((install) => {
        const isFocused = focusedId === install.installationId;
        return (
          <Card
            key={install.installationId}
            className={
              isFocused ? 'border-brand-500/40 shadow-brand' : 'border-border/70 shadow-sm'
            }
          >
            <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-3">
              <div className="grid min-w-0 gap-1">
                <CardTitle className="flex items-center gap-2 text-base font-semibold">
                  <Github className="size-4 shrink-0 text-brand-600" aria-hidden />
                  <span className="truncate font-mono text-foreground">
                    @{install.account.login}
                  </span>
                </CardTitle>
                <CardDescription>
                  Bivouac App installed on{' '}
                  <span className="text-foreground">
                    {install.account.type === 'Organization' ? 'organization' : 'user'}
                  </span>{' '}
                  <span className="font-mono">@{install.account.login}</span>
                  {isFocused ? ' (just confirmed)' : ''}.
                </CardDescription>
              </div>
              <Badge variant="secondary" className="gap-1.5">
                <span className="size-1.5 rounded-full bg-emerald-500" />
                Active
              </Badge>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {install.repos.length === 0 ? (
                <p className="rounded-md border border-dashed border-border bg-muted/40 px-4 py-3 text-small text-muted-foreground">
                  No repositories were selected during this install. Re-run the install and tick the
                  repos you want on watch.
                </p>
              ) : (
                <ul className="flex flex-col divide-y divide-border/70 rounded-lg border border-border/70 bg-card/60">
                  {install.repos.map((repo) => (
                    <li key={repo.githubNodeId} className="flex items-center gap-3 px-4 py-3">
                      <span className="font-mono text-small text-muted-foreground">
                        @{repo.ownerHandle}
                      </span>
                      <span aria-hidden className="text-small text-border">
                        /
                      </span>
                      <span className="truncate font-medium text-foreground">{repo.name}</span>
                      <span className="ml-auto inline-flex items-center gap-1 text-caption text-muted-foreground">
                        <GitBranch className="size-3.5" aria-hidden />
                        {repo.defaultBranch}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="text-small text-muted-foreground">
                {install.repos.length === 0
                  ? 'No triage will run until you re-install and pick at least one repo.'
                  : `${install.repos.length} ${
                      install.repos.length === 1 ? 'repository' : 'repositories'
                    } on watch. Bivouac will start scanning each on its default branch within the next minute.`}
              </p>
            </CardContent>
          </Card>
        );
      })}

      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
        <p className="text-small text-muted-foreground">
          Want to enroll repos from a different GitHub account? Run the install again.
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <Button asChild variant="outline" size="sm" className="gap-1.5">
            <Link href="/connect">
              <Github className="size-4" aria-hidden /> Connect another account
            </Link>
          </Button>
          {focusedId ? (
            <Button asChild variant="secondary" size="sm" className="gap-1.5">
              <Link href={`/connect/repo?installation_id=${encodeURIComponent(focusedId)}`}>
                <Lock className="size-4" aria-hidden /> Pick a single repo
              </Link>
            </Button>
          ) : null}
          <Button asChild size="sm" className="gap-1.5 shadow-brand">
            <Link
              href={
                focusedId
                  ? `/dashboard/repos/connect?installation_id=${encodeURIComponent(focusedId)}`
                  : '/dashboard/repos'
              }
            >
              {focusedId ? (
                <>
                  Pick repositories <ArrowRight className="size-4" aria-hidden />
                </>
              ) : (
                <>
                  Go to dashboard <ArrowRight className="size-4" aria-hidden />
                </>
              )}
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
