// @polsia:user-owned — client island for /connect. Owns the four render
// states the data plane demands (loading/ready/error/unconfigured) and the
// primary install button. The button does a SAME-WINDOW redirect via
// `window.location.href` (NOT `target="_blank"`) because the round-trip
// has to keep the better-auth session cookie in scope — and on return we
// land on /connect/confirm which the dashboard-shell then renders.
//
// The page itself stays a Server Component that exports `metadata`.

'use client';

import { AlertTriangle, Github, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import { ConnectInstallUrl } from '@/lib/contracts/connect';
import { ConnectScopeList } from './connect-scope-list';

type InstallState =
  | { status: 'loading' }
  | { status: 'ready'; url: string; appName: string; appId: string }
  | { status: 'error'; message: string }
  | { status: 'unconfigured' };

function isUnconfiguredCause(body: unknown): boolean {
  if (typeof body !== 'object' || body === null) return false;
  const record = body as { error?: unknown };
  if (typeof record.error !== 'string') return false;
  const msg = record.error.toLowerCase();
  return (
    msg.includes('github_app_slug') ||
    msg.includes('github_app_id') ||
    msg.includes('github_app_private_key') ||
    msg.includes('github_app_state_secret')
  );
}

export function ConnectInstallCard() {
  const [state, setState] = useState<InstallState>({ status: 'loading' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/connect/install-url', {
        schema: ConnectInstallUrl,
      });
      const appId = data.appId ?? '';
      if (!data.appId) {
        setState({ status: 'unconfigured' });
        return;
      }
      setState({ status: 'ready', url: data.url, appName: data.appName, appId });
    } catch (err: unknown) {
      if (err instanceof Error && isUnconfiguredCause(err.cause)) {
        setState({ status: 'unconfigured' });
        return;
      }
      const reason = err instanceof Error ? err.message : 'Unknown error fetching install URL.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.status === 'loading') {
    return (
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="space-y-2 pb-4">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <Skeleton className="h-24 w-full rounded-lg" />
          <Skeleton className="h-10 w-44" />
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'unconfigured') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>GitHub App is not configured for this deployment.</AlertTitle>
        <AlertDescription>
          The <code className="font-mono text-xs">GITHUB_APP_SLUG</code>,{' '}
          <code className="font-mono text-xs">GITHUB_APP_ID</code>,{' '}
          <code className="font-mono text-xs">GITHUB_APP_PRIVATE_KEY</code>, or{' '}
          <code className="font-mono text-xs">GITHUB_APP_STATE_SECRET</code> environment variable is
          missing. Ask the operator to finish the App registration and try again.
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load install URL.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach the install endpoint right now. Retry in a moment, or contact us if
            this keeps failing.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => void load()}>
            <RefreshCw className="size-3.5" aria-hidden /> Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="border-border/70 shadow-sm">
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-4">
        <div className="grid gap-1">
          <CardTitle className="text-base font-semibold">
            Bivouac GitHub App
            <span className="ml-2 text-small font-normal text-muted-foreground">
              @{state.appName}
            </span>
          </CardTitle>
          <CardDescription>
            Install the app on the GitHub org or user that owns the repos you want on watch.
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <ConnectScopeList />

        <div className="flex flex-col gap-3">
          <Button
            type="button"
            size="lg"
            className="gap-2 shadow-brand"
            onClick={() => {
              window.location.href = state.url;
            }}
          >
            <Github className="size-4" aria-hidden />
            Install on GitHub
            <span aria-hidden className="text-small opacity-80">
              ↗
            </span>
          </Button>
          <p className="text-small text-muted-foreground">
            You&apos;ll be sent to GitHub to grant access. After you install, Bivouac lists every
            repo you grant access to on the dashboard within a minute and starts scanning them on
            their default branch. Triage PRs land as drafts — humans get paged only when a rule
            trips.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
