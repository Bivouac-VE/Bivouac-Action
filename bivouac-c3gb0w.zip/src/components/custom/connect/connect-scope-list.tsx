// @polsia:user-owned — presentational scope explainer for the GitHub App
// install. Pure JSX, no data fetch. Lives in the install card body.

import { GitPullRequest, Lock, Workflow } from 'lucide-react';
import type { ReactNode } from 'react';

interface ScopeRow {
  icon: ReactNode;
  title: string;
  detail: string;
}

const SCOPES: ScopeRow[] = [
  {
    icon: <Workflow className="size-4 shrink-0 text-brand-600" aria-hidden />,
    title: 'Repository metadata (read)',
    detail:
      'Names, default branches, and recent commit history — used to enroll a repo onto the watch list.',
  },
  {
    icon: <Lock className="size-4 shrink-0 text-brand-600" aria-hidden />,
    title: 'Contents (read & write)',
    detail:
      'Read source files to fingerprint dependencies and write a triage PR branch when Bivouac opens a draft.',
  },
  {
    icon: <GitPullRequest className="size-4 shrink-0 text-brand-600" aria-hidden />,
    title: 'Pull requests (write)',
    detail:
      'Open, update, and label draft triage PRs. Bivouac never merges without an explicit human signal.',
  },
];

export function ConnectScopeList() {
  return (
    <ul
      aria-label="GitHub App permissions requested at install"
      className="flex flex-col divide-y divide-border/70 rounded-lg border border-border/70 bg-card/60"
    >
      {SCOPES.map((scope) => (
        <li key={scope.title} className="flex items-start gap-3 px-4 py-3">
          {scope.icon}
          <div className="flex min-w-0 flex-col gap-1">
            <p className="text-sm font-medium text-foreground">{scope.title}</p>
            <p className="text-small text-muted-foreground">{scope.detail}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}
