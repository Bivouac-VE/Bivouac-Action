// @polsia:user-owned — client island for /settings/billing.
//
// Owns the four render states the data-plane rule demands:
//   - loading    : /api/billing/state is in flight
//   - unauthed   : GET 401 → router.replace('/login?next=/settings/billing')
//   - no-plan    : empty-state card with CTA → /pricing (never a dead end)
//   - with-plan  : plan summary, repo-count vs limit, SLA addons, Switch plan
//
// All data comes from apiFetch(/api/billing/state, { schema: BillingState }) so
// shape drift surfaces as a ZodError instead of silent UI breakage.

'use client';

import { AlertTriangle, ArrowRight, CircleDot, Receipt, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import { PLANS } from '@/lib/business/plans';
import {
  BillingCheckoutRequest,
  BillingCheckoutResponse,
  type BillingCheckoutResponse as BillingCheckoutResponseT,
  BillingInvoicesResponse,
  type BillingInvoicesResponse as BillingInvoicesResponseT,
  type BillingPlanSlug as BillingPlanSlugT,
  type BillingPlanStatus,
  BillingState,
  type BillingState as BillingStateT,
  PortalSyncResponse,
  type PortalSyncResponse as PortalSyncResponseT,
} from '@/lib/contracts/billing';
import { cn } from '@/lib/utils';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'unauthed' }
  | { status: 'empty' }
  | { status: 'ready'; state: BillingStateT };

const STRIPE_ERROR_COPY: Record<string, string> = {
  STRIPE_NOT_ENABLED:
    'Payments are not enabled for this app yet. The owner needs to enable runtime payments from the Polsia dashboard.',
  ONBOARDING_REQUIRED:
    'Stripe onboarding is incomplete. The owner must finish onboarding from the Polsia dashboard Payments page before checkout can run.',
  STRIPE_NOT_CONFIGURED:
    'Stripe is not configured for this app yet. Set up billing from the Polsia dashboard.',
  stripe_billing_not_configured:
    'Stripe billing is not configured for this app yet. Set up billing from the Polsia dashboard.',
  invalid_plan: 'That plan is not available. Pick a tier from the page above.',
  checkout_failed: 'Checkout failed. Try again, or write to bivouac-c3gb0w@polsia.app.',
  portal_not_implemented:
    'Stripe customer portal is not wired yet. Use Switch plan → Starter to step down through Checkout.',
};

function formatUsd(value: number): string {
  return `$${value}`;
}

function errorStatus(err: unknown): string | null {
  if (err && typeof err === 'object' && 'cause' in err) {
    const cause = (err as { cause: unknown }).cause;
    if (cause && typeof cause === 'object' && 'error' in cause) {
      const inside = (cause as { error?: unknown }).error;
      if (typeof inside === 'string') return inside;
    }
  }
  return null;
}

export function BillingSettingsView() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });
  const router = useRouter();

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/billing/state', { schema: BillingState });
      setState(data.plan ? { status: 'ready', state: data } : { status: 'empty' });
    } catch (err: unknown) {
      const code = errorStatus(err);
      if (code === 'Unauthorized') {
        setState({ status: 'unauthed' });
        return;
      }
      const reason = err instanceof Error ? err.message : 'Could not load billing state.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (state.status === 'unauthed') {
      router.replace('/login?next=/settings/billing');
    }
  }, [router, state.status]);

  if (state.status === 'loading') {
    return <BillingSkeleton />;
  }

  if (state.status === 'unauthed') {
    return (
      <Card className="border-border bg-card/60">
        <CardContent className="py-10 text-center">
          <p className="text-small text-muted-foreground">Redirecting to sign in…</p>
        </CardContent>
      </Card>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load your billing state.</AlertTitle>
        <AlertDescription>
          We could not reach the billing endpoint right now. Retry in a moment.{' '}
          <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'empty') {
    return <NoPlanEmptyState />;
  }

  return <WithPlanPanel state={state.state} onRefresh={load} />;
}

// ----------------------------------------------------------------------------

function BillingSkeleton() {
  return (
    <section aria-label="Loading billing state" className="flex flex-col gap-4">
      <Skeleton className="h-10 w-60" />
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-24 w-full rounded-xl" />
    </section>
  );
}

function NoPlanEmptyState() {
  return (
    <section
      aria-label="No plan yet"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-card via-muted/40 to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[360px] text-brand-500/15 md:-right-32"
      >
        <svg
          viewBox="0 0 360 360"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative upgrade nod</title>
          <circle cx="180" cy="180" r="160" strokeWidth="1" />
          <circle cx="180" cy="180" r="110" strokeWidth="1" />
          <circle cx="180" cy="180" r="60" strokeWidth="1.5" />
          <path d="M 180 20 L 180 340" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="relative flex flex-col items-start gap-6 p-8 md:p-12">
        <p className="text-eyebrow">No plan yet</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          Pick a Bivouac tier to put the agent on duty.
        </h2>
        <p className="max-w-xl text-body text-muted-foreground">
          Plans are billed monthly per active repository. You can switch tiers any time from the
          settings page once you have one.
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <Button asChild size="lg" className="gap-2 shadow-brand">
            <Link href="/pricing">
              See plans
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
          <Button asChild size="lg" variant="ghost" className="gap-2">
            <Link href="/dashboard">Back to dashboard</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------

function WithPlanPanel({
  state,
  onRefresh,
}: {
  state: BillingStateT;
  onRefresh: () => Promise<void>;
}) {
  // All hooks at the top — the early-return guard below MUST stay AFTER the
  // last hook call so React doesn't trip a "hooks called conditionally" error.
  const [switchPending, setSwitchPending] = useState<BillingPlanSlugT | null>(null);
  const [cancelPending, setCancelPending] = useState(false);
  const [invoices, setInvoices] = useState<
    | { status: 'loading' }
    | { status: 'ready'; invoices: BillingInvoicesResponseT['invoices'] }
    | { status: 'unavailable' }
  >({ status: 'loading' });

  const loadInvoices = useCallback(async () => {
    setInvoices({ status: 'loading' });
    try {
      const res = await apiFetch<BillingInvoicesResponseT>('/api/billing/invoices', {
        schema: BillingInvoicesResponse,
      });
      setInvoices({ status: 'ready', invoices: res.invoices });
    } catch {
      setInvoices({ status: 'unavailable' });
    }
  }, []);

  useEffect(() => {
    void loadInvoices();
  }, [loadInvoices]);

  const switchPlan = useCallback(
    async (target: BillingPlanSlugT) => {
      if (switchPending) return;
      setSwitchPending(target);
      try {
        const parsed = BillingCheckoutRequest.parse({ planId: target });
        const res = await apiFetch<BillingCheckoutResponseT>('/api/billing/checkout', {
          method: 'POST',
          schema: BillingCheckoutResponse,
          body: JSON.stringify(parsed),
        });
        if (res.ok === 'checkout') {
          window.location.href = res.url;
          return;
        }
        toast.error(STRIPE_ERROR_COPY[res.error] ?? res.error);
        setSwitchPending(null);
      } catch (err: unknown) {
        const code = errorStatus(err);
        toast.error(
          STRIPE_ERROR_COPY[code ?? ''] ??
            'Could not reach /api/billing/checkout. Check your connection and try again.',
        );
        setSwitchPending(null);
      }
    },
    [switchPending],
  );

  const cancelAtPeriodEnd = useCallback(async () => {
    if (cancelPending) return;
    setCancelPending(true);
    try {
      const res = await apiFetch<PortalSyncResponseT>('/api/billing/portal', {
        method: 'POST',
        schema: PortalSyncResponse,
      });
      toast.message(
        res.cancelAtPeriodEnd
          ? 'Cancellation scheduled — your plan ends at the current period close.'
          : 'Stripe reports your subscription is active. Reloading…',
      );
      // Force a fresh /api/billing/state read so the UI flag, the badge, and
      // the renew date all reflect the just-mirrored Stripe state.
      await onRefresh();
    } catch (err: unknown) {
      const code = errorStatus(err);
      if (code === 'stripe_billing_not_configured') {
        toast.error(STRIPE_ERROR_COPY[code]);
      } else if (code === 'email_required_for_subscription_status') {
        toast.error('Your account is missing an email on file — required to query Stripe.');
      } else if (code === 'Unauthorized') {
        toast.error('Session expired — sign in again to manage your subscription.');
      } else {
        toast.error('Could not reach /api/billing/portal.');
      }
    } finally {
      setCancelPending(false);
    }
  }, [cancelPending, onRefresh]);

  const plan = state.plan;
  // plan is non-null by the way we transition into this branch, but TS needs
  // the guard for sound typing.
  if (!plan) return <NoPlanEmptyState />;

  const planRecord = PLANS.find((p) => p.slug === plan.slug);
  const repoLimit = plan.repoLimit;
  const limitLabel = repoLimit === null ? 'Unlimited' : `${repoLimit}`;
  const overLimit = repoLimit !== null && state.repoCount > repoLimit;
  const monthlyTotal = plan.monthlyPerRepoUsd + state.addons.reduce((s, a) => s + a.monthlyUsd, 0);

  return (
    <section aria-label="Billing" className="flex flex-col gap-8">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Subscription</p>
        <h1 className="font-display text-h2 text-balance text-foreground">Your Bivouac plan</h1>
        <p className="text-body-lg text-muted-foreground">
          Switch tiers and SLA add-ons at any time — changes go through Stripe Checkout.
        </p>
      </header>

      {/* ---------- Current plan card ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-3">
          <div className="grid min-w-0 gap-1">
            <p className="text-eyebrow">Current tier</p>
            <CardTitle className="font-display text-h3 text-foreground">
              {planRecord?.name ?? plan.slug}
            </CardTitle>
            <CardDescription className="text-small text-muted-foreground">
              {planRecord?.eyebrow ??
                `${formatUsd(plan.monthlyPerRepoUsd)} per active repo, monthly`}
            </CardDescription>
          </div>
          <Badge variant="outline" className={toneForStatus(plan.status)}>
            {labelForStatus(plan.status)}
          </Badge>
        </CardHeader>
        <CardContent className="flex flex-col gap-6 px-5 pb-5 pt-0 text-small text-muted-foreground">
          <dl className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Stat
              label="Active repos"
              value={String(state.repoCount)}
              right={repoLimit === null ? 'unlimited' : `of ${limitLabel}`}
              tone={overLimit ? 'warn' : undefined}
            />
            <Stat
              label="Per-repo price"
              value={formatUsd(plan.monthlyPerRepoUsd)}
              right="/ active repo / month"
            />
            <Stat
              label="Total monthly"
              value={formatUsd(monthlyTotal)}
              right={state.addons.length > 0 ? `+ ${state.addons.length} add-on(s)` : 'base plan'}
            />
          </dl>

          {state.addons.length > 0 ? (
            <div className="flex flex-col gap-2">
              <p className="text-eyebrow">SLA add-ons</p>
              <div className="flex flex-wrap gap-2">
                {state.addons.map((addon) => (
                  <Badge
                    key={addon.id}
                    variant="outline"
                    className="border-brand-500/40 bg-card text-foreground"
                  >
                    <Sparkles
                      className="mr-1 size-3 text-brand-700 dark:text-brand-300"
                      aria-hidden
                    />
                    {addon.label} · {formatUsd(addon.monthlyUsd)}/mo
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}

          <div className="flex flex-col gap-2 border-t border-border pt-4 text-small text-muted-foreground">
            {plan.currentPeriodEnd ? (
              <p className="flex items-center gap-2">
                <CircleDot className="size-3.5 shrink-0 text-foreground/70" aria-hidden />
                Current period renews{' '}
                <time dateTime={plan.currentPeriodEnd} className="font-medium text-foreground">
                  {formatDate(plan.currentPeriodEnd)}
                </time>
              </p>
            ) : (
              <p>Awaiting confirmation from Stripe.</p>
            )}
            {plan.cancelAtPeriodEnd ? (
              <p className="text-amber-600 dark:text-amber-400">
                Cancellation scheduled — your plan ends at the current period close.
              </p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* ---------- Switch plan panels ---------- */}
      <section aria-label="Plan switcher" className="flex flex-col gap-3">
        <p className="text-eyebrow">Switch plan</p>
        <p className="text-small text-muted-foreground">
          New price takes effect at your next renewal. The exact prorated amount is shown on the
          Stripe Checkout page before you pay.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          {PLANS.filter(
            (option) => option.slug !== plan.slug && option.ctaLabel !== 'Talk to sales',
          ).map((option) => {
            const isUpgrade = tierRank(option.slug as BillingPlanSlugT) > tierRank(plan.slug);
            const label = isUpgrade ? 'Upgrade' : 'Downgrade';
            const pending = switchPending === option.slug;
            return (
              <Card
                key={option.slug}
                className={cn(
                  'flex flex-col gap-3 border-border bg-card p-5',
                  isUpgrade && 'shadow-brand',
                )}
              >
                <div className="flex flex-col gap-1">
                  <p className="text-eyebrow">{option.eyebrow}</p>
                  <p className="font-display text-h4 text-foreground">{option.name}</p>
                  <p className="text-small text-muted-foreground">
                    {formatUsd(option.monthlyPerRepoUsd)} / active repo / month
                  </p>
                </div>
                <Button
                  type="button"
                  variant={isUpgrade ? 'default' : 'outline'}
                  disabled={Boolean(switchPending) || cancelPending}
                  onClick={() => switchPlan(option.slug as BillingPlanSlugT)}
                  className={cn('gap-1.5', isUpgrade && 'shadow-brand')}
                >
                  {pending ? (
                    <span className="inline-flex items-center gap-2">
                      <span
                        aria-hidden
                        className="size-3 animate-spin rounded-full border-2 border-current border-t-transparent"
                      />
                      Working…
                    </span>
                  ) : (
                    <>
                      {label} to {option.name}
                      <ArrowRight className="size-4" aria-hidden />
                    </>
                  )}
                </Button>
              </Card>
            );
          })}
        </div>
        {planRecord?.ctaLabel === 'Talk to sales' ? null : (
          <p className="text-small text-muted-foreground">
            Need volume pricing, custom policy packs, or SBOM provenance?{' '}
            <a
              href="mailto:bivouac-c3gb0w@polsia.app?subject=Bivouac%20Enterprise"
              className="text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
            >
              Talk to the team
            </a>
            .
          </p>
        )}
      </section>

      {/* ---------- Subscription management ---------- */}
      <section
        aria-label="Subscription management"
        className="flex flex-col gap-3 border-t border-border pt-6"
      >
        <p className="text-eyebrow">Manage subscription</p>
        <div className="flex flex-wrap items-center gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={cancelAtPeriodEnd}
            disabled={plan.cancelAtPeriodEnd || cancelPending || Boolean(switchPending)}
            className="gap-1.5"
          >
            <Receipt className="size-4" aria-hidden />
            {plan.cancelAtPeriodEnd
              ? 'Cancellation pending'
              : cancelPending
                ? 'Working…'
                : 'Cancel at period end'}
          </Button>
          <span className="text-small text-muted-foreground">
            Stepping down? Pick the Starter tier above — it routes through the same Stripe Checkout.
          </span>
        </div>
      </section>

      {/* ---------- Invoice history ---------- */}
      <InvoiceHistory invoices={invoices} onRetry={loadInvoices} />
    </section>
  );
}

// ----------------------------------------------------------------------------

function Stat({
  label,
  value,
  right,
  tone,
}: {
  label: string;
  value: string;
  right?: string;
  tone?: 'warn';
}) {
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border/70 bg-background/60 p-3">
      <p className="text-eyebrow">{label}</p>
      <p
        className={cn(
          'font-display text-h3 text-foreground',
          tone === 'warn' && 'text-amber-700 dark:text-amber-400',
        )}
      >
        {value}
      </p>
      {right ? <p className="text-small text-muted-foreground">{right}</p> : null}
    </div>
  );
}

function toneForStatus(s: BillingPlanStatus): string {
  if (s === 'CANCELLED') return 'border-border bg-muted text-muted-foreground';
  if (s === 'PAST_DUE') {
    return 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground';
  }
  return 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300';
}

function labelForStatus(s: BillingPlanStatus): string {
  switch (s) {
    case 'ACTIVE':
      return 'Active';
    case 'CANCELLED':
      return 'Cancelled';
    case 'PAST_DUE':
      return 'Past due';
  }
}

// ----------------------------------------------------------------------------

function InvoiceHistory({
  invoices,
  onRetry,
}: {
  invoices:
    | { status: 'loading' }
    | { status: 'ready'; invoices: BillingInvoicesResponseT['invoices'] }
    | { status: 'unavailable' };
  onRetry: () => Promise<void>;
}) {
  return (
    <section aria-label="Invoice history" className="flex flex-col gap-3">
      <div className="flex items-end justify-between gap-3">
        <p className="text-eyebrow">Invoice history</p>
        {invoices.status === 'ready' && invoices.invoices.length > 0 ? (
          <span className="text-small text-muted-foreground">
            Last {invoices.invoices.length} payment{invoices.invoices.length === 1 ? '' : 's'}
          </span>
        ) : null}
      </div>

      <Card className="border-border bg-card/80 p-0">
        <CardContent className="p-0">
          {invoices.status === 'loading' ? (
            <div className="flex flex-col gap-2 p-4">
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-5 w-64" />
              <Skeleton className="h-5 w-56" />
            </div>
          ) : invoices.status === 'unavailable' ? (
            <div className="flex flex-col gap-3 p-4 text-small text-muted-foreground">
              <p>
                The invoice feed could not be reached. Retry, or write to bivouac-c3gb0w@polsia.app.
              </p>
              <div>
                <Button type="button" variant="outline" onClick={() => void onRetry()}>
                  Retry
                </Button>
              </div>
            </div>
          ) : invoices.invoices.length === 0 ? (
            <div className="p-4 text-small text-muted-foreground">
              No invoices yet — your first one lands after the first renewal.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-eyebrow text-muted-foreground">Date</TableHead>
                  <TableHead className="text-eyebrow text-muted-foreground">Description</TableHead>
                  <TableHead className="text-right text-eyebrow text-muted-foreground">
                    Amount
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.invoices.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell className="text-small text-foreground">
                      {formatDate(row.occurredAt)}
                    </TableCell>
                    <TableCell className="text-small text-muted-foreground">
                      {row.description ?? (
                        <span className="text-muted-foreground/70">Subscription renewal</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-small font-medium text-foreground">
                      {row.amountUsd === null ? '—' : formatUsd(row.amountUsd)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </section>
  );
}

function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

const TIER_RANK: Record<BillingPlanSlugT, number> = {
  free: 0,
  starter: 1,
  team: 2,
  enterprise: 3,
};

function tierRank(slug: BillingPlanSlugT): number {
  return TIER_RANK[slug] ?? 0;
}
