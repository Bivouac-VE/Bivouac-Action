// @polsia:user-owned — client island for /settings/billing/return.
//
// 1. POST /api/billing/sync { sessionId, planId, addons } → server verifies the
//    Stripe session via verifyCheckoutSession and upserts the authed user's
//    BillingPlan / BillingAddon rows.
// 2. router.replace('/settings/billing') — the page refetches fresh state.

'use client';

import { Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';

export function BillingReturnIsland({
  sessionId,
  plan,
  addons,
}: {
  sessionId: string;
  plan: string;
  addons: string[];
}) {
  const router = useRouter();
  const fired = useRef(false);

  useEffect(() => {
    if (fired.current) return;
    fired.current = true;
    if (!sessionId) {
      toast.error('Missing session id — return to billing and re-try.');
      router.replace('/settings/billing');
      return;
    }
    if (!plan) {
      toast.error('No plan returned from Stripe — open Switch plan to retry.');
      router.replace('/settings/billing');
      return;
    }
    (async () => {
      try {
        await apiFetch('/api/billing/sync', {
          method: 'POST',
          body: JSON.stringify({ sessionId, planId: plan, addons }),
        });
        router.replace('/settings/billing');
      } catch (err: unknown) {
        const cause =
          err && typeof err === 'object' && 'cause' in err
            ? (err as { cause: unknown }).cause
            : null;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? String((cause as { error: unknown }).error)
            : null;
        toast.error(code ? `Sync failed: ${code}` : 'Could not reconcile your Stripe session.');
        router.replace('/settings/billing');
      }
    })();
  }, [router, sessionId, plan, addons]);

  return (
    <Card className="border-border bg-card/60">
      <CardContent className="flex items-center gap-3 py-10 text-small text-muted-foreground">
        <Loader2 className="size-4 animate-spin" aria-hidden />
        Reconciling your Stripe session…
      </CardContent>
    </Card>
  );
}
