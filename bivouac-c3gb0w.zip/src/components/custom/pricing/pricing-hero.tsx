// @polsia:user-owned — pricing page hero. Server-rendered presentational:
// eyebrow badge + h1 + dominant free-first-repo CTA panel + subhead. The
// interactive card grid lives in pricing-client.tsx so this stays free of
// `'use client'`.

import { ArrowRight, Github } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const FREE_SIGNUP_HREF = `/signup?plan=free&returnTo=${encodeURIComponent('/dashboard/repos?welcome=first-repo')}`;

export function PricingHero() {
  return (
    <header className="container-page flex flex-col gap-8 pt-section-lg">
      <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
        <span className="size-1.5 rounded-full bg-brand-500" aria-hidden />
        <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
          Four plans · billed per active repo · cancel anytime
        </span>
      </Badge>

      <h1 className="font-display text-h1 text-balance text-foreground">
        Four plans, billed per active repo.
      </h1>

      <Card className="relative overflow-hidden border-brand-500/40 bg-gradient-to-br from-brand-50/70 via-card to-card shadow-brand">
        <div
          aria-hidden
          className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-brand-300 via-brand-500 to-brand-700"
        />
        <CardContent className="flex flex-col gap-5 p-6 sm:p-8 md:flex-row md:items-center md:justify-between md:gap-10">
          <div className="flex max-w-2xl flex-col gap-3">
            <p className="text-eyebrow">Start free — no card required</p>
            <h2 className="font-display text-h3 text-balance text-foreground">
              Free for the first repo. No card to start.
            </h2>
            <p className="text-body-lg text-muted-foreground">
              Connect GitHub, get a draft PR within five minutes. Upgrade only when you&apos;re
              ready — one repo stays free forever.
            </p>
          </div>
          <div className="flex shrink-0 flex-col gap-2 sm:flex-row sm:items-center md:flex-col md:items-stretch">
            <Button asChild size="lg" className="w-full gap-2 shadow-brand">
              <Link href={FREE_SIGNUP_HREF}>
                <Github className="size-5" aria-hidden />
                Start with your first repo
                <ArrowRight className="size-5" aria-hidden />
              </Link>
            </Button>
            <p className="text-center text-small text-muted-foreground md:text-left">
              1 active repo · continuous dependency watch · draft PRs
            </p>
          </div>
        </CardContent>
      </Card>

      <p className="max-w-3xl text-body-lg text-muted-foreground">
        All tiers ship with SOC 2 / NIS2 / CRA evidence-ready audit trails, the same triage loop,
        and the same test-gated auto-merge guardrails. Higher plans widen what the agent handles
        autonomously — and how fast it commits a fix. Bivouac produces the evidence; the
        certifications are your team&apos;s.
      </p>
    </header>
  );
}
