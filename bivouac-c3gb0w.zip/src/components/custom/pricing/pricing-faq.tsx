// @polsia:user-owned — /pricing FAQ island. Client island wraps the Radix
// Accordion primitive; literal copy, no apiFetch, no state beyond the
// accordion open/closed UI. Mirrors the visual block of the homepage buyer
// FAQ so the pricing tier cards and the FAQ below them look like one page.

'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const PRICING_FAQ: ReadonlyArray<{ q: string; a: string }> = [
  {
    q: 'Can I switch plans mid-cycle?',
    a: 'Yes — upgrade or downgrade any time from the dashboard. Plan-level caps shift on the next patch window; no retroactive refund, no proration back to the lower tier.',
  },
  {
    q: "What's actually included at each tier?",
    a: 'Free covers 1 repo with manual patch PRs and the Standard SLA. Starter adds forward-fix patches and a real test-suite merge gate on up to 5 repos. Team lifts the agent into autonomous patch-and-merge with downgrade-as-fix, multi-repo policy packs, and private advisory feeds on up to 25 repos. Enterprise removes the cap entirely, layers in supply-chain provenance scoring, SBOM attestation exports, and dedicated on-call routing — referenced against the tier cards above this FAQ.',
  },
  {
    q: 'Is there an annual billing option, or only monthly?',
    a: 'The published rates for Free, Starter, and Team are monthly per active repository, and that is the cycle you are billed on. Enterprise engagements are invoiced annually per contract; there is no annual discount layered on the per-repo price.',
  },
  {
    q: 'What counts toward the repo limit?',
    a: 'Any GitHub repo with at least one dependency scan in the last 30 days. A repo you pause or remove stops counting the same day, and your first repo is always free, regardless of tier.',
  },
  {
    q: 'What happens if I exceed my tier’s active-repo cap — an overage charge, or a hard throttle?',
    a: 'A prorated partial-month charge is added for the new active repo and the agent keeps running. There is no surprise throttle. An explicit overage line on the invoice is planned but not yet shipped — today the added repo simply appears in the next cycle.',
  },
  {
    q: 'How do refunds and downgrades actually work?',
    a: 'Downgrades take effect on the next cycle; there is no retroactive refund for time already paid at the higher tier. Removing a repo mid-cycle credits the remainder of that repo’s billing to the next invoice rather than issuing a cash refund, so the credit is durable and applied automatically.',
  },
];

export function PricingFaq() {
  return (
    <section id="pricing-faq" className="section scroll-mt-20">
      <div className="container-page flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Billing, caps, and cycle mechanics</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Six questions a buyer should be able to answer before they upgrade.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Plain-language answers about plan changes, what each tier actually unlocks, the monthly
            cycle, what counts as an active repo, what happens past the cap, and how refunds and
            downgrades are credited. If something&rsquo;s missing, ping us — we read every message.
          </p>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <Accordion type="single" collapsible className="px-2">
            {PRICING_FAQ.map((item, idx) => (
              <AccordionItem key={item.q} value={`pricing-faq-${idx}`}>
                <AccordionTrigger className="px-4 py-5 text-left font-display text-body font-semibold text-foreground hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-5 text-body text-muted-foreground">
                  <p>{item.a}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
