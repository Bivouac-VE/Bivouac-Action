// @polsia:user-owned — interactive pricing island.
//
// 'use client': composes the four tier cards, the SLA add-ons row, and the
// FAQ. All visible data (names, prices, feature bodies, SLA catalog, FAQ
// copy) comes from typed catalogs at @/lib/business so there's NO server
// work in the island. Per-tier CTA posts to /api/checkout, which returns the
// discriminated CheckoutResponse envelope (hosted Stripe URL for authed
// subscribers, /signup redirect for anonymous + Free, mailto for
// Enterprise).

'use client';

import { Check, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { PLANS } from '@/lib/business/plans';
import { SLA_ADDONS } from '@/lib/business/sla';
import type { PricingPlan } from '@/lib/contracts/pricing';
import { cn } from '@/lib/utils';
import { planAccents } from './checkout-button';
import { PricingFaq } from './pricing-faq';
import { PricingSubscribeButton } from './pricing-subscribe-button';

function formatRepos(count: PricingPlan['includedActiveRepos']) {
  if (count === 'unlimited') return 'Unlimited repos';
  return `${count} active ${count === 1 ? 'repo' : 'repos'}`;
}

export function PricingClient() {
  return (
    <>
      {/* ---------- Tier grid ---------- */}
      <div className="container-page mt-section">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 md:items-stretch">
          {PLANS.map((plan) => {
            const accent = planAccents(plan.slug);
            return (
              <Card
                key={plan.slug}
                id={plan.slug}
                className={cn(
                  'relative flex scroll-mt-20 flex-col overflow-hidden lift',
                  accent.container,
                )}
              >
                <div aria-hidden className={cn('h-1 w-full', accent.bar)} />
                <CardHeader className="gap-3">
                  <p className={cn('text-eyebrow', accent.eyebrow)}>{plan.eyebrow}</p>
                  <div className="flex items-end gap-3">
                    <CardTitle className="font-display text-h2 text-foreground">
                      {plan.monthlyPerRepoUsd === 0 ? (
                        <>
                          $0
                          <span className="text-h4 font-semibold text-foreground"> free</span>
                        </>
                      ) : (
                        `$${plan.monthlyPerRepoUsd}`
                      )}
                    </CardTitle>
                    {plan.monthlyPerRepoUsd === 0 ? null : (
                      <span className="pb-1 text-small text-muted-foreground">
                        / active repo / month
                      </span>
                    )}
                  </div>
                  <CardDescription className="text-small text-muted-foreground">
                    {formatRepos(plan.includedActiveRepos)} · {plan.priceFootnote}
                  </CardDescription>
                  <PricingSubscribeButton plan={plan} />
                </CardHeader>

                <CardContent className="flex flex-1 flex-col gap-5">
                  <Separator />
                  <ul className="flex flex-col gap-3">
                    {plan.features.map((f) => (
                      <li key={f.label} className="flex items-start gap-3">
                        <span
                          className={cn(
                            'mt-1 inline-flex size-5 shrink-0 items-center justify-center rounded-full border',
                            f.highlight
                              ? 'border-brand-500/60 bg-brand-500/15 text-brand-700 dark:text-brand-300'
                              : 'border-border bg-muted text-foreground',
                          )}
                          aria-hidden
                        >
                          <Check className="size-3" />
                        </span>
                        <div className="flex flex-col gap-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-small font-medium text-foreground">
                              {f.label}
                            </span>
                            {f.highlight ? (
                              <Badge
                                variant="secondary"
                                className="border-brand-500/40 bg-brand-500/15 text-brand-700 dark:text-brand-300"
                              >
                                {f.highlight === 'autonomous-patch'
                                  ? 'Autonomous patch'
                                  : 'Downgrade-as-fix'}
                              </Badge>
                            ) : null}
                          </div>
                          <span className="text-small text-muted-foreground">{f.body}</span>
                        </div>
                      </li>
                    ))}
                  </ul>

                  {plan.slaAddons.length > 0 ? (
                    <div className="flex flex-col gap-2">
                      <p className="text-eyebrow">SLA add-ons</p>
                      <div className="flex flex-wrap gap-2">
                        {plan.slaAddons.map((addon) => (
                          <Badge
                            key={addon.badge}
                            variant="outline"
                            title={addon.tooltip}
                            className="border-brand-500/40 bg-card text-foreground"
                          >
                            <Sparkles
                              className="mr-1 size-3 text-brand-700 dark:text-brand-300"
                              aria-hidden
                            />
                            {addon.badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* ---------- SLA add-ons comparison row ---------- */}
      <section className="container-page mt-section-lg">
        <div className="flex flex-col gap-3 pb-6">
          <p className="text-eyebrow">Usage-based add-ons</p>
          <h2 className="font-display text-h3 text-balance text-foreground">SLA add-ons</h2>
          <p className="max-w-2xl text-body text-muted-foreground">
            Pair any tier with an SLA upgrade. Each add-on bills on its own usage curve — pricing
            finalised once customer contracts are in flight.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 md:items-stretch">
          {SLA_ADDONS.map((addon, idx) => {
            const accent = planAccents((['starter', 'team', 'enterprise'] as const)[idx] ?? 'team');
            return (
              <Card
                key={addon.slug}
                className={cn(
                  'relative flex scroll-mt-20 flex-col overflow-hidden lift',
                  accent.container,
                )}
              >
                <div aria-hidden className={cn('h-1 w-full', accent.bar)} />
                <CardHeader className="gap-3">
                  <p className={cn('text-eyebrow', accent.eyebrow)}>SLA add-on</p>
                  <div className="flex items-center gap-2">
                    <Sparkles className="size-5 text-brand-700 dark:text-brand-300" aria-hidden />
                    <CardTitle className="font-display text-h4 text-foreground">
                      {addon.label}
                    </CardTitle>
                  </div>
                  <CardDescription className="text-small text-muted-foreground">
                    {addon.body}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col gap-4">
                  <Separator />
                  <div className="flex flex-col gap-1">
                    <span className="text-eyebrow">Pricing</span>
                    <span className="text-small text-foreground">{addon.pricingNote}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* ---------- FAQ ---------- */}
      <PricingFaq />
    </>
  );
}
