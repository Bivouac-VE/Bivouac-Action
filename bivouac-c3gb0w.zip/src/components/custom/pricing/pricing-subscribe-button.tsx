// @polsia:user-owned — Subscribe button island for the public pricing tier.
//
// Bridges the click → POST /api/checkout → hosted Stripe Checkout (or
// redirect envelope for anonymous / "Talk to sales" branches). Free clicks
// short-circuit in the client straight to /signup (no Stripe call, no API
// roundtrip). The button is a plain <Button>, not asChild, so a spinner can
// live inline without the <Link> wrapper. Visual parity with the
// <PlanCtaLink/> is kept via the same accent-derived emphasis / shadow.

'use client';

import { ArrowRight, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { apiFetch } from '@/lib/api-client';
import { CheckoutResponse, type PricingPlan } from '@/lib/contracts/pricing';
import { cn } from '@/lib/utils';
import { planAccents } from './checkout-button';

const ERROR_COPY: Record<string, string> = {
  STRIPE_NOT_ENABLED:
    'Payments are not enabled for this app yet. The owner needs to enable runtime payments from the Polsia dashboard.',
  ONBOARDING_REQUIRED:
    'Stripe onboarding is incomplete. The owner must finish onboarding before checkout can run.',
  STRIPE_NOT_CONFIGURED:
    'Stripe is not configured for this app yet. Set up billing from the Polsia dashboard.',
  invalid_plan: 'That plan is not available. Pick a tier from the page above.',
  checkout_failed: 'Checkout failed. Try again, or write to bivouac-c3gb0w@polsia.app.',
};

const FREE_SIGNUP_URL = `/signup?plan=free&returnTo=${encodeURIComponent('/dashboard/repos?welcome=first-repo')}`;

export function PricingSubscribeButton({ plan }: { plan: PricingPlan }) {
  const [pending, setPending] = useState(false);
  const accent = planAccents(plan.slug);

  async function onClick() {
    // Free — no Stripe, no /api/checkout. The catalog's Free plan prescribes
    // /signup → GitHub App install → first repo, so mirror that chain
    // directly. Subsequent authed Free calls (with a session) would reach
    // /api/checkout, which returns the same redirect shape.
    if (plan.ctaLabel === 'Start free' || plan.slug === 'free') {
      if (pending) return;
      setPending(true);
      window.location.href = FREE_SIGNUP_URL;
      return;
    }
    if (pending) return;
    setPending(true);
    try {
      const res = await apiFetch('/api/checkout', {
        method: 'POST',
        schema: CheckoutResponse,
        body: JSON.stringify({ planId: plan.slug }),
      });
      if (res.ok === 'checkout') {
        window.location.href = res.url;
        return;
      }
      if (res.ok === 'redirect') {
        window.location.href = res.redirectTo;
        return;
      }
      toast.error(ERROR_COPY[res.error] ?? res.error);
      setPending(false);
    } catch (err: unknown) {
      const cause =
        err && typeof err === 'object' && 'cause' in err ? (err as { cause: unknown }).cause : null;
      const code =
        cause && typeof cause === 'object' && 'error' in cause
          ? String((cause as { error: unknown }).error)
          : null;
      toast.error(ERROR_COPY[code ?? ''] ?? 'Could not reach checkout. Try again in a moment.');
      setPending(false);
    }
  }

  return (
    <Button
      type="button"
      variant={
        accent.emphasis === 'dominant'
          ? 'default'
          : accent.emphasis === 'secondary'
            ? 'secondary'
            : 'outline'
      }
      onClick={() => void onClick()}
      disabled={pending}
      className={cn('w-full gap-2', accent.emphasis === 'dominant' && 'shadow-brand')}
    >
      {pending ? (
        <span className="inline-flex items-center gap-2">
          <Loader2 className="size-4 animate-spin" aria-hidden />
          Working…
        </span>
      ) : (
        <>
          {plan.ctaLabel}
          <ArrowRight className="size-4" aria-hidden />
        </>
      )}
    </Button>
  );
}
