// @polsia:user-owned — presentational CTA link for a pricing tier card.
// Stateless deep-link to /signup (Stripe checkout deferred per brief).

import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import type { PricingPlan } from '@/lib/contracts/pricing';
import { cn } from '@/lib/utils';

const ACCENTS: Record<
  PricingPlan['slug'],
  {
    container: string;
    bar: string;
    eyebrow: string;
    emphasis: 'dominant' | 'secondary' | 'outline';
  }
> = {
  free: {
    container:
      'border-brand-500/60 ring-1 ring-brand-500/40 bg-gradient-to-br from-brand-50/60 via-card to-card',
    bar: 'bg-gradient-to-r from-brand-300 via-brand-500 to-brand-700',
    eyebrow: 'text-brand-700 dark:text-brand-300',
    emphasis: 'dominant',
  },
  starter: {
    container: 'border-border',
    bar: 'bg-border',
    eyebrow: 'text-muted-foreground',
    emphasis: 'outline',
  },
  team: {
    container: 'border-brand-500/50 ring-1 ring-brand-500/30',
    bar: 'bg-gradient-to-r from-brand-400 via-brand-500 to-brand-600',
    eyebrow: 'text-brand-700 dark:text-brand-300',
    emphasis: 'dominant',
  },
  enterprise: {
    container: 'border-border bg-gradient-to-br from-card to-muted/40',
    bar: 'bg-foreground/70',
    eyebrow: 'text-foreground',
    emphasis: 'secondary',
  },
};

export function PlanCtaLink({
  href,
  label,
  accent,
}: {
  href: string;
  label: string;
  accent: PricingPlan['slug'];
}) {
  const accentEntry = ACCENTS[accent];
  const variant =
    accentEntry.emphasis === 'dominant'
      ? 'default'
      : accentEntry.emphasis === 'secondary'
        ? 'secondary'
        : 'outline';
  const shadowBrand = accentEntry.emphasis === 'dominant';
  return (
    <Button asChild variant={variant} className={cn('w-full gap-2', shadowBrand && 'shadow-brand')}>
      <Link href={href}>
        {label}
        <ArrowRight className="size-4" aria-hidden />
      </Link>
    </Button>
  );
}

export function planAccents(slug: PricingPlan['slug']) {
  return ACCENTS[slug];
}
