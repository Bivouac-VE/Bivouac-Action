// @polsia:user-owned — /vs hub grid. Four competitor cards, each linking to the
// /vs/[competitor] deep page. Pure presentational; data comes from
// src/lib/business/vs-comparison.ts.

'use client';

import { ArrowRight, Scale } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  competitorHeadlines,
  competitorOrder,
  competitorProfiles,
} from '@/lib/business/vs-comparison';

export function VsHubGrid() {
  return (
    <section id="vs-grid" className="section">
      <div className="container-page flex flex-col gap-10">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Pick a competitor</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Four deep dives — same three dimensions, every row cited.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Each card opens a side-by-side built from the verbatim research on the landing page.
            Three rows. Three dimensions. Every cell traces back to the same source.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {competitorOrder.map((slug) => {
            const profile = competitorProfiles[slug];
            return (
              <Card key={slug} className="lift flex flex-col">
                <CardHeader>
                  <div className="mb-2 inline-flex size-9 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                    <Scale className="size-4" aria-hidden />
                  </div>
                  <CardTitle className="font-display text-h4">
                    <span className="text-foreground">{profile.name}</span>
                    <span className="ml-2 text-small font-normal text-muted-foreground">
                      vs Bivouc
                    </span>
                  </CardTitle>
                  <CardDescription className="text-foreground">
                    {competitorHeadlines[slug]}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-1 flex-col justify-between gap-4">
                  <p className="text-small text-muted-foreground">{profile.tagline}</p>
                  <Button asChild variant="outline" size="sm" className="w-fit gap-2">
                    <Link href={`/vs/${slug}`}>
                      Open the comparison
                      <ArrowRight className="size-4" aria-hidden />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="flex flex-col items-start gap-3 rounded-lg border border-brand-500/30 bg-gradient-to-br from-brand-500/10 via-background to-background p-8 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-col gap-1">
            <p className="text-eyebrow">Try Bivouc</p>
            <p className="max-w-xl text-body text-foreground">
              Same triage loop on every competitor page — watch one repo, see a downgrade PR land in
              your queue.
            </p>
          </div>
          <Button asChild size="lg" className="gap-2 shadow-brand">
            <Link href="/signup">
              Sign up
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
        </div>

        <p className="text-small text-muted-foreground">
          Plug Bivouc alongside your existing watch?{' '}
          <Link
            href="/pricing"
            className="font-medium text-foreground underline decoration-dotted underline-offset-4 hover:text-brand-700 dark:hover:text-brand-300"
          >
            See plans →
          </Link>
        </p>
      </div>
    </section>
  );
}
