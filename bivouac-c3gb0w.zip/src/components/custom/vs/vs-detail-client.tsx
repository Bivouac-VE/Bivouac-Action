// @polsia:user-owned — /vs/[competitor] detail island. Renders the comparison
// table, source citation footnote per row, the verbatim caveat, the brief's
// one-liner headline, the shared /signup CTA, and cross-links back to the
// hub and the landing page. Pure presentational; data is typed and static.

'use client';

import { ArrowLeft, ArrowRight, GitCompare, Quote, Wallet } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import type { CompetitorProfile, CompetitorSlug } from '@/lib/business/vs-comparison';

type VsDetailClientProps = {
  profile: CompetitorProfile;
  competitor: CompetitorSlug;
};

export function VsDetailClient({ profile, competitor }: VsDetailClientProps) {
  return (
    <main className="flex flex-col">
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden border-b border-border">
        <div aria-hidden className="pointer-events-none absolute inset-0 hidden md:block">
          <svg
            viewBox="0 0 800 240"
            className="absolute -right-32 top-0 h-[460px] w-[760px] text-brand-500/15"
            fill="none"
            stroke="currentColor"
            role="presentation"
          >
            <title>Decorative comparison rails</title>
            <path d="M 0 200 L 800 200" strokeWidth="1" />
            <path d="M 0 120 L 800 120" strokeWidth="1" />
            <circle cx="180" cy="200" r="6" fill="currentColor" />
            <circle cx="620" cy="120" r="6" fill="currentColor" />
          </svg>
        </div>

        <div className="container-page relative flex flex-col gap-6 pt-section-lg pb-section">
          <div className="flex items-center gap-2 text-small text-muted-foreground">
            <Button asChild variant="ghost" size="sm" className="gap-1 px-2">
              <Link href="/vs">
                <ArrowLeft className="size-3.5" aria-hidden />
                All comparisons
              </Link>
            </Button>
            <span aria-hidden>·</span>
            <span className="font-mono text-caption uppercase tracking-[0.08em]">
              /vs/{competitor}
            </span>
          </div>

          <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
            <GitCompare className="size-3.5 text-brand-700 dark:text-brand-300" aria-hidden />
            <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
              {profile.researchTab === 'flag-bots'
                ? 'Flag-only tools · dependabot / renovate / snyk'
                : 'Generative coding agents · copilot coding agent / cursor bugbot / devin'}
            </span>
          </Badge>

          <h1 className="font-display text-h1 text-balance text-foreground">
            Bivouc vs {profile.name}
          </h1>

          <p className="max-w-3xl text-body-lg text-muted-foreground">{profile.tagline}</p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button asChild size="lg" className="gap-2 shadow-brand">
              <Link href="/signup">
                Sign up
                <ArrowRight className="size-4" aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="ghost">
              <Link href="/">
                Back to overview
                <ArrowRight className="size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ---------- HEADLINE CALLOUT ---------- */}
      <section className="section">
        <div className="container-page flex flex-col gap-6">
          <Card className="border-brand-500/30 bg-gradient-to-br from-brand-500/10 via-card to-card">
            <CardHeader>
              <p className="text-eyebrow">The headline difference</p>
              <CardTitle className="font-display text-h3 text-balance text-foreground">
                {profile.oneLiner}
              </CardTitle>
              <CardDescription className="text-body text-muted-foreground">
                {profile.ctaSubline}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild size="lg" className="gap-2 shadow-brand">
                <Link href="/signup">
                  Sign up
                  <ArrowRight className="size-4" aria-hidden />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* ---------- COMPARISON TABLE ---------- */}
      <section className="bg-muted/40 section">
        <div className="container-page flex flex-col gap-8">
          <div className="flex flex-col gap-3">
            <p className="text-eyebrow">The comparison</p>
            <h2 className="font-display text-h2 text-balance text-foreground">
              Three dimensions. Every row traced to its source bullet.
            </h2>
            <p className="max-w-3xl text-body-lg text-muted-foreground">
              Each row maps to a verbatim finding from the “How Bivouc compares” research on the
              landing page. Sources link the row to the exact bullet it comes from.
            </p>
          </div>

          <div className="overflow-x-auto rounded-lg border border-border bg-card shadow-sm">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/60 hover:bg-muted/60">
                  <TableHead className="w-[26%] text-foreground">Dimension</TableHead>
                  <TableHead className="w-[37%] text-foreground">Bivouc</TableHead>
                  <TableHead className="w-[37%] text-foreground">{profile.name}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {profile.rows.map((row) => (
                  <TableRow key={row.dimension}>
                    <TableCell className="align-top">
                      <p className="font-display text-h4 text-foreground">{row.dimension}</p>
                      <p className="mt-2 text-caption text-muted-foreground">
                        Source: <span className="font-mono">“{row.source.bullet}”</span> ·{' '}
                        {row.source.tab === 'flag-bots' ? 'flag-bots' : 'fix-bots'} tab
                      </p>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="rounded-md border border-brand-500/40 bg-brand-500/10 p-3 text-small text-foreground">
                        {row.bivouc}
                      </div>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="rounded-md border border-border bg-background p-3 text-small text-muted-foreground">
                        {row.competitor}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex items-start gap-3 rounded-md border border-border bg-card p-4 text-small text-muted-foreground">
            <Quote
              className="mt-0.5 size-4 shrink-0 text-brand-700 dark:text-brand-300"
              aria-hidden
            />
            <p className="text-foreground">
              <span className="font-display text-h4">Caveat — {profile.caveat}</span>
              <span className="mt-1 block text-muted-foreground">
                Verbatim from the “How Bivouc compares” research on the landing page.
              </span>
            </p>
          </div>
        </div>
      </section>

      {/* ---------- PRICING TIE-IN ---------- */}
      <section className="section">
        <div className="container-page flex flex-col gap-6">
          <Card className="lift border-brand-500/30 bg-card">
            <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between md:gap-6">
              <div className="flex items-start gap-3">
                <div className="inline-flex size-9 shrink-0 items-center justify-center rounded-md border border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300">
                  <Wallet className="size-4" aria-hidden />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-eyebrow">What it costs</p>
                  <CardTitle className="font-display text-h3 text-balance text-foreground">
                    One plan covers {profile.name}.
                  </CardTitle>
                  <CardDescription className="text-body text-muted-foreground">
                    Bivouc plans are open — see the live pricing for what each surface costs.{' '}
                    {profile.researchTab === 'flag-bots'
                      ? 'Flag-bots coverage scales with the repos on watch.'
                      : 'Generative-agent scope stays narrow even on the higher tiers.'}
                  </CardDescription>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 md:flex-col md:items-end">
                <Button asChild size="lg" className="gap-2 shadow-brand">
                  <Link href="/pricing">
                    See plans
                    <ArrowRight className="size-4" aria-hidden />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="ghost">
                  <Link href="/vs">← All comparisons</Link>
                </Button>
              </div>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* ---------- CTA + CROSS-LINKS ---------- */}
      <section className="section-lg">
        <div className="container-page flex flex-col gap-8">
          <Card className="relative overflow-hidden border-brand-500/30 bg-gradient-to-br from-brand-500/15 via-background to-background p-8 md:p-10">
            <div
              aria-hidden
              className="absolute -right-20 -top-20 size-72 rounded-full bg-brand-500/20 blur-3xl"
            />
            <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between md:gap-10">
              <div className="flex flex-col gap-3">
                <p className="text-eyebrow">Try Bivouc</p>
                <h3 className="font-display text-h2 text-balance text-foreground">
                  Watch one repo for a week. Same coverage, smarter queue.
                </h3>
                <p className="max-w-xl text-body-lg text-muted-foreground">{profile.ctaSubline}</p>
              </div>
              <div className="flex flex-col gap-3 md:items-end">
                <Button asChild size="lg" className="gap-2 shadow-brand">
                  <Link href="/signup">
                    Sign up
                    <ArrowRight className="size-4" aria-hidden />
                  </Link>
                </Button>
                <div className="flex flex-wrap items-center gap-3 text-small text-muted-foreground">
                  <Link
                    href="/vs"
                    className="underline decoration-dotted underline-offset-4 hover:text-foreground"
                  >
                    ← All comparisons
                  </Link>
                  <span aria-hidden>·</span>
                  <Link
                    href="/"
                    className="underline decoration-dotted underline-offset-4 hover:text-foreground"
                  >
                    Landing page
                  </Link>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </main>
  );
}
