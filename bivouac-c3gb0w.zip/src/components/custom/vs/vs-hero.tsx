// @polsia:user-owned — /vs hero island. Headline + value-prop + the shared
// /signup CTA + a soft anchor to the comparison grid below. Pure presentational
// — data lives in src/lib/business/vs-comparison.ts.

'use client';

import { ArrowRight, GitCompare } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export function VsHero() {
  return (
    <section className="relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0 hidden md:block">
        <svg
          viewBox="0 0 800 600"
          className="absolute -right-40 -top-24 h-[760px] w-[760px] text-brand-500/15"
          fill="none"
          stroke="currentColor"
          role="presentation"
        >
          <title>Decorative comparison chart</title>
          <path d="M 120 460 L 680 460" strokeWidth="1.5" />
          <path d="M 120 320 L 680 320" strokeWidth="1.5" />
          <path d="M 120 180 L 680 180" strokeWidth="1.5" />
          <circle cx="400" cy="460" r="6" fill="currentColor" />
          <circle cx="565" cy="320" r="6" fill="currentColor" />
          <circle cx="235" cy="180" r="6" fill="currentColor" />
          <path d="M 400 460 L 565 320 L 235 180" strokeDasharray="3 4" />
        </svg>
      </div>

      <div className="container-page relative grid gap-10 pt-section-lg pb-section md:grid-cols-[1.1fr_1fr] md:items-center md:gap-12">
        <div className="flex flex-col gap-6">
          <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
            <GitCompare className="size-3.5 text-brand-700 dark:text-brand-300" aria-hidden />
            <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
              Side by side · same research, four tools
            </span>
          </Badge>

          <h1 className="font-display text-display text-balance text-foreground">
            How Bivouc measures up against the tools already in your queue.
          </h1>

          <p className="max-w-2xl text-body-lg text-muted-foreground">
            Same live research that powers the “How Bivouc compares” section on the landing page —
            grown into per-competitor pages that cite the exact finding each row is built on. The
            same <span className="text-foreground">/signup</span> button drops you straight into a
            trial.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <Button asChild size="lg" className="gap-2 shadow-brand">
              <Link href="/signup">
                Sign up
                <ArrowRight className="size-4" aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="#vs-grid">
                Jump to the comparisons
                <ArrowRight className="size-4" aria-hidden />
              </Link>
            </Button>
          </div>

          <p className="max-w-xl text-small text-muted-foreground">
            Four competitors. Three dimensions each. Every row traces back to a verbatim bullet from
            the comparison research — no invented trade-offs.
          </p>
        </div>

        <div className="hidden md:block">
          <div className="relative overflow-hidden rounded-lg border border-border bg-card p-6 shadow-md">
            <div className="absolute -right-16 -top-16 size-48 rounded-full bg-brand-500/15 blur-3xl" />
            <div className="relative flex flex-col gap-4">
              <div
                aria-hidden
                className="flex items-center justify-between border-b border-border pb-3 text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground"
              >
                <span>Dimension</span>
                <span>Bivouc</span>
                <span>Competitor</span>
              </div>
              {[
                ['Trigger cadence', 'continuous', 'on alert'],
                ['Decision-making', 'solved locally', 'human review'],
                ['On-call load', 'auto-merge on green', 'every PR'],
              ].map(([dim, a, b]) => (
                <div
                  key={dim}
                  className="grid grid-cols-[1.2fr_1fr_1fr] items-center gap-3 text-small"
                >
                  <span className="font-medium text-foreground">{dim}</span>
                  <span className="rounded-md border border-brand-500/30 bg-brand-500/10 px-2 py-1 text-center font-mono text-caption font-semibold text-brand-700 dark:text-brand-300">
                    {a}
                  </span>
                  <span className="rounded-md border border-border bg-muted px-2 py-1 text-center font-mono text-caption text-muted-foreground">
                    {b}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
