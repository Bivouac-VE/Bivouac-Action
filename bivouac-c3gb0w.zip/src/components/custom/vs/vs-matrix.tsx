// @polsia:user-owned — /vs hub matrix. One table that lines up every supported
// competitor alongside Bivouac across the same three dimensions the deep page
// uses. Cells come from `matrixSummary()` so this never lives apart from the
// per-competitor deep pages. Static data — pure presentational.

'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  type CompetitorSlug,
  competitorOrder,
  competitorProfiles,
  matrixSummary,
} from '@/lib/business/vs-comparison';

type DimensionKey = 'triggerCadence' | 'decisionMaking' | 'onCallAudit';

const DIMENSIONS: { key: DimensionKey; label: string; source: string }[] = [
  {
    key: 'triggerCadence',
    label: 'Trigger cadence',
    source: 'flag-bots · “Strong at surfacing” · fix-bots · “General-purpose”',
  },
  {
    key: 'decisionMaking',
    label: 'Decision-making',
    source: 'flag-bots · “No judgment” · fix-bots · “Broad blast radius”',
  },
  {
    key: 'onCallAudit',
    label: 'On-call load & audit',
    source: 'flag-bots · “Queue pressure” · fix-bots · “Unregulated trust”',
  },
];

const BIVOUAC_NAME = 'Bivouac';

export function VsMatrix() {
  return (
    <section className="bg-muted/30 section border-y border-border">
      <div className="container-page flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <p className="text-eyebrow">Side by side</p>
          <h2 className="font-display text-h1 text-balance text-foreground">
            Every competitor, lined up against Bivouac.
          </h2>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            The same research used in the per-tool pages, lined up side by side. Three dimensions,
            every cell derived from one source — open a comparison for the full table.
          </p>
        </div>

        <div className="overflow-x-auto rounded-lg border border-border bg-card shadow-sm">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/60 hover:bg-muted/60">
                <TableHead className="w-[20%] text-foreground">Capability</TableHead>
                <TableHead className="w-[26%] text-foreground">{BIVOUAC_NAME}</TableHead>
                {competitorOrder.map((slug: CompetitorSlug) => (
                  <TableHead key={slug} className="w-[18%] text-foreground">
                    {competitorProfiles[slug].name}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {DIMENSIONS.map((dim) => (
                <TableRow key={dim.key}>
                  <TableCell className="align-top">
                    <p className="font-display text-h4 text-foreground">{dim.label}</p>
                    <p className="mt-2 text-caption text-muted-foreground">{dim.source}</p>
                  </TableCell>
                  <TableCell className="align-top">
                    <div className="rounded-md border border-brand-500/40 bg-brand-500/10 p-3 text-small text-foreground">
                      {firstBivouacCell(dim.key)}
                    </div>
                  </TableCell>
                  {competitorOrder.map((slug) => {
                    const summary = matrixSummary(competitorProfiles[slug]);
                    return (
                      <TableCell key={slug} className="align-top">
                        <div className="rounded-md border border-border bg-background p-3 text-small text-muted-foreground">
                          {summary[dim.key].competitor}
                        </div>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <p className="text-small text-muted-foreground">
          Each cell is a first-sentence excerpt of the corresponding row in the deep-page table —
          open any competitor above for the full comparison.
        </p>
      </div>
    </section>
  );
}

function firstBivouacCell(key: DimensionKey): string {
  // Bivouac row text is identical per dimension across all profiles, so the
  // first profile's summary returns the right cell. Hoist into a const so
  // strict-mode array-index types stay satisfied (`competitorOrder[0]` widens).
  const firstSlug = competitorOrder[0] as CompetitorSlug;
  return matrixSummary(competitorProfiles[firstSlug])[key].bivouac;
}
