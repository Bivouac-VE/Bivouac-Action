// @polsia:user-owned — shared "Continue with GitHub" button used by both the
// sign-in and sign-up forms. Calls better-auth's social sign-in client; the
// client redirects to /api/auth/sign-in/social/github, which the catch-all
// handler forwards to GitHub. On success GitHub redirects back to
// /api/auth/callback/github which sets the session cookie and 302s to
// callbackURL (the returnTo). The button disables itself on click so a
// double-tap doesn't fire two redirects.

'use client';

import { Loader2 } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { signIn } from '@/lib/auth-client';

export interface OAuthButtonProps {
  /** Where to land after the OAuth callback. Must be a same-origin path. */
  callbackURL: string;
}

export function OAuthButton({ callbackURL }: OAuthButtonProps) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setPending(true);
    setError(null);
    try {
      const { error: signInError } = await signIn.social({
        provider: 'github',
        callbackURL,
      });
      if (signInError) {
        setError(signInError.message ?? 'Could not start GitHub sign-in.');
        setPending(false);
      }
      // On success the client triggers a redirect — leave the button disabled
      // so a stray click doesn't kick off a second OAuth flow.
    } catch {
      setError('Could not start GitHub sign-in.');
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <Button
        type="button"
        variant="outline"
        disabled={pending}
        onClick={handleClick}
        className="w-full"
      >
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden />
            <span>Redirecting to GitHub…</span>
          </>
        ) : (
          <GithubMark />
        )}
      </Button>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
    </div>
  );
}

function GithubMark() {
  return (
    <span className="inline-flex items-center gap-2">
      <svg
        aria-hidden="true"
        viewBox="0 0 24 24"
        className="size-5 fill-foreground"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.009-.868-.014-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0 1 12 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.02 10.02 0 0 0 22 12.017C22 6.484 17.522 2 12 2Z"
        />
      </svg>
      <span>Continue with GitHub</span>
    </span>
  );
}
