// @polsia:user-owned — single changelog entry surface, used by /changelog.
// Pure presentational Server Component (date + tag badge + title + summary +
// optional links row). No state, no fetch, no client boundary needed; rendered
// by the client island inside ChangelogTimeline.
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { ChangelogEntry, ChangelogTag } from '@/lib/contracts/changelog';

const TAG_LABEL: Record<ChangelogTag, string> = {
  Hero: 'Hero',
  Pricing: 'Pricing',
  Dashboard: 'Dashboard',
  Content: 'Content',
  Tooling: 'Tooling',
};

// Brand-tuned tag tones — five distinct, on-palette accents with light + dark
// variants so each tag reads distinctly without drifting from the design system.
const TAG_TONE: Record<ChangelogTag, string> = {
  Hero: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
  Pricing: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  Dashboard: 'border-sky-500/40 bg-sky-500/10 text-sky-700 dark:text-sky-300',
  Content: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  Tooling: 'border-violet-500/40 bg-violet-500/10 text-violet-700 dark:text-violet-300',
};

const DATE_FORMAT = new Intl.DateTimeFormat('en-US', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : DATE_FORMAT.format(d);
}

export function ChangelogEntryCard({ entry }: { entry: ChangelogEntry }) {
  const links = entry.links ?? [];
  return (
    <article className="lift flex flex-col gap-3 rounded-md border border-border/80 bg-card/70 p-5">
      <header className="flex flex-wrap items-center gap-2 text-caption uppercase tracking-[0.08em] text-muted-foreground">
        <time dateTime={entry.date}>{formatDate(entry.date)}</time>
        <span aria-hidden className="text-border">
          ·
        </span>
        <Badge variant="outline" className={`border ${TAG_TONE[entry.tag]}`}>
          {TAG_LABEL[entry.tag]}
        </Badge>
      </header>
      <h3 className="font-display text-h4 tracking-tight text-foreground">{entry.title}</h3>
      <p className="text-body text-muted-foreground">{entry.summary}</p>
      {links.length > 0 ? (
        <footer className="flex flex-wrap items-center gap-x-1 gap-y-1 pt-1 text-caption">
          {links.map((link, i) => (
            <span key={`${entry.date}-${link.href}`} className="flex items-center gap-1">
              <Button asChild variant="link" size="sm" className="h-auto px-0 text-caption">
                <a
                  href={link.href}
                  target={link.href.startsWith('http') ? '_blank' : undefined}
                  rel={link.href.startsWith('http') ? 'noreferrer noopener' : undefined}
                >
                  {link.label}
                </a>
              </Button>
              {i < links.length - 1 ? (
                <span aria-hidden className="text-border">
                  ·
                </span>
              ) : null}
            </span>
          ))}
        </footer>
      ) : null}
    </article>
  );
}
