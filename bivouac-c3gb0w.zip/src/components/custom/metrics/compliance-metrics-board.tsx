// @polsia:user-owned — Compliance dashboard surface mounted at
// /dashboard/metrics. Composes the brief's three series (MTTP, auto-merge
// rate, human-override rate) over a 30/60/90 toggle plus the per-repo
// breakdown table. All data runs through /api/metrics via apiFetch + the
// ComplianceMetrics zod contract. The directory page stays a Server
// Component exporting metadata; this island owns the fetch + URL sync.

'use client';

import { AlertTriangle, GitMerge, Info, ScrollText, TimerReset, UserCheck } from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ZodType } from 'zod';
import { AutoMergeChart } from '@/components/custom/metrics/auto-merge-chart';
import { MttpTrendChart } from '@/components/custom/metrics/mttp-trend-chart';
import { OverrideRateChart } from '@/components/custom/metrics/override-rate-chart';
import { RepoBreakdownTable } from '@/components/custom/metrics/repo-breakdown-table';
import { WindowToggle } from '@/components/custom/metrics/window-toggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { apiFetch } from '@/lib/api-client';
import {
  ComplianceMetrics,
  type MetricsRangeDays,
  MetricsRangeDaysEnum,
} from '@/lib/contracts/metrics';
import { DEFAULT_RANGE_DAYS, MetricsRangeContext } from './metrics-context';

interface FetchState<T> {
  data: T | null;
  error: string | null;
  loaded: boolean;
}

function parseWindow(raw: string | null): MetricsRangeDays {
  const candidate = (raw ?? '').trim().toLowerCase();
  const numeric = candidate.endsWith('d') ? candidate.slice(0, -1) : candidate;
  const parsed = MetricsRangeDaysEnum.safeParse(Number.parseInt(numeric, 10));
  return parsed.success ? parsed.data : DEFAULT_RANGE_DAYS;
}

function ErrorBanner({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm">
      <AlertTriangle aria-hidden="true" className="mt-0.5 size-4 text-destructive" />
      <div className="grid flex-1 gap-1">
        <p className="font-medium text-foreground">Couldn’t load compliance metrics.</p>
        <p className="text-muted-foreground">{message}</p>
      </div>
      <button
        type="button"
        onClick={onRetry}
        className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border/70 bg-background px-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
      >
        <TimerReset aria-hidden="true" className="size-3.5" />
        Retry
      </button>
    </div>
  );
}

function ChartSkeleton() {
  return (
    <div className="grid h-[240px] w-full place-items-center rounded-md border border-border/60 bg-muted/20">
      <span className="sr-only">Loading compliance metric</span>
      <Skeleton className="h-4 w-48" />
    </div>
  );
}

function TableSkeleton() {
  return (
    <div className="grid gap-2 rounded-md border border-border/70 bg-card/80 p-5">
      <Skeleton className="h-4 w-40" />
      <Skeleton className="h-3 w-64" />
      <Skeleton className="mt-2 h-32 w-full" />
    </div>
  );
}

interface MetricCardProps {
  title: string;
  subtitle: string;
  tone: 'brand' | 'emerald' | 'amber';
  icon: typeof TimerReset;
  tooltip: string;
  children: React.ReactNode;
}

const TONE_RING: Record<MetricCardProps['tone'], string> = {
  brand: 'ring-1 ring-inset ring-brand-500/30 dark:ring-brand-500/20',
  emerald: 'ring-1 ring-inset ring-emerald-500/30 dark:ring-emerald-500/20',
  amber: 'ring-1 ring-inset ring-amber-500/30 dark:ring-amber-500/20',
};

const TONE_ICON: Record<MetricCardProps['tone'], string> = {
  brand: 'text-brand-600 dark:text-brand-400',
  emerald: 'text-emerald-600 dark:text-emerald-400',
  amber: 'text-amber-600 dark:text-amber-400',
};

function MetricCard({ title, subtitle, tone, icon: Icon, tooltip, children }: MetricCardProps) {
  return (
    <Card className={`flex h-full flex-col gap-3 bg-card/80 ${TONE_RING[tone]}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-2">
        <div className="grid gap-1">
          <div className="flex items-center gap-2">
            <CardTitle className="font-display text-h4 leading-tight tracking-tight">
              {title}
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  aria-label={`${title} definition`}
                  className="inline-flex size-5 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  <Info aria-hidden="true" className="size-3.5" />
                </button>
              </TooltipTrigger>
              <TooltipContent>{tooltip}</TooltipContent>
            </Tooltip>
          </div>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
        <span
          className={`flex size-8 items-center justify-center rounded-md border border-border/60 bg-background ${TONE_ICON[tone]}`}
        >
          <Icon aria-hidden="true" className="size-4" />
        </span>
      </CardHeader>
      <CardContent className="flex flex-col gap-1 p-5 pt-0">{children}</CardContent>
    </Card>
  );
}

export function ComplianceMetricsBoard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const rangeDays = useMemo<MetricsRangeDays>(
    () => parseWindow(searchParams.get('window')),
    [searchParams],
  );

  // Hold a pending range so we can mirror it to the URL in the same effect
  // pass that initiates the fetch — keeps the URL state from racing the
  // fetch when the user clicks a toggle quickly.
  const [pendingRange, setPendingRange] = useState<MetricsRangeDays | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [data, setData] = useState<FetchState<ComplianceMetrics>>({
    data: null,
    error: null,
    loaded: false,
  });

  useEffect(() => {
    if (pendingRange === null) return;
    const next = new URLSearchParams(searchParams.toString());
    if (pendingRange === DEFAULT_RANGE_DAYS) {
      next.delete('window');
    } else {
      next.set('window', `${pendingRange}d`);
    }
    const qs = next.toString();
    router.replace(qs.length > 0 ? `?${qs}` : '?', { scroll: false });
    setPendingRange(null);
  }, [pendingRange, router, searchParams]);

  useEffect(() => {
    const controller = new AbortController();
    setData({ data: null, error: null, loaded: false });

    const schema: ZodType<ComplianceMetrics> = ComplianceMetrics;
    void (async () => {
      try {
        const json = await apiFetch<ComplianceMetrics>(
          `/api/metrics?window=${rangeDays}d&_=${reloadKey}`,
          { schema, signal: controller.signal },
        );
        if (!controller.signal.aborted) {
          setData({ data: json, error: null, loaded: true });
        }
      } catch (err) {
        if (!controller.signal.aborted) {
          setData({
            data: null,
            error: err instanceof Error ? err.message : 'Unknown error',
            loaded: true,
          });
        }
      }
    })();

    return () => {
      controller.abort();
    };
  }, [rangeDays, reloadKey]);

  const handleRangeChange = useCallback((next: MetricsRangeDays) => {
    setPendingRange(next);
    setReloadKey((k) => k + 1);
  }, []);

  const handleRetry = useCallback(() => {
    setReloadKey((k) => k + 1);
  }, []);

  const loading = !data.loaded;
  const errored = data.error !== null && data.loaded;
  const payload = data.data;
  const emptyRepos =
    payload !== null && payload.connectedRepoCount === 0 && payload.repos.length === 0;
  const auditHref =
    payload !== null
      ? `/dashboard/audit?from=${encodeURIComponent(payload.from)}&to=${encodeURIComponent(payload.to)}`
      : `/dashboard/audit?range=${rangeDays}d`;

  return (
    <MetricsRangeContext.Provider
      value={{
        rangeDays,
        setRangeDays: handleRangeChange,
      }}
    >
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div className="flex flex-col gap-2">
            <p className="text-eyebrow">Compliance metrics</p>
            <p className="max-w-2xl text-body text-muted-foreground">
              Mean time to patch, auto-merge rate, and human-override rate over time — one pane that
              backs the agent’s value claim with daily evidence, plus a per-repo breakdown for
              reviewers.
            </p>
          </div>
          <WindowToggle busy={loading} />
        </div>

        {errored && payload === null ? (
          <ErrorBanner message={data.error ?? 'Unknown error'} onRetry={handleRetry} />
        ) : null}

        <div className="grid gap-4 lg:grid-cols-3">
          {payload !== null && !loading ? (
            <>
              <MetricCard
                title="Mean time to patch"
                subtitle="Average hours from PR-open to a terminal decision, per day."
                tone="brand"
                icon={TimerReset}
                tooltip="MTTP = avg(now − createdAt) in hours over terminal-decision rows whose createdAt falls in that calendar day. Used as a proxy for the brief's CVE/breaking-change → PR-opened lead time since the schema's only timestamp is createdAt."
              >
                <MttpTrendChart points={payload.mttpSeries.points} />
              </MetricCard>
              <MetricCard
                title="Auto-merge rate"
                subtitle="Share of terminal-decision rows the agent merged without a human page."
                tone="emerald"
                icon={GitMerge}
                tooltip="Auto-merge rate = count(AUTO_MERGE) / count(AUTO_MERGE | MANUAL_REVIEW | BLOCKED), bucketed by day. Denominator-zero days emit 0 so the line stays continuous."
              >
                <AutoMergeChart points={payload.autoMergeSeries.points} />
              </MetricCard>
              <MetricCard
                title="Human-override rate"
                subtitle="Share of terminal decisions that paged a human reviewer."
                tone="amber"
                icon={UserCheck}
                tooltip="Override rate = count(MANUAL_REVIEW) / count(TERMINAL), per day. The CveTriageLog table IS the audit log — MANUAL_REVIEW rows surface an actor='human' entry in /dashboard/audit."
              >
                <OverrideRateChart points={payload.overrideSeries.points} />
              </MetricCard>
            </>
          ) : (
            <>
              <ChartSkeleton />
              <ChartSkeleton />
              <ChartSkeleton />
            </>
          )}
        </div>

        <section className="flex flex-col gap-3">
          <div className="flex items-end justify-between gap-3">
            <div>
              <h2 className="font-display text-h3 tracking-tight text-foreground">
                Per-repo breakdown
              </h2>
              <p className="text-sm text-muted-foreground">
                Each connected repo’s headline numbers plus a 12-week MTTP sparkline.
              </p>
            </div>
          </div>
          {loading || payload === null ? (
            <TableSkeleton />
          ) : (
            <RepoBreakdownTable repos={payload.repos} />
          )}
          {emptyRepos && payload !== null ? (
            <p className="text-xs text-muted-foreground">
              Compliance metrics become visible once at least one repo is connected.
            </p>
          ) : null}
        </section>

        <div className="flex justify-end">
          <Button asChild variant="outline" size="default">
            <Link href={auditHref} aria-label="View underlying audit rows for the selected window">
              <ScrollText aria-hidden="true" className="size-4" />
              View underlying audit rows
            </Link>
          </Button>
        </div>
      </div>
    </MetricsRangeContext.Provider>
  );
}
