// @polsia:user-owned — 30/60/90-day window toggle for the compliance board.
// Reuses the Radix <Tabs/> primitive (already in the UI set) as a single-
// group selector. Reads + writes through MetricsRangeContext so the three
// daily charts + the per-repo table reflect the same window without each
// board child re-deriving the param. Disabled while the board is fetching
// to avoid a flicker mid-update.

'use client';

import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { MetricsRangeDays } from '@/lib/contracts/metrics';
import { useMetricsRange } from './metrics-context';

const RANGES: MetricsRangeDays[] = [30, 60, 90];

export interface WindowToggleProps {
  /** Optional busy flag; when true the trigger is interactive but visually muted. */
  busy?: boolean;
}

export function WindowToggle({ busy = false }: WindowToggleProps) {
  const { rangeDays, setRangeDays } = useMetricsRange();
  return (
    <Tabs
      value={String(rangeDays)}
      onValueChange={(value) => {
        const parsed = Number.parseInt(value, 10);
        if (parsed === 30 || parsed === 60 || parsed === 90) {
          setRangeDays(parsed as MetricsRangeDays);
        }
      }}
      aria-label="Compliance metrics window"
    >
      <TabsList className={`bg-muted/60 ${busy ? 'opacity-70' : ''}`}>
        {RANGES.map((d) => (
          <TabsTrigger key={d} value={String(d)} type="button">
            Last {d} days
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
}
