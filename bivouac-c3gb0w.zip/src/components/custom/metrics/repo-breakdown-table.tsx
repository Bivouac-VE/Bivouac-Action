// @polsia:user-owned — Per-repo breakdown table for the compliance dashboard.
// Lists each repo connected by the signed-in user with the three headline
// numbers (MTTP hours, auto-merge %, override %) and a 12-week sparkline of
// weekly MTTP hours. Rows default to ascending MTTP so the worst-offending
// repos sort to the top — the board re-sorts if the brief ever calls for a
// different default. Empty-state redirects to /dashboard/repos.

'use client';

import { AlertCircle } from 'lucide-react';
import Link from 'next/link';
import { useMemo } from 'react';
import { Button } from '@/components/ui/button';
import type { RepoBreakdownRow } from '@/lib/contracts/metrics';

export interface RepoBreakdownTableProps {
  repos: RepoBreakdownRow[];
}

function fmtHours(n: number | null): string {
  if (n === null) return '—';
  if (n < 1) return `${Math.round(n * 60)}m`;
  if (n < 24) return `${Math.round(n)}h`;
  const days = n / 24;
  if (days < 14) return `${Math.round(days)}d`;
  return `${Math.round(days)}d`;
}

function fmtPercent(v: number): string {
  return `${Math.round(v * 100)}%`;
}

const SPARK_WIDTH = 120;
const SPARK_HEIGHT = 28;

function MiniSparkline({ values }: { values: Array<number | null> }) {
  if (values.length === 0) {
    return (
      <div className="grid h-7 w-[120px] place-items-center rounded border border-dashed border-border/60 text-[10px] text-muted-foreground">
        —
      </div>
    );
  }
  const finite = values.filter((v): v is number => v !== null && Number.isFinite(v));
  if (finite.length === 0) {
    return (
      <div className="grid h-7 w-[120px] place-items-center rounded border border-dashed border-border/60 text-[10px] text-muted-foreground">
        no patch weeks
      </div>
    );
  }
  const max = Math.max(...finite);
  // Cap the top so a slow repo doesn't flatten the visible trend.
  const yMax = max <= 24 ? 24 : max * 1.05;
  const slotCount = values.length;
  const slotWidth = slotCount > 1 ? SPARK_WIDTH / (slotCount - 1) : 0;
  const projectX = (idx: number) => idx * slotWidth;
  const projectY = (v: number) => SPARK_HEIGHT - (v / yMax) * SPARK_HEIGHT;

  const segments: Array<{ id: string; d: string }> = [];
  let currentD: string | null = null;
  let currentFirst = 0;
  for (let i = 0; i < values.length; i += 1) {
    const v = values[i];
    if (v === undefined || v === null || !Number.isFinite(v)) {
      if (currentD !== null) {
        segments.push({ id: `seg-${currentFirst}-${i}`, d: currentD });
        currentD = null;
      }
      continue;
    }
    const value: number = v;
    const command: 'M' | 'L' = currentD === null ? 'M' : 'L';
    const x = projectX(i).toFixed(2);
    const y = projectY(value).toFixed(2);
    const nextD: string =
      currentD === null ? `${command}${x},${y}` : `${currentD}${command}${x},${y}`;
    if (currentD === null) currentFirst = i;
    currentD = nextD;
  }
  if (currentD !== null) segments.push({ id: `seg-${currentFirst}-end`, d: currentD });

  return (
    <svg
      viewBox={`0 0 ${SPARK_WIDTH} ${SPARK_HEIGHT}`}
      role="img"
      aria-label="12-week MTTP sparkline"
      className="block h-7 w-[120px]"
    >
      <title>MTTP hours, last 12 weeks</title>
      {segments.map((segment) => (
        <path
          key={segment.id}
          d={segment.d}
          fill="none"
          strokeWidth={1.5}
          strokeLinecap="round"
          strokeLinejoin="round"
          className="stroke-brand-500"
        />
      ))}
      {values.map((pointValue, idxPos) => {
        if (pointValue === null || !Number.isFinite(pointValue)) return null;
        // Synthetic day-zero key derived from the value + slot position is
        // not stable across re-orders; use the day-coordinate string instead.
        const dayCount = `${idxPos}-${pointValue}`;
        return (
          <g key={`spark-dot-${dayCount}`}>
            <circle
              cx={projectX(idxPos)}
              cy={projectY(pointValue)}
              r={1.5}
              className="fill-brand-500"
            />
          </g>
        );
      })}
    </svg>
  );
}

export function RepoBreakdownTable({ repos }: RepoBreakdownTableProps) {
  const sorted = useMemo(() => {
    const rows = repos.slice();
    rows.sort((a, b) => {
      // Per the brief, default sort by MTTP ascending so a reviewer sees
      // repos at a glance — nulls land at the bottom so empty repos don't
      // crowd the top, then numeric MTTP orders fastest-to-slowest. Patch
      // counts and alphabetic order are the secondary ordering tie-breakers.
      if (a.mttpHours === null && b.mttpHours === null) {
        if (a.patchCount !== b.patchCount) return b.patchCount - a.patchCount;
        return a.fullName.localeCompare(b.fullName);
      }
      if (a.mttpHours === null) return 1;
      if (b.mttpHours === null) return -1;
      if (a.mttpHours === b.mttpHours) {
        return a.fullName.localeCompare(b.fullName);
      }
      return a.mttpHours - b.mttpHours;
    });
    return rows;
  }, [repos]);

  if (sorted.length === 0) {
    return (
      <div className="flex items-start gap-3 rounded-md border border-border/60 bg-muted/30 p-5 text-sm">
        <AlertCircle aria-hidden="true" className="mt-0.5 size-4 text-muted-foreground" />
        <div className="grid flex-1 gap-2">
          <p className="font-medium text-foreground">No compliance metrics yet.</p>
          <p className="text-muted-foreground">
            Connect a repo to see compliance metrics. Numbers here populate once Bivouac opens its
            first patch PR for your account.
          </p>
          <div>
            <Button asChild variant="outline" size="sm">
              <Link href="/dashboard/repos">Manage repos</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-md border border-border/70 bg-card/80">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-border/70 bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <th scope="col" className="px-4 py-3 font-semibold">
              Repo
            </th>
            <th
              scope="col"
              className="px-4 py-3 text-right font-semibold"
              title="Mean time to patch — hours from PR-opened to terminal decision"
            >
              MTTP
            </th>
            <th
              scope="col"
              className="px-4 py-3 text-right font-semibold"
              title="Auto-merged as a share of all terminal-decision rows"
            >
              Auto-merge
            </th>
            <th
              scope="col"
              className="px-4 py-3 text-right font-semibold"
              title="Paged a human as a share of all terminal-decision rows"
            >
              Override
            </th>
            <th scope="col" className="px-4 py-3 text-right font-semibold">
              Patches
            </th>
            <th scope="col" className="px-4 py-3 font-semibold">
              Trend
            </th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((row) => (
            <tr
              key={row.repoId}
              className="border-b border-border/40 last:border-b-0 hover:bg-muted/20"
            >
              <td className="px-4 py-3 font-medium text-foreground">{row.fullName}</td>
              <td className="px-4 py-3 text-right font-mono tabular-nums text-foreground">
                {fmtHours(row.mttpHours)}
              </td>
              <td className="px-4 py-3 text-right font-mono tabular-nums text-foreground">
                {fmtPercent(row.autoMergeRate)}
              </td>
              <td className="px-4 py-3 text-right font-mono tabular-nums text-foreground">
                {fmtPercent(row.overrideRate)}
              </td>
              <td className="px-4 py-3 text-right text-muted-foreground tabular-nums">
                {row.patchCount}
              </td>
              <td className="px-4 py-3">
                <div className="flex justify-end">
                  <MiniSparkline values={row.sparkMttpHours} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
