// @polsia:user-owned — shared inline-SVG line-chart primitive for the
// compliance dashboard's daily series (MTTP and the two rates). Parameterised
// over `{ date: YYYY-MM-DD, value: number | null }[]` so a single chart
// can render heterogeneous data (finite points with null gaps) plus a
// caller-supplied y-axis formatter. Empty stretches with null gaps break the
// path into a fresh subpath so an uneventful day stays a gap, not a
// misleading zero dot. Inline SVG keeps it CSP-safe with no chart deps.

import { useMemo } from 'react';

export interface DailyLineChartPoint {
  date: string;
  value: number | null;
}

export interface DailyLineChartProps {
  points: DailyLineChartPoint[];
  fmtY: (n: number) => string;
  /** Stroke colour class (Tailwind utility); defaults to brand. */
  strokeClass?: string;
  /** Inclusive [0, 1] ceiling for 0..1 rate series. Locks the y axis to
   *  0..1 instead of auto-scaling so the two rate charts share a scale. */
  fixedYMax?: number;
  /** Accessible label for the chart title element. */
  ariaLabel: string;
}

const CHART_WIDTH = 720;
const CHART_HEIGHT = 240;
const PADDING = { top: 16, right: 16, bottom: 28, left: 56 };

function fmtDay(iso: string): string {
  const date = new Date(`${iso}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

// For percent (0..1) series we want ticks at 0/25/50/75/100 — flatten those
// to integer percent labels. For other value ranges, three evenly-spaced
// ticks render a clean numeric baseline.
function buildTicks(yMax: number): number[] {
  if (yMax <= 1) {
    return [0, 0.25, 0.5, 0.75, 1];
  }
  if (yMax <= 10) {
    return [0, yMax / 2, yMax];
  }
  return [0, yMax / 2, yMax];
}

function niceCeiling(value: number): number {
  if (value <= 0) return 1;
  if (value <= 1) return 1;
  if (value <= 6) return Math.ceil(value);
  if (value <= 24) return Math.ceil(value / 6) * 6;
  if (value <= 72) return Math.ceil(value / 12) * 12;
  if (value <= 168) return Math.ceil(value / 24) * 24;
  return Math.ceil(value / 48) * 48;
}

export function DailyLineChart({
  points,
  fmtY,
  strokeClass = 'stroke-brand-500',
  fixedYMax,
  ariaLabel,
}: DailyLineChartProps) {
  const data = useMemo(() => points.slice().sort((a, b) => a.date.localeCompare(b.date)), [points]);
  const finiteValues = data
    .map((p) => p.value)
    .filter((v): v is number => v !== null && Number.isFinite(v));
  const innerWidth = CHART_WIDTH - PADDING.left - PADDING.right;
  const innerHeight = CHART_HEIGHT - PADDING.top - PADDING.bottom;

  if (data.length === 0) {
    return (
      <div className="grid h-[240px] w-full place-items-center rounded-md border border-dashed border-border/60 bg-muted/30 text-sm text-muted-foreground">
        No data in this window.
      </div>
    );
  }
  if (finiteValues.length === 0) {
    return (
      <div className="grid h-[240px] w-full place-items-center rounded-md border border-dashed border-border/60 bg-muted/30 text-sm text-muted-foreground">
        No patches with a terminal merge decision in this window.
      </div>
    );
  }

  const maxValue =
    fixedYMax !== undefined
      ? fixedYMax
      : niceCeiling(finiteValues.reduce((acc, v) => Math.max(acc, v), 0));
  const yMax = fixedYMax !== undefined ? Math.max(fixedYMax, maxValue) : maxValue;

  const slotCount = data.length;
  const slotWidth = slotCount > 1 ? innerWidth / (slotCount - 1) : 0;
  const projectX = (idx: number) => PADDING.left + idx * slotWidth;
  const projectY = (v: number) => {
    if (yMax === 0) return PADDING.top + innerHeight;
    return PADDING.top + innerHeight - (v / yMax) * innerHeight;
  };

  // Build a path made of finite segments only — a null day breaks the line.
  const segments: Array<{ key: string; d: string }> = [];
  let currentSegment: string | null = null;
  let currentSegmentStart = 0;
  for (let idx = 0; idx < data.length; idx += 1) {
    const point = data[idx];
    const value = point?.value;
    if (value === undefined || value === null || !Number.isFinite(value)) {
      if (currentSegment !== null) {
        const startDate = data[currentSegmentStart]?.date ?? 's';
        segments.push({ key: `${startDate}-${idx}`, d: currentSegment });
        currentSegment = null;
      }
      continue;
    }
    const command: 'M' | 'L' = currentSegment === null ? 'M' : 'L';
    const x = projectX(idx).toFixed(2);
    const y = projectY(value).toFixed(2);
    const newSegment: string =
      currentSegment === null ? `${command}${x},${y}` : `${currentSegment}${command}${x},${y}`;
    if (currentSegment === null) currentSegmentStart = idx;
    currentSegment = newSegment;
  }
  if (currentSegment !== null) {
    const startDate = data[currentSegmentStart]?.date ?? 's';
    segments.push({ key: `${startDate}-end`, d: currentSegment });
  }

  const ticks = buildTicks(yMax);
  const xLabelSlots =
    slotCount <= 6
      ? Array.from({ length: slotCount }, (_, i) => i)
      : [
          0,
          Math.floor(slotCount / 4),
          Math.floor(slotCount / 2),
          Math.floor((3 * slotCount) / 4),
          slotCount - 1,
        ];

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}
        role="img"
        aria-label={ariaLabel}
        className="block w-full"
      >
        <title>{ariaLabel}</title>
        {ticks.map((tick) => {
          const y =
            yMax === 0
              ? PADDING.top + innerHeight
              : PADDING.top + innerHeight - (tick / yMax) * innerHeight;
          return (
            <g key={`yt-${tick}`}>
              <line
                x1={PADDING.left}
                x2={CHART_WIDTH - PADDING.right}
                y1={y}
                y2={y}
                stroke="currentColor"
                strokeWidth={0.5}
                className="text-border"
              />
              <text
                x={PADDING.left - 8}
                y={y + 4}
                textAnchor="end"
                fontSize={11}
                className="fill-muted-foreground"
              >
                {fmtY(tick)}
              </text>
            </g>
          );
        })}
        {segments.map((segment) => (
          <path
            key={segment.key}
            d={segment.d}
            fill="none"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
            className={strokeClass}
          />
        ))}
        {data.map((point, idx) => {
          if (point.value === null || !Number.isFinite(point.value)) return null;
          const cx = projectX(idx);
          const cy = projectY(point.value);
          return (
            <circle
              key={`pt-${point.date}`}
              cx={cx}
              cy={cy}
              r={2.5}
              className={strokeClass.replace('stroke-', 'fill-')}
            >
              <title>{`${fmtDay(point.date)}: ${fmtY(point.value)}`}</title>
            </circle>
          );
        })}
        {xLabelSlots.map((idx) => {
          if (idx < 0 || idx >= data.length) return null;
          const point = data[idx];
          if (!point) return null;
          const x = projectX(idx);
          const y = CHART_HEIGHT - 8;
          return (
            <text
              key={`xt-${point.date}`}
              x={x}
              y={y}
              textAnchor="middle"
              fontSize={11}
              className="fill-muted-foreground"
            >
              {fmtDay(point.date)}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
