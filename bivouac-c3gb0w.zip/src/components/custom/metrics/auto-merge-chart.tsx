// @polsia:user-owned — Daily line-chart for the auto-merge rate (0..1).
// Distinct stroke colour (emerald) so the rate pairs visually separate from
// the override-rate line below it. Em-dash ticks at 0/25/50/75/100% make
// the rate scale legible at a glance.

import { DailyLineChart } from './daily-line-chart';

export interface AutoMergeChartProps {
  points: Array<{ date: string; value: number | null }>;
}

function fmtPercent(v: number): string {
  return `${Math.round(v * 100)}%`;
}

export function AutoMergeChart({ points }: AutoMergeChartProps) {
  return (
    <DailyLineChart
      points={points}
      fmtY={fmtPercent}
      strokeClass="stroke-emerald-500"
      fixedYMax={1}
      ariaLabel="Auto-merge rate per day"
    />
  );
}
