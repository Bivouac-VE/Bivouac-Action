// @polsia:user-owned — Daily line-chart for the human-override rate (0..1).
// Distinct stroke colour (amber) so the visual separation from the auto-merge
// line is unambiguous when both are stacked.

import { DailyLineChart } from './daily-line-chart';

export interface OverrideRateChartProps {
  points: Array<{ date: string; value: number | null }>;
}

function fmtPercent(v: number): string {
  return `${Math.round(v * 100)}%`;
}

export function OverrideRateChart({ points }: OverrideRateChartProps) {
  return (
    <DailyLineChart
      points={points}
      fmtY={fmtPercent}
      strokeClass="stroke-amber-500"
      fixedYMax={1}
      ariaLabel="Human-override rate per day"
    />
  );
}
