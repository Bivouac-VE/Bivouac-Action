// @polsia:user-owned — Daily line-chart wrapper for mean-time-to-patch.
// Projects { date, hours } daily points through the shared
// <DailyLineChart/> primitive, formatting hours with the same human-friendly
// rendering the KPI tiles use so a tooltip here matches the tile value. The
// exported symbol stays `MttpTrendChart` so the board can swap the series
// surface without renaming the import in the client island.

import { DailyLineChart } from './daily-line-chart';

export interface MttpTrendChartProps {
  points: Array<{ date: string; value: number | null }>;
}

function fmtHours(n: number): string {
  if (n < 1) {
    const mins = Math.round(n * 60);
    return mins <= 1 ? '<1m' : `${mins}m`;
  }
  if (n < 24) return `${Math.round(n)}h`;
  const days = n / 24;
  if (days < 14) return `${Math.round(days)}d`;
  return `${Math.round(days)}d`;
}

export function MttpTrendChart({ points }: MttpTrendChartProps) {
  return (
    <DailyLineChart
      points={points}
      fmtY={fmtHours}
      strokeClass="stroke-brand-500"
      ariaLabel="Mean time to patch per day"
    />
  );
}
