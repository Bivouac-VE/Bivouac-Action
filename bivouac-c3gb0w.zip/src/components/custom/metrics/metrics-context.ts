// @polsia:user-owned — Trivial React context for the compliance metrics
// dashboard. Hoists the selected 30/60/90-day window from <WindowToggle/> to
// <ComplianceMetricsBoard/>'s children (the three daily charts + the
// per-repo breakdown table) without prop-drilling. Board owns the state and
// exposes it through the provider, so a future component (a download button,
// a date-picker) can read or set `rangeDays` from the same source.

'use client';

import { createContext, useContext } from 'react';
import type { MetricsRangeDays } from '@/lib/contracts/metrics';

export const DEFAULT_RANGE_DAYS: MetricsRangeDays = 30;

export interface MetricsRangeContextValue {
  rangeDays: MetricsRangeDays;
  setRangeDays: (next: MetricsRangeDays) => void;
}

export const MetricsRangeContext = createContext<MetricsRangeContextValue | null>(null);

export function useMetricsRange(): MetricsRangeContextValue {
  const ctx = useContext(MetricsRangeContext);
  if (!ctx) {
    throw new Error('useMetricsRange must be used within a <MetricsRangeProvider/>');
  }
  return ctx;
}
