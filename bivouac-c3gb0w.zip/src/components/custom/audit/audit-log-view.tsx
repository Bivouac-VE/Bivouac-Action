// @polsia:user-owned — client island for /dashboard/audit. Owns:
//  - URL sync for filter values (refresh / share preserves state)
//  - the filter UI (repo multi-select via Popover, CVE id, date range,
//    severity, action incl. downgraded, actor)
//  - the debounced /api/audit-log fetch (re-fetches when filters change)
//  - the rendered table (or empty / loading / error branch)
//  - the "Download CSV" anchor — a plain <a href> with `download`, no
//    client-side Blob / URL.createObjectURL tricks.
//
// The page itself stays a Server Component that only exports metadata.

'use client';

import {
  AlertTriangle,
  ArrowDown,
  Bot,
  Check,
  ChevronDown,
  Download,
  Filter,
  RefreshCcw,
  TriangleAlert,
  UserRound,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import {
  type AuditLogAction,
  type AuditLogActor,
  AuditLogList,
  type AuditLogRow,
  type AuditLogSeverity,
} from '@/lib/contracts/audit-log';
import { type Repo, RepoList } from '@/lib/contracts/repos';
import { cn } from '@/lib/utils';
import { AuditEmptyState } from './audit-empty-state';

type Tones = { tone: string; label: string };

const SEVERITY_LABEL: Record<AuditLogSeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

function severityTone(s: AuditLogSeverity): Tones {
  switch (s) {
    case 'critical':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: SEVERITY_LABEL[s],
      };
    case 'high':
      return {
        tone: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
        label: SEVERITY_LABEL[s],
      };
    case 'medium':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: SEVERITY_LABEL[s],
      };
    case 'low':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: SEVERITY_LABEL[s],
      };
  }
}

const ACTION_LABEL: Record<AuditLogAction, string> = {
  'auto-merged': 'Auto-merged',
  downgraded: 'Downgraded',
  paged: 'Paged',
  declined: 'Declined',
  exported: 'Exported',
};

function actionTone(action: AuditLogAction): Tones {
  switch (action) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: ACTION_LABEL[action],
      };
    case 'downgraded':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: ACTION_LABEL[action],
      };
    case 'paged':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: ACTION_LABEL[action],
      };
    case 'declined':
      return {
        tone: 'border-destructive/30 bg-destructive/10 text-destructive',
        label: ACTION_LABEL[action],
      };
    case 'exported':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: ACTION_LABEL[action],
      };
  }
}

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c', 'sk-d', 'sk-e'] as const;

const ALL_VALUE = '__all__';

// `repo` URL value is comma-joined slugs (`owner/name,owner/name,...`). Empty
// string or all-empty filter clears the param.
function parseRepoParam(value: string): string[] {
  if (!value) return [];
  return Array.from(
    new Set(
      value
        .split(',')
        .map((part) => part.trim())
        .filter((part) => part.length > 0),
    ),
  );
}

function joinRepoParam(slugs: string[]): string {
  return slugs.filter((s) => s.length > 0).join(',');
}

function buildHref(base: string, searchParams: URLSearchParams): string {
  const filtered = new URLSearchParams();
  for (const [key, value] of searchParams.entries()) {
    const trimmed = value.trim();
    if (trimmed.length > 0) filtered.set(key, trimmed);
  }
  const qs = filtered.toString();
  return qs.length > 0 ? `${base}?${qs}` : base;
}

type FetchState =
  | { status: 'loading' }
  | { status: 'ready'; rows: AuditLogRow[] }
  | { status: 'error'; message: string };

export function AuditLogView() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const repoParam = searchParams.get('repo') ?? '';
  const selectedRepos = useMemo(() => parseRepoParam(repoParam), [repoParam]);
  const cveId = searchParams.get('cveId') ?? '';
  const from = searchParams.get('from') ?? '';
  const to = searchParams.get('to') ?? '';
  const severityParam = searchParams.get('severity') ?? '';
  const severity = (severityParam || '') as AuditLogSeverity | '';
  const actionParam = searchParams.get('action') ?? '';
  const action = (actionParam || '') as AuditLogAction | '';
  const actorParam = searchParams.get('actor') ?? '';
  const actor = (actorParam || '') as AuditLogActor | '';

  const [cveInput, setCveInput] = useState(cveId);
  useEffect(() => {
    setCveInput(cveId);
  }, [cveId]);

  const updateParam = useCallback(
    (key: string, value: string) => {
      const next = new URLSearchParams(searchParams.toString());
      if (value.trim().length === 0) {
        next.delete(key);
      } else {
        next.set(key, value.trim());
      }
      const qs = next.toString();
      router.replace(qs.length > 0 ? `?${qs}` : '?', { scroll: false });
    },
    [router, searchParams],
  );

  const toggleRepo = useCallback(
    (slug: string, checked: boolean) => {
      const current = new Set(selectedRepos);
      if (checked) {
        current.add(slug);
      } else {
        current.delete(slug);
      }
      updateParam('repo', joinRepoParam(Array.from(current)));
    },
    [selectedRepos, updateParam],
  );

  const clearRepos = useCallback(() => updateParam('repo', ''), [updateParam]);

  // Debounce CVE id edits — other inputs commit immediately so a date
  // picker or severity select doesn't feel laggy.
  useEffect(() => {
    if (cveInput === cveId) return;
    const timer = setTimeout(() => {
      updateParam('cveId', cveInput);
    }, 350);
    return () => {
      clearTimeout(timer);
    };
  }, [cveInput, cveId, updateParam]);

  // The list endpoint key must be stable across re-renders (otherwise it
  // would re-fetch on every render). Use the rendered query string as the
  // canonical dep so every filter change refetches exactly once.
  const listHref = buildHref('/api/audit-log', searchParams);
  const isFiltered = (listHref.split('?')[1] ?? '').length > 0;
  const exportHref = buildHref('/api/audit-log/export', searchParams);

  const [rowsState, setRowsState] = useState<FetchState>({ status: 'loading' });
  const [repos, setRepos] = useState<Repo[]>([]);

  useEffect(() => {
    let active = true;
    apiFetch(listHref, { schema: AuditLogList })
      .then((data) => {
        if (active) setRowsState({ status: 'ready', rows: data.items });
      })
      .catch((err: unknown) => {
        if (!active) return;
        const reason = err instanceof Error ? err.message : 'Could not load the audit log.';
        setRowsState({ status: 'error', message: reason });
      });
    return () => {
      active = false;
    };
  }, [listHref]);

  useEffect(() => {
    let active = true;
    apiFetch('/api/repos', { schema: RepoList })
      .then((data) => {
        if (active) setRepos(data.items);
      })
      .catch(() => {
        // Repo dropdown is informational; missing it shouldn't break the page.
      });
    return () => {
      active = false;
    };
  }, []);

  function resetFilters() {
    router.replace('?', { scroll: false });
  }

  return (
    <div className="flex flex-col gap-section">
      <Card aria-label="Audit log filters">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display text-h4">
            <Filter aria-hidden className="size-4 text-brand-700 dark:text-brand-300" />
            Filter the audit trail
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="audit-repo-trigger"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              Repo
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="audit-repo-trigger"
                  type="button"
                  variant="outline"
                  role="combobox"
                  aria-haspopup="listbox"
                  aria-expanded="false"
                  aria-label="Repo"
                  className={cn(
                    'w-full justify-between gap-2 font-normal',
                    selectedRepos.length === 0 && 'text-muted-foreground',
                  )}
                >
                  <span className="truncate">
                    {selectedRepos.length === 0
                      ? 'All repos'
                      : selectedRepos.length === 1
                        ? selectedRepos[0]
                        : `${selectedRepos.length} repos selected`}
                  </span>
                  <ChevronDown aria-hidden className="size-4 shrink-0 opacity-60" />
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-72 p-0">
                <div className="flex items-center justify-between border-b border-border/70 px-3 py-2">
                  <p className="text-xs font-medium uppercase tracking-normal text-muted-foreground">
                    Filter by repo
                  </p>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={clearRepos}
                    disabled={selectedRepos.length === 0}
                    className="h-7 gap-1 px-2"
                  >
                    Clear
                  </Button>
                </div>
                <ul className="max-h-64 overflow-y-auto p-1" aria-label="Repos">
                  {repos.length === 0 ? (
                    <li className="px-2 py-3 text-caption text-muted-foreground">
                      No connected repos yet.
                    </li>
                  ) : (
                    repos.map((rep) => {
                      const slug = `${rep.ownerHandle}/${rep.name}`;
                      const checked = selectedRepos.includes(slug);
                      const id = `audit-repo-${rep.id}`;
                      return (
                        <li key={rep.id}>
                          <label
                            htmlFor={id}
                            className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent hover:text-accent-foreground"
                          >
                            <Checkbox
                              id={id}
                              checked={checked}
                              onCheckedChange={(value) => toggleRepo(slug, value === true)}
                            />
                            <span className="font-mono text-caption text-foreground">{slug}</span>
                            {checked ? (
                              <Check
                                aria-hidden
                                className="ml-auto size-3.5 text-brand-700 dark:text-brand-300"
                              />
                            ) : null}
                          </label>
                        </li>
                      );
                    })
                  )}
                </ul>
                {selectedRepos.length > 0 ? (
                  <>
                    <Separator />
                    <div className="px-3 py-2 text-caption text-muted-foreground">
                      {selectedRepos.length} {selectedRepos.length === 1 ? 'repo' : 'repos'}{' '}
                      selected — rows from any selected repo will appear.
                    </div>
                  </>
                ) : null}
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-cve"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              CVE id
            </label>
            <Input
              id="audit-cve"
              type="search"
              inputMode="search"
              value={cveInput}
              onChange={(e) => setCveInput(e.target.value)}
              placeholder="e.g. CVE-2024-1001"
              autoComplete="off"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-from"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              From
            </label>
            <Input
              id="audit-from"
              type="date"
              value={from}
              onChange={(e) => updateParam('from', e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-to"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              To
            </label>
            <Input
              id="audit-to"
              type="date"
              value={to}
              onChange={(e) => updateParam('to', e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-severity"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              Severity
            </label>
            <Select
              value={severity || ALL_VALUE}
              onValueChange={(value) => updateParam('severity', value === ALL_VALUE ? '' : value)}
            >
              <SelectTrigger id="audit-severity">
                <SelectValue placeholder="Any severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_VALUE}>Any severity</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-action"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              Action
            </label>
            <Select
              value={action || ALL_VALUE}
              onValueChange={(value) => updateParam('action', value === ALL_VALUE ? '' : value)}
            >
              <SelectTrigger id="audit-action">
                <SelectValue placeholder="Any action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_VALUE}>Any action</SelectItem>
                <SelectItem value="auto-merged">Auto-merged</SelectItem>
                <SelectItem value="downgraded">Downgraded</SelectItem>
                <SelectItem value="paged">Paged</SelectItem>
                <SelectItem value="declined">Declined</SelectItem>
                <SelectItem value="exported">Exported</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="audit-actor"
              className="text-xs font-medium uppercase tracking-normal text-muted-foreground"
            >
              Actor
            </label>
            <Select
              value={actor || ALL_VALUE}
              onValueChange={(value) => updateParam('actor', value === ALL_VALUE ? '' : value)}
            >
              <SelectTrigger id="audit-actor">
                <SelectValue placeholder="Any actor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_VALUE}>Any actor</SelectItem>
                <SelectItem value="agent">Agent</SelectItem>
                <SelectItem value="human">Human</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>

        <CardContent className="flex flex-wrap items-center justify-between gap-3 border-t border-border/70 pt-4">
          <div className="flex items-center gap-2 text-small text-muted-foreground">
            {rowsState.status === 'ready' ? (
              <span>
                Showing <span className="text-foreground">{rowsState.rows.length}</span>{' '}
                {rowsState.rows.length === 1 ? 'event' : 'events'}
                {isFiltered ? ' · filtered' : ''}
              </span>
            ) : (
              <span>Loading events…</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={resetFilters}
              disabled={!isFiltered}
              className="gap-1.5"
            >
              <RefreshCcw aria-hidden className="size-4" />
              Reset filters
            </Button>
            <Button asChild size="sm" variant="outline" className="gap-1.5">
              <a href={exportHref} download>
                <Download aria-hidden className="size-4" />
                Download CSV
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>

      {rowsState.status === 'loading' && (
        <Card aria-busy="true">
          <CardContent className="flex flex-col gap-3 py-8">
            <p className="text-small text-muted-foreground">Loading triage events…</p>
            <div className="flex flex-col gap-2">
              {SKELETON_IDS.map((id) => (
                <Skeleton key={id} className="h-10 w-full rounded-md" />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {rowsState.status === 'error' && (
        <Alert variant="destructive" className="border-destructive/40">
          <AlertTriangle className="size-4" aria-hidden />
          <AlertTitle>Could not load the audit log.</AlertTitle>
          <AlertDescription>
            {rowsState.message}{' '}
            <button
              type="button"
              onClick={() => router.refresh()}
              className="underline decoration-dotted underline-offset-4 hover:text-foreground"
            >
              Retry
            </button>
            .
          </AlertDescription>
        </Alert>
      )}

      {rowsState.status === 'ready' && rowsState.rows.length === 0 && <AuditEmptyState />}

      {rowsState.status === 'ready' && rowsState.rows.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-h4">
              {rowsState.rows.length}{' '}
              {rowsState.rows.length === 1 ? 'triage event' : 'triage events'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>When</TableHead>
                  <TableHead>Repo</TableHead>
                  <TableHead>CVE / Event</TableHead>
                  <TableHead>Package · version</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Actor</TableHead>
                  <TableHead>PR</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rowsState.rows.map((row) => {
                  if (row.eventKind === 'ATTESTATION') {
                    const details = row.details;
                    const actionBadge = actionTone(row.action);
                    const formatLabel = details?.format?.toUpperCase() ?? 'JSON';
                    // All the re-export links below point to /dashboard/attest
                    // with `repoId` set to the row's database cuid so the
                    // picker lands on the same repo. /dashboard/attest
                    // currently initialises its dropdown from `selectedRepoId`
                    // — see AttestationBoard; the page reads its initial
                    // state from the URL params above and re-runs the export.
                    const attestHref = details
                      ? `/dashboard/attest?repoId=${encodeURIComponent(details.repoId)}&quarter=${encodeURIComponent(details.quarter)}&format=${encodeURIComponent(details.format)}`
                      : '/dashboard/attest';
                    // Audit rows for an attestation export are a "system
                    // event" — the user clicked the button and the audit
                    // trail logged the resulting download. Render the actor
                    // as System instead of Human; the person behind the
                    // session isn't the audit-worthy detail here.
                    return (
                      <TableRow key={row.id}>
                        <TableCell className="text-caption text-muted-foreground">
                          <time dateTime={row.createdAt}>{formatTimestamp(row.createdAt)}</time>
                        </TableCell>
                        <TableCell className="font-mono text-caption text-muted-foreground">
                          {details ? (
                            <span>
                              {details.ownerHandle}/{details.repoName}
                            </span>
                          ) : (
                            row.repo || '—'
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-caption text-foreground">
                          <Link
                            href={attestHref}
                            className="inline-flex flex-wrap items-center gap-2 text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
                          >
                            <span>Attestation export</span>
                            {details ? (
                              <>
                                <Badge
                                  variant="outline"
                                  className="border-border/70 bg-muted/40 font-mono text-[11px] text-foreground"
                                >
                                  {details.quarter}
                                </Badge>
                                <Badge
                                  variant="outline"
                                  className="border-brand-500/40 bg-brand-500/10 font-mono text-[11px] text-brand-700 dark:text-brand-300"
                                >
                                  {formatLabel}
                                </Badge>
                                <span
                                  className="font-mono text-[11px] text-muted-foreground"
                                  title={details.bundleHash}
                                >
                                  {details.bundleHash.slice(0, 12)}…
                                </span>
                              </>
                            ) : null}
                          </Link>
                        </TableCell>
                        <TableCell className="font-mono text-small text-muted-foreground">
                          <span>—</span>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="border-border/70 bg-muted/40 text-muted-foreground"
                          >
                            Export
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={actionBadge.tone}>
                            {actionBadge.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="inline-flex items-center gap-1.5 text-small text-muted-foreground">
                            <Bot
                              aria-hidden
                              className="size-4 text-brand-700 dark:text-brand-300"
                            />
                            <span>System</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Link
                            href={attestHref}
                            className="inline-flex items-center gap-1.5 text-small text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
                          >
                            Re-export
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  }
                  const sev = severityTone(row.severity);
                  const actionBadge = actionTone(row.action);
                  const isBreaking = row.eventKind === 'BREAKING' || row.cveId === null;
                  const isDowngradedRow = row.action === 'downgraded';
                  return (
                    <TableRow key={row.id}>
                      <TableCell className="text-caption text-muted-foreground">
                        <time dateTime={row.createdAt}>{formatTimestamp(row.createdAt)}</time>
                      </TableCell>
                      <TableCell className="font-mono text-caption text-muted-foreground">
                        {row.repo || '—'}
                      </TableCell>
                      <TableCell className="font-mono text-caption text-foreground">
                        <Link
                          href={`/dashboard/patches/${encodeURIComponent(row.id)}`}
                          className="inline-flex items-center gap-2 text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
                        >
                          {isBreaking ? (
                            <>
                              <span>{row.packageName}</span>
                              <Badge
                                variant="outline"
                                className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                              >
                                <TriangleAlert aria-hidden className="mr-1 size-3" />
                                Breaking
                              </Badge>
                            </>
                          ) : (
                            <span>{row.cveId}</span>
                          )}
                        </Link>
                      </TableCell>
                      <TableCell className="font-mono text-small text-muted-foreground">
                        <span className="inline-flex items-center gap-2">
                          <span>
                            {row.fromVersion} → {row.toVersion}
                          </span>
                          {isDowngradedRow ? (
                            <Badge
                              variant="outline"
                              className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                              aria-label="Version downgrade"
                            >
                              <ArrowDown aria-hidden className="mr-1 size-3" />
                              downgrade
                            </Badge>
                          ) : null}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={sev.tone}>
                          {sev.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={actionBadge.tone}>
                          {actionBadge.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="inline-flex items-center gap-1.5 text-small text-muted-foreground">
                          {row.actor === 'human' ? (
                            <UserRound
                              aria-hidden
                              className="size-4 text-brand-700 dark:text-brand-300"
                            />
                          ) : (
                            <Bot
                              aria-hidden
                              className="size-4 text-brand-700 dark:text-brand-300"
                            />
                          )}
                          <span>{row.actor === 'human' ? 'Human' : 'Agent'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <a
                          href={row.prUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 text-small text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
                        >
                          Open PR
                        </a>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
