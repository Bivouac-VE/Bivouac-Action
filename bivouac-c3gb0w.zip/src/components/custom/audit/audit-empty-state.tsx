// @polsia:user-owned — empty state for the /audit page. Renders ONLY when
// /api/audit-log returns zero rows. Decorative scroll artwork + a
// primary CTA to /connect so the user knows how to populate history.

import { ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export function AuditEmptyState() {
  return (
    <section
      aria-label="No triage events yet"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-muted/60 via-background to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[420px] text-brand-500/15 md:-right-32"
      >
        <svg
          viewBox="0 0 420 420"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative audit scroll</title>
          <path
            d="M 110 70 L 310 70 L 330 90 L 330 350 L 310 370 L 110 370 L 90 350 L 90 90 Z"
            strokeWidth="1.5"
          />
          <path d="M 310 70 L 310 90 L 330 90" strokeWidth="1.5" />
          <path d="M 120 130 L 300 130" strokeWidth="1" />
          <path d="M 120 160 L 300 160" strokeWidth="1" />
          <path d="M 120 190 L 300 190" strokeWidth="1" />
          <path d="M 120 220 L 300 220" strokeWidth="1" />
          <path d="M 120 250 L 300 250" strokeWidth="1" />
          <path d="M 120 280 L 300 280" strokeWidth="1" />
          <path d="M 120 310 L 300 310" strokeWidth="1" />
        </svg>
      </div>

      <div className="relative flex flex-col items-start gap-6 p-8 md:p-12">
        <p className="text-eyebrow">No activity yet</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          No triage events to show.
        </h2>
        <p className="max-w-xl text-body text-muted-foreground">
          The daily CVE→PR cron writes to this log the first time it opens a patch against a
          connected repository. Connect a repository to put Bivouac on duty — new CVEs and upstream
          breaking changes will land here within minutes.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <Button asChild size="lg" className="gap-2 shadow-brand">
            <Link href="/connect">
              <ArrowRight className="size-4" aria-hidden />
              Connect a repository
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
