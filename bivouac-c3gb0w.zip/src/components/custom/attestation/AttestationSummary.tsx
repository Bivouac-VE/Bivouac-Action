// @polsia:user-owned — presentational view of an AttestationSummary. No
// fetching; the parent island passes the parsed summary down through props.

import {
  AlertTriangle,
  CalendarClock,
  ClipboardList,
  GitMerge,
  ShieldCheck,
  ShieldHalf,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { AttestationSummary } from '@/lib/contracts/attestation';

const SEVERITY_LABEL: Record<'low' | 'medium' | 'high' | 'critical', string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const SEVERITY_RING: Record<'low' | 'medium' | 'high' | 'critical', string> = {
  low: 'ring-1 ring-inset ring-border/60',
  medium: 'ring-1 ring-inset ring-border/60',
  high: 'ring-1 ring-inset ring-amber-500/30 dark:ring-amber-500/20',
  critical: 'ring-1 ring-inset ring-destructive/40',
};

function fmtDays(days: number | null): string {
  if (days === null) return '—';
  if (days < 1) {
    const hours = Math.round(days * 24);
    return hours <= 1 ? '<1h' : `${hours}h`;
  }
  return `${days.toFixed(2)}d`;
}

interface KpiProps {
  label: string;
  value: string;
  hint: string | null;
  icon: typeof ShieldCheck;
  emphasis?: 'brand' | 'neutral' | 'warm';
}

const EMPHASIS_RING: Record<NonNullable<KpiProps['emphasis']>, string> = {
  brand: 'ring-1 ring-inset ring-brand-500/30 dark:ring-brand-500/20',
  neutral: 'ring-1 ring-inset ring-border/60',
  warm: 'ring-1 ring-inset ring-amber-500/30 dark:ring-amber-500/20',
};
const EMPHASIS_ICON: Record<NonNullable<KpiProps['emphasis']>, string> = {
  brand: 'text-brand-600 dark:text-brand-400',
  neutral: 'text-muted-foreground',
  warm: 'text-amber-600 dark:text-amber-400',
};

function KpiCard({ label, value, hint, icon: Icon, emphasis = 'neutral' }: KpiProps) {
  return (
    <Card className={`flex h-full flex-col gap-3 bg-card/80 ${EMPHASIS_RING[emphasis]}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-3 space-y-0 p-5 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        <span
          className={`flex size-8 items-center justify-center rounded-md border border-border/60 bg-background ${EMPHASIS_ICON[emphasis]}`}
        >
          <Icon aria-hidden="true" className="size-4" />
        </span>
      </CardHeader>
      <CardContent className="px-5 pt-0">
        <p className="font-display text-h2 leading-none text-foreground">{value}</p>
        <p className="mt-1 text-xs text-muted-foreground">{hint ?? ' '}</p>
      </CardContent>
    </Card>
  );
}

export interface AttestationSummaryViewProps {
  data: AttestationSummary;
}

export function AttestationSummaryView({ data }: AttestationSummaryViewProps) {
  const patchTotal =
    data.counts.patches.low +
    data.counts.patches.medium +
    data.counts.patches.high +
    data.counts.patches.critical;

  return (
    <div className="flex flex-col gap-6">
      <Card className="border-border/70 bg-card/80">
        <CardHeader className="border-b border-border/70">
          <div className="grid gap-1">
            <CardTitle className="font-display text-h3 tracking-tight">
              {data.meta.ownerHandle}/{data.meta.name}
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Quarter <span className="font-mono text-foreground">{data.meta.quarter}</span>
              {' · '}
              Policy{' '}
              <span className="font-mono text-foreground">{data.meta.policyVersion.version}</span>
              {' · '}
              Generated{' '}
              <span className="font-mono text-foreground">
                {data.meta.generatedAt.slice(0, 19).replace('T', ' ')} UTC
              </span>
            </p>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label="Mean time to patch"
          value={fmtDays(data.mttp.valueDays)}
          hint={`Over n=${data.mttp.sampleSize} terminal samples`}
          icon={CalendarClock}
          emphasis="brand"
        />
        <KpiCard
          label="Patches opened"
          value={String(patchTotal)}
          hint="Across the quarter"
          icon={GitMerge}
          emphasis="neutral"
        />
        <KpiCard
          label="Severity mix"
          value={`H${data.counts.patches.high} · M${data.counts.patches.medium}`}
          hint={`L${data.counts.patches.low} / C${data.counts.patches.critical} also seen`}
          icon={ShieldCheck}
          emphasis={data.counts.patches.critical > 0 ? 'warm' : 'neutral'}
        />
        <KpiCard
          label="Human overrides"
          value={String(data.counts.overrides)}
          hint="Decisions the agent handed to a human"
          icon={ShieldHalf}
          emphasis={data.counts.overrides > 0 ? 'warm' : 'neutral'}
        />
      </div>

      <Card className="border-border/70 bg-card/80">
        <CardHeader>
          <CardTitle className="font-display text-h4">Severity distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-3">
            {(['low', 'medium', 'high', 'critical'] as const).map((sev) => (
              <div
                key={sev}
                className={`flex flex-col gap-1 rounded-md border border-border/70 bg-card p-4 ${SEVERITY_RING[sev]}`}
              >
                <p className="text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground">
                  {SEVERITY_LABEL[sev]}
                </p>
                <p className="font-display text-h2 leading-none">{data.counts.patches[sev]}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="border-border/70 bg-card/80">
          <CardHeader>
            <CardTitle className="font-display text-h4">Remediated CVE IDs</CardTitle>
            <p className="text-xs text-muted-foreground">
              Distinct advisories closed by patch PRs in this quarter.
            </p>
          </CardHeader>
          <CardContent>
            {data.cveIdsRemediated.length === 0 ? (
              <p className="text-sm text-muted-foreground">No CVEs remediated in this quarter.</p>
            ) : (
              <ul className="flex flex-wrap gap-1.5">
                {data.cveIdsRemediated.map((cve) => (
                  <li key={cve}>
                    <Badge
                      variant="outline"
                      className="border-border bg-muted/40 font-mono text-[11px]"
                    >
                      {cve}
                    </Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/70 bg-card/80">
          <CardHeader>
            <CardTitle className="font-display text-h4">SBOM rollup</CardTitle>
            <p className="text-xs text-muted-foreground">
              Distinct packages touched by patch events in this quarter, split by ecosystem. The
              JSON/PDF bundle carries the same numbers for cross-check.
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <p className="font-display text-h2 leading-none text-foreground">
                {data.sbom.packagesTouched}
              </p>
              <p className="text-xs text-muted-foreground">
                {data.sbom.packagesTouched === 1 ? 'package touched' : 'packages touched'} in this
                quarter
              </p>
              {Object.entries(data.sbom.ecosystems).length > 0 ? (
                <ul className="mt-2 flex flex-wrap gap-1.5">
                  {Object.entries(data.sbom.ecosystems)
                    .sort(([a], [b]) => a.localeCompare(b))
                    .map(([eco, count]) => (
                      <li key={eco}>
                        <Badge
                          variant="outline"
                          className="border-border bg-muted/40 font-mono text-[11px]"
                        >
                          {eco}: {count}
                        </Badge>
                      </li>
                    ))}
                </ul>
              ) : null}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="font-display text-h4">Human overrides</CardTitle>
            <p className="text-xs text-muted-foreground">
              Patches the agent opened but a human had to approve. The full reason + actor is
              included in the downloaded bundle.
            </p>
          </CardHeader>
          <CardContent>
            {data.overrides.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No overrides — agent handled every decision.
              </p>
            ) : (
              <ul className="flex flex-col gap-2">
                {data.overrides.map((o) => (
                  <li
                    key={o.id}
                    className="flex items-start gap-3 rounded-md border border-border/70 bg-muted/20 p-3"
                  >
                    <AlertTriangle
                      aria-hidden="true"
                      className="mt-0.5 size-4 text-amber-600 dark:text-amber-400"
                    />
                    <div className="grid flex-1 gap-0.5">
                      <p className="font-mono text-xs font-medium text-foreground">{o.cveId}</p>
                      <p className="text-xs text-muted-foreground">
                        {o.packageName} {o.fromVersion} → {o.toVersion} ·{' '}
                        <span className="font-mono">{o.mergeDecision}</span> · {o.repo}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/70 bg-card/80">
        <CardHeader>
          <CardTitle className="font-display text-h4">MTTP derivation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="font-mono text-xs text-muted-foreground">{data.mttp.derivation}</p>
          <p className="mt-2 text-xs text-muted-foreground">
            Note — MTTP is time-since-PR-open at export time, not time-to-merge. The bundle embeds
            the same formula so an auditor can recompute.
          </p>
        </CardContent>
      </Card>

      <details className="rounded-md border border-border/70 bg-card/80 p-4">
        <summary className="flex cursor-pointer items-center gap-2 text-sm font-medium text-foreground">
          <ClipboardList aria-hidden="true" className="size-4 text-muted-foreground" />
          Raw bundle (preview JSON)
        </summary>
        <pre className="mt-3 max-h-64 overflow-auto rounded bg-muted/30 p-3 text-[11px] leading-snug text-muted-foreground">
          {JSON.stringify(data, null, 2)}
        </pre>
      </details>
    </div>
  );
}
