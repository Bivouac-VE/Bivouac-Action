// @polsia:user-owned — layout shell for the attestation picker. Three named
// slots so the island stays focused on fetch + state, and the layout cadence
// is reusable on later forms.

import type { ReactNode } from 'react';

export interface AttestationPreviewToolbarProps {
  repoSlot: ReactNode;
  quarterSlot: ReactNode;
  actionSlot: ReactNode;
  errorSlot?: ReactNode;
}

export function AttestationPreviewToolbar({
  repoSlot,
  quarterSlot,
  actionSlot,
  errorSlot,
}: AttestationPreviewToolbarProps) {
  return (
    <div className="flex flex-col gap-3 rounded-md border border-border/70 bg-card/80 p-5">
      <div className="flex flex-col gap-3 md:flex-row md:flex-wrap md:items-end">
        <fieldset className="flex flex-col gap-1 border-0 p-0">
          <legend className="sr-only">Repository</legend>
          <label
            htmlFor="attestation-repo"
            className="text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground"
          >
            Repository
          </label>
          {repoSlot}
        </fieldset>
        <fieldset className="flex flex-col gap-1 border-0 p-0">
          <legend className="sr-only">Quarter</legend>
          <label
            htmlFor="attestation-quarter"
            className="text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground"
          >
            Quarter
          </label>
          {quarterSlot}
        </fieldset>
        <div className="flex flex-col gap-1 md:ml-auto">
          <span className="text-xs font-medium uppercase tracking-[0.08em] text-transparent">
            Action
          </span>
          {actionSlot}
        </div>
      </div>
      {errorSlot}
    </div>
  );
}
