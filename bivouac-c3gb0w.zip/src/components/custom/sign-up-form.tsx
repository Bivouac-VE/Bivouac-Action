// @polsia:user-owned — Email + password sign-up with GitHub OAuth as a linked
// identity provider. Composes the template's base shadcn primitives
// (Button/Input/Label) styled through the theme tokens. Restyle freely — this
// file is user-owned.
//
// On email sign-up: better-auth's authClient.signUp.email creates the user
// (autoSignIn: true in authConfig), sets the session cookie via the catch-all
// handler, and returns the new session. We then navigate to `returnTo`
// (default /dashboard) so the visitor lands back in their original destination.
// On OAuth: continues through GitHub and lands at `returnTo` with the same
// cookie set.

'use client';

import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { OAuthButton } from '@/components/custom/auth/oauth-button';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { signUp } from '@/lib/auth-client';

export interface SignUpFormProps {
  /** Where to land after a successful sign-up (sign-up auto-signs in via
   * authConfig). Must be a same-origin path; defaults to /dashboard. */
  returnTo?: string;
}

export function SignUpForm({ returnTo = '/dashboard' }: SignUpFormProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError(undefined);

    const { error: signUpError } = await signUp.email({
      name,
      email,
      password,
      callbackURL: returnTo,
    });
    setPending(false);

    if (signUpError) {
      setError(signUpError.message ?? 'Could not create your account. Try again.');
      return;
    }

    window.location.assign(returnTo);
  }

  return (
    <div className="flex flex-col gap-5">
      <OAuthButton callbackURL={returnTo} />

      <div className="relative">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">Or with email</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3" noValidate>
        <Label htmlFor="sign-up-name">Name</Label>
        <Input
          id="sign-up-name"
          name="name"
          type="text"
          autoComplete="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          aria-invalid={error ? true : undefined}
        />
        <Label htmlFor="sign-up-email">Email address</Label>
        <Input
          id="sign-up-email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          aria-invalid={error ? true : undefined}
        />
        <Label htmlFor="sign-up-password">Password</Label>
        <Input
          id="sign-up-password"
          name="password"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          aria-invalid={error ? true : undefined}
        />
        {error ? <p className="text-sm text-destructive">{error}</p> : null}
        <Button type="submit" disabled={pending} className="w-full">
          {pending ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden />
              <span>Creating account…</span>
            </>
          ) : (
            'Create account'
          )}
        </Button>
        <p className="text-center text-small text-muted-foreground">
          Already have an account?{' '}
          <Link
            href={`/login${returnTo !== '/dashboard' ? `?returnTo=${encodeURIComponent(returnTo)}` : ''}`}
            className="text-brand-600 font-medium hover:text-brand-700 hover:underline underline-offset-2 transition-colors"
          >
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
}
