// @polsia:user-owned — client island for /settings/policy-packs.
//
// Owns all UI state for the page: loads the global policy-packs catalog
// via /api/policy-packs, loads the caller's connected repos via /api/repos,
// renders three <PolicyPackCard/> rows (one per pack seed), and handles the
// "Apply to selected repos" flow (Radix Dialog picker + apply endpoint).
// On success the island dispatches a `bivouac:repo-policy-changed`
// CustomEvent so the dashboard's <RepoCardsGrid/> re-fetches /api/repos and
// the per-card pack label updates without a manual reload.

'use client';

import { AlertTriangle, Check, Loader2, ShieldCheck, Sparkles, X } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  ApplyPolicyInput,
  ApplyPolicyResult,
  PolicyPackList,
  type PolicyPack as PolicyPackT,
} from '@/lib/contracts/policy-packs';
import { type Repo, RepoList } from '@/lib/contracts/repos';
import { cn } from '@/lib/utils';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; packs: PolicyPackT[]; repos: Repo[] };

const LOCKFILE_LABEL: Record<PolicyPackT['scopeToggles']['lockfileUpdates'], string> = {
  strict: 'Strict lockfile updates',
  'cve-only': 'CVE-only lockfile changes',
  asis: 'Lockfile as-is',
};

const DEP_SCOPE_LABEL: Record<PolicyPackT['scopeToggles']['dependencyScope'], string> = {
  all: 'All dependencies',
  direct: 'Direct only',
  'direct+transitive': 'Direct + transitive',
};

const ADVISORY_LABEL: Record<PolicyPackT['scopeToggles']['advisoryScope'], string> = {
  nvd: 'NVD',
  ghsa: 'GHSA',
  'nvd+ghsa': 'NVD + GHSA',
};

const REPO_POLICY_EVENT = 'bivouac:repo-policy-changed';

export function PolicyPacksIsland() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });
  const [pickerPack, setPickerPack] = useState<PolicyPackT | null>(null);
  const [pickerSelection, setPickerSelection] = useState<Set<string>>(new Set());
  const [pickerPending, setPickerPending] = useState(false);
  const [pickerError, setPickerError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const [packs, repos] = await Promise.all([
        apiFetch('/api/policy-packs', { schema: PolicyPackList }),
        apiFetch('/api/repos', { schema: RepoList }),
      ]);
      setState({ status: 'ready', packs: packs.items, repos: repos.items });
    } catch (err: unknown) {
      const reason = err instanceof Error ? err.message : 'Could not load policy packs.';
      setState({ status: 'error', message: reason });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openPicker = useCallback((pack: PolicyPackT) => {
    setPickerPack(pack);
    setPickerSelection(new Set());
    setPickerError(null);
  }, []);

  const closePicker = useCallback(() => {
    if (pickerPending) return;
    setPickerPack(null);
    setPickerError(null);
  }, [pickerPending]);

  const toggleRepoInPicker = useCallback((repoId: string, checked: boolean) => {
    setPickerSelection((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(repoId);
      } else {
        next.delete(repoId);
      }
      return next;
    });
  }, []);

  const submitApply = useCallback(async () => {
    if (!pickerPack || pickerPending) return;
    const parsed = ApplyPolicyInput.safeParse({
      packSlug: pickerPack.slug,
      repoIds: Array.from(pickerSelection),
    });
    if (!parsed.success) {
      setPickerError('Pick at least one repo to apply this pack.');
      return;
    }
    setPickerPending(true);
    setPickerError(null);
    try {
      const res = await apiFetch('/api/repo-policies/apply', {
        method: 'POST',
        schema: ApplyPolicyResult,
        body: JSON.stringify(parsed.data),
      });
      const count = res.applied.length;
      toast.success(
        count === 1
          ? `${pickerPack.title} applied to 1 repo.`
          : `${pickerPack.title} applied to ${count} repos.`,
      );
      window.dispatchEvent(new CustomEvent(REPO_POLICY_EVENT));
      setPickerPack(null);
      setPickerSelection(new Set());
      // Pull activePack decorations for the picker summary.
      void load();
    } catch (err: unknown) {
      const cause = (err as { cause?: unknown } | null)?.cause;
      const code =
        cause && typeof cause === 'object' && 'error' in cause
          ? ((cause as { error?: unknown }).error as string | undefined)
          : undefined;
      setPickerError(
        code ?? (err instanceof Error ? err.message : 'Could not apply that policy pack.'),
      );
    } finally {
      setPickerPending(false);
    }
  }, [load, pickerPack, pickerPending, pickerSelection]);

  if (state.status === 'loading') {
    return <PolicyPacksSkeleton />;
  }
  if (state.status === 'error') {
    return <PolicyPacksError message={state.message} onRetry={load} />;
  }

  return (
    <section aria-label="Policy packs" className="flex flex-col gap-section">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Reusable triage policies</p>
        <h1 className="font-display text-h2 text-balance text-foreground">Policy packs</h1>
        <p className="text-body-lg text-muted-foreground">
          Reusable triage policies you can apply to one or more repos at once. Pack settings write
          straight into each repo and surface as the active pack on the dashboard cards.
        </p>
      </header>

      <div className="grid gap-4">
        {state.packs.map((pack) => {
          const applied = state.repos
            .filter((r) => r.activePack?.packSlug === pack.slug)
            .map((r) => r);
          return (
            <PolicyPackCard
              key={pack.slug}
              pack={pack}
              appliedCount={applied.length}
              appliedNames={applied.map((r) => r.name)}
              disabled={state.packs.length === 0}
              onApply={() => openPicker(pack)}
            />
          );
        })}
      </div>

      <Dialog
        open={pickerPack !== null}
        onOpenChange={(open) => {
          if (!open) closePicker();
        }}
      >
        <DialogContent className="max-w-xl">
          {pickerPack ? (
            <PickerPanel
              pack={pickerPack}
              repos={state.repos}
              selection={pickerSelection}
              pending={pickerPending}
              error={pickerError}
              onToggle={toggleRepoInPicker}
              onSelectAll={(checked) => {
                setPickerSelection(checked ? new Set(state.repos.map((r) => r.id)) : new Set());
              }}
              onCancel={closePicker}
              onSubmit={() => void submitApply()}
            />
          ) : null}
        </DialogContent>
      </Dialog>
    </section>
  );
}

// ----------------------------------------------------------------------------

function PolicyPacksSkeleton() {
  return (
    <section aria-label="Loading policy packs" className="flex flex-col gap-section">
      <Skeleton className="h-12 w-72" />
      <Skeleton className="h-44 w-full rounded-xl" />
      <Skeleton className="h-44 w-full rounded-xl" />
      <Skeleton className="h-44 w-full rounded-xl" />
    </section>
  );
}

function PolicyPacksError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Alert variant="destructive" className="border-destructive/40">
      <AlertTriangle className="size-4" aria-hidden />
      <AlertTitle>Could not load policy packs.</AlertTitle>
      <AlertDescription>
        We could not reach the catalog right now. Retry in a moment.{' '}
        <span className="text-xs text-muted-foreground">({message})</span>
      </AlertDescription>
      <Button type="button" variant="outline" size="sm" onClick={onRetry} className="mt-3 w-fit">
        Retry
      </Button>
    </Alert>
  );
}

function PolicyPackCard({
  pack,
  appliedCount,
  appliedNames,
  disabled,
  onApply,
}: {
  pack: PolicyPackT;
  appliedCount: number;
  appliedNames: string[];
  disabled: boolean;
  onApply: () => void;
}) {
  return (
    <Card className="lift border-border bg-card/80 p-0">
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 p-5 pb-3">
        <div className="grid min-w-0 gap-1">
          <div className="flex items-center gap-2">
            <ShieldCheck
              className="size-4 shrink-0 text-brand-700 dark:text-brand-300"
              aria-hidden
            />
            <CardTitle className="font-display text-h4 tracking-tight text-foreground">
              {pack.title}
            </CardTitle>
          </div>
          <CardDescription className="text-small text-muted-foreground">
            {pack.description}
          </CardDescription>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          {appliedCount > 0 ? (
            <Badge
              variant="outline"
              className="border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300"
            >
              <Sparkles className="mr-1 size-3" aria-hidden />
              Active on {appliedCount} {appliedCount === 1 ? 'repo' : 'repos'}
            </Badge>
          ) : (
            <Badge variant="outline" className="border-border bg-muted/40 text-muted-foreground">
              Not applied
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-5 px-5 pb-5 text-small text-muted-foreground">
        <dl className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <ScopeItem
            label="Lockfile updates"
            value={LOCKFILE_LABEL[pack.scopeToggles.lockfileUpdates]}
          />
          <ScopeItem
            label="Dependency scope"
            value={DEP_SCOPE_LABEL[pack.scopeToggles.dependencyScope]}
          />
          <ScopeItem label="Advisories" value={ADVISORY_LABEL[pack.scopeToggles.advisoryScope]} />
        </dl>
        <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-3">
          <p className="text-eyebrow">Auto-merge threshold</p>
          <p className="font-display text-h4 text-foreground">{pack.autoMergeThreshold}</p>
        </div>
        <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-3">
          <p className="text-eyebrow">Page a human when</p>
          {pack.pageHumanWhen.length > 0 ? (
            <ul className="flex flex-wrap gap-2">
              {pack.pageHumanWhen.map((rule) => (
                <li key={rule}>
                  <Badge variant="outline" className="border-border bg-muted/40 text-foreground">
                    {humanRuleLabel(rule)}
                  </Badge>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-small text-muted-foreground">No human-paging rules configured.</p>
          )}
        </div>
        {appliedNames.length > 0 ? (
          <p className="text-small text-muted-foreground">
            Active on:{' '}
            <span className="text-foreground">{appliedNames.slice(0, 4).join(', ')}</span>
            {appliedNames.length > 4 ? ` and ${appliedNames.length - 4} more` : ''}
          </p>
        ) : null}
        <div className="flex justify-end">
          <Button
            type="button"
            onClick={onApply}
            disabled={disabled}
            className="gap-1.5 shadow-brand"
          >
            <Check className="size-3.5" aria-hidden />
            Apply to selected repos
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ScopeItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border/70 bg-background/60 p-3">
      <p className="text-eyebrow">{label}</p>
      <p className="text-small text-foreground">{value}</p>
    </div>
  );
}

function humanRuleLabel(rule: PolicyPackT['pageHumanWhen'][number]): string {
  const map: Record<PolicyPackT['pageHumanWhen'][number], string> = {
    'high-severity-cve': 'High-severity CVE',
    'license-change': 'License change',
    'public-api-break': 'Public API break',
    'security-sensitive': 'Security-sensitive',
    'red-build': 'Red build',
    'major-bump': 'Major version bump',
    'minor-bump': 'Minor version bump',
  };
  return map[rule];
}

// ----------------------------------------------------------------------------

function PickerPanel({
  pack,
  repos,
  selection,
  pending,
  error,
  onToggle,
  onSelectAll,
  onCancel,
  onSubmit,
}: {
  pack: PolicyPackT;
  repos: Repo[];
  selection: Set<string>;
  pending: boolean;
  error: string | null;
  onToggle: (repoId: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  onCancel: () => void;
  onSubmit: () => void;
}) {
  const allSelected = useMemo(
    () => repos.length > 0 && selection.size === repos.length,
    [repos.length, selection.size],
  );
  const noneSelected = selection.size === 0;

  return (
    <>
      <DialogHeader>
        <DialogTitle className="font-display text-h3 text-foreground">
          Apply {pack.title}
        </DialogTitle>
        <DialogDescription className="text-small text-muted-foreground">
          Pick the repos that should run on this triage policy. The active pack on each card updates
          immediately on apply.
        </DialogDescription>
      </DialogHeader>

      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-3 rounded-md border border-border/70 bg-background/60 px-3 py-2 text-small">
          <label
            htmlFor="policy-pack-select-all"
            className="inline-flex cursor-pointer items-center gap-2"
          >
            <Checkbox
              id="policy-pack-select-all"
              checked={allSelected}
              onCheckedChange={(value) => onSelectAll(value === true)}
              disabled={pending || repos.length === 0}
            />
            <span className="text-foreground">
              Select all <span className="text-muted-foreground">({repos.length})</span>
            </span>
          </label>
          <span className="text-xs text-muted-foreground">{selection.size} selected</span>
        </div>

        <div className="flex max-h-72 flex-col gap-1 overflow-y-auto rounded-md border border-border/70 bg-background/60 p-2">
          {repos.length === 0 ? (
            <p className="px-2 py-4 text-small text-muted-foreground">
              No connected repos yet — connect one first.
            </p>
          ) : (
            repos.map((repo) => (
              <label
                key={repo.id}
                htmlFor={`policy-pack-repo-${repo.id}`}
                className={cn(
                  'flex cursor-pointer items-center gap-3 rounded-sm border border-transparent px-2 py-2 text-small transition-colors',
                  selection.has(repo.id)
                    ? 'border-brand-500/40 bg-brand-500/5'
                    : 'hover:bg-muted/40',
                )}
              >
                <Checkbox
                  id={`policy-pack-repo-${repo.id}`}
                  checked={selection.has(repo.id)}
                  onCheckedChange={(value) => onToggle(repo.id, value === true)}
                  disabled={pending}
                />
                <span className="flex min-w-0 flex-col">
                  <span className="truncate text-foreground">
                    <span className="font-mono text-muted-foreground">@{repo.ownerHandle}</span>
                    <span aria-hidden> / </span>
                    <span className="font-medium">{repo.name}</span>
                  </span>
                  <span className="truncate text-xs text-muted-foreground">
                    Currently on: {repo.activePack?.packTitle ?? 'default'}
                  </span>
                </span>
              </label>
            ))
          )}
        </div>

        {error ? (
          <Alert variant="destructive" className="border-destructive/40">
            <X className="size-4" aria-hidden />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}
      </div>

      <DialogFooter className="gap-2">
        <Button type="button" variant="outline" size="sm" onClick={onCancel} disabled={pending}>
          Cancel
        </Button>
        <Button
          type="button"
          size="sm"
          onClick={onSubmit}
          disabled={pending || noneSelected || repos.length === 0}
          className="gap-1.5 shadow-brand"
        >
          {pending ? (
            <>
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
              Applying…
            </>
          ) : (
            <>
              <Check className="size-3.5" aria-hidden />
              Apply to {selection.size} {selection.size === 1 ? 'repo' : 'repos'}
            </>
          )}
        </Button>
      </DialogFooter>
    </>
  );
}
