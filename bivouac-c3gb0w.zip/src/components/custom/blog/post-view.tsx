// @polsia:user-owned — single-post reader island for /blog/[slug]. Fetches the
// post the route handler serves via /api/posts/<slug>, renders the title +
// date + markdown body, and 404s into a 'not found' card that links back to
// /blog (matching the CveTriageLogsTable loading/error pattern, with one
// extra state for the not-found path).
//
// BlogPosting structured data is emitted by the page's `generateMetadata`
// (other.script:ld+json) so the canonical payload ships in the SSR HTML and
// is unchanged on hydrate — no client-side JSON-LD upgrade is needed.

'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { apiFetch } from '@/lib/api-client';
import { Post, type Post as PostT } from '@/lib/contracts/blog';

const DATE_FORMAT = new Intl.DateTimeFormat('en', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : DATE_FORMAT.format(d);
}

export function PostViewIsland({ slug }: { slug: string }) {
  const [post, setPost] = useState<PostT | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let active = true;
    apiFetch(`/api/posts/${encodeURIComponent(slug)}`, { schema: Post })
      .then((data) => {
        if (active) setPost(data);
      })
      .catch((err: unknown) => {
        if (!active) return;
        // Server hands back 404 with { error } — surface a friendly 'not found'
        // card rather than the raw error string, since the user got the URL
        // wrong or followed a stale link.
        if (err instanceof Error) {
          const cause = err.cause as { error?: string } | null;
          if (typeof cause?.error === 'string' && cause.error === 'Not found') {
            setNotFound(true);
            return;
          }
          setError(err.message);
        } else {
          setError('Could not load the post.');
        }
      });
    return () => {
      active = false;
    };
  }, [slug]);

  if (notFound) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h3">Article not found</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <p className="text-body text-muted-foreground">
            This post is either unpublished or no longer exists. Head back to the index for the
            latest.
          </p>
          <div>
            <Button asChild variant="default" size="sm">
              <Link href="/blog">Back to the blog</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="font-display text-h4 text-destructive">
            Could not load this post
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">{error}</p>
        </CardContent>
      </Card>
    );
  }

  if (!post) {
    return (
      <Card>
        <CardContent className="py-10">
          <p className="text-small text-muted-foreground">Loading the article…</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <article className="flex flex-col gap-6">
      <header className="flex flex-col gap-3">
        <p className="text-caption uppercase tracking-[0.08em] text-muted-foreground">
          <time dateTime={post.publishedAt}>{formatDate(post.publishedAt)}</time>
        </p>
        <h1 className="font-display text-h1 text-balance text-foreground">{post.title}</h1>
        <p className="max-w-3xl text-body-lg text-muted-foreground">{post.excerpt}</p>
      </header>

      <div className="max-w-none text-body text-foreground">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            h1: ({ children }) => <h1 className="font-display text-h1">{children}</h1>,
            h2: ({ children }) => (
              <h2 className="mt-10 mb-4 font-display text-h3 text-foreground">{children}</h2>
            ),
            h3: ({ children }) => (
              <h3 className="mt-8 mb-3 font-display text-h4 text-foreground">{children}</h3>
            ),
            h4: ({ children }) => (
              <h4 className="mt-6 mb-2 font-display text-small uppercase tracking-[0.06em] text-muted-foreground">
                {children}
              </h4>
            ),
            p: ({ children }) => (
              <p className="mt-4 leading-[1.65] text-body text-foreground">{children}</p>
            ),
            a: ({ children, href }) => (
              <a
                href={href}
                className="text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
              >
                {children}
              </a>
            ),
            ul: ({ children }) => (
              <ul className="mt-4 ml-6 list-disc text-body text-foreground">{children}</ul>
            ),
            ol: ({ children }) => (
              <ol className="mt-4 ml-6 list-decimal text-body text-foreground">{children}</ol>
            ),
            code: ({ children, className }) => {
              const isBlock = (className ?? '').includes('language-');
              if (isBlock) {
                return (
                  <code className={`${className ?? ''} font-mono text-small text-foreground`}>
                    {children}
                  </code>
                );
              }
              return (
                <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-small text-foreground">
                  {children}
                </code>
              );
            },
            pre: ({ children }) => (
              <pre className="my-6 overflow-x-auto rounded-md border border-border bg-secondary p-4 font-mono text-small text-foreground">
                {children}
              </pre>
            ),
            blockquote: ({ children }) => (
              <blockquote className="my-6 border-l-2 border-brand-500/40 pl-4 italic text-muted-foreground">
                {children}
              </blockquote>
            ),
            table: ({ children }) => (
              <div className="my-6 overflow-x-auto rounded-md border border-border bg-card">
                <Table>{children}</Table>
              </div>
            ),
            thead: ({ children }) => <TableHeader>{children}</TableHeader>,
            tbody: ({ children }) => <TableBody>{children}</TableBody>,
            th: ({ children }) => (
              <TableHead className="font-display text-caption uppercase tracking-wider">
                {children}
              </TableHead>
            ),
            td: ({ children }) => (
              <TableCell className="text-small text-foreground">{children}</TableCell>
            ),
            tr: ({ children }) => <TableRow>{children}</TableRow>,
          }}
        >
          {post.body}
        </ReactMarkdown>
      </div>
    </article>
  );
}
