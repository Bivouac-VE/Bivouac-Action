// @polsia:user-owned — listing island for /blog. Fetches the published-post
// roster from /api/posts and renders each one as a /blog/<slug> link with
// title (text-h3), date, and excerpt. Loading / empty / error mirrors the
// CveTriageLogsTable pattern.

'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { type PostSummary, PostSummaryList } from '@/lib/contracts/blog';

const DATE_FORMAT = new Intl.DateTimeFormat('en', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

function formatDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : DATE_FORMAT.format(d);
}

export function PostListIsland() {
  const [items, setItems] = useState<PostSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    apiFetch('/api/posts', { schema: PostSummaryList })
      .then((data) => {
        if (active) setItems(data.items);
      })
      .catch((err: unknown) => {
        if (active) {
          setError(err instanceof Error ? err.message : 'Could not load the blog posts.');
        }
      });
    return () => {
      active = false;
    };
  }, []);

  if (error) {
    return (
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="font-display text-h4 text-destructive">Blog unavailable</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">{error}</p>
        </CardContent>
      </Card>
    );
  }

  if (items === null) {
    return (
      <Card>
        <CardContent className="py-10">
          <p className="text-small text-muted-foreground">Loading the latest posts…</p>
        </CardContent>
      </Card>
    );
  }

  if (items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">No posts yet</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">
            Drafts in flight aren&rsquo;t listed here — the first published post will land on this
            page the moment it ships.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <ul className="flex flex-col gap-4">
      {items.map((post) => (
        <li key={post.id}>
          <Card className="lift border-border/80 transition-colors hover:border-brand-500/40">
            <CardHeader className="gap-3">
              <p className="text-caption uppercase tracking-[0.08em] text-muted-foreground">
                <time dateTime={post.publishedAt}>{formatDate(post.publishedAt)}</time>
              </p>
              <CardTitle className="font-display text-h3 text-foreground">
                <Link href={`/blog/${post.slug}`} className="underline-offset-4 hover:underline">
                  {post.title}
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-body text-muted-foreground">{post.excerpt}</p>
            </CardContent>
          </Card>
        </li>
      ))}
    </ul>
  );
}
