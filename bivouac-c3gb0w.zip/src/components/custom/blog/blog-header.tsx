// @polsia:user-owned — public blog header (eyebrow + h1 + subhead) rendered
// on the index page. Server Component, pure markup — no 'use client' needed.

import { Badge } from '@/components/ui/badge';

export function BlogHeader() {
  return (
    <header className="container-page flex flex-col gap-6 pt-section-lg">
      <Badge variant="outline" className="w-fit gap-1.5 border-brand-500/40 bg-brand-500/10">
        <span className="size-1.5 rounded-full bg-brand-500" aria-hidden />
        <span className="text-caption font-semibold uppercase tracking-[0.08em] text-brand-700 dark:text-brand-300">
          Notes from the on-call agent
        </span>
      </Badge>

      <h1 className="font-display text-display text-balance text-foreground">
        CVE benchmarks, dep-comparison guides, and what’s shifting in dependency triage.
      </h1>

      <p className="max-w-3xl text-body-lg text-muted-foreground">
        Field reports from teams shipping with Bivouac — how we benchmark CVE handling time against
        a human on-call, what we change between Dependabot / Renovate / Snyk OSS during a migration,
        and what an autonomous patch pipeline actually does overnight. No teaser — numbers and the
        trade-offs that produced them.
      </p>
    </header>
  );
}
