// @polsia:user-owned — interactive comparison Tabs for the "How Bivouac compares"
// section. shadcn Tabs is wired as a Radix client component, so this must run
// on the client.

'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

type Approach = {
  value: string;
  eyebrow: string;
  headline: string;
  bullets: { label: string; body: string }[];
  caveat: string;
};

const APPROACHES: Approach[] = [
  {
    value: 'flag-bots',
    eyebrow: 'Flag-only tools',
    headline: 'Dependabot, Renovate, Snyk',
    bullets: [
      {
        label: 'Strong at surfacing',
        body: 'Open PRs the moment a CVE lands or a minor version drifts. The signal leaves the moment the alert opens.',
      },
      {
        label: 'No judgment',
        body: 'They cannot choose between forward fix, downgrade, or pinning when SemVer major bumps break consumers.',
      },
      {
        label: 'Queue pressure',
        body: 'Every alert reaches the on-call rotation. People triage bots that should be triaging themselves.',
      },
    ],
    caveat: 'Useful — but the human still owns the decision tree.',
  },
  {
    value: 'fix-bots',
    eyebrow: 'Generative coding agents',
    headline: 'Copilot Coding Agent, Cursor Bugbot, Devin',
    bullets: [
      {
        label: 'General-purpose',
        body: 'Built to write features, refactor code, and chase arbitrary issues. Dependency triage is one job among many.',
      },
      {
        label: 'Broad blast radius',
        body: 'A fix-bot reshapes code adjacent to the patch; for a CVE the wrong neighbor edit is a regression.',
      },
      {
        label: 'Unregulated trust',
        body: 'Limited attestation for SOC 2 / NIS2 / CRA — every step must be reproducible in an external audit.',
      },
    ],
    caveat: 'Powerful — but wider scope is wider risk in a regulated tree.',
  },
  {
    value: 'bivouac',
    eyebrow: 'Bivouac',
    headline: 'Narrow scope, full audit',
    bullets: [
      {
        label: 'One job, very well',
        body: 'Only CVEs, upstream breaking changes, and supply-chain incidents. Nothing else lands in the queue.',
      },
      {
        label: 'Decides before paging',
        body: 'Forward fix vs. downgrade vs. pin is solved locally; the test suite is the gate, the human is the escalation.',
      },
      {
        label: 'Audit-ready by default',
        body: 'Every PR carries a trail: feed source, decision rationale, test result, merge outcome. SOC 2 / NIS2 / CRA evidence-ready.',
      },
    ],
    caveat: 'Sits alongside the others — narrows scope, owns the trail.',
  },
];

export function CompareTabs() {
  return (
    <Tabs defaultValue="bivouac" className="w-full">
      <TabsList className="grid h-auto w-full grid-cols-3 gap-0 bg-transparent p-0">
        {APPROACHES.map((a) => (
          <TabsTrigger
            key={a.value}
            value={a.value}
            className={cn(
              'flex flex-col items-start gap-1 rounded-md border border-border bg-card px-4 py-3 text-left',
              'data-[state=active]:border-brand-500 data-[state=active]:bg-brand-500/10',
              'transition-colors hover:bg-accent',
            )}
          >
            <span className="text-caption font-semibold uppercase tracking-[0.08em] text-muted-foreground">
              {a.eyebrow}
            </span>
            <span className="text-small font-medium text-foreground">{a.headline}</span>
          </TabsTrigger>
        ))}
      </TabsList>

      {APPROACHES.map((a) => (
        <TabsContent key={a.value} value={a.value} className="mt-6">
          <div className="grid gap-4 md:grid-cols-3">
            {a.bullets.map((b) => (
              <div
                key={b.label}
                className="rounded-md border border-border bg-card p-5 transition-shadow hover:shadow-sm"
              >
                <p className="font-display text-h4 text-foreground">{b.label}</p>
                <p className="mt-2 text-small text-muted-foreground">{b.body}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-small text-muted-foreground">{a.caveat}</p>
        </TabsContent>
      ))}
    </Tabs>
  );
}
