// @polsia:user-owned — client island for /patches/[id] AND /dashboard/patches/[id].
// Fetches the derived detail for one patch via /api/patches/[id], parses
// through the shared PatchDetail contract, and renders:
//   - title + target repo + linked CVE id + package pin + opened-at header
//   - severity / test outcome / merge-state badges + outbound PR link
//   - per-file unified-diff list (<details> collapsed by default)
//   - four-state test panel: status header + run/passed/failed dl + log excerpt
//   - "Policy rule" card above the rationale with a page-a-human callout
//   - rationale paragraph at the bottom
// Owns loading / empty / error / 404 branches. Used by both the marketing
// /patches/[id] page and the dashboard /dashboard/patches/[id] page.

'use client';

import { AlertTriangle, ArrowLeft, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  PatchDetail as PatchDetailSchema,
  type PatchDetail as PatchDetailT,
  type PatchFileStatus,
  type PatchMergeState,
  type PatchPolicyAction,
  type PatchSeverity,
  type PatchTestOutcome,
} from '@/lib/contracts/patches';
import { cn } from '@/lib/utils';

type Tones = { tone: string; label: string };

const SEVERITY_LABEL: Record<PatchSeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const MERGE_LABEL: Record<PatchMergeState, string> = {
  'auto-merged': 'Auto-merged',
  open: 'Open',
  declined: 'Declined',
  // Brief wording — "Awaiting human review" reads on the badge instead of
  // the shorter "Paged human" so the merge state tells the story directly.
  'paged-human': 'Awaiting human review',
};

const TEST_LABEL: Record<PatchTestOutcome, string> = {
  pass: 'Tests passing',
  fail: 'Tests failing',
  running: 'Tests running',
  queued: 'Tests queued',
};

const FILE_STATUS_LABEL: Record<PatchFileStatus, string> = {
  added: 'Added',
  modified: 'Modified',
  deleted: 'Deleted',
};

const FILE_STATUS_TONE: Record<PatchFileStatus, string> = {
  added: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  modified: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  deleted:
    'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
};

const POLICY_ACTION_LABEL: Record<PatchPolicyAction, string> = {
  'auto-merge': 'Auto-merge',
  'open-pr-wait': 'Open PR and wait',
  'page-human': 'Page a human',
  decline: 'Decline',
};

const POLICY_ACTION_TONE: Record<PatchPolicyAction, string> = {
  'auto-merge': 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
  'open-pr-wait': 'border-border bg-muted text-muted-foreground',
  'page-human': 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
  decline:
    'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
};

function severityTone(s: PatchSeverity): Tones {
  switch (s) {
    case 'critical':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: SEVERITY_LABEL[s],
      };
    case 'high':
      return {
        tone: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
        label: SEVERITY_LABEL[s],
      };
    case 'medium':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: SEVERITY_LABEL[s],
      };
    case 'low':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: SEVERITY_LABEL[s],
      };
  }
}

function testTone(t: PatchTestOutcome): Tones {
  switch (t) {
    case 'pass':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: TEST_LABEL[t],
      };
    case 'fail':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: TEST_LABEL[t],
      };
    case 'queued':
    case 'running':
      return {
        tone: 'border-border bg-muted text-muted-foreground',
        label: TEST_LABEL[t],
      };
  }
}

function mergeTone(m: PatchMergeState): Tones {
  switch (m) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: MERGE_LABEL[m],
      };
    case 'paged-human':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: MERGE_LABEL[m],
      };
    case 'declined':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: MERGE_LABEL[m],
      };
    case 'open':
      return {
        tone: 'border-border bg-muted text-muted-foreground',
        label: MERGE_LABEL[m],
      };
  }
}

export interface PatchDetailProps {
  id: string;
}

export function PatchDetail({ id }: PatchDetailProps) {
  const [state, setState] = useState<
    | { status: 'loading' }
    | { status: 'ready'; detail: PatchDetailT }
    | { status: 'not-found' }
    | { status: 'error'; message: string }
  >({ status: 'loading' });

  useEffect(() => {
    let active = true;
    apiFetch(`/api/patches/${encodeURIComponent(id)}`, { schema: PatchDetailSchema })
      .then((detail) => {
        if (active) setState({ status: 'ready', detail });
      })
      .catch((err: unknown) => {
        if (!active) return;
        const errorMessage = err instanceof Error ? err.message : 'Could not load this patch.';
        const causeStatus =
          err instanceof Error && typeof err.cause === 'object' && err.cause !== null
            ? (err.cause as { status?: number }).status
            : undefined;
        const isNotFound = causeStatus === 404 || errorMessage.includes('(404)');
        if (isNotFound) {
          setState({ status: 'not-found' });
        } else {
          setState({ status: 'error', message: errorMessage });
        }
      });
    return () => {
      active = false;
    };
  }, [id]);

  if (state.status === 'loading') {
    return (
      <div aria-busy="true" className="flex flex-col gap-6">
        <Skeleton className="h-10 w-2/3" />
        <Skeleton className="h-6 w-1/2" />
        <div className="flex flex-wrap gap-2">
          <Skeleton className="h-6 w-24 rounded-md" />
          <Skeleton className="h-6 w-32 rounded-md" />
          <Skeleton className="h-6 w-28 rounded-md" />
        </div>
        <Skeleton className="h-48 w-full rounded-md" />
        <Skeleton className="h-20 w-full rounded-md" />
      </div>
    );
  }

  if (state.status === 'not-found') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Patch not found</AlertTitle>
        <AlertDescription>
          That patch id doesn&apos;t match any record we&apos;ve created yet.{' '}
          <Link
            href="/dashboard"
            className="underline decoration-dotted underline-offset-4 hover:text-foreground"
          >
            Back to the dashboard
          </Link>
          .
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load this patch.</AlertTitle>
        <AlertDescription>
          {state.message}{' '}
          <Link
            href="/dashboard"
            className="underline decoration-dotted underline-offset-4 hover:text-foreground"
          >
            Back to the dashboard
          </Link>
          .
        </AlertDescription>
      </Alert>
    );
  }

  const detail = state.detail;
  const sev = severityTone(detail.severity);
  const test = testTone(detail.testOutcome);
  const merge = mergeTone(detail.mergeState);
  const rule = detail.policyRule;

  return (
    <article className="flex flex-col gap-section">
      <Button asChild variant="ghost" size="sm" className="self-start gap-1.5">
        <Link href="/dashboard">
          <ArrowLeft className="size-4" aria-hidden /> Back to the dashboard
        </Link>
      </Button>

      <header className="flex flex-col gap-3">
        <p className="text-eyebrow">Patch</p>
        <h1 className="font-display text-h1 text-balance text-foreground">{detail.title}</h1>
        <p className="text-body-lg text-muted-foreground">
          <span className="font-mono">@{detail.targetRepo}</span>
          <span aria-hidden> · </span>
          <span className="font-mono">{detail.packageName}</span>{' '}
          <span className="font-mono">
            <span className="text-muted-foreground">{detail.fromVersion}</span>
            {' → '}
            <span className="text-foreground">{detail.toVersion}</span>
          </span>
          <span aria-hidden> · </span>
          <span className="text-muted-foreground">opened</span>{' '}
          <time dateTime={detail.createdAt}>
            {new Date(detail.createdAt).toLocaleString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </time>
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        <Badge
          variant="outline"
          className={cn('font-mono text-caption', 'border-border text-foreground')}
        >
          {detail.cveId}
        </Badge>
        <Badge variant="outline" className={sev.tone}>
          {sev.label} severity
        </Badge>
        <Badge variant="outline" className={test.tone}>
          {test.label}
        </Badge>
        <Badge variant="outline" className={merge.tone}>
          {merge.label}
        </Badge>
        <a
          href={detail.prUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 text-small text-brand-700 underline decoration-dotted underline-offset-4 hover:text-foreground dark:text-brand-300"
        >
          Open PR
          <ExternalLink className="size-3.5" aria-hidden />
        </a>
      </div>

      <Separator />

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">
            Proposed diff ({detail.files.length} file{detail.files.length === 1 ? '' : 's'})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ul className="divide-y divide-border/70">
            {detail.files.map((file) => {
              const tone = FILE_STATUS_TONE[file.status];
              const label = FILE_STATUS_LABEL[file.status];
              // <details> peers for each file entry — collapsed-by-default so
              // a long diff list doesn't dominate the page on first paint.
              // The summary is the full keyboard target (Enter / Space open).
              return (
                <li key={file.path} className="px-5 py-4">
                  <details className="group flex flex-col gap-3">
                    <summary className="flex cursor-pointer list-none flex-wrap items-center gap-3 rounded-md px-1 py-1 transition-colors hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring [&::-webkit-details-marker]:hidden">
                      <span
                        aria-hidden
                        className="inline-flex size-5 shrink-0 items-center justify-center rounded-full border border-border/70 bg-card text-caption text-muted-foreground transition-transform group-open:rotate-90"
                      >
                        ▸
                      </span>
                      <span className="font-mono text-small text-foreground">{file.path}</span>
                      <Badge variant="outline" className={cn('text-caption', tone)}>
                        {label}
                      </Badge>
                    </summary>
                    <pre className="m-0 overflow-x-auto rounded-md bg-muted/40 px-4 py-3 font-mono text-small leading-relaxed text-foreground">
                      {file.diff}
                    </pre>
                  </details>
                </li>
              );
            })}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-3">
          <CardTitle className="font-display text-h4">Test results</CardTitle>
          <Badge variant="outline" className={test.tone}>
            {test.label}
          </Badge>
        </CardHeader>
        <CardContent className="flex flex-col gap-5">
          <dl className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="flex flex-col gap-1">
              <dt className="text-eyebrow text-muted-foreground">Tests passing</dt>
              <dd className="font-display text-h3 text-foreground">{detail.testsPassed}</dd>
            </div>
            <div className="flex flex-col gap-1">
              <dt className="text-eyebrow text-muted-foreground">Tests failing</dt>
              <dd className="font-display text-h3 text-foreground">{detail.testsFailed}</dd>
            </div>
            <div className="flex flex-col gap-1">
              <dt className="text-eyebrow text-muted-foreground">Tests run</dt>
              <dd className="font-display text-h3 text-foreground">{detail.testsRun}</dd>
            </div>
          </dl>
          <div className="flex flex-col gap-2">
            <p className="text-eyebrow text-muted-foreground">Log excerpt</p>
            <pre className="m-0 max-h-56 overflow-auto whitespace-pre rounded-md bg-muted/40 px-4 py-3 font-mono text-small leading-relaxed text-foreground">
              {detail.testLog}
            </pre>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">Policy rule</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className={POLICY_ACTION_TONE[rule.action]}>
              {POLICY_ACTION_LABEL[rule.action]}
            </Badge>
            <span className="font-mono text-caption text-muted-foreground">id: {rule.id}</span>
          </div>
          <p className="text-body text-foreground">{rule.label}</p>
          {rule.pagedHuman ? (
            <Alert className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300">
              <AlertTriangle className="size-4" aria-hidden />
              <AlertTitle>A human reviewer was paged for this patch</AlertTitle>
              <AlertDescription className="text-amber-700/90 dark:text-amber-300/90">
                The agent could not decide alone. A reviewer was paged to weigh the trade-off before
                this patch lands.
              </AlertDescription>
            </Alert>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">Why the agent took this path</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-body text-foreground">{detail.rationale}</p>
        </CardContent>
      </Card>
    </article>
  );
}
