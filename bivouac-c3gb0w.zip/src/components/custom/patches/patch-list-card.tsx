// @polsia:user-owned — client island for the dashboard patch list. Fetches
// /api/patches, parses the response through the shared PatchList contract,
// and renders a compact list of the latest agent-opened PRs, each linking
// to its /dashboard/patches/[id] detail view (matches the routing used by
// the repo-detail "Recent patches" tab and the audit log row click). Owns
// loading / empty / error branches so the page itself stays a Server
// Component that only exports metadata.

'use client';

import { ArrowUpRight } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import {
  PatchList,
  type PatchListItem,
  type PatchMergeState,
  type PatchSeverity,
} from '@/lib/contracts/patches';
import { cn } from '@/lib/utils';

type Tones = { tone: string; label: string };

const SEVERITY_LABEL: Record<PatchSeverity, string> = {
  low: 'Low',
  medium: 'Medium',
  high: 'High',
  critical: 'Critical',
};

const MERGE_LABEL: Record<PatchMergeState, string> = {
  'auto-merged': 'Auto-merged',
  open: 'Open',
  declined: 'Declined',
  'paged-human': 'Paged human',
};

function severityTone(s: PatchSeverity): Tones {
  switch (s) {
    case 'critical':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: SEVERITY_LABEL[s],
      };
    case 'high':
      return {
        tone: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
        label: SEVERITY_LABEL[s],
      };
    case 'medium':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: SEVERITY_LABEL[s],
      };
    case 'low':
      return {
        tone: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
        label: SEVERITY_LABEL[s],
      };
  }
}

function mergeTone(m: PatchMergeState): Tones {
  switch (m) {
    case 'auto-merged':
      return {
        tone: 'border-brand-500/40 bg-brand-500/10 text-brand-700 dark:text-brand-300',
        label: MERGE_LABEL[m],
      };
    case 'paged-human':
      return {
        tone: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
        label: MERGE_LABEL[m],
      };
    case 'declined':
      return {
        tone: 'border-destructive/40 bg-destructive/10 text-destructive dark:text-destructive-foreground',
        label: MERGE_LABEL[m],
      };
    case 'open':
      return {
        tone: 'border-border bg-muted text-muted-foreground',
        label: MERGE_LABEL[m],
      };
  }
}

const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c', 'sk-d'] as const;

export function PatchListCard() {
  const [items, setItems] = useState<PatchListItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    apiFetch('/api/patches', { schema: PatchList })
      .then((data) => {
        if (active) setItems(data.items);
      })
      .catch((err: unknown) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Could not load recent patches.');
      });
    return () => {
      active = false;
    };
  }, []);

  if (error) {
    return (
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="font-display text-h4 text-destructive">
            Recent patches unavailable
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">{error}</p>
        </CardContent>
      </Card>
    );
  }

  if (items === null) {
    return (
      <Card>
        <CardContent className="flex flex-col gap-3 py-8">
          <p className="text-small text-muted-foreground">Loading the latest patches…</p>
          <div className="flex flex-col gap-2">
            {SKELETON_IDS.map((id) => (
              <Skeleton key={id} className="h-12 w-full rounded-md" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-h4">No patches yet</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-small text-muted-foreground">
            The cron hasn&apos;t opened any patch PRs yet. Once it does, every one shows up here
            with its status.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-h4">Recent patches</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col divide-y divide-border/70 p-0">
        {items.map((row) => {
          const sev = severityTone(row.severity);
          const merge = mergeTone(row.mergeState);
          return (
            <Link
              key={row.id}
              href={`/dashboard/patches/${row.id}`}
              className={cn(
                'group flex flex-col gap-2 px-5 py-4 transition-colors',
                'hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <p className="font-display text-base font-semibold text-balance text-foreground group-hover:text-brand-700 dark:group-hover:text-brand-300">
                  {row.title}
                </p>
                <ArrowUpRight
                  className="mt-0.5 size-4 shrink-0 text-muted-foreground group-hover:text-foreground"
                  aria-hidden
                />
              </div>
              <div className="flex flex-wrap items-center gap-2 text-caption text-muted-foreground">
                <span className="font-mono text-foreground/80">{row.cveId}</span>
                <span aria-hidden>·</span>
                <span className="font-mono">
                  {row.packageName}@<span className="text-muted-foreground">{row.fromVersion}</span>{' '}
                  → <span className="font-semibold text-foreground">{row.toVersion}</span>
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className={sev.tone}>
                  {sev.label} severity
                </Badge>
                <Badge variant="outline" className={merge.tone}>
                  {merge.label}
                </Badge>
              </div>
            </Link>
          );
        })}
      </CardContent>
    </Card>
  );
}
