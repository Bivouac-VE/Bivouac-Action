// @polsia:user-owned — Pending-invites list for /settings/team. Renders the
// outstanding invites with Revoke + Resend actions. Resend calls the same
// POST /api/team/invites endpoint (creating a NEW row + re-sending the
// email); the original is preserved as audit until it expires.

'use client';

import { Loader2, RefreshCw, Send, X } from 'lucide-react';
import { useCallback, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { apiFetch } from '@/lib/api-client';
import {
  InviteCreate,
  InviteCreateResponse,
  type PendingInviteItem,
  ROLE_TONE,
} from '@/lib/contracts/team';

export interface PendingInvitesProps {
  invites: PendingInviteItem[];
  isTeamAdmin: boolean;
  onRefresh: () => Promise<void>;
}

const ERROR_COPY: Record<string, string> = {
  invite_already_pending:
    'A new invite for that email is already pending. Revoke that one first to resend.',
  already_a_member: 'That teammate already belongs to your team.',
  invalid_request: 'Check the email and try again.',
};

interface RowState {
  revoking?: boolean;
  resending?: boolean;
}

function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function PendingInvites({ invites, isTeamAdmin, onRefresh }: PendingInvitesProps) {
  const [rowState, setRowState] = useState<Record<string, RowState>>({});
  const [error, setError] = useState<string | null>(null);

  const onRevoke = useCallback(
    async (rowId: string, label: string) => {
      setError(null);
      setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], revoking: true } }));
      try {
        await apiFetch(`/api/team/invites/${rowId}`, { method: 'DELETE' });
        toast.message(`Invite to ${label} revoked.`);
        await onRefresh();
      } catch (err: unknown) {
        const cause = (err as { cause?: unknown } | null)?.cause;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? ((cause as { error?: unknown }).error as string | undefined)
            : undefined;
        setError(ERROR_COPY[code ?? ''] ?? 'Could not revoke that invite.');
        toast.error(ERROR_COPY[code ?? ''] ?? 'Could not revoke that invite.');
      } finally {
        setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], revoking: false } }));
      }
    },
    [onRefresh],
  );

  const onResend = useCallback(
    async (row: PendingInviteItem) => {
      if (rowState[row.id]?.resending) return;
      setError(null);
      setRowState((prev) => ({ ...prev, [row.id]: { ...prev[row.id], resending: true } }));
      try {
        await apiFetch('/api/team/invites', {
          method: 'POST',
          schema: InviteCreateResponse,
          body: JSON.stringify(
            InviteCreate.parse({ email: row.email.toLowerCase(), role: row.role }),
          ),
        });
        toast.success(`Resent invite to ${row.email}.`);
        await onRefresh();
      } catch (err: unknown) {
        const cause = (err as { cause?: unknown } | null)?.cause;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? ((cause as { error?: unknown }).error as string | undefined)
            : undefined;
        setError(ERROR_COPY[code ?? ''] ?? 'Could not resend that invite.');
        toast.error(ERROR_COPY[code ?? ''] ?? 'Could not resend that invite.');
      } finally {
        setRowState((prev) => ({ ...prev, [row.id]: { ...prev[row.id], resending: false } }));
      }
    },
    [onRefresh, rowState],
  );

  if (invites.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col gap-3">
      <p className="text-eyebrow">Pending invites</p>

      {error ? (
        <Alert variant="destructive" className="border-destructive/40">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <ul className="flex flex-col gap-2">
        {invites.map((row) => {
          const row_ = rowState[row.id] ?? {};
          return (
            <li
              key={row.id}
              className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-md border border-border/70 bg-background/60 px-3 py-2.5 text-sm"
            >
              <div className="flex flex-col gap-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium text-foreground">{row.email}</span>
                  <Badge variant="outline" className={ROLE_TONE[row.role].toneClass}>
                    {ROLE_TONE[row.role].label}
                  </Badge>
                  {row.lastSendStatus === 'failed' ? (
                    <Badge
                      variant="outline"
                      className="border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300"
                    >
                      Send failed
                    </Badge>
                  ) : null}
                </div>
                <p className="text-xs text-muted-foreground">
                  Expires {formatDateTime(row.expiresAt)} · invited {formatDateTime(row.invitedAt)}
                </p>
              </div>

              {isTeamAdmin ? (
                <div className="flex items-center gap-1.5">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => void onResend(row)}
                    disabled={row_.resending}
                    className="gap-1.5"
                  >
                    {row_.resending ? (
                      <Loader2 className="size-3.5 animate-spin" aria-hidden />
                    ) : (
                      <RefreshCw className="size-3.5" aria-hidden />
                    )}
                    Resend
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => void onRevoke(row.id, row.email)}
                    disabled={row_.revoking || row_.resending}
                    className="gap-1.5 text-muted-foreground hover:text-destructive"
                  >
                    {row_.revoking ? (
                      <Loader2 className="size-3.5 animate-spin" aria-hidden />
                    ) : (
                      <X className="size-3.5" aria-hidden />
                    )}
                    Revoke
                  </Button>
                </div>
              ) : (
                <span className="text-xs text-muted-foreground">
                  <Send className="mr-1 inline size-3 text-foreground/60" aria-hidden />
                  Awaiting signup
                </span>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
