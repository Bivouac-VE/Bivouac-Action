// @polsia:user-owned — clientside MembersTable for /settings/team. Renders the
// seated roster with role chips, an inline role-change <Select> for admins,
// and a remove <Button variant="ghost">. Optimistic local update with rollback
// on error, refetch is owned by the parent island.

'use client';

import { Check, Loader2, Trash2, UserMinus } from 'lucide-react';
import { useCallback, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { apiFetch } from '@/lib/api-client';
import {
  type MemberItem,
  MemberRoleUpdate,
  ROLE_TONE,
  type TeamRoleEnum,
} from '@/lib/contracts/team';
import { cn } from '@/lib/utils';

export interface MembersTableProps {
  members: MemberItem[];
  currentUserId: string;
  isTeamAdmin: boolean;
  /**
   * Called after a successful PATCH (role change) or DELETE (remove member) so
   * the parent island can refetch `/api/team/state`. The shell picks up the
   * new role on the next pathname change — the refetch here keeps the
   * MembersTable row state in sync with the server (the optimistic update is
   * rolled back on error and replaced with the canonical response on success).
   */
  onRefresh: () => void;
}

// Optimistic local mutations are kept here in a per-row `pending` map. The
// parent always re-fetches after each PATCH/DELETE so the optimistic state is
// short-lived; on failure we revert + toast.
interface RowState {
  role?: TeamRoleEnum;
  removing?: boolean;
}

const ERROR_COPY: Record<string, string> = {
  sole_admin_promote_first: "That's the only admin on the team. Promote another admin first.",
  Forbidden: "You don't have permission to change that member.",
  Not_found: 'That member no longer exists.',
  invalid_request: 'Invalid role change.',
};

export function MembersTable({
  members,
  currentUserId,
  isTeamAdmin,
  onRefresh,
}: MembersTableProps) {
  const [rowState, setRowState] = useState<Record<string, RowState>>({});
  const [error, setError] = useState<string | null>(null);

  const sorted = useMemo(
    () =>
      [...members].sort((a, b) => {
        // Admins first, then on-call, then viewer; alphabetical within role.
        const order = { admin: 0, on_call: 1, viewer: 2 } as const;
        const ax = order[a.role];
        const bx = order[b.role];
        if (ax !== bx) return ax - bx;
        return a.email.localeCompare(b.email);
      }),
    [members],
  );

  const onRoleChange = useCallback(
    async (rowId: string, userId: string, nextRole: TeamRoleEnum, previousRole: TeamRoleEnum) => {
      setError(null);
      setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], role: nextRole } }));
      try {
        await apiFetch(`/api/team/members/${userId}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(MemberRoleUpdate.parse({ role: nextRole })),
        });
        // Server-side success — refetch so the row + the shell-level team
        // role for any current-row caller stay consistent. Deferred so the
        // toast reads as the result of the action, not the refetch.
        onRefresh();
      } catch (err: unknown) {
        const cause = (err as { cause?: unknown } | null)?.cause;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? ((cause as { error?: unknown }).error as string | undefined)
            : undefined;
        setError(ERROR_COPY[code ?? ''] ?? 'Could not change role.');
        // Rollback optimistic state.
        setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], role: previousRole } }));
        toast.error(ERROR_COPY[code ?? ''] ?? 'Could not change role.');
      }
    },
    [onRefresh],
  );

  const onRemove = useCallback(
    async (rowId: string, userId: string, label: string) => {
      setError(null);
      setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], removing: true } }));
      try {
        await apiFetch(`/api/team/members/${userId}`, { method: 'DELETE' });
        toast.message(`${label} removed from the team.`);
        // Parent will re-fetch and forget the row — leave the pending shell
        // until then, then ask the parent for fresh state.
        onRefresh();
      } catch (err: unknown) {
        const cause = (err as { cause?: unknown } | null)?.cause;
        const code =
          cause && typeof cause === 'object' && 'error' in cause
            ? ((cause as { error?: unknown }).error as string | undefined)
            : undefined;
        setError(ERROR_COPY[code ?? ''] ?? 'Could not remove that member.');
        setRowState((prev) => ({ ...prev, [rowId]: { ...prev[rowId], removing: false } }));
        toast.error(ERROR_COPY[code ?? ''] ?? 'Could not remove that member.');
      }
    },
    [onRefresh],
  );

  if (sorted.length === 0) {
    return (
      <p className="py-4 text-small text-muted-foreground">
        No seated members yet. Invite one to start building the team.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {error ? (
        <Alert variant="destructive" className="border-destructive/40">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <div className="overflow-x-auto rounded-md border border-border/70">
        <table className="w-full text-sm" aria-label="Team members">
          <thead className="bg-muted/30 text-left text-eyebrow uppercase">
            <tr>
              <th scope="col" className="px-3 py-2 font-medium text-muted-foreground">
                Member
              </th>
              <th scope="col" className="px-3 py-2 font-medium text-muted-foreground">
                Role
              </th>
              <th scope="col" className="px-3 py-2 text-right font-medium text-muted-foreground">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((m) => {
              const row = rowState[m.id] ?? {};
              const role = row.role ?? m.role;
              const isSelf = m.userId === currentUserId;
              const disabled = !isTeamAdmin || row.removing;
              const identity = m.name?.trim() || m.email || 'Unnamed teammate';
              return (
                <tr key={m.id} className="border-t border-border/70">
                  <td className="px-3 py-3 align-middle">
                    <div className="flex flex-col gap-0.5">
                      <p className="font-medium text-foreground">{identity}</p>
                      <p className="text-xs text-muted-foreground">{m.email}</p>
                    </div>
                  </td>
                  <td className="px-3 py-3 align-middle">
                    {isTeamAdmin ? (
                      <Select
                        value={role}
                        onValueChange={(value: string) =>
                          void onRoleChange(m.id, m.userId, value as TeamRoleEnum, m.role)
                        }
                        disabled={disabled}
                      >
                        <SelectTrigger
                          aria-label={`Change ${identity}'s role`}
                          className={cn('h-8 w-36 text-xs', ROLE_TONE[role].toneClass)}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(Object.keys(ROLE_TONE) as TeamRoleEnum[]).map((key) => (
                            <SelectItem key={key} value={key}>
                              <span className="inline-flex items-center gap-2">
                                {ROLE_TONE[key].label}
                                {key === role ? (
                                  <Check className="size-3 opacity-70" aria-hidden />
                                ) : null}
                              </span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge variant="outline" className={ROLE_TONE[role].toneClass}>
                        {ROLE_TONE[role].label}
                      </Badge>
                    )}
                  </td>
                  <td className="px-3 py-3 text-right align-middle">
                    <div className="inline-flex items-center gap-1.5">
                      {!isTeamAdmin ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          disabled
                          className="gap-1.5 opacity-50"
                        >
                          <UserMinus className="size-3.5" aria-hidden />
                          Remove
                        </Button>
                      ) : row.removing ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          disabled
                          className="gap-1.5"
                        >
                          <Loader2 className="size-3.5 animate-spin" aria-hidden />
                          Removing…
                        </Button>
                      ) : isSelf ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          disabled
                          className="gap-1.5 opacity-50"
                          title="Ask another team admin to remove you."
                        >
                          <Trash2 className="size-3.5" aria-hidden />
                          Remove
                        </Button>
                      ) : (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => void onRemove(m.id, m.userId, identity)}
                          className="gap-1.5 text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="size-3.5" aria-hidden />
                          Remove
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
