// @polsia:user-owned — client island for /settings/team.
//
// Owns the four render states the data-plane rule demands:
//   - loading      : /api/team/state is in flight
//   - error        : unknown failure (retry affordance)
//   - no-plan      : wrong-tier (Starter) → /pricing CTA, OR no-plan empty
//   - ok           : compose MembersTable + InviteMemberForm + PendingInvites
//
// All data comes from apiFetch('/api/team/state', { schema: TeamState }) so
// shape drift surfaces as a ZodError instead of silent UI breakage.

'use client';

import { AlertTriangle, ArrowRight, ShieldOff, Users } from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import { ROLE_TONE, TeamState, type TeamState as TeamStateT } from '@/lib/contracts/team';
import { InviteMemberForm } from './invite-member-form';
import { MembersTable } from './members-table';
import { PendingInvites } from './pending-invites';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'unauthed' }
  | { status: 'empty' }
  | { status: 'ready'; state: TeamStateT };

const copyForError = (err: string): string => {
  return err;
};

export function TeamSettingsView() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/team/state', { schema: TeamState });
      if (!data.tier || data.tier === 'no-plan' || data.tier === 'wrong-tier') {
        setState({ status: 'empty' });
        return;
      }
      if (!data.currentUser) {
        setState({ status: 'unauthed' });
        return;
      }
      setState({ status: 'ready', state: data });
    } catch (err: unknown) {
      // Type narrow on the apiFetch error shape.
      const cause = (err as { cause?: unknown } | null)?.cause;
      const nested =
        cause && typeof cause === 'object' && 'error' in cause
          ? (cause as { error?: unknown }).error
          : undefined;
      const code = typeof nested === 'string' ? nested : undefined;
      if (code === 'Unauthorized') {
        setState({ status: 'unauthed' });
        return;
      }
      const message = err instanceof Error ? err.message : 'request_failed';
      setState({ status: 'error', message: copyForError(message) });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.status === 'loading') {
    return <TeamSkeleton />;
  }
  if (state.status === 'unauthed') {
    return (
      <Card className="border-border bg-card/60">
        <CardContent className="py-10 text-center">
          <p className="text-small text-muted-foreground">Sign in to manage your team.</p>
          <Button asChild variant="outline" size="sm" className="mt-4">
            <Link href="/login?next=/settings/team">Sign in</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }
  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load your team state.</AlertTitle>
        <AlertDescription>
          We could not reach the team endpoint right now. Retry in a moment.{' '}
          <span className="text-xs text-muted-foreground">({state.message})</span>
        </AlertDescription>
      </Alert>
    );
  }
  if (state.status === 'empty') {
    return <WrongTierEmptyState />;
  }

  return <ReadyPanel state={state.state} onRefresh={load} />;
}

// ----------------------------------------------------------------------------

function TeamSkeleton() {
  return (
    <section aria-label="Loading team state" className="flex flex-col gap-4">
      <Skeleton className="h-10 w-60" />
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-24 w-full rounded-xl" />
    </section>
  );
}

function WrongTierEmptyState() {
  return (
    <section
      aria-label="Team unavailable on this tier"
      className="relative overflow-hidden rounded-lg border border-border/70 bg-gradient-to-br from-card via-muted/40 to-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 -top-24 size-[360px] text-brand-500/15"
      >
        <svg
          viewBox="0 0 360 360"
          fill="none"
          stroke="currentColor"
          className="size-full"
          role="presentation"
        >
          <title>Decorative team-grid nod</title>
          <rect x="36" y="36" width="120" height="120" strokeWidth="1" />
          <rect x="204" y="36" width="120" height="120" strokeWidth="1" />
          <rect x="36" y="204" width="120" height="120" strokeWidth="1" />
          <rect x="204" y="204" width="120" height="120" strokeWidth="1" />
          <path d="M 156 96 L 204 96" strokeWidth="1.5" />
          <path d="M 156 264 L 204 264" strokeWidth="0.5" />
        </svg>
      </div>
      <div className="relative flex flex-col items-start gap-6 p-8 md:p-12">
        <p className="text-eyebrow">Multi-seat access</p>
        <h2 className="font-display text-h2 text-balance text-foreground">
          Move your team onto the Team or Enterprise tier.
        </h2>
        <p className="max-w-xl text-body text-muted-foreground">
          Multi-seat management lives on the Team and Enterprise plans. Upgrade from the settings
          page to invite teammates, change roles, and route on-call paging.
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <Button asChild size="lg" className="gap-2 shadow-brand">
            <Link href="/pricing">
              See plans
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          </Button>
          <Button asChild size="lg" variant="ghost" className="gap-2">
            <Link href="/dashboard">Back to dashboard</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------

function ReadyPanel({ state, onRefresh }: { state: TeamStateT; onRefresh: () => Promise<void> }) {
  const me = state.currentUser;
  const isAdmin = me.isTeamAdmin;
  const myRoleEntry = state.members.find((m) => m.userId === me.userId);
  const myRole = myRoleEntry?.role ?? 'viewer';
  const adminCount = state.members.filter((m) => m.role === 'admin').length;
  const pendingCount = state.pendingInvites.length;
  const seatCount = state.members.length;
  const totalCount = seatCount + pendingCount;

  return (
    <section aria-label="Team management" className="flex flex-col gap-8">
      <header className="flex flex-col gap-1">
        <p className="text-eyebrow">Team</p>
        <h1 className="font-display text-h2 text-balance text-foreground">Your Bivouac team</h1>
        <p className="text-body-lg text-muted-foreground">
          {isAdmin
            ? 'Invite teammates, change their seats, and route the on-call. Sole-admin changes are blocked until you promote another admin.'
            : 'Read-only view. Ask a team admin to invite, change roles, or remove teammates.'}
        </p>
      </header>

      {/* ---------- Top stats strip ---------- */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard label="Seated" value={String(seatCount)} right="members" icon={Users} />
        <StatCard
          label="Pending invites"
          value={String(pendingCount)}
          right={pendingCount === 1 ? 'invite' : 'invites'}
          icon={ShieldOff}
        />
        <StatCard
          label="Admins"
          value={String(adminCount)}
          right={adminCount === 1 ? 'sole admin' : 'on the team'}
          icon={Users}
        />
      </div>

      {/* ---------- Tabular members ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0 p-5 pb-3">
          <div className="grid gap-1">
            <CardTitle className="font-display text-h4 text-foreground">Members</CardTitle>
            <CardDescription className="text-small text-muted-foreground">
              {totalCount === 0
                ? 'No teammates yet — invite one to start.'
                : `${seatCount} seated, ${pendingCount} pending`}
            </CardDescription>
          </div>
          <Badge
            variant="outline"
            className={
              ROLE_TONE[myRole]?.toneClass ?? 'border-border bg-muted text-muted-foreground'
            }
          >
            Your role: {ROLE_TONE[myRole]?.label ?? myRole}
          </Badge>
        </CardHeader>
        <CardContent className="flex flex-col gap-6 px-5 pb-5">
          <MembersTable
            members={state.members}
            currentUserId={me.userId}
            isTeamAdmin={isAdmin}
            onRefresh={onRefresh}
          />
          <Separator />
          <PendingInvites
            invites={state.pendingInvites}
            isTeamAdmin={isAdmin}
            onRefresh={onRefresh}
          />
        </CardContent>
      </Card>

      {/* ---------- Invite form ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="space-y-0 p-5 pb-3">
          <CardTitle className="font-display text-h4 text-foreground">Invite a teammate</CardTitle>
          <CardDescription className="text-small text-muted-foreground">
            Send a magic-link invite. The recipient signs up and lands in your team at the role you
            choose — no separate account-migration step.
          </CardDescription>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          {isAdmin ? (
            <InviteMemberForm onSuccess={() => void onRefresh()} />
          ) : (
            <p className="text-small text-muted-foreground">
              Only team admins can send invites. Ask one of{' '}
              <span className="font-medium text-foreground">
                {state.members
                  .filter((m) => m.role === 'admin')
                  .map((a) => a.email)
                  .join(', ') || 'your admins'}
              </span>{' '}
              to send one.
            </p>
          )}
        </CardContent>
      </Card>
    </section>
  );
}

// ----------------------------------------------------------------------------

function StatCard({
  label,
  value,
  right,
  icon: Icon,
}: {
  label: string;
  value: string;
  right: string;
  icon: typeof Users;
}) {
  return (
    <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-4">
      <div className="flex items-center gap-2">
        <Icon className="size-3.5 shrink-0 text-brand-700 dark:text-brand-300" aria-hidden />
        <p className="text-eyebrow">{label}</p>
      </div>
      <p className="font-display text-h3 text-foreground">{value}</p>
      <p className="text-small text-muted-foreground">{right}</p>
    </div>
  );
}
