// @polsia:user-owned — invite-member form for /settings/team.
//
// Posts to /api/team/invites, surfaces field-level errors from the response,
// and on success emits a toast + invokes onSuccess (parent refetches).

'use client';

import { Loader2, Send } from 'lucide-react';
import { useCallback, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { apiFetch } from '@/lib/api-client';
import {
  InviteCreate,
  InviteCreateResponse,
  ROLE_TONE,
  type TeamRoleEnum,
} from '@/lib/contracts/team';

export interface InviteMemberFormProps {
  /** Called after a successful POST so the parent island can re-fetch state. */
  onSuccess: () => void;
}

const ERROR_COPY: Record<string, string> = {
  invite_already_pending:
    'That email already has a pending invite. Revoke it first to send a new one.',
  already_a_member: 'That teammate already belongs to your team.',
  invalid_request: 'Check the email and try again.',
};

const DEFAULT_ROLE: TeamRoleEnum = 'viewer';

function isZodIssues(value: unknown): boolean {
  // Light detection of zod field-level errors; route returns { error: 'invalid_request' }
  // for present field validation, so callers receive the bottom-line message.
  return value instanceof Error && value.name === 'ZodError';
}

export function InviteMemberForm({ onSuccess }: InviteMemberFormProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<TeamRoleEnum>(DEFAULT_ROLE);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (pending) return;
      const parsed = InviteCreate.safeParse({ email: email.trim().toLowerCase(), role });
      if (!parsed.success) {
        const issues = parsed.error.issues
          .map((i) => {
            if (i.path[0] === 'email') return 'That email looks invalid.';
            if (i.path[0] === 'role') return 'Pick a role.';
            return i.message;
          })
          .join(' ');
        setError(issues || 'Check the form and try again.');
        return;
      }
      setPending(true);
      setError(null);
      try {
        const res = await apiFetch('/api/team/invites', {
          method: 'POST',
          schema: InviteCreateResponse,
          body: JSON.stringify(parsed.data),
        });
        const sent = res.invite.lastSendStatus === 'sent';
        toast.success(
          sent
            ? `Invite sent to ${res.invite.email}.`
            : `Invite recorded for ${res.invite.email}, but the email failed to send. Try Resend.`,
        );
        setEmail('');
        setRole(DEFAULT_ROLE);
        onSuccess();
      } catch (err: unknown) {
        if (isZodIssues(err)) {
          setError('The server response was malformed.');
        } else {
          const cause = (err as { cause?: unknown } | null)?.cause;
          const code =
            cause && typeof cause === 'object' && 'error' in cause
              ? ((cause as { error?: unknown }).error as string | undefined)
              : undefined;
          setError(ERROR_COPY[code ?? ''] ?? 'Could not send that invite.');
          toast.error(ERROR_COPY[code ?? ''] ?? 'Could not send that invite.');
        }
      } finally {
        setPending(false);
      }
    },
    [email, onSuccess, pending, role],
  );

  return (
    <div className="rounded-md border border-border/70 bg-background/60 p-4">
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <p className="text-eyebrow">New invite</p>
        <p className="text-small text-muted-foreground">
          Pick a role and send a magic invite link. The teardown is just revoke.
        </p>

        <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
          <div className="flex flex-col gap-2">
            <Label htmlFor="invite-email">Email</Label>
            <Input
              id="invite-email"
              name="email"
              type="email"
              inputMode="email"
              autoComplete="off"
              spellCheck={false}
              placeholder="teammate@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              aria-invalid={Boolean(error)}
              disabled={pending}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="invite-role">Role</Label>
            <Select
              value={role}
              onValueChange={(value: string) => setRole(value as TeamRoleEnum)}
              disabled={pending}
            >
              <SelectTrigger id="invite-role" className="h-9 w-full sm:w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(ROLE_TONE) as TeamRoleEnum[]).map((key) => (
                  <SelectItem key={key} value={key}>
                    <span className="inline-flex flex-col gap-0.5">
                      <span className="font-medium">{ROLE_TONE[key].label}</span>
                      <span className="text-xs text-muted-foreground">{ROLE_TONE[key].blurb}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {error ? (
          <Alert variant="destructive" className="border-destructive/40">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            Roles: <span className="font-medium text-foreground">Admin</span> — manage members,{' '}
            <span className="font-medium text-foreground">On-call</span> — paged for contested
            decisions, <span className="font-medium text-foreground">Viewer</span> — read-only.
          </p>
          <Button
            type="submit"
            size="sm"
            disabled={pending || !email.trim()}
            className="gap-1.5 shadow-brand"
          >
            {pending ? (
              <>
                <Loader2 className="size-3.5 animate-spin" aria-hidden /> Working…
              </>
            ) : (
              <>
                <Send className="size-3.5" aria-hidden /> Send invite
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
