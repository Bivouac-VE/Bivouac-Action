// @polsia:user-owned — client island for /dashboard/team.
//
// The page (src/app/(dashboard)/dashboard/team/page.tsx) is a Server Component
// that exports metadata and delegates to this island. The island OWNS the
// data fetch: the page MUST NOT import @/lib/db, prisma, requireAuth,
// next/headers, or server-only — those all live strictly in /api/team/**.
//
// Renders four states from /api/team/state:
//   - loading  : skeleton blocks for header + table + invite form
//   - error    : destructive alert with retry (re-runs load())
//   - unauthed : 'sign in' card (DashboardShell usually redirects before this
//                renders — this is the transient state)
//   - ready    : header, MembersTable, PendingInvites, then InviteMemberForm
//                (admin) OR "Ask an admin" card (non-admin)
//
// Admin/non-admin branching is sourced from `state.currentUser.isTeamAdmin`
// (computed server-side by isTeamAdmin() against the Membership table) —
// NOT from the session hook here. Server is authoritative, client is a
// renderer.

'use client';

import { AlertTriangle, Inbox, MailPlus, RefreshCcw, ShieldOff, Users } from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { apiFetch } from '@/lib/api-client';
import { ROLE_TONE, TeamState, type TeamState as TeamStateT } from '@/lib/contracts/team';
import { InviteMemberForm } from './invite-member-form';
import { MembersTable } from './members-table';
import { PendingInvites } from './pending-invites';

type ViewState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'unauthed' }
  | { status: 'ready'; state: TeamStateT };

export function TeamManagementView() {
  const [state, setState] = useState<ViewState>({ status: 'loading' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });
    try {
      const data = await apiFetch('/api/team/state', { schema: TeamState });
      if (!data.currentUser) {
        setState({ status: 'unauthed' });
        return;
      }
      setState({ status: 'ready', state: data });
    } catch (err: unknown) {
      const cause = (err as { cause?: unknown } | null)?.cause;
      const nested =
        cause && typeof cause === 'object' && 'error' in cause
          ? (cause as { error?: unknown }).error
          : undefined;
      const code = typeof nested === 'string' ? nested : undefined;
      if (code === 'Unauthorized') {
        setState({ status: 'unauthed' });
        return;
      }
      const message = err instanceof Error ? err.message : 'request_failed';
      setState({ status: 'error', message });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (state.status === 'loading') {
    return <TeamSkeleton />;
  }
  if (state.status === 'unauthed') {
    return (
      <Card className="border-border bg-card/60">
        <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
          <ShieldOff className="size-6 text-muted-foreground" aria-hidden />
          <p className="text-small text-muted-foreground">
            Sign in to see your team roster and pending invites.
          </p>
          <Button asChild variant="outline" size="sm" className="mt-1">
            <Link href="/login?next=/dashboard/team">Sign in</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }
  if (state.status === 'error') {
    return (
      <Alert variant="destructive" className="border-destructive/40">
        <AlertTriangle className="size-4" aria-hidden />
        <AlertTitle>Could not load your team state.</AlertTitle>
        <AlertDescription className="flex flex-col gap-3">
          <span>
            We could not reach the team endpoint right now. Retry in a moment.{' '}
            <span className="text-xs text-muted-foreground">({state.message})</span>
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void load()}
            className="w-fit gap-1.5"
          >
            <RefreshCcw className="size-3.5" aria-hidden />
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return <ReadyPanel state={state.state} onRefresh={load} />;
}

// ---------------------------------------------------------------------------

function TeamSkeleton() {
  return (
    <section aria-label="Loading team state" className="flex flex-col gap-section">
      <div className="flex flex-col gap-2">
        <Skeleton className="h-4 w-20" />
        <Skeleton className="h-9 w-72" />
        <Skeleton className="h-5 w-96 max-w-full" />
      </div>
      <Skeleton className="h-40 w-full rounded-xl" />
      <Skeleton className="h-24 w-full rounded-xl" />
      <Skeleton className="h-56 w-full rounded-xl" />
    </section>
  );
}

// ---------------------------------------------------------------------------

function ReadyPanel({ state, onRefresh }: { state: TeamStateT; onRefresh: () => Promise<void> }) {
  const me = state.currentUser;
  const isAdmin = me.isTeamAdmin;
  const myRoleEntry = state.members.find((m) => m.userId === me.userId);
  const myRole = myRoleEntry?.role ?? null;
  const adminCount = state.members.filter((m) => m.role === 'admin').length;
  const pendingCount = state.pendingInvites.length;
  const seatCount = state.members.length;
  const adminEmails = state.members.filter((m) => m.role === 'admin').map((m) => m.email);

  return (
    <section aria-label="Team management" className="flex flex-col gap-section">
      {!isAdmin ? <ReadOnlyBanner /> : null}

      {/* ---------- Header ---------- */}
      <header className="flex flex-col gap-2">
        <p className="text-eyebrow">Team</p>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h1 className="font-display text-h1 text-balance text-foreground">Team members</h1>
          {myRole ? (
            <Badge
              variant="outline"
              className={ROLE_TONE[myRole].toneClass}
              aria-label={`Your role: ${ROLE_TONE[myRole].label}`}
            >
              Your role: {ROLE_TONE[myRole].label}
            </Badge>
          ) : null}
        </div>
        <p className="max-w-2xl text-body-lg text-muted-foreground">
          {isAdmin
            ? `Invite a teammate by email with a chosen role, or change a seated member's role below. Removing a member keeps the seat open.`
            : 'Read-only view. Ask an admin to invite, change roles, or remove teammates.'}
        </p>
      </header>

      {/* ---------- Stats strip ---------- */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard
          label="Seated"
          value={String(seatCount)}
          right={seatCount === 1 ? 'member' : 'members'}
          icon={Users}
        />
        <StatCard
          label="Pending invites"
          value={String(pendingCount)}
          right={pendingCount === 1 ? 'invite' : 'invites'}
          icon={MailPlus}
        />
        <StatCard
          label="Admins"
          value={String(adminCount)}
          right={adminCount === 1 ? 'sole admin' : 'on the team'}
          icon={Users}
        />
      </div>

      {/* ---------- Members + pending invites ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="flex flex-row items-center justify-between gap-3 space-y-0 p-5 pb-3">
          <div className="grid gap-1">
            <CardTitle className="font-display text-h4 text-foreground">Members</CardTitle>
            <CardDescription className="text-small text-muted-foreground">
              {seatCount === 0 && pendingCount === 0
                ? 'No teammates yet — invite one to start.'
                : `${seatCount} seated, ${pendingCount} pending`}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col gap-6 px-5 pb-5">
          <MembersTable
            members={state.members}
            currentUserId={me.userId}
            isTeamAdmin={isAdmin}
            onRefresh={onRefresh}
          />
          <Separator />
          <PendingInvites
            invites={state.pendingInvites}
            isTeamAdmin={isAdmin}
            onRefresh={onRefresh}
          />
        </CardContent>
      </Card>

      {/* ---------- Invite form (admin) | Ask-an-admin card (non-admin) ---------- */}
      <Card className="lift border-border bg-card/80 p-0">
        <CardHeader className="space-y-0 p-5 pb-3">
          <CardTitle className="font-display text-h4 text-foreground">
            {isAdmin ? 'Invite a teammate' : 'Ask an admin'}
          </CardTitle>
          <CardDescription className="text-small text-muted-foreground">
            {isAdmin
              ? 'Send a magic-link invite. The recipient signs up and lands in your team at the role you choose.'
              : 'Only team admins can send invites or change seated roles. Reach out to one of them below.'}
          </CardDescription>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          {isAdmin ? (
            <InviteMemberForm onSuccess={() => void onRefresh()} />
          ) : (
            <AskAnAdminCard adminEmails={adminEmails} />
          )}
        </CardContent>
      </Card>
    </section>
  );
}

// ---------------------------------------------------------------------------

function ReadOnlyBanner() {
  return (
    <output className="flex items-start gap-3 rounded-md border border-border/70 bg-muted/40 p-4">
      <Inbox className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden />
      <div className="flex flex-col gap-0.5 text-small">
        <p className="font-medium text-foreground">Read-only view</p>
        <p className="text-muted-foreground">
          Only team admins can invite, change roles, or remove members. Ask one of them to make a
          change for you.
        </p>
      </div>
    </output>
  );
}

// ---------------------------------------------------------------------------

function AskAnAdminCard({ adminEmails }: { adminEmails: string[] }) {
  if (adminEmails.length === 0) {
    return (
      <div className="flex flex-col gap-2 rounded-md border border-dashed border-border/70 bg-background/60 p-4 text-small text-muted-foreground">
        <p>
          Your workspace doesn’t have a seated team admin yet. Ask the account owner to promote one
          so invites and role changes can happen here.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 rounded-md border border-border/70 bg-background/60 p-4">
      <p className="text-small text-muted-foreground">
        Reach out to one of your team admins to invite a new teammate, change a role, or remove a
        member.
      </p>
      <ul className="flex flex-col gap-2">
        {adminEmails.map((email) => (
          <li
            key={email}
            className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border/40 bg-card/60 px-3 py-2"
          >
            <span className="font-medium text-foreground">{email}</span>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <a href={`mailto:${email}?subject=Team%20access%20for%20Bivouac`}>
                <MailPlus className="size-3.5" aria-hidden />
                Email
              </a>
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------------------------------------------------------------------

function StatCard({
  label,
  value,
  right,
  icon: Icon,
}: {
  label: string;
  value: string;
  right: string;
  icon: typeof Users;
}) {
  return (
    <div className="flex flex-col gap-2 rounded-md border border-border/70 bg-background/60 p-4">
      <div className="flex items-center gap-2">
        <Icon className="size-3.5 shrink-0 text-brand-700 dark:text-brand-300" aria-hidden />
        <p className="text-eyebrow">{label}</p>
      </div>
      <p className="font-display text-h3 text-foreground">{value}</p>
      <p className="text-small text-muted-foreground">{right}</p>
    </div>
  );
}
