// @vitest-environment node
// node not jsdom — derivePolicyRule / etc. live in src/lib/business/patches.ts
// which imports 'server-only', and jsdom cannot resolve the runtime-relative
// marker. node matches Next's runtime + vi.mock('server-only', ...) clears
// that marker for the unit tests below.
import { describe, expect, it, vi } from 'vitest';

vi.mock('server-only', () => ({}));

import {
  derivePolicyRule,
  deriveSeverity,
  deriveTestOutcome,
  SEVERITY_BY_CVE,
  synthesizeTestLog,
} from '@/lib/business/patches';
import { PatchDetail, PatchList, PatchTestOutcomeEnum } from '@/lib/contracts/patches';

// Pair-wise covers the new business/contracts surface shipped with the
// /dashboard/patches/[id] drilldown — keep these in lock-step with the
// `derive*` helpers in src/lib/business/patches.ts and the zod shape in
// src/lib/contracts/patches.ts.
describe('deriveTestOutcome', () => {
  it('maps PASSED → pass', () => {
    expect(deriveTestOutcome('PASSED')).toBe('pass');
  });

  it('maps FAILED and ERRORED → fail', () => {
    expect(deriveTestOutcome('FAILED')).toBe('fail');
    expect(deriveTestOutcome('ERRORED')).toBe('fail');
  });

  it('maps PENDING → queued (not running — brief is explicit about the distinction)', () => {
    expect(deriveTestOutcome('PENDING')).toBe('queued');
  });

  it('maps unknown values → running (cron posted status but no pass/fail yet)', () => {
    expect(deriveTestOutcome('UNKNOWN')).toBe('running');
    expect(deriveTestOutcome('')).toBe('running');
  });

  it('matches the zod enum for every branch', () => {
    for (const stored of ['PASSED', 'FAILED', 'ERRORED', 'PENDING', 'UNKNOWN', '']) {
      const outcome = deriveTestOutcome(stored);
      expect(() => PatchTestOutcomeEnum.parse(outcome)).not.toThrow();
    }
  });
});

describe('derivePolicyRule', () => {
  const base = { cveId: 'CVE-2024-1001', severity: 'high' as const, testOutcome: 'PASSED' };

  it('maps AUTO_MERGE → auto-merge without paging a human', () => {
    const rule = derivePolicyRule({ ...base, mergeDecision: 'AUTO_MERGE' });
    expect(rule.action).toBe('auto-merge');
    expect(rule.pagedHuman).toBe(false);
    expect(rule.label).toMatch(/Auto-merge/);
    expect(rule.id).toBe('auto-merge:cve-known-good');
  });

  it('maps MANUAL_REVIEW → page-human with the pagedHuman flag on', () => {
    const rule = derivePolicyRule({ ...base, mergeDecision: 'MANUAL_REVIEW' });
    expect(rule.action).toBe('page-human');
    expect(rule.pagedHuman).toBe(true);
    expect(rule.label).toMatch(/Page a human/);
    expect(rule.id).toBe('page-human:reviewer-required');
  });

  it('maps BLOCKED → decline without paging a human', () => {
    const rule = derivePolicyRule({ ...base, mergeDecision: 'BLOCKED' });
    expect(rule.action).toBe('decline');
    expect(rule.pagedHuman).toBe(false);
    expect(rule.label).toMatch(/Decline/);
    expect(rule.id).toBe('guardrail:decline');
  });

  it('maps null / PENDING mergeDecision → open-pr-wait (defaults branch)', () => {
    expect(derivePolicyRule({ ...base, mergeDecision: '' }).action).toBe('open-pr-wait');
    expect(derivePolicyRule({ ...base, mergeDecision: 'PENDING' }).action).toBe('open-pr-wait');
    expect(derivePolicyRule({ ...base, mergeDecision: 'NEW_BRANCH' }).action).toBe('open-pr-wait');
    expect(derivePolicyRule({ ...base, mergeDecision: 'OPEN' }).pagedHuman).toBe(false);
  });
});

describe('synthesizeTestLog', () => {
  it('emits a passing-runs log fragment for PASSED', () => {
    const log = synthesizeTestLog('PASSED', 'CVE-2024-1001', 'left-pad');
    expect(log.length).toBeGreaterThan(0);
    expect(log).toMatch(/PASS/);
    expect(log).toMatch(/success/);
    expect(log).not.toMatch(/FAIL/);
  });

  it('emits a failing-runs log fragment for FAILED / ERRORED', () => {
    const failLog = synthesizeTestLog('FAILED', 'CVE-2024-1002', 'tiny-validator');
    expect(failLog).toMatch(/FAIL/);
    expect(failLog).toMatch(/failure/);

    const erroredLog = synthesizeTestLog('ERRORED', 'CVE-2024-1002', 'tiny-validator');
    expect(erroredLog).toMatch(/FAIL/);
  });

  it('emits a queued log fragment for PENDING (no runner output yet)', () => {
    const log = synthesizeTestLog('PENDING', 'CVE-2024-1001', 'left-pad');
    expect(log).toMatch(/queued/i);
  });

  it('emits an in-progress log fragment for unknown values', () => {
    const log = synthesizeTestLog('UNKNOWN', 'CVE-2024-1001', 'left-pad');
    expect(log).toMatch(/running/i);
  });

  it('keeps the log excerpt cosmetic-only — no secrets or stack traces', () => {
    const log = synthesizeTestLog('FAILED', 'CVE-2024-1002', 'tiny-validator');
    expect(log).not.toMatch(/at .*:\d+/); // no Node-style stack frames
    expect(log).not.toMatch(/api[_-]?key|token|secret/i); // no secrets
  });
});

describe('deriveSeverity', () => {
  it('returns the pre-scored severity for known CVEs', () => {
    for (const cve of Object.keys(SEVERITY_BY_CVE) as Array<keyof typeof SEVERITY_BY_CVE>) {
      expect(deriveSeverity(cve)).toBe(SEVERITY_BY_CVE[cve]);
    }
  });

  it('falls back to medium for unknown CVEs', () => {
    expect(deriveSeverity('CVE-9999-0000')).toBe('medium');
  });
});

// Round-trip through the zod contracts to catch contract drift: if PatchDetail
// grows a required field, these tests should fail before any UI sees the gap.
describe('PatchDetail / PatchList contracts', () => {
  it('accepts the canonical payload shape shipped by the route handler', () => {
    const payload = {
      id: 'abc123',
      title: 'Pin left-pad to 1.3.0 for CVE-2024-1001',
      cveId: 'CVE-2024-1001',
      packageName: 'left-pad',
      fromVersion: '1.2.9',
      toVersion: '1.3.0',
      severity: 'high' as const,
      mergeState: 'auto-merged' as const,
      targetRepo: 'sample-firmware',
      prUrl: 'https://github.com/bivouac/sample-firmware/pull/1001',
      testOutcome: 'pass' as const,
      testLog: '> npm test\nPASS  lef-pad.test.ts',
      policyRule: {
        id: 'auto-merge:cve-known-good',
        label: 'Auto-merge · acknowledge CVE-2024-1001 (high-severity)',
        action: 'auto-merge' as const,
        pagedHuman: false,
      },
      files: [
        {
          path: 'package.json',
          diff: '--- a/package.json\n+++ b/package.json\n-    "left-pad": "1.2.9",\n+    "left-pad": "1.3.0",',
          status: 'modified' as const,
        },
      ],
      testsRun: 12,
      testsPassed: 12,
      testsFailed: 0,
      rationale: 'Detected a high-severity advisory …',
      createdAt: '2026-08-10T00:00:00.000Z',
    };
    expect(() => PatchDetail.parse(payload)).not.toThrow();
  });

  it('accepts an empty-queued patch payload (PENDING → queued)', () => {
    const payload = {
      id: 'queued-1',
      title: 'Pin left-pad to 1.3.0 for CVE-2024-1001',
      cveId: 'CVE-2024-1001',
      packageName: 'left-pad',
      fromVersion: '1.2.9',
      toVersion: '1.3.0',
      severity: 'high' as const,
      mergeState: 'open' as const,
      targetRepo: 'sample-firmware',
      prUrl: 'https://github.com/bivouac/sample-firmware/pull/pending',
      testOutcome: 'queued' as const,
      testLog: '> npm test\n> vitest queued',
      policyRule: {
        id: 'open-pr:awaiting-tests',
        label: 'Open PR and wait · awaiting tests',
        action: 'open-pr-wait' as const,
        pagedHuman: false,
      },
      files: [
        {
          path: 'package.json',
          diff: '--- a/package.json\n+++ b/package.json',
          status: 'modified' as const,
        },
      ],
      testsRun: 0,
      testsPassed: 0,
      testsFailed: 0,
      rationale: 'Detected …',
      createdAt: '2026-08-10T00:00:00.000Z',
    };
    expect(() => PatchDetail.parse(payload)).not.toThrow();
  });

  it('rejects a payload missing the new required testLog / policyRule fields', () => {
    const incomplete = {
      id: 'no-log',
      title: 'Title',
      cveId: 'CVE-2024-1001',
      packageName: 'left-pad',
      fromVersion: '1.2.9',
      toVersion: '1.3.0',
      severity: 'high' as const,
      mergeState: 'open' as const,
      targetRepo: 'sample-firmware',
      prUrl: 'https://github.com/bivouac/sample-firmware/pull/1001',
      testOutcome: 'pass' as const,
      files: [{ path: 'package.json', diff: 'diff', status: 'modified' as const }],
      testsRun: 0,
      testsPassed: 0,
      testsFailed: 0,
      rationale: 'r',
      createdAt: '2026-08-10T00:00:00.000Z',
    };
    expect(() => PatchDetail.parse(incomplete)).toThrow();
  });

  it('accepts the list contract', () => {
    expect(() => PatchList.parse({ items: [] })).not.toThrow();
  });
});
