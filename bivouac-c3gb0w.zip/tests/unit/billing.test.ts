// @vitest-environment node
// node not jsdom — resolvePlanQuote imports `server-only`, jsdom cannot resolve
// the runtime-relative marker. node matches Next's runtime.
import { describe, expect, it, vi } from 'vitest';

vi.mock('server-only', () => ({}));

import { resolvePlanQuote } from '../../src/lib/business/billing';
import {
  BillingCheckoutRequest,
  BillingState,
  BillingSyncRequest,
  InvoiceRecord,
  PortalSyncResponse,
} from '../../src/lib/contracts/billing';

describe('resolvePlanQuote()', () => {
  it('starter base: $19/mo × 1 repo totals to 19 with the 5-repo cap and no addons', () => {
    const quote = resolvePlanQuote('starter', [], 1);
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.totalUsd).toBe(19);
    expect(quote.repoLimit).toBe(5);
    expect(quote.paidRepoCount).toBe(1);
    expect(quote.addons).toEqual([]);
    expect(quote.base.name).toBe('Starter');
  });

  it('starter × 3 repos totals $57 (per-repo × monthly)', () => {
    const quote = resolvePlanQuote('starter', [], 3);
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.totalUsd).toBe(57);
    expect(quote.paidRepoCount).toBe(3);
  });

  it('starter with zero repos returns null (no chargeable repos)', () => {
    expect(resolvePlanQuote('starter', [], 0)).toBeNull();
  });

  it('starter + one 24h-critical SLA addon adds $199 per repo to the total', () => {
    const quote = resolvePlanQuote('starter', ['+24h-critical-sla'], 1);
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.totalUsd).toBe(19 + 199);
    expect(quote.repoLimit).toBe(5);
    expect(quote.addons).toHaveLength(1);
    expect(quote.addons[0]?.slug).toBe('+24h-critical-sla');
    expect(quote.addons[0]?.monthlyUsd).toBe(199);
  });

  it('enterprise + both SLA addons times 1 repo: 99 + 199 + 149, repoLimit null', () => {
    const quote = resolvePlanQuote(
      'enterprise',
      ['+24h-critical-sla', '+business-hours-paging'],
      1,
    );
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.totalUsd).toBe(99 + 199 + 149);
    expect(quote.repoLimit).toBeNull();
    expect(quote.addons).toHaveLength(2);
    expect(quote.addons[0]?.slug).toBe('+24h-critical-sla');
    expect(quote.addons[1]?.slug).toBe('+business-hours-paging');
  });

  it('dedupes duplicate addon slugs while preserving first-seen order', () => {
    const quote = resolvePlanQuote('team', ['+24h-critical-sla', '+24h-critical-sla'], 1);
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.addons).toHaveLength(1);
    expect(quote.addons[0]?.slug).toBe('+24h-critical-sla');
    // 39 (team × 1 repo) + 199 (deduped single 24h SLA) — NOT 39 + 199 + 199.
    expect(quote.totalUsd).toBe(39 + 199);
  });

  it('free tier resolves with zero totalUsd and bypasses the repoCount guard', () => {
    const quote = resolvePlanQuote('free', [], 0);
    expect(quote).not.toBeNull();
    if (!quote) return;
    expect(quote.totalUsd).toBe(0);
    expect(quote.paidRepoCount).toBe(0);
  });
});

describe('billing contracts round-trip', () => {
  it('BillingState parses a known-good with-plan payload', () => {
    const parsed = BillingState.parse({
      plan: {
        id: 'bp_1',
        slug: 'team',
        monthlyPerRepoUsd: 39,
        paidRepoCount: 7,
        repoLimit: 25,
        status: 'ACTIVE',
        currentPeriodEnd: '2026-09-12T00:00:00.000Z',
        cancelAtPeriodEnd: false,
      },
      repoCount: 7,
      addons: [
        {
          id: 'ba_1',
          slug: '+24h-critical-sla',
          label: '+24h critical SLA',
          monthlyUsd: 199,
        },
      ],
    });
    expect(parsed.plan?.slug).toBe('team');
    expect(parsed.repoCount).toBe(7);
    expect(parsed.addons).toHaveLength(1);
  });

  it('BillingState parses the no-plan payload (plan: null)', () => {
    const parsed = BillingState.parse({ plan: null, repoCount: 0, addons: [] });
    expect(parsed.plan).toBeNull();
    expect(parsed.repoCount).toBe(0);
  });

  it('BillingCheckoutRequest round-trips a plan switch payload (with and without addons)', () => {
    const a = BillingCheckoutRequest.parse({ planId: 'team' });
    expect(a.planId).toBe('team');
    expect(a.addons).toBeUndefined();

    const b = BillingCheckoutRequest.parse({
      planId: 'enterprise',
      addons: ['+24h-critical-sla'],
    });
    expect(b.planId).toBe('enterprise');
    expect(b.addons).toEqual(['+24h-critical-sla']);
  });

  it('BillingSyncRequest round-trips the post-checkout reconciliation payload', () => {
    const parsed = BillingSyncRequest.parse({
      sessionId: 'cs_test_123',
      planId: 'team',
      addons: ['+24h-critical-sla', '+business-hours-paging'],
    });
    expect(parsed.sessionId).toBe('cs_test_123');
    expect(parsed.planId).toBe('team');
    expect(parsed.addons).toHaveLength(2);
  });

  it('InvoiceRecord round-trips a Stripe payment event row with optionals touched', () => {
    const parsed = InvoiceRecord.parse({
      id: 1,
      stripeCheckoutSessionId: 'cs_test_1',
      amountUsd: 218,
      description: 'Team plan + +24h critical SLA',
      occurredAt: '2026-08-12T03:00:00.000Z',
    });
    expect(parsed.amountUsd).toBe(218);
    expect(parsed.stripeCheckoutSessionId).toBe('cs_test_1');

    // Nullable fields are tolerated — the upstream feed occasionally drops them.
    const sparse = InvoiceRecord.parse({
      id: 2,
      stripeCheckoutSessionId: null,
      amountUsd: null,
      description: null,
      occurredAt: '2026-08-12T03:00:00.000Z',
    });
    expect(sparse.amountUsd).toBeNull();
    expect(sparse.description).toBeNull();
  });

  it('PortalSyncResponse round-trips a fresh Stripe mirror', () => {
    const fresh = PortalSyncResponse.parse({
      cancelAtPeriodEnd: true,
      currentPeriodEnd: '2026-09-12T00:00:00.000Z',
    });
    expect(fresh.cancelAtPeriodEnd).toBe(true);

    const renewing = PortalSyncResponse.parse({
      cancelAtPeriodEnd: false,
      currentPeriodEnd: null,
    });
    expect(renewing.cancelAtPeriodEnd).toBe(false);
    expect(renewing.currentPeriodEnd).toBeNull();
  });
});
