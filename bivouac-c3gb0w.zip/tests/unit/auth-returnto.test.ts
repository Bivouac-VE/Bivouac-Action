// @vitest-environment node
import { describe, expect, it } from 'vitest';

import { AUTH_RETURN_TO_DEFAULT, readReturnTo } from '../../src/lib/business/auth-returnto';

describe('readReturnTo (open-redirect guard + /dashboard/repos default)', () => {
  const DEFAULT = '/dashboard/repos';

  it('passes through a same-origin /dashboard path', () => {
    expect(readReturnTo('/dashboard/attest')).toBe('/dashboard/attest');
    expect(readReturnTo('/dashboard/audit')).toBe('/dashboard/audit');
    expect(readReturnTo('/dashboard/team')).toBe('/dashboard/team');
  });

  it('passes through a same-origin nested path', () => {
    expect(readReturnTo('/patches/abc-123')).toBe('/patches/abc-123');
    expect(readReturnTo('/dashboard/policy/packs?active=1')).toBe(
      '/dashboard/policy/packs?active=1',
    );
  });

  it('rejects a protocol-relative URL (//evil.com) and falls back', () => {
    expect(readReturnTo('//evil.com/path')).toBe(DEFAULT);
    expect(readReturnTo('//evil.com')).toBe(DEFAULT);
  });

  it('rejects an external URL and falls back', () => {
    expect(readReturnTo('https://evil.com')).toBe(DEFAULT);
    expect(readReturnTo('http://evil.com/dashboard')).toBe(DEFAULT);
    expect(readReturnTo('javascript:alert(1)')).toBe(DEFAULT);
  });

  it('falls back when value is missing or empty', () => {
    expect(readReturnTo(null)).toBe(DEFAULT);
    expect(readReturnTo(undefined)).toBe(DEFAULT);
    expect(readReturnTo('')).toBe(DEFAULT);
  });

  it('ignores non-string values', () => {
    expect(readReturnTo(42)).toBe(DEFAULT);
    expect(readReturnTo({})).toBe(DEFAULT);
    expect(readReturnTo(true)).toBe(DEFAULT);
  });

  it('default is /dashboard/repos (the empty-state CTA landing)', () => {
    expect(DEFAULT).toBe('/dashboard/repos');
    expect(AUTH_RETURN_TO_DEFAULT).toBe('/dashboard/repos');
  });
});
