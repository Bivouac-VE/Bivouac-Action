// @vitest-environment node
// node not jsdom — the helpers being tested import node:crypto (createHash) and
// `server-only` (a runtime-relative marker jsdom cannot resolve). node also
// matches the runtime the helpers run in under Next.
import { describe, expect, it, vi } from 'vitest';

vi.mock('server-only', () => ({}));

import {
  attestationHash,
  buildAttestationSummary,
  canonicalizeForHash,
  computeMttp,
  computeSeverityCounts,
  type HashableAttestationContent,
  quarterBounds,
} from '../../src/lib/business/attestation';
import { AttestationBundle, type MttpMetric } from '../../src/lib/contracts/attestation';

describe('quarterBounds()', () => {
  it('returns Jan 1 UTC start and Apr 1 UTC end for Q1', () => {
    const { startUtc, endUtc } = quarterBounds('2026-Q1');
    expect(startUtc.toISOString()).toBe('2026-01-01T00:00:00.000Z');
    expect(endUtc.toISOString()).toBe('2026-04-01T00:00:00.000Z');
  });

  it('returns Apr 1 UTC start and Jul 1 UTC end for Q2', () => {
    const { startUtc, endUtc } = quarterBounds('2025-Q2');
    expect(startUtc.toISOString()).toBe('2025-04-01T00:00:00.000Z');
    expect(endUtc.toISOString()).toBe('2025-07-01T00:00:00.000Z');
  });

  it('returns Jul 1 UTC start and Oct 1 UTC end for Q3', () => {
    const { startUtc, endUtc } = quarterBounds('2025-Q3');
    expect(startUtc.toISOString()).toBe('2025-07-01T00:00:00.000Z');
    expect(endUtc.toISOString()).toBe('2025-10-01T00:00:00.000Z');
  });

  it('returns Oct 1 UTC start and Jan 1 UTC end for Q4', () => {
    const { startUtc, endUtc } = quarterBounds('2024-Q4');
    expect(startUtc.toISOString()).toBe('2024-10-01T00:00:00.000Z');
    expect(endUtc.toISOString()).toBe('2025-01-01T00:00:00.000Z');
  });

  it('throws on malformed quarter ids', () => {
    expect(() => quarterBounds('2026-Q5' as never)).toThrow();
    expect(() => quarterBounds('2026-Q0' as never)).toThrow();
    expect(() => quarterBounds('26Q1' as never)).toThrow();
  });
});

describe('computeSeverityCounts()', () => {
  function row(cveId: string) {
    return {
      id: `id-${Math.random()}`,
      createdAt: new Date(),
      cveId,
      packageName: 'p',
      fromVersion: '1',
      toVersion: '2',
      prUrl: 'https://github.com/o/r/pull/1',
      testOutcome: 'PASSED',
      mergeDecision: 'AUTO_MERGE',
    };
  }

  it('buckets by the cveId severity mapping', () => {
    const counts = computeSeverityCounts([
      row('CVE-2024-1001'),
      row('CVE-2024-1001'),
      row('CVE-2024-1002'),
      row('CVE-UNKNOWN'),
      row('CVE-UNKNOWN'),
      row('CVE-UNKNOWN'),
    ]);

    expect(counts).toEqual({ low: 0, medium: 4, high: 2, critical: 0 });
  });
});

describe('computeMttp()', () => {
  const ASOF = new Date('2026-03-31T23:59:59.999Z');

  function makeEvent(mergeDecision: string, createdAt: Date) {
    return {
      id: `id-${Math.random()}`,
      createdAt,
      cveId: 'CVE-2024-1001',
      packageName: 'p',
      fromVersion: '1',
      toVersion: '2',
      prUrl: 'https://github.com/o/r/pull/1',
      testOutcome: 'PASSED',
      mergeDecision,
    };
  }

  it('returns null valueDays when no terminal decisions', () => {
    const result = computeMttp([makeEvent('OPEN', new Date('2026-03-01T00:00:00Z'))], ASOF);
    expect(result.valueDays).toBeNull();
    expect(result.sampleSize).toBe(0);
    expect(result.asOf).toBe(ASOF.toISOString());
    expect(result.derivation).toMatch(/terminal-decision/);
  });

  it('averages age to a known stable value when asOf is fixed', () => {
    // asOf = 2026-03-31T23:59:59.999Z.
    // event A created 2026-01-01 (90 days 0.5h age = ~90.02 days)
    // event B created 2026-02-01 (59 days 1h age   = ~59.04 days)
    // Mean ≈ (90.02 + 59.04) / 2 = 74.53  (rounded).
    const result = computeMttp(
      [
        makeEvent('AUTO_MERGE', new Date('2026-01-01T00:00:00Z')),
        makeEvent('MANUAL_REVIEW', new Date('2026-02-01T00:00:00Z')),
      ],
      ASOF,
    );
    expect(result.sampleSize).toBe(2);
    expect(result.valueDays).not.toBeNull();
    if (result.valueDays !== null) {
      expect(Math.abs(result.valueDays - 74.53)).toBeLessThan(0.1);
    }
  });

  it('ignores open-pending decisions', () => {
    const result = computeMttp(
      [
        makeEvent('AUTO_MERGE', new Date('2026-03-01T00:00:00Z')),
        makeEvent('OPEN', new Date('2025-01-01T00:00:00Z')),
      ],
      ASOF,
    );
    expect(result.sampleSize).toBe(1);
  });
});

function fixtureMttp(): MttpMetric {
  return {
    valueDays: 2,
    sampleSize: 5,
    asOf: '2026-03-31T23:59:59.999Z',
    derivation: 'd',
  };
}

function fixtureHashable(): HashableAttestationContent {
  return {
    meta: {
      repoId: 'r1',
      ownerHandle: 'o',
      name: 'n',
      quarter: '2026-Q1',
      policyVersion: {
        id: 'x',
        version: 'POL-2026-Q1',
        title: 't',
        effectiveFrom: '2026-01-01T00:00:00.000Z',
        effectiveTo: null,
      },
    },
    counts: { patches: { low: 0, medium: 1, high: 2, critical: 3 }, overrides: 4 },
    cveIdsRemediated: ['c1', 'c2'],
    mttp: fixtureMttp(),
    overrides: [],
    patchEvents: [],
    sbom: { packagesTouched: 2, totalPackages: 2, ecosystems: { npm: 2 } },
  };
}

describe('canonicalizeForHash() + attestationHash()', () => {
  it('produces identical output for equal data in different key order', () => {
    const a = canonicalizeForHash(fixtureHashable());
    const reordered: HashableAttestationContent = {
      patchEvents: [],
      overrides: [],
      mttp: {
        derivation: 'd',
        sampleSize: 5,
        valueDays: 2,
        asOf: '2026-03-31T23:59:59.999Z',
      },
      cveIdsRemediated: ['c1', 'c2'],
      counts: { overrides: 4, patches: { critical: 3, high: 2, medium: 1, low: 0 } },
      meta: {
        policyVersion: {
          effectiveTo: null,
          effectiveFrom: '2026-01-01T00:00:00.000Z',
          title: 't',
          version: 'POL-2026-Q1',
          id: 'x',
        },
        quarter: '2026-Q1',
        name: 'n',
        ownerHandle: 'o',
        repoId: 'r1',
      },
      sbom: { packagesTouched: 2, totalPackages: 2, ecosystems: { npm: 2 } },
    };
    const b = canonicalizeForHash(reordered);
    expect(a).toBe(b);
  });

  it('emits a 64-char hex sha256 hash', () => {
    const canonical = canonicalizeForHash(fixtureHashable());
    const hash = attestationHash(canonical);
    expect(hash).toMatch(/^[0-9a-f]{64}$/);
  });

  it('hashes a known canonical string to a known sha256', () => {
    // sha256('{"a":1}') = 015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862
    expect(attestationHash('{"a":1}')).toBe(
      '015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862',
    );
  });

  it('is stable across reruns for the same data (no Date.now() influence)', () => {
    const canonical = canonicalizeForHash(fixtureHashable());
    const h1 = attestationHash(canonical);
    // Sleep a few ms to guarantee wall-clock has moved IF Date.now() had snuck in.
    const waitStart = Date.now();
    while (Date.now() - waitStart < 5) {
      /* spin */
    }
    const h2 = attestationHash(canonical);
    expect(h1).toBe(h2);
  });
});

describe('buildAttestationSummary()', () => {
  it('omits patchEvents while keeping all rollups', () => {
    const bundle: import('../../src/lib/contracts/attestation').AttestationBundle = {
      meta: {
        repoId: 'r1',
        ownerHandle: 'o',
        name: 'n',
        quarter: '2026-Q1',
        generatedAt: '2026-01-01T00:00:00.000Z',
        policyVersion: {
          id: 'x',
          version: 'POL-2026-Q1',
          title: 't',
          effectiveFrom: '2026-01-01T00:00:00.000Z',
          effectiveTo: null,
        },
      },
      counts: { patches: { low: 0, medium: 1, high: 0, critical: 0 }, overrides: 0 },
      cveIdsRemediated: ['CVE-2024-1002'],
      mttp: { valueDays: 5, sampleSize: 1, derivation: 'd', asOf: '2026-03-31T23:59:59.999Z' },
      overrides: [],
      patchEvents: [
        {
          id: 'p1',
          createdAt: '2026-01-15T00:00:00.000Z',
          cveId: 'CVE-2024-1002',
          packageName: 'tiny-validator',
          fromVersion: '2.5.0',
          toVersion: '2.5.1',
          severity: 'medium',
          testOutcome: 'PASSED',
          mergeDecision: 'AUTO_MERGE',
          repo: 'o/n',
          prUrl: 'https://github.com/o/n/pull/1',
          isHumanOverride: false,
          upstreamSha: '1',
        },
      ],
      sbom: { packagesTouched: 1, totalPackages: 1, ecosystems: { npm: 1 } },
      attestation: { hash: 'h' },
    };
    const parsed = AttestationBundle.parse(bundle);
    const summary = buildAttestationSummary(parsed);
    expect(summary.meta).toEqual(bundle.meta);
    expect(summary.counts).toEqual(bundle.counts);
    expect(summary.cveIdsRemediated).toEqual(bundle.cveIdsRemediated);
    expect(summary.mttp).toEqual(bundle.mttp);
    expect(summary.overrides).toEqual(bundle.overrides);
    expect(summary.sbom).toEqual(bundle.sbom);
    expect((summary as unknown as { patchEvents?: unknown[] }).patchEvents).toBeUndefined();
    expect((summary as unknown as { attestation?: unknown }).attestation).toBeUndefined();
  });
});
