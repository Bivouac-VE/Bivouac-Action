// @vitest-environment node
// node not jsdom — we exercise the file-system path used by the route handler.
import { readFileSync } from 'node:fs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { DemoState } from '@/lib/contracts/demo';

vi.mock('server-only', () => ({}));

const fixPath = 'tests/unit/_fixtures/sample-ledger.json';

describe('DemoState shared contract', () => {
  const fixture = JSON.parse(readFileSync(fixPath, 'utf8'));

  it('accepts the fixture ledger and parses it to the documented shape', () => {
    const parsed = DemoState.parse(fixture);
    expect(parsed.before.openDependabotPRs).toBe(1);
    expect(parsed.after.autoMerged).toBe(1);
    expect(parsed.beforeEntries).toHaveLength(1);
    expect(parsed.afterEntries).toHaveLength(1);
    expect(parsed.beforeEntries[0]?.cveId).toBe('CVE-2024-21538');
  });

  it('rejects a malformed CVE id (anything that does not look like CVE-YYYY-NNNN)', () => {
    const bad = {
      ...fixture,
      beforeEntries: [{ ...fixture.beforeEntries[0], cveId: 'CVE-notanumber' }],
    };
    expect(DemoState.safeParse(bad).success).toBe(false);
  });

  it('rejects an unknown decision enum', () => {
    const bad = {
      ...fixture,
      afterEntries: [{ ...fixture.afterEntries[0], decision: 'YOLO' }],
    };
    expect(DemoState.safeParse(bad).success).toBe(false);
  });
});

describe('demo GET handler', () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it('parses the real demo-bivouac/ledger.json (canonical source of truth)', async () => {
    const realLedgerPath = 'demo-bivouac/ledger.json';
    const json = JSON.parse(readFileSync(realLedgerPath, 'utf8'));
    const parsed = DemoState.parse(json);
    expect(parsed.before.openDependabotPRs).toBeGreaterThan(0);
    expect(parsed.after.autoMerged).toBeGreaterThanOrEqual(0);
    expect(parsed.beforeEntries.length).toBe(parsed.afterEntries.length);
  });

  it('GET /api/demo returns 200 with the parsed payload', async () => {
    const { GET } = await import('@/app/api/demo/route');
    const res = await GET();
    expect(res.status).toBe(200);
    const body = await res.json();
    const parsed = DemoState.parse(body);
    expect(parsed.beforeEntries.length).toBeGreaterThan(0);
    expect(parsed.afterEntries.length).toBeGreaterThan(0);
  });
});
