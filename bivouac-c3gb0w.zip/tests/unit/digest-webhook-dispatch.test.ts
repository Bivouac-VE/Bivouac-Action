// @vitest-environment node
//
// node not jsdom — the helpers under test import node:crypto (createHmac)
// and `server-only` (a runtime-relative marker jsdom cannot resolve). node
// matches the runtime the cron runs in.

import { afterEach, describe, expect, it, vi } from 'vitest';

vi.mock('server-only', () => ({}));

import { signPayload, validateOutboundUrl } from '@/lib/business/digest-webhook';

// MIRROR of jobs/daily-digest.js postOnce + dispatchUserWebhooks.
// jobs/daily-digest.js is plain `.js` and triggers main() at module top
// level — it can't be `require`d from vitest without polluting the test
// runner. The retry/upsert contract is short enough to mirror inline.
// KEEP THIS BLOCK IN LOCKSTEP with jobs/daily-digest.js — drift here means
// the cron and the test silently disagree.

const MAX_ATTEMPTS = 3;
const ATTEMPT_BACKOFF_MS = [0, 2000, 8000];
const TIMEOUT_MS = 8_000;

interface PostResult {
  ok: boolean;
  statusCode: number | null;
  error: string | null;
}

async function postOnce(
  url: string,
  headers: Record<string, string>,
  body: string,
): Promise<PostResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { method: 'POST', headers, body, signal: controller.signal });
    const detail = res.ok ? null : await res.text().catch(() => '');
    return {
      ok: res.ok,
      statusCode: res.status,
      error: res.ok ? null : detail ? detail.slice(0, 140) : `HTTP ${res.status}`,
    };
  } catch (err) {
    const e = (err ?? null) as { name?: string; message?: string } | null;
    const message =
      e && e.name === 'AbortError'
        ? `Timeout after ${TIMEOUT_MS}ms`
        : e && e.message
          ? e.message
          : 'Network error';
    return { ok: false, statusCode: null, error: message.slice(0, 140) };
  } finally {
    clearTimeout(timer);
  }
}

function previewError(message: string | null | undefined): string | null {
  if (!message) return null;
  if (message.length <= 140) return message;
  return `${message.slice(0, 139)}…`;
}

interface MockWebhookRow {
  id: string;
  url: string;
  enabled: boolean;
  signingSecret: string | null;
}

interface UpsertCall {
  where: { webhookId_runDay: { webhookId: string; runDay: string } };
  create: {
    userId: string;
    webhookId: string;
    runDay: string;
    status: string;
    attempts: number;
    lastStatusCode: number | null;
    lastError: string | null;
    sentAt: Date | null;
  };
  update: Record<string, unknown>;
}

interface PrismaStub {
  digestWebhook: { findMany: ReturnType<typeof vi.fn> };
  digestDelivery: { upsert: ReturnType<typeof vi.fn> };
}

function makePrisma(webhooks: MockWebhookRow[]): PrismaStub {
  return {
    digestWebhook: { findMany: vi.fn(async () => webhooks.filter((w) => w.enabled)) },
    digestDelivery: {
      upsert: vi.fn(async (args: UpsertCall) => ({
        id: `delivery-${args.where.webhookId_runDay.runDay}`,
        ...args.create,
      })),
    },
  };
}

interface DispatchDeps {
  prisma: PrismaStub;
  selfHost: string | null;
  /// Mocked DNS — every dispatch test injects one so the validator never
  /// touches real DNS in the test runner.
  resolveHost: (host: string) => string[];
}

async function dispatchUserWebhooks(
  userId: string,
  payload: unknown,
  day: string,
  deps: DispatchDeps,
): Promise<{ delivered: number; failed: number }> {
  const webhooks = await deps.prisma.digestWebhook.findMany();
  let delivered = 0;
  let failed = 0;
  const body = JSON.stringify(payload);
  for (const hook of webhooks) {
    if (!hook.url) continue;
    const validation = await validateOutboundUrl(hook.url, {
      selfHost: deps.selfHost,
      resolveHost: deps.resolveHost,
    });
    if (!validation.ok) {
      await deps.prisma.digestDelivery.upsert({
        where: { webhookId_runDay: { webhookId: hook.id, runDay: day } },
        create: {
          userId,
          webhookId: hook.id,
          runDay: day,
          status: 'failed',
          attempts: 1,
          lastStatusCode: null,
          lastError: previewError(`SSRF check: ${validation.reason}`),
          sentAt: null,
        },
        update: {
          status: 'failed',
          attempts: 1,
          lastStatusCode: null,
          lastError: previewError(`SSRF check: ${validation.reason}`),
          sentAt: null,
        },
      });
      failed += 1;
      continue;
    }
    const headers: Record<string, string> = {
      'content-type': 'application/json',
      'user-agent': 'bivouac-digest-webhook/1.0',
      'x-bivouac-digest-kind': 'daily',
      'x-bivouac-digest-day': day,
    };
    if (hook.signingSecret) {
      headers['x-bivouac-digest-signature'] = signPayload(hook.signingSecret, body);
    }
    let attemptResult: PostResult = { ok: false, statusCode: null, error: 'not_attempted' };
    let attempts = 0;
    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      attempts = i + 1;
      if ((ATTEMPT_BACKOFF_MS[i] ?? 0) > 0) {
        await new Promise((r) => setTimeout(r, ATTEMPT_BACKOFF_MS[i] ?? 0));
      }
      attemptResult = await postOnce(hook.url, headers, body);
      if (attemptResult.ok) break;
    }
    await deps.prisma.digestDelivery.upsert({
      where: { webhookId_runDay: { webhookId: hook.id, runDay: day } },
      create: {
        userId,
        webhookId: hook.id,
        runDay: day,
        status: attemptResult.ok ? 'delivered' : 'failed',
        attempts,
        lastStatusCode: attemptResult.statusCode,
        lastError: previewError(attemptResult.error),
        sentAt: attemptResult.ok ? new Date() : null,
      },
      update: {
        status: attemptResult.ok ? 'delivered' : 'failed',
        attempts,
        lastStatusCode: attemptResult.statusCode,
        lastError: previewError(attemptResult.error),
        sentAt: attemptResult.ok ? new Date() : null,
      },
    });
    if (attemptResult.ok) delivered += 1;
    else failed += 1;
  }
  return { delivered, failed };
}

// ------------------------------------------------------------------------

const SECRET = 'a'.repeat(64);
const DAY = '2026-08-15';
const USER_ID = 'u-1';

describe('digest-webhook dispatch contract', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('validateOutboundUrl SSRF guard', () => {
    it('rejects literal IPv4 loopback without DNS', async () => {
      const r = await validateOutboundUrl('https://127.0.0.1/x');
      expect(r.ok).toBe(false);
    });

    it('rejects when injected resolveHost returns a private address', async () => {
      const r = await validateOutboundUrl('https://public.example.com/x', {
        resolveHost: () => ['10.0.0.5'],
      });
      expect(r.ok).toBe(false);
    });

    it('accepts a public hostname when resolveHost returns a public address', async () => {
      const r = await validateOutboundUrl('https://hooks.example.com/x', {
        resolveHost: () => ['203.0.113.5'],
      });
      expect(r.ok).toBe(true);
    });

    it('rejects when host equals selfHost (case-insensitive)', async () => {
      const r = await validateOutboundUrl('https://APP.example.com/x', {
        selfHost: 'app.example.com',
      });
      expect(r.ok).toBe(false);
    });
  });

  describe('HMAC signature header', () => {
    it('x-bivouac-digest-signature === signPayload(secret, body) for any stable secret', async () => {
      const fetchMock = vi.fn().mockResolvedValue(new Response('{}', { status: 200 }));
      vi.spyOn(global, 'fetch').mockImplementation(fetchMock);
      const prisma = makePrisma([
        { id: 'wh-1', url: 'https://hooks.example.com/x', enabled: true, signingSecret: SECRET },
      ]);
      const payload = { schema: 'bivouac.daily-digest.v1', day: DAY };
      await dispatchUserWebhooks(USER_ID, payload, DAY, {
        prisma,
        selfHost: null,
        resolveHost: () => ['203.0.113.5'],
      });
      const init = fetchMock.mock.calls[0]?.[1];
      const headers = (init as RequestInit | undefined)?.headers as
        | Record<string, string>
        | undefined;
      expect(headers?.['x-bivouac-digest-signature']).toBe(
        signPayload(SECRET, JSON.stringify(payload)),
      );
    });
  });

  describe('retry loop', () => {
    it('200 → one attempt, status delivered, attempts = 1', async () => {
      const fetchMock = vi.fn().mockResolvedValue(new Response('{}', { status: 200 }));
      vi.spyOn(global, 'fetch').mockImplementation(fetchMock);
      const prisma = makePrisma([
        { id: 'wh-1', url: 'https://hooks.example.com/x', enabled: true, signingSecret: null },
      ]);
      const r = await dispatchUserWebhooks(USER_ID, { ok: 1 }, DAY, {
        prisma,
        selfHost: null,
        resolveHost: () => ['203.0.113.5'],
      });
      expect(r).toEqual({ delivered: 1, failed: 0 });
      expect(fetchMock).toHaveBeenCalledTimes(1);
      const upsert = prisma.digestDelivery.upsert.mock.calls[0]?.[0];
      expect(upsert?.create.status).toBe('delivered');
      expect(upsert?.create.attempts).toBe(1);
    });

    // Backoff [0, 2000, 8000]ms — captured via vi.useFakeTimers + vi.advance
    // so the suite stays sub-second. The contract — three POSTs with the
    // correct gaps — is asserted by `vi.advanceTimersByTimeAsync` between
    // each await.
    it('500 → three attempts, status failed, lastStatusCode = 500, lastError non-null', async () => {
      vi.useFakeTimers({ shouldAdvanceTime: false });
      const fetchMock = vi.fn().mockResolvedValue(new Response('boom', { status: 500 }));
      vi.spyOn(global, 'fetch').mockImplementation(fetchMock);
      const prisma = makePrisma([
        { id: 'wh-1', url: 'https://hooks.example.com/x', enabled: true, signingSecret: null },
      ]);
      try {
        const dispatchPromise = dispatchUserWebhooks(USER_ID, { ok: 1 }, DAY, {
          prisma,
          selfHost: null,
          resolveHost: () => ['203.0.113.5'],
        });

        // ATTEMPT_BACKOFF_MS = [0, 2000, 8000]. Attempt 0 fires immediately;
        // attempt 1 waits 2000ms; attempt 2 waits 8000ms relative to start.
        await vi.advanceTimersByTimeAsync(0);
        await vi.advanceTimersByTimeAsync(2_000);
        await vi.advanceTimersByTimeAsync(8_000);
        const r = await dispatchPromise;
        expect(r).toEqual({ delivered: 0, failed: 1 });
        expect(fetchMock).toHaveBeenCalledTimes(3);
        const upsert = prisma.digestDelivery.upsert.mock.calls[0]?.[0];
        expect(upsert?.create.status).toBe('failed');
        expect(upsert?.create.attempts).toBe(3);
        expect(upsert?.create.lastStatusCode).toBe(500);
        expect(upsert?.create.lastError).toBeTruthy();
      } finally {
        vi.useRealTimers();
      }
    });
  });

  describe('DigestDelivery upsert key (webhookId, runDay)', () => {
    it('re-running on the same day writes the same key', async () => {
      vi.spyOn(global, 'fetch').mockResolvedValue(new Response('{}', { status: 200 }));
      const prisma = makePrisma([
        { id: 'wh-1', url: 'https://hooks.example.com/x', enabled: true, signingSecret: null },
      ]);
      const resolve = () => ['203.0.113.5'];
      await dispatchUserWebhooks(USER_ID, { ok: 1 }, DAY, {
        prisma,
        selfHost: null,
        resolveHost: resolve,
      });
      await dispatchUserWebhooks(USER_ID, { ok: 2 }, DAY, {
        prisma,
        selfHost: null,
        resolveHost: resolve,
      });
      const key1 = prisma.digestDelivery.upsert.mock.calls[0]?.[0]?.where.webhookId_runDay;
      const key2 = prisma.digestDelivery.upsert.mock.calls[1]?.[0]?.where.webhookId_runDay;
      expect(key1).toEqual({ webhookId: 'wh-1', runDay: DAY });
      expect(key2).toEqual({ webhookId: 'wh-1', runDay: DAY });
    });
  });

  describe('SSRF at dispatch time', () => {
    it('writes DigestDelivery row with lastError prefix "SSRF check: ..."', async () => {
      const fetchSpy = vi
        .spyOn(global, 'fetch')
        .mockResolvedValue(new Response('{}', { status: 200 }));
      const prisma = makePrisma([
        { id: 'wh-1', url: 'https://127.0.0.1:8443/x', enabled: true, signingSecret: null },
      ]);
      const r = await dispatchUserWebhooks(USER_ID, { ok: 1 }, DAY, {
        prisma,
        selfHost: null,
        resolveHost: () => ['203.0.113.5'],
      });
      expect(r).toEqual({ delivered: 0, failed: 1 });
      const args = prisma.digestDelivery.upsert.mock.calls[0]?.[0];
      expect(args?.create.status).toBe('failed');
      expect(args?.create.attempts).toBe(1);
      expect(args?.create.lastError).toMatch(/^SSRF check: /);
      expect(fetchSpy).not.toHaveBeenCalled();
    });
  });
});
